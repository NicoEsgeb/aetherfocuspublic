"""Business logic for the Clean07 "Ingresar Demandas BBRR" bridge.

Clean07 is the PJUD twin of Clean05: the human opens their own Chrome, logs into
the Oficina Judicial Virtual by hand, and the bot works the page from a Chrome
extension that talks to this loopback bridge.

The run is:

  1. validate the selected planilla against the required column set,
  2. validate input/01_mandatos holds the 5 fixed shared documents,
  3. validate input/02_contratos holds every contrato the planilla references,
  4. validate input/03_demandas holds at least one row's signed demanda PDF,
  5. validate input/04_Carpeta-Ruts holds at least one RUT the planilla needs,
  6. open the bridge and confirm the extension connected (Start pressed),
  7. drive the portal one step at a time: ``PREP_STEPS`` once, then
     ``LOOP_STEPS`` once per row.

The portal route is being built one step at a time: ``PREP_STEPS`` covers the
one-time page setup (tribunal, materia, both fixed litigantes); ``LOOP_STEPS``
is the per-row loop, still partial, that repeats for every RUT. Most
validation is deliberately fail-fast — a planilla or folder that cannot be
processed at all must never reach the browser, so the operator finds out in
BotManager instead of halfway through a real ingreso. input/03_demandas is
the one exception: a missing PDF only disqualifies its own row (flagged via
``row["demanda_missing"]``), not the whole run — see ``inspect_demandas_folder``.
The per-row loop does not act on that flag yet (LOOP_STEPS never reaches the
point of using the demanda PDF); once it does, a flagged row should stop
being processed and be reported with ESTADO "Causa no ingresada".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import json
import threading
import time
import urllib.parse

ALLOWED_EXCEL_SUFFIXES = {".xlsx", ".xlsm"}
BOT_ID = "clean07_ingreso_demandas_bbrr"
BOT_LABEL = "Clean07"

# The page the operator is expected to run the bot from. Start is accepted from
# any PJUD page (the content script only runs on that origin), but a different
# page is recorded so the log shows where the handoff actually happened.
PORTAL_HOST = "oficinajudicialvirtual.pjud.cl"
PORTAL_START_PAGE = "indexN.php"

# Columns the planilla must expose, taken from the reference workbook
# input/planilla_ingreso/Planilla_Ingreso_Demandas.xlsx (the output of Clean06).
# Matching is case-insensitive and whitespace-tolerant, so "hoja de firma" and
# "  HOJA   DE  FIRMA " both satisfy "HOJA DE FIRMA". Underscores are NOT
# whitespace, so "HOJA_DE_FIRMA" and "HOJA DE FIRMA" stay two distinct columns —
# they are two different columns in the real planilla.
#
# `Contrato` is deliberately ABSENT: Clean06 dropped that column on 2026-08-17
# (Contrato.pdf never existed as a file; the mandato case now writes
# <RUT>\Contrato_Mandato.pdf into 6_Contrato_CPSB). An older reference workbook
# on disk may still carry it — do NOT re-add it from there. Requiring it would
# reject every current Clean06 planilla; leaving it out accepts both layouts,
# since an extra column in the input is simply ignored.
REQUIRED_COLUMNS: tuple[str, ...] = (
    "ESTADO",
    "RUT",
    "DV",
    "CARTERA",
    "ARCH_DEMANDA",
    "ARCH_PAGARES",
    "1_Mandato_11709-2026.pdf",
    "2_Mandato_37590-2016.pdf",
    "3_Resolucion_409.pdf",
    "4_Certificado_2215.pdf",
    "5_Mandato_9342-2016.pdf",
    "6_Contrato_CPSB",
    "7_HOJA_DE_FIRMA.pdf",
    "DEMANDA",
    "PAGARES",
    "MANDATO-1",
    "MANDATO-2",
    "RESOLUCION",
    "CERTIFICADO",
    "Pagare firmado cliente",
    "CONTRATO_MANDATO_FIRMADO_CLIENTE",
    "HOJA_DE_FIRMA",
    "MANDATO-5",
    "CONTRATO",
    "HOJA DE FIRMA",
)

# The 5 shared documents every filing needs, regardless of RUT — same names as
# the first 5 REQUIRED_COLUMNS above (those are the planilla's column headers;
# these are the actual files input/01_mandatos must physically contain).
REQUIRED_MANDATO_FILENAMES: tuple[str, ...] = (
    "1_Mandato_11709-2026.pdf",
    "2_Mandato_37590-2016.pdf",
    "3_Resolucion_409.pdf",
    "4_Certificado_2215.pdf",
    "5_Mandato_9342-2016.pdf",
)

# Which planilla column holds the Referencia TEXT for each fixed mandato-
# family file — the actual document NAME the client wants filed ("MANDATO-5"
# for the third Mandato-labeled file, not an ordinal "MANDATO 3"), read fresh
# per row so the client can change the wording in the planilla without a code
# change. Matches REQUIRED_MANDATO_FILENAMES 1:1.
MANDATO_REFERENCIA_COLUMNS: dict[str, str] = {
    "1_Mandato_11709-2026.pdf": "MANDATO-1",
    "2_Mandato_37590-2016.pdf": "MANDATO-2",
    "3_Resolucion_409.pdf": "RESOLUCION",
    "4_Certificado_2215.pdf": "CERTIFICADO",
    "5_Mandato_9342-2016.pdf": "MANDATO-5",
}

# Which results[rut] field a mandato-family file's confirmation updates —
# snake_case siblings of MANDATO_REFERENCIA_COLUMNS' own values, used by both
# the result-tracking in report_action() and the output columns in
# write_result_excel().
MANDATO_RESULT_KEYS: dict[str, str] = {
    "1_Mandato_11709-2026.pdf": "mandato_1",
    "2_Mandato_37590-2016.pdf": "mandato_2",
    "3_Resolucion_409.pdf": "resolucion",
    "4_Certificado_2215.pdf": "certificado",
    "5_Mandato_9342-2016.pdf": "mandato_5",
}

# The per-RUT audit trail, written into the run's own output folder. Named
# here rather than at the call site because it is written from THREE places:
# up front (so the file exists from the start), periodically during the run
# (so a hard kill still leaves current progress), and once at the end.
RESULT_EXCEL_FILENAME = "Clean07_Resultado.xlsx"

# write_result_excel's fixed columns, in order — (header, results[rut] key).
# PAGARE-N columns are appended dynamically, one per pagaré the RUT with the
# most pagarés in THIS run has, not a fixed count.
RESULT_FIXED_COLUMNS: tuple[tuple[str, str], ...] = (
    ("ESTADO", "estado"),
    ("RUT", "rut"),
    ("DETALLE", "detail"),
    ("DEMANDA", "demanda"),
    ("MANDATO-1", "mandato_1"),
    ("MANDATO-2", "mandato_2"),
    ("RESOLUCION", "resolucion"),
    ("CERTIFICADO", "certificado"),
    ("MANDATO-5", "mandato_5"),
    ("CONTRATO", "contrato"),
    # Last of the fixed columns on purpose: the dynamic PAGARE-N columns are
    # appended after these, so this lands immediately before them.
    ("HOJA DE FIRMA", "hoja_de_firma"),
)

HEADER_ROW = 1

# One-time page setup, run exactly ONCE per session (not per row): opens the
# form, fills the tribunal/materia block, and adds the two litigantes that
# never change (Itaú as DTE., the abogado patrocinante as AB.DTE.). The names
# are the contract with extension/content.js: every entry must have a handler
# in its STEP_HANDLERS map.
PREP_STEPS: tuple[str, ...] = (
    # Left menu of indexN.php: "Ingresar Demanda/Recurso".
    "click_ingresar_demanda",
    # Competencia / tribunal block, filled in cascade order.
    "select_competencia",
    "select_corte",
    "select_tribunal",
    # "Dirigido a" comes pre-selected with the patrocinating abogado, so this
    # only confirms it and corrects it if the portal ever defaults elsewhere.
    "ensure_dirigido_a",
    # Checks "Fijar Datos" so the tribunal block stays filled for the next
    # ingreso instead of resetting on every row.
    "click_fijar_datos",
    # "Ingreso de Demanda" card: Procedimiento = Ejecutivo, then its Materia.
    "select_procedimiento",
    "select_materia",
    # Second "Fijar Datos" — the one in the Ingreso de Demanda card footer.
    # It is a DIFFERENT checkbox from the tribunal one above; both render the
    # same "Fijar Datos" text, so they are only distinguishable by id.
    "click_fijar_datos_materia",
    # Agregar is LAST in this section: it adds the materia to the causa and
    # opens the next section below, so it must fire after Fijar Datos, not
    # before — reversed from the order this was first built in.
    "click_agregar_materia",
    # Litigantes section, opened by Agregar Materia above. "Tipo Sujeto" is a
    # select2 bound to tipoLitiganteSel inside a `foreach: litigantesCausa`
    # list; this targets the FIRST litigante block only, same as this bot
    # started with the first Fijar Datos before the second appeared.
    "select_tipo_sujeto",
    # Rut of that same litigante (plain <input name="rut">, Knockout-bound to
    # rutSel). Gated by `disable: bloqueoRutComp`, which Tipo Sujeto above is
    # expected to clear.
    "fill_rut",
    # Once the verification digit lands, the portal runs its own RUT lookup
    # and reveals "Tipo Persona" and "Razón Social" — both auto-filled by the
    # system itself, nothing to click or type. The animation can take 10+
    # seconds, so this step just waits for both to land on the expected
    # values instead of driving anything.
    "await_litigante_lookup",
    # The SII lookup fills Razón Social with the full legal name including the
    # merger note "(O ITAÚ CORPBANCA)"; the client wants the shorter "BANCO
    # ITAÚ CHILE" filed instead, so this overwrites what the lookup wrote.
    "edit_razon_social",
    # Third "Fijar Datos" — the litigante card's own footer checkbox
    # (id_check_fijar_mod_lit), so the DTE's data stays filled for the next
    # ingreso the same way the tribunal and materia ones do. Reuses
    # click_fijar_datos; only the checkbox id differs.
    "click_fijar_datos_litigante",
    # Same shape as Agregar Materia: no stable id, reached by its Knockout
    # click binding (validarIngresoLitigante). Confirms the litigante was
    # added by counting litigantesCausa's own rendered children before/after.
    "click_agregar_litigante",
    # Confirming the first litigante (DTE.) opens a SECOND blank litigante
    # block for the abogado patrocinante. Reuses select_tipo_sujeto's handler
    # with a different option — same select2, same tipoLitiganteSel binding,
    # just now rendered for this second entry.
    "select_tipo_sujeto_abogado",
    # Rut of the abogado patrocinante — same JOAQUÍN MAURICIO CARRILLO MORENO
    # as Dirigido a. Reuses fill_rut's handler; only the STEP_VALUES entry
    # differs.
    "fill_rut_abogado",
    # The abogado's RUT is a natural person, so the lookup reveals Tipo
    # Persona + three name fields (Nombres, Primer apellido, Segundo
    # apellido) instead of Razón Social — all auto-filled and disabled,
    # nothing to click or type.
    "await_abogado_lookup",
    # Same button, same binding, as click_agregar_litigante above — confirms
    # this SECOND litigante (the abogado) the same way the first one was.
    "click_agregar_litigante",
)

# The steps that repeat once per planilla row, after PREP_STEPS runs exactly
# once. This is where the row's own data (the demandado's Tipo Sujeto/Rut/
# etc.) enters — everything in PREP_STEPS above was the same for every row.
LOOP_STEPS: tuple[str, ...] = (
    # THIRD litigante block, opened the same way the second one was. "DDO."
    # (demandado) is the row-specific party — unlike DTE./AB.DTE. above, this
    # one is different for every RUT, which is why it lives in the loop and
    # not in PREP_STEPS. Reuses select_tipo_sujeto's handler.
    "select_tipo_sujeto_ddo",
    # This ROW's own Rut (not a fixed constant like fill_rut/fill_rut_abogado
    # above) — resolved dynamically from RUT+DV in next_action(), not carried
    # in STEP_VALUES.
    "fill_rut_ddo",
    # Unlike await_litigante_lookup / await_abogado_lookup, the expected NAME
    # is not known ahead of time (it is the debtor's own name, looked up by
    # the portal from their Rut) — so this only confirms Tipo Persona resolved
    # and the three name fields came back non-empty, not their exact content.
    "await_ddo_lookup",
    # Same button, same binding, as the two click_agregar_litigante uses in
    # PREP_STEPS — confirms this THIRD litigante (the demandado for this row)
    # the same way the first two were.
    "click_agregar_litigante",
    # Reads the litigante SUMMARY card (rutFormateado / tipoLitigante) rather
    # than trusting the count-based check inside click_agregar_litigante —
    # this confirms it is THIS row's own Rut tagged as "Demandado", not just
    # that *something* got added. Worth the extra check right before Ingresar,
    # which actually files the demanda.
    "await_ddo_summary",
    # THE SUBMIT BUTTON. ingresarCausa files the demanda with PJUD for real —
    # there is no draft/preview state before this. HALT_AFTER_FIRST_ROW is the
    # only thing standing between this and looping unattended over every row.
    "click_ingresar",
    # Confirms the "Adjuntar Archivo" modal that PJUD opens right after a
    # successful Ingresar, before anything inside it is touched. The page
    # takes a few seconds to load it, same lookup-animation reasoning as the
    # litigante steps above.
    "await_adjuntar_modal",
    # Types the fixed "Demanda" label into the Documento Principal's required
    # Referencia field, plain Knockout `value` binding, same key-replay
    # approach as edit_razon_social.
    "fill_referencia_principal",
    # Fetches THIS row's own signed demanda PDF from the bridge (GET /file)
    # and injects it into the hidden #uploadMultiFileDocPrincipal input via
    # DataTransfer — a synthetic click on "Adjuntar" alone cannot open PJUD's
    # native file dialog (Chrome only allows that from a trusted user
    # gesture), so this is the only way to attach the file without a human
    # picking it by hand.
    "attach_demanda_file",
    # Presses "Adjuntar" (uploadDocumentoPrincipal) now that Referencia is
    # filled and a file is staged on the hidden input.
    "click_adjuntar",
    # Reads the documentoPrincipal card list for one with THIS Referencia and
    # a positive tamano() (PJUD's own computed file size) — a real number
    # there means PJUD actually received bytes, not just that the click
    # landed. Retries Adjuntar once if no card confirms in time; if that
    # retry also fails to confirm, this step still does not fail the run —
    # continuing unconfirmed beats aborting on what may just be a slow
    # render, and there is no recovery route for THIS row's causa anyway
    # (it is already filed by click_ingresar).
    "await_documento_principal_attached",
    # --- Documento Anexo mini-loop ---------------------------------------
    # The second card in the same modal ("ADJUNTAR DOCUMENTOS", div#dDAnexo)
    # attaches EVERY supporting document this row needs — every pagaré PDF
    # the RUT has, then its own contrato (if any), then the 5 fixed
    # mandato-family files — one at a time, repeating this whole block. See
    # resolve_anexo_items() for the combined, ordered list report_action()
    # walks via anexo_cursor. ALL of these steps reset on the page after each
    # Adjuntar (Referencia comes back empty, Original Papel unchecked), so
    # the whole block must be redone per file, not just the file-specific
    # parts.
    #
    # Plain `value: referencia` binding, distinct from the first card's
    # `value: referenciaPrincipal`. Types THIS item's own Referencia
    # ("PAGARE" / "CONTRATO" / "MANDATO 1".."MANDATO 5") — resolve_anexo_items
    # decides which, not a fixed STEP_VALUES entry.
    "fill_referencia_anexo",
    # "Original Papel" checkbox (#id_check_muestra_especie) — PAGARÉ ONLY.
    # Checking it is what reveals Tipo de Documento/Cantidad/Observación
    # below; every non-pagaré kind (contrato/mandato/hoja_firma) skips it
    # (and therefore the two steps after it too), and PJUD accepts those
    # with nothing but Referencia + file.
    # report_action() skips this step entirely when the current item's kind
    # is not "pagare" — see PAGARE_ONLY_STEPS. Reuses click_fijar_datos'
    # handler; the id alone tells checkboxes apart.
    "click_original_papel",
    # "Tipo de Documento" select2 — PAGARÉ ONLY, same skip reasoning as
    # click_original_papel (it only exists in the DOM once that checkbox
    # reveals it). Bound `value: tipoEspecie` with no stable container id
    # (autogen ids drift between renders, same as Procedimiento/Materia).
    "select_tipo_documento_anexo",
    # Ordinal PJUD expects per pagaré on THIS row ("1", "2", "3"...) — PAGARÉ
    # ONLY, same skip reasoning; depends on anexo_cursor so it cannot live in
    # the static STEP_VALUES anyway.
    "fill_observacion_pagare",
    # Fetches THIS anexo item (GET /file?row=N&kind=pagare|contrato|mandato,
    # plus &index=I for pagare/mandato) and injects it via DataTransfer, same
    # technique as attach_demanda_file — Adjuntar's native file dialog has
    # the same trusted-gesture problem here.
    "attach_anexo_file",
    # Presses the Anexo card's own "Adjuntar" (uploadDocumentoAnexo) — a
    # DIFFERENT binding from Documento Principal's uploadDocumentoPrincipal.
    "click_adjuntar_anexo",
    # Confirms via documentosAnexos' card list, same tamano()>0 idea as
    # await_documento_principal_attached — but diffs the card COUNT first,
    # since several items on this row can render the SAME Referencia
    # ("PAGARE" repeats, "MANDATO 1".."5" are each unique), so "any matching
    # card" alone can't tell the Nth attach from the 1st. Same no-fatal-
    # failure reasoning as the Principal confirm.
    "await_documento_anexo_attached",
    # Runs ONCE per row, after the mini-loop drains, while the modal is still
    # open: re-checks every file this row injected against the cards actually
    # on the page and corrects the per-document results. This is what lets
    # the per-file confirms above stay short — a slow upload that missed its
    # own 20s window has had the rest of the row to land by the time this
    # sweep looks, so it is recorded as "Ingresado" instead of a false
    # "No Ingresado", without ever blocking the run for minutes.
    "verify_documentos_adjuntos",
    # THIS ROW's whole Documento Anexo mini-loop has run out of items by the
    # time step_index reaches here (report_action only lets it fall through
    # once anexo_cursor has covered every pagaré/contrato/mandato). Closes
    # the "Adjuntar Archivo" modal (cerrarAdjuntar) and returns to the causa
    # form — the last step of a row's own work, for now.
    "click_cerrar_continuar",
)

# Steps in the Documento Anexo mini-loop that ONLY apply to a "pagare" item —
# report_action() skips straight past these for every other kind
# (contrato/mandato/hoja_firma), since their required section of the form
# never even renders without Original Papel checked first.
PAGARE_ONLY_STEPS = frozenset({
    "click_original_papel",
    "select_tipo_documento_anexo",
    "fill_observacion_pagare",
})

# Values for the tribunal block. They live here, not in the extension, so the
# day a Corte has to come from the planilla (clean03 carries REGION_DEUDOR) only
# this side changes and the extension stays generic.
#
# Civil is right because what gets filed is a juicio ejecutivo on a pagaré:
# clean04 writes «Procedimiento EJECUTIVO / Materia COBRO DE PAGARÉ» addressed
# to «S.J.L. en lo Civil de Santiago». PJUD's "Cobranza" is the Juzgado de
# Cobranza Laboral y Previsional — a different jurisdiction entirely.
#
# "Dist. Corte Santiago" is the distribución office, not a named court: the
# Corte assigns the causa to one of its juzgados civiles. That is why the
# demanda is addressed to «S.J.L. en lo Civil de Santiago» with no number.
#
# The abogado matches clean04's ABOGADO / ABOGADO_RUT (11.346.197-7), the same
# person rpa06 files under.
STEP_VALUES: dict[str, str] = {
    "select_competencia": "Civil",
    "select_corte": "C.A. de Santiago",
    "select_tribunal": "Dist. Corte Santiago",
    "ensure_dirigido_a": "JOAQUÍN MAURICIO CARRILLO MORENO",
    # Same reasoning as Competencia=Civil: clean04 emits «Procedimiento
    # EJECUTIVO / Materia COBRO DE PAGARÉ». "Procedimiento Concursal" is a
    # different option in the same list, so the extension matches EXACTLY.
    "select_procedimiento": "Ejecutivo",
    # The extension folds case and accents before comparing, so the portal
    # writing "Pagaré" changes nothing — only the WORDING and punctuation have
    # to match, because the comparison is otherwise exact. If the real option
    # reads differently, the step fails and reports the list the portal offered.
    "select_materia": "Pagaré, cobro de",
    # The "Fijar Datos" checkboxes are carried as VALUES, not hardcoded in the
    # extension, because they are indistinguishable by label — all three read
    # "Fijar Datos" — and only the id separates tribunal / materia / litigante.
    "click_fijar_datos": "id_check_fijar_mod_tribunal",
    "click_fijar_datos_materia": "id_check_fijar_mod_materia",
    "click_fijar_datos_litigante": "id_check_fijar_mod_lit",
    # The option renders as "DTE." (with the trailing period) in the portal's
    # select2 list, and matching stays exact, so the period is kept here too.
    "select_tipo_sujeto": "DTE.",
    # Second litigante: the abogado patrocinante, distinct from plain "DTE."
    # (the demandante itself) and "DDO."/"AP.DTE" — matching stays exact so
    # the wrong one can never be picked.
    "select_tipo_sujeto_abogado": "AB.DTE.",
    # Third litigante, first LOOP_STEPS entry: the demandado for this row.
    # The option itself ("DDO.") is fixed on every row; what varies per row
    # is its RUT, filled by a later loop step from the planilla data.
    "select_tipo_sujeto_ddo": "DDO.",
    # Banco Itaú Chile's RUT — the fixed demandante on every filing (same
    # constant as clean04's DEMANDANTE_RUT "97.023.000-9"). Typed as bare
    # digits INCLUDING the verification digit ("970230009"); the portal's own
    # mask inserts the dots and dash as it types, and finishes formatting once
    # the "9" lands — which is also what reveals the next two fields.
    "fill_rut": "970230009",
    # Abogado patrocinante's RUT — clean04's ABOGADO_RUT "11.346.197-7",
    # same person as Dirigido a. Bare digits including the verification
    # digit, same masked-input reasoning as fill_rut above.
    "fill_rut_abogado": "113461977",
    # What the portal's own RUT lookup is expected to fill in, packed as
    # "tipo_persona::razon_social" since STEP_VALUES only carries one string
    # per step. Both come from the SII record behind Itaú's RUT, not from
    # anything the extension chooses.
    "await_litigante_lookup": "JURIDICA::BANCO ITAÚ CHILE (O ITAÚ CORPBANCA)",
    # The client wants the shorter legal name filed, without the merger note
    # the SII lookup appends.
    "edit_razon_social": "BANCO ITAÚ CHILE",
    # What the abogado's RUT lookup is expected to fill in, packed as
    # "tipo_persona::nombres::primer_apellido::segundo_apellido" — a natural
    # person this time, so four fields instead of Razón Social's one. Same
    # JOAQUÍN MAURICIO CARRILLO MORENO as Dirigido a, split into its parts.
    "await_abogado_lookup": "NATURAL::JOAQUÍN MAURICIO::CARRILLO::MORENO",
    # Fixed label for the Documento Principal's Referencia field — describes
    # what the attached file is, same value on every row.
    "fill_referencia_principal": "Demanda",
    # Documento Anexo card's Referencia is now dynamic — see
    # resolve_anexo_items / _current_anexo_referencia — since it also
    # attaches contrato ("CONTRATO") and the mandato family
    # ("MANDATO 1".."MANDATO 5"), not just pagaré ("PAGARE").
    # click_fijar_datos reuses this id to find the "Original Papel" checkbox.
    "click_original_papel": "id_check_muestra_especie",
    # Exact option text select2 must match in "Tipo de Documento" (Documento
    # Anexo card) — the accent in "Pagaré" is kept, matching stays exact.
    "select_tipo_documento_anexo": "Pagaré",
}

# Milestone guard: while LOOP_STEPS was incomplete, this stopped the run
# after PREP_STEPS plus one full LOOP_STEPS pass, so the operator watched one
# clean row instead of repeating a partial flow on every row. LOOP_STEPS now
# files a demanda end to end (litigantes, Ingresar, Documento Principal, the
# full Documento Anexo mini-loop, Cerrar y Continuar) and write_result_excel
# gives every row an audit trail even if the run stops partway — so this now
# runs every row in the planilla, unattended.
HALT_AFTER_FIRST_ROW = False

DEFAULT_DONE_MESSAGE = "Conexión verificada con BotManager."

# How many times the same step may be handed to the extension before the bridge
# declares the loop stuck. One retry is tolerated (a reloaded tab re-asks for
# the step it was performing); beyond that the run stops.
MAX_STEP_ISSUES = 2

# The extension polls /next about every 1.2 s once Start is pressed. If it goes
# quiet for this long (tab closed, extension reloaded, operator walked away),
# close the session instead of hanging until the global timeout.
#
# Must stay comfortably ABOVE the extension's longest single step. While a step
# handler runs, pumpWork is busy and pollBridge has already stopped, so the only
# thing keeping this fresh is content.js's own heartbeat() during the upload
# confirm waits (150 s each). If a heartbeat is ever dropped, this margin is
# what stops a genuinely slow PJUD upload from being mistaken for a closed tab
# and killing a run mid-causa.
EXTENSION_IDLE_SECONDS = 90


class MissingColumnsError(ValueError):
    """Raised when the planilla is missing one or more required columns."""

    def __init__(self, missing: list[str], sheet_name: str, found: list[str]):
        self.missing = list(missing)
        self.sheet_name = sheet_name
        self.found = list(found)
        super().__init__(
            "La planilla no tiene todas las columnas necesarias. "
            f"Faltan: {', '.join(self.missing)}."
        )


class InputError(ValueError):
    """Raised when an input other than the columns makes the run impossible.

    Carries a short machine-readable ``reason`` so the desktop notification can
    explain the exact problem instead of a generic failure.
    """

    def __init__(self, message: str, *, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(message)


def _normalize_header(value: Any) -> str:
    """Fold a header to its comparable form: trimmed, collapsed and caseless."""
    return " ".join(str(value if value is not None else "").split()).casefold()


def _read_header_row(worksheet: Any) -> dict[str, tuple[str, int]]:
    """Map normalized header -> (original text, 1-based column index)."""
    headers: dict[str, tuple[str, int]] = {}
    for row in worksheet.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW, values_only=True):
        for index, cell in enumerate(row, start=1):
            normalized = _normalize_header(cell)
            if not normalized:
                continue
            # First occurrence wins, so a duplicated header cannot shadow it.
            headers.setdefault(normalized, (" ".join(str(cell).split()), index))
        break
    return headers


def _match_required_columns(
    headers: dict[str, tuple[str, int]],
) -> tuple[dict[str, Any], list[str]]:
    """Resolve every required column, collecting ALL misses instead of the first."""
    resolved: dict[str, Any] = {}
    missing: list[str] = []
    for required in REQUIRED_COLUMNS:
        match = headers.get(_normalize_header(required))
        if match is None:
            missing.append(required)
            continue
        original, index = match
        resolved[required] = {"header": original, "index": index}
    return resolved, missing


def inspect_excel(path: str) -> dict[str, Any]:
    """Validate the selected planilla and return non-sensitive workbook metadata.

    Every required column is checked before failing, so the operator sees the
    complete list of what is missing instead of only the first offender.
    """
    import openpyxl

    target = Path(path).expanduser()
    if not target.exists() or not target.is_file():
        raise InputError(
            f"No se encontró la planilla seleccionada: {target.name}",
            reason="planilla_inexistente",
            detail=str(target),
        )
    if target.suffix.lower() not in ALLOWED_EXCEL_SUFFIXES:
        raise InputError(
            "La planilla debe ser un archivo Excel .xlsx o .xlsm.",
            reason="planilla_formato",
            detail=target.name,
        )

    try:
        workbook = openpyxl.load_workbook(str(target), read_only=True, data_only=True)
    except Exception as exc:
        raise InputError(
            f"No se pudo abrir la planilla: {exc}",
            reason="planilla_ilegible",
            detail=target.name,
        ) from exc

    try:
        sheet_names = list(workbook.sheetnames)
        if not sheet_names:
            raise InputError(
                "La planilla no contiene hojas.",
                reason="planilla_sin_hojas",
                detail=target.name,
            )

        # The planilla may carry helper sheets, so keep the first sheet that
        # exposes every required column and fall back to the closest match.
        best: dict[str, Any] | None = None
        for name in sheet_names:
            worksheet = workbook[name]
            headers = _read_header_row(worksheet)
            resolved, missing = _match_required_columns(headers)
            candidate = {
                "sheet_name": name,
                "columns": resolved,
                "missing": missing,
                "found_headers": [original for original, _ in headers.values()],
                "data_rows": max(0, int(worksheet.max_row or 0) - HEADER_ROW),
            }
            if not missing:
                best = candidate
                break
            if best is None or len(missing) < len(best["missing"]):
                best = candidate

        assert best is not None  # sheet_names is non-empty
        if best["missing"]:
            raise MissingColumnsError(best["missing"], best["sheet_name"], best["found_headers"])
    finally:
        workbook.close()

    return {
        "filename": target.name,
        "path": str(target),
        "sheet_names": sheet_names,
        "sheet_count": len(sheet_names),
        "sheet_name": best["sheet_name"],
        "columns": best["columns"],
        "data_rows": best["data_rows"],
    }


def read_rows(path: str, sheet_name: str, columns: dict[str, Any]) -> list[dict[str, Any]]:
    """Read the planilla rows, keeping the Excel row number for every record.

    Fully blank rows are dropped so trailing formatting does not inflate the
    count the operator sees in the panel.
    """
    import openpyxl

    workbook = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    try:
        worksheet = workbook[sheet_name]
        indexes = {name: int(meta["index"]) for name, meta in columns.items()}
        rows: list[dict[str, Any]] = []
        for excel_row, raw in enumerate(
            worksheet.iter_rows(min_row=HEADER_ROW + 1, values_only=True),
            start=HEADER_ROW + 1,
        ):
            if not any(cell not in (None, "") for cell in raw):
                continue
            record: dict[str, Any] = {"excel_row": excel_row}
            for name, index in indexes.items():
                value = raw[index - 1] if index - 1 < len(raw) else None
                record[name] = value
            rows.append(record)
        return rows
    finally:
        workbook.close()


def format_rut(rut: object, dv: object) -> str:
    """`5228857` + `6` -> `5.228.857-6`. Returns "" when either part is missing.

    Copy of Clean06's formatter (bots/clean06_crear-planilla-ingreso-demandas/
    functions.py) — Clean06 is the planilla's source, so its RUT format is the
    one the folder names on disk must match. Not imported across bots per the
    project convention; this is small enough to duplicate.
    """
    body = "".join(ch for ch in str(rut or "") if ch.isdigit())
    check = str(dv or "").strip().upper().replace(".", "").replace("-", "")
    if not body or not check:
        return ""

    grouped: list[str] = []
    while len(body) > 3:
        grouped.insert(0, body[-3:])
        body = body[:-3]
    grouped.insert(0, body)
    return f"{'.'.join(grouped)}-{check}"


def bare_rut(rut: object, dv: object) -> str:
    """Same digits as format_rut, without the dots/dash.

    This is what the masked Rut inputs expect while TYPING (see fill_rut /
    fill_rut_abogado) — the mask itself inserts the dots and dash live.
    """
    return format_rut(rut, dv).replace(".", "").replace("-", "")


def _is_si(value: object) -> bool:
    """True only when a planilla flag literally says SI.

    Same rule as clean06's own ``is_si`` (bots/clean06_crear-planilla-ingreso-
    demandas/functions.py), which is what WRITES these flags — matching it
    exactly is what keeps an accented "SÍ" from silently reading as NO.
    """
    return " ".join(str(value or "").split()).upper() in {"SI", "SÍ"}


def inspect_mandatos_folder(path: str) -> dict[str, Any]:
    """Validate input/01_mandatos holds the fixed shared document set.

    These 5 files are the same on every filing session (mandato, resolución,
    certificado — not per-RUT), so the check is a hard, exact-filename match
    against REQUIRED_MANDATO_FILENAMES rather than anything read from the
    planilla.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de mandatos (input/01_mandatos).",
            reason="carpeta_mandatos_inexistente",
            detail=str(target),
        )

    present = {p.name for p in target.iterdir() if p.is_file()}
    missing = [name for name in REQUIRED_MANDATO_FILENAMES if name not in present]
    if missing:
        raise InputError(
            f"Faltan {len(missing)} documento(s) en input/01_mandatos.",
            reason="mandatos_incompletos",
            detail=" | ".join(missing),
        )

    return {
        "path": str(target),
        "file_count": len(present),
    }


def inspect_contratos_folder(path: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate input/02_contratos holds every SHARED contrato the planilla references.

    The 6_Contrato_CPSB column carries a value like `5.228.857-6\\6_CPSB_Rept_
    14172.pdf` per row (empty when a row needs none). Only the FILENAME after
    the last backslash matters here — the RUT-DV prefix identifies which row
    needs it, not a real subfolder; every contrato sits flat in this folder.

    One value is deliberately EXCLUDED: `Contrato_Mandato.pdf` (the "mandato
    case" — see REQUIRED_COLUMNS' docstring). That file is per-RUT, not
    shared, and lives as `<RUT-DV>_CONTRATO_MANDATO.pdf` inside that RUT's own
    input/03_demandas/<RUT-DV>/ subfolder — a different name and a different
    folder, resolved when the per-row loop actually files that row, not here.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de contratos (input/02_contratos).",
            reason="carpeta_contratos_inexistente",
            detail=str(target),
        )

    present = {p.name for p in target.iterdir() if p.is_file()}
    referenced: set[str] = set()
    for row in rows:
        text = str(row.get("6_Contrato_CPSB") or "").strip()
        if not text:
            continue
        filename = Path(text.replace("\\", "/")).name
        if filename and filename.casefold() != "contrato_mandato.pdf":
            referenced.add(filename)

    missing = sorted(name for name in referenced if name not in present)
    if missing:
        raise InputError(
            f"Faltan {len(missing)} contrato(s) en input/02_contratos.",
            reason="contratos_faltantes",
            detail=" | ".join(missing),
        )

    return {
        "path": str(target),
        "file_count": len(present),
        "referenced_count": len(referenced),
    }


def inspect_demandas_folder(path: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate input/03_demandas and flag which rows are missing their PDF.

    Flat files, one per RUT, named `<RUT-DV>_DEMANDA_firmado.pdf` — no
    subfolders (that is input/04_Carpeta-Ruts' job now). Softened to the same
    "at least one match" sanity check used elsewhere: a planilla with 50 rows
    and 3 missing demandas should still run the other 47, not abort before the
    browser even opens. Only a folder with none of the expected PDFs fails the
    whole run.

    Each row in ``rows`` is mutated in place with ``row["demanda_missing"]``
    (bool) and, when true, ``row["demanda_missing_reason"]`` — the per-row
    loop can use these once it reaches the point of using this file, to stop
    processing that row and report ESTADO "Causa no ingresada" instead.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de demandas (input/03_demandas).",
            reason="carpeta_inexistente",
            detail=str(target),
        )

    present = {p.name for p in target.iterdir() if p.is_file()}
    expected: list[str] = []
    missing: list[str] = []
    for row in rows:
        rut = format_rut(row.get("RUT"), row.get("DV"))
        if not rut:
            continue
        filename = f"{rut}_DEMANDA_firmado.pdf"
        expected.append(filename)
        if filename in present:
            row["demanda_missing"] = False
            row["demanda_missing_reason"] = ""
        else:
            row["demanda_missing"] = True
            row["demanda_missing_reason"] = (
                f"{filename} No fue encontrado en la carpeta 03_Demandas"
            )
            missing.append(filename)

    if expected and len(missing) == len(expected):
        raise InputError(
            "No se encontró ninguna demanda firmada en input/03_demandas.",
            reason="demandas_faltantes",
            detail=" | ".join(sorted(missing)),
        )

    return {
        "path": str(target),
        "pdf_count": len(present),
        "expected_count": len(expected),
        "missing_count": len(missing),
        "missing": sorted(missing),
    }


def inspect_carpeta_ruts_folder(path: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate input/04_Carpeta-Ruts holds at least the RUTs this planilla needs.

    This is what input/03_demandas used to be: one subfolder per RUT holding
    the rest of that row's documents (ARCH_PAGARES, CEDULA_IDENTIDAD, etc.),
    resolved lazily when the loop actually files that row. Deliberately a
    cheap up-front sanity check — the right BATCH was dropped in — not a
    guarantee every single row's folder exists.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de RUTs (input/04_Carpeta-Ruts).",
            reason="carpeta_inexistente",
            detail=str(target),
        )

    pdfs = sorted(p for p in target.rglob("*") if p.is_file() and p.suffix.lower() == ".pdf")
    subfolders = sorted(p.name for p in target.iterdir() if p.is_dir())
    if not pdfs:
        raise InputError(
            "La carpeta input/04_Carpeta-Ruts no contiene ningún PDF.",
            reason="carpeta_vacia",
            detail=str(target),
        )

    expected_ruts = sorted({format_rut(row.get("RUT"), row.get("DV")) for row in rows} - {""})
    if expected_ruts and not (set(subfolders) & set(expected_ruts)):
        raise InputError(
            "Ninguno de los RUT de la planilla tiene carpeta en input/04_Carpeta-Ruts.",
            reason="carpeta_ruts_sin_rut_coincidente",
            detail=" | ".join(expected_ruts[:10]),
        )

    return {
        "path": str(target),
        "pdf_count": len(pdfs),
        "subfolder_count": len(subfolders),
        "subfolders": subfolders[:20],
    }


def _normalize_build(value: Any) -> str:
    """Compare builds without tripping over the "v" prefix.

    content.js carries "v0.7.2" for the panel title while manifest.json carries
    "0.7.2"; they are the same build.
    """
    text = str(value or "").strip()
    return text[1:] if text[:1].lower() == "v" else text


def extension_manifest_version() -> str:
    """Version of the extension AS INSTALLED ON DISK, next to this file.

    Deliberately read from the manifest rather than duplicated in a constant:
    the packaged bot and its extension always ship together, so the manifest is
    the one value that cannot silently disagree with what was deployed.
    """
    manifest = Path(__file__).parent / "extension" / "manifest.json"
    try:
        with manifest.open("r", encoding="utf-8") as handle:
            return str(json.load(handle).get("version") or "")
    except (OSError, json.JSONDecodeError):
        return ""


def _blank_result(rut: str, estado: str = "No procesada", detail: str = "") -> dict[str, Any]:
    """A fresh results[rut] entry — see BridgeState.results and write_result_excel.

    Every per-document field starts None ("not required / not yet known").
    ``report_action`` flips the required ones to "No Ingresado" the moment a
    causa is actually filed (click_ingresar), then to "Ingresado" as each
    attach confirms — so a run that stops partway leaves an honest, pessimistic
    trail instead of silently omitting what never got attempted.
    """
    return {
        "rut": rut,
        "estado": estado,
        "detail": detail,
        "demanda": None,
        "mandato_1": None,
        "mandato_2": None,
        "resolucion": None,
        "certificado": None,
        "mandato_5": None,
        "contrato": None,
        "hoja_de_firma": None,
        "pagares": [],
    }


@dataclass
class BridgeState:
    """Shared state between the desktop task and the Chrome extension.

    The extension polls /health, the operator presses Start (/start), and from
    then on every /next hands out the current phase's step (``PREP_STEPS``
    once, then ``LOOP_STEPS`` per row), which the extension performs and
    answers on /report. Mirrors Clean05's machine.
    """

    input_path: str
    workbook: dict[str, Any]
    demandas: dict[str, Any]
    mandatos: dict[str, Any]
    contratos: dict[str, Any]
    carpeta_ruts: dict[str, Any]
    rows: list[dict[str, Any]] = field(default_factory=list)
    # Per-RUT audit trail for write_result_excel — pre-populated by
    # build_bridge_state() with estado="No procesada" for every RUT in the
    # planilla, so a RUT the run never reaches still shows up in the output.
    # See report_action() for the update points.
    results: dict[str, dict[str, Any]] = field(default_factory=dict)
    extension_seen_at: float = 0.0
    started_at: float = 0.0
    finished: bool = False
    error: str = ""
    portal_url: str = ""
    portal_title: str = ""
    logs: list[str] = field(default_factory=list)
    # "prep" runs PREP_STEPS exactly once; "loop" runs LOOP_STEPS once per
    # row. report_action() is what flips prep -> loop, when PREP_STEPS runs out.
    phase: str = "prep"
    # Position in the run: which planilla row (loop phase only — stays 0
    # during prep), and which step inside the CURRENT phase's step list.
    cursor: int = 0
    step_index: int = 0
    # Index into THIS row's combined anexo item list (see
    # resolve_anexo_items: every pagaré, then contrato, then the mandato
    # family), 0-based. Advanced by report_action() when
    # await_documento_anexo_attached completes and more items remain for
    # this row; reset to 0 whenever the row itself advances.
    anexo_cursor: int = 0
    rows_done: int = 0
    steps_done: int = 0
    last_step_done: int = 0
    completion_message: str = ""
    # Repeat guard: which step was last handed out, and how many times in a row.
    issued_key: tuple[str, int, int] | None = None
    issued_count: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock)

    def next_action(self) -> dict[str, Any]:
        """Tell the extension what to do next on the PJUD page."""
        with self.lock:
            self.extension_seen_at = time.time()
            if not self.started_at:
                return {"action": "wait", "message": "Esperando Start."}
            if self.finished or self.cursor >= len(self.rows):
                self.finished = True
                return self._done_step_unlocked()

            row = self.rows[self.cursor]
            phase_steps = PREP_STEPS if self.phase == "prep" else LOOP_STEPS
            step_name = phase_steps[self.step_index]

            # The extension is busy while it performs a step, so it only asks
            # again after reporting. Handing out the same step repeatedly means
            # the reports are not arriving — and repeating an action on the
            # portal is what gets the session blocked by the WAF. Stop instead.
            key = (self.phase, self.cursor, self.step_index)
            self.issued_count = self.issued_count + 1 if key == self.issued_key else 1
            self.issued_key = key
            if self.issued_count > MAX_STEP_ISSUES:
                self.error = (
                    f"Fila {self.cursor + 1}, paso {self.step_index + 1} "
                    f"({step_name}): la extensión pidió el mismo paso "
                    f"{self.issued_count} veces sin informar el resultado. "
                    "Se detuvo la corrida para no repetirlo en el portal."
                )
                self.completion_message = (
                    f"El bot se detuvo en Step {self.step_index + 1}. Revisa BotManager."
                )
                self.logs.append(self.error)
                self.finished = True
                return self._done_step_unlocked()

            step: dict[str, Any] = {
                "action": step_name,
                "row_number": self.cursor + 1,
                "excel_row": row.get("excel_row"),
                "total": len(self.rows),
                "step_number": self.step_index + 1,
                "step_total": len(phase_steps),
            }
            if step_name == "fill_rut_ddo":
                # Row-specific, unlike every other STEP_VALUES entry — this is
                # THIS row's own debtor, so it comes from the planilla, not a
                # constant.
                step["value"] = bare_rut(row.get("RUT"), row.get("DV"))
            elif step_name == "await_ddo_summary":
                # The summary card shows the FORMATTED Rut (rutFormateado()),
                # not the bare digits fill_rut_ddo typed.
                step["value"] = format_rut(row.get("RUT"), row.get("DV"))
            elif step_name == "await_documento_principal_attached":
                # Same literal the row's own fill_referencia_principal step
                # typed — single source of truth, so confirmation always
                # looks for exactly what was filled.
                step["value"] = STEP_VALUES["fill_referencia_principal"]
            elif step_name == "fill_referencia_anexo":
                # THIS anexo item's own Referencia — resolve_anexo_items
                # decides pagaré/contrato/mandato, not a fixed STEP_VALUES
                # entry (that stopped being true once contrato/mandato joined
                # the same mini-loop).
                step["value"] = self._current_anexo_referencia(self.cursor + 1)
            elif step_name == "fill_observacion_pagare":
                # 1-based ordinal for THIS pagaré on this row. Pagarés are
                # always first in resolve_anexo_items, so anexo_cursor still
                # equals the pagaré-only ordinal here — depends on
                # anexo_cursor either way, so it cannot live in STEP_VALUES.
                step["value"] = str(self.anexo_cursor + 1)
            elif step_name == "attach_anexo_file":
                # Which item (0-based, into the SAME combined list) to fetch
                # from GET /file?kind=pagare|contrato|mandato.
                step["anexo_index"] = self.anexo_cursor
            elif step_name == "await_documento_anexo_attached":
                # Same literal this row's own fill_referencia_anexo step just
                # typed — single source of truth, same reasoning as
                # await_documento_principal_attached above.
                step["value"] = self._current_anexo_referencia(self.cursor + 1)
            elif step_name in STEP_VALUES:
                step["value"] = STEP_VALUES[step_name]
            return step

    def resolve_demanda_file(self, row_number: int) -> Path | None:
        """Absolute path to THIS row's own signed demanda PDF, or None.

        ``row_number`` is 1-based, matching next_action()'s "row_number".
        Returns None for an out-of-range row, a row already flagged
        ``demanda_missing`` (see inspect_demandas_folder), or a file that
        vanished from disk between validation and the attach step.
        """
        index = row_number - 1
        if index < 0 or index >= len(self.rows):
            return None
        row = self.rows[index]
        if row.get("demanda_missing"):
            return None
        rut = format_rut(row.get("RUT"), row.get("DV"))
        if not rut:
            return None
        folder = Path(self.demandas.get("path") or "")
        candidate = folder / f"{rut}_DEMANDA_firmado.pdf"
        return candidate if candidate.is_file() else None

    def resolve_pagare_files(self, row_number: int) -> list[Path]:
        """Every pagaré PDF THIS row's RUT has, sorted for a stable order.

        A RUT can have several — one per pagaré it owes, e.g. one MP and one
        LP — living flat in its own input/04_Carpeta-Ruts/<RUT-DV>/ subfolder
        as `<RUT-DV>_PAGARE_<TIPO>[_N].pdf` (see clean02/clean06 for where
        that naming comes from). Matched by `_pagare_` in the filename
        case-insensitively rather than trusting the planilla's ARCH_PAGARES
        column, which carries clean06's own (different) naming convention and
        is never guaranteed to match what actually landed on disk.
        """
        index = row_number - 1
        if index < 0 or index >= len(self.rows):
            return []
        row = self.rows[index]
        rut = format_rut(row.get("RUT"), row.get("DV"))
        if not rut:
            return []
        base = Path(self.carpeta_ruts.get("path") or "")
        folder = base / rut
        if not folder.is_dir():
            return []
        return sorted(
            p for p in folder.iterdir()
            if p.is_file() and p.suffix.lower() == ".pdf" and "_pagare_" in p.name.casefold()
        )

    def resolve_pagare_file(self, row_number: int, index: int) -> Path | None:
        """The ``index``-th (0-based) pagaré PDF for this row, or None."""
        files = self.resolve_pagare_files(row_number)
        return files[index] if 0 <= index < len(files) else None

    def resolve_hoja_firma_file(self, row_number: int) -> Path | None:
        """THIS row's own Hoja de Firma PDF, or None.

        Per-RUT (not shared like the mandato family), sitting in the same
        input/04_Carpeta-Ruts/<RUT-DV>/ subfolder as that row's pagarés.

        The name is matched on its `hoja_de_firma` part case-insensitively
        rather than trusting the planilla's 7_HOJA_DE_FIRMA.pdf column, for
        the same reason resolve_pagare_files globs instead of trusting
        ARCH_PAGARES: clean06 WRITES that column as
        `<RUT-DV>\\7_HOJA_DE_FIRMA.pdf` while the folders that actually ship
        carry `<RUT-DV>_HOJA_DE_FIRMA.pdf`. Both land here; the RUT-prefixed
        name wins when a folder somehow holds both.
        """
        index = row_number - 1
        if index < 0 or index >= len(self.rows):
            return None
        rut = format_rut(self.rows[index].get("RUT"), self.rows[index].get("DV"))
        if not rut:
            return None
        folder = Path(self.carpeta_ruts.get("path") or "") / rut
        if not folder.is_dir():
            return None
        exact = folder / f"{rut}_HOJA_DE_FIRMA.pdf"
        if exact.is_file():
            return exact
        matches = sorted(
            p for p in folder.iterdir()
            if p.is_file()
            and p.suffix.lower() == ".pdf"
            and "hoja_de_firma" in p.name.casefold()
        )
        return matches[0] if matches else None

    def resolve_anexo_items(self, row_number: int) -> list[dict[str, Any]]:
        """Every document THIS row's Documento Anexo card needs, in order.

        Pagarés first (existing behavior — see resolve_pagare_files), then
        this row's own contrato (only if the planilla's 6_Contrato_CPSB
        column carries one — most rows need none), then the 5 fixed
        mandato-family files from input/01_mandatos (same on every row,
        already guaranteed present by inspect_mandatos_folder), and last this
        row's own Hoja de Firma when its HOJA_DE_FIRMA flag says SI.

        Each item: {"kind": "pagare"|"contrato"|"mandato"|"hoja_firma",
        "referencia": str,
        "path": Path, "result_key": str|None}. anexo_cursor indexes into this
        same list — pagarés occupying the front of it is what lets
        fill_observacion_pagare keep using anexo_cursor directly as the
        pagaré ordinal. "result_key" is None for pagaré (tracked by list
        position in results[rut]["pagares"] instead), "contrato" for the
        contrato item and "hoja_de_firma" for the Hoja de Firma; for a
        mandato item it is the results field it maps to (see
        MANDATO_RESULT_KEYS).

        Contrato and mandato Referencia text comes from THIS row's own
        CONTRATO / MANDATO-1 / MANDATO-2 / RESOLUCION / CERTIFICADO /
        MANDATO-5 columns (see MANDATO_REFERENCIA_COLUMNS) — the actual
        document NAME the client wants filed, not an ordinal ("MANDATO-5" is
        a real mandato's name, not "the 3rd one"). Read fresh per row instead
        of hardcoded, so the client can change the wording in the planilla
        without a code change.

        A BLANK column means this RUT does not need that document at all —
        the file is skipped entirely (not attached with a fallback label).
        Only 6_Contrato_CPSB gates contrato the same way; the mandato-family
        files are otherwise unconditionally present on disk (shared/fixed),
        so their own Referencia column is the only per-row signal for
        whether THIS causa needs them.
        """
        items: list[dict[str, Any]] = [
            {"kind": "pagare", "referencia": "PAGARE", "path": path, "result_key": None}
            for path in self.resolve_pagare_files(row_number)
        ]

        index = row_number - 1
        row = self.rows[index] if 0 <= index < len(self.rows) else None

        if row is not None:
            text = str(row.get("6_Contrato_CPSB") or "").strip()
            if text:
                filename = Path(text.replace("\\", "/")).name
                if filename and filename.casefold() != "contrato_mandato.pdf":
                    contrato_path = Path(self.contratos.get("path") or "") / filename
                    if contrato_path.is_file():
                        referencia = str(row.get("CONTRATO") or "").strip() or "CONTRATO"
                        items.append({
                            "kind": "contrato", "referencia": referencia,
                            "path": contrato_path, "result_key": "contrato",
                        })

        mandatos_folder = Path(self.mandatos.get("path") or "")
        for filename in REQUIRED_MANDATO_FILENAMES:
            mandato_path = mandatos_folder / filename
            if not mandato_path.is_file():
                continue
            column = MANDATO_REFERENCIA_COLUMNS[filename]
            referencia = str(row.get(column) or "").strip() if row is not None else ""
            if not referencia:
                # Blank cell -> this RUT's causa does not need this
                # particular mandato-family document. Skip it entirely.
                continue
            items.append({
                "kind": "mandato", "referencia": referencia,
                "path": mandato_path, "result_key": MANDATO_RESULT_KEYS[filename],
            })

        # Hoja de Firma — per-RUT like the contrato, but gated on a SI/NO flag
        # instead of a filename column. Clean06 sets exactly ONE of
        # HOJA_DE_FIRMA / CONTRATO_MANDATO_FIRMADO_CLIENTE / "Pagare firmado
        # cliente" to SI, so anything but SI here means this causa genuinely
        # does not need the document — skip it rather than attaching a
        # placeholder. Only the row that OPENS a RUT is ever read (repeat rows
        # are skipped before they reach here), which is the same row clean06
        # writes these flags on.
        if row is not None and _is_si(row.get("HOJA_DE_FIRMA")):
            hoja_path = self.resolve_hoja_firma_file(row_number)
            if hoja_path is not None:
                # Referencia comes from the SEPARATE "HOJA DE FIRMA" column —
                # spaces, not underscores; a different column from the flag
                # above (see REQUIRED_COLUMNS). Clean06 fills it with the
                # literal "HOJA DE FIRMA", which is also the fallback.
                referencia = str(row.get("HOJA DE FIRMA") or "").strip() or "HOJA DE FIRMA"
                items.append({
                    "kind": "hoja_firma", "referencia": referencia,
                    "path": hoja_path, "result_key": "hoja_de_firma",
                })

        return items

    def resolve_anexo_file(self, row_number: int, index: int) -> Path | None:
        """The ``index``-th (0-based) anexo item's own PDF, or None."""
        items = self.resolve_anexo_items(row_number)
        return items[index]["path"] if 0 <= index < len(items) else None

    def _current_anexo_referencia(self, row_number: int) -> str:
        items = self.resolve_anexo_items(row_number)
        return items[self.anexo_cursor]["referencia"] if 0 <= self.anexo_cursor < len(items) else ""

    def _current_anexo_kind(self, row_number: int) -> str:
        items = self.resolve_anexo_items(row_number)
        return items[self.anexo_cursor]["kind"] if 0 <= self.anexo_cursor < len(items) else ""

    def _advance_past_unfileable_rows(self) -> None:
        """From the current cursor, skip every row that must never be filed.

        A row with no signed demanda PDF (row["demanda_missing"], set by
        inspect_demandas_folder) must never reach click_ingresar — mark it
        "Causa no ingresada" in results and move past it, along with any
        row repeating the same RUT (same fate either way, since the
        filename that's missing is per-RUT, not per-row). Loops so a run of
        several consecutive unfileable RUTs skips all of them in one go.
        Caller already holds self.lock.
        """
        while self.cursor < len(self.rows):
            row = self.rows[self.cursor]
            if not row.get("demanda_missing"):
                return
            rut = format_rut(row.get("RUT"), row.get("DV"))
            reason = str(row.get("demanda_missing_reason") or "")
            if rut:
                entry = self.results.setdefault(rut, _blank_result(rut))
                entry["estado"] = "Causa no ingresada"
                entry["detail"] = reason
            self.logs.append(
                f"Fila {self.cursor + 1}: {reason or 'demanda firmada no encontrada'} "
                "Causa no ingresada — se omite esta fila."
            )
            self.cursor += 1
            self.rows_done += 1
            while (
                rut
                and self.cursor < len(self.rows)
                and format_rut(
                    self.rows[self.cursor].get("RUT"), self.rows[self.cursor].get("DV")
                ) == rut
            ):
                self.cursor += 1
                self.rows_done += 1

    def report_action(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Record how the step the extension just performed went.

        A failed step stops the run. There is no recovery route on PJUD yet, and
        a step that failed means the page is not where the bot believed it was —
        continuing blindly there risks filing into the wrong causa.
        """
        with self.lock:
            self.extension_seen_at = time.time()
            ok = bool(payload.get("ok"))
            detail = " ".join(str(payload.get("detail") or "").split())[:300]
            position = self.cursor + 1
            step_number = self.step_index + 1
            phase_steps = PREP_STEPS if self.phase == "prep" else LOOP_STEPS
            step_name = phase_steps[self.step_index]

            if not ok:
                self.logs.append(f"Fila {position} [{step_name}]: ERROR {detail}")
                self.error = (
                    f"Fila {position}, paso {step_number} ({step_name}): "
                    f"{detail or 'el paso falló sin detalle.'}"
                )
                self.completion_message = (
                    f"El bot se detuvo en Step {step_number}. Revisa BotManager."
                )
                self.finished = True
                return self._report_reply_unlocked()

            self.logs.append(f"Fila {position} [{step_name}]: OK. {detail}".strip())
            self.steps_done += 1
            self.last_step_done = step_number
            self.step_index += 1

            rut = (
                format_rut(self.rows[self.cursor].get("RUT"), self.rows[self.cursor].get("DV"))
                if self.cursor < len(self.rows) else ""
            )
            confirmed = bool(payload.get("confirmed", True))

            if step_name == "click_ingresar" and rut:
                # THIS causa is now genuinely filed with PJUD — every
                # document the Documento Anexo mini-loop is ABOUT to attach
                # starts pessimistically "No Ingresado" until its own
                # confirm step flips it. A run that stops mid-row leaves
                # this honest instead of looking like nothing was attempted.
                entry = self.results.setdefault(rut, _blank_result(rut))
                entry["estado"] = "Ingresada"
                entry["demanda"] = "No Ingresado"
                for item in self.resolve_anexo_items(position):
                    if item["result_key"] is None:  # pagaré, tracked by position
                        entry["pagares"].append("No Ingresado")
                    else:
                        entry[item["result_key"]] = "No Ingresado"
            elif step_name == "await_documento_principal_attached" and rut:
                entry = self.results.setdefault(rut, _blank_result(rut))
                entry["demanda"] = "Ingresado" if confirmed else "No Ingresado"
            elif step_name == "await_documento_anexo_attached" and rut:
                # Resolve which item THIS confirm belongs to using the
                # CURRENT (not-yet-advanced) anexo_cursor — the rewind logic
                # below is what moves it on to the next item.
                items = self.resolve_anexo_items(position)
                if 0 <= self.anexo_cursor < len(items):
                    item = items[self.anexo_cursor]
                    entry = self.results.setdefault(rut, _blank_result(rut))
                    status = "Ingresado" if confirmed else "No Ingresado"
                    if item["result_key"] is None:
                        # Pagarés always occupy the front of the list
                        # (0..num_pagares-1), so anexo_cursor IS the
                        # pagaré's own 0-based position here.
                        pagares = entry["pagares"]
                        while len(pagares) <= self.anexo_cursor:
                            pagares.append("No Ingresado")
                        pagares[self.anexo_cursor] = status
                    else:
                        entry[item["result_key"]] = status
            elif step_name == "verify_documentos_adjuntos" and rut:
                # The extension re-checked every file for this row against
                # the cards actually on the page. This is the LAST word on
                # what landed: it overwrites the per-file guesses above,
                # including flipping a pessimistic "No Ingresado" back to
                # "Ingresado" for an upload that was merely slow.
                verified = payload.get("verified") or {}
                entry = self.results.setdefault(rut, _blank_result(rut))
                entry["demanda"] = "Ingresado" if verified.get("principal") else "No Ingresado"
                anexos = verified.get("anexos") or {}
                items = self.resolve_anexo_items(position)
                for raw_index, landed in anexos.items():
                    try:
                        index = int(raw_index)
                    except (TypeError, ValueError):
                        continue
                    if not (0 <= index < len(items)):
                        continue
                    item = items[index]
                    status = "Ingresado" if landed else "No Ingresado"
                    if item["result_key"] is None:
                        pagares = entry["pagares"]
                        while len(pagares) <= index:
                            pagares.append("No Ingresado")
                        pagares[index] = status
                    else:
                        entry[item["result_key"]] = status

            if step_name == "await_documento_anexo_attached":
                # THIS anexo item is done — check whether the row has
                # another one waiting (pagaré / contrato / mandato, all in
                # ONE combined list — see resolve_anexo_items). If so, rewind
                # the mini-loop instead of letting step_index fall through
                # past it (there is nothing after it in LOOP_STEPS yet
                # either way).
                total_items = len(self.resolve_anexo_items(position))
                self.anexo_cursor += 1
                if self.anexo_cursor < total_items:
                    self.step_index = LOOP_STEPS.index("fill_referencia_anexo")
                else:
                    self.anexo_cursor = 0

            if self.phase == "loop":
                # Every non-pagaré item skips Original Papel entirely, which
                # is what reveals Tipo de Documento/Observación on the page
                # in the first place — so those three steps do not apply to
                # them at all. Fast-forward past any of them the current
                # item doesn't need, rather than issuing a step that has
                # nothing to act on.
                while (
                    self.step_index < len(LOOP_STEPS)
                    and LOOP_STEPS[self.step_index] in PAGARE_ONLY_STEPS
                    and self._current_anexo_kind(self.cursor + 1) != "pagare"
                ):
                    self.step_index += 1

            if self.phase == "prep" and self.step_index >= len(PREP_STEPS):
                # PREP_STEPS ran exactly once; hand off to the per-row loop
                # starting at row 1, LOOP_STEPS' own first step.
                self.phase = "loop"
                self.step_index = 0
                # Row 1 itself might have no signed demanda — never let
                # click_ingresar fire for it either.
                self._advance_past_unfileable_rows()
                self.completion_message = (
                    f"Preparación completa. Iniciando fila 1/{len(self.rows)}."
                )
                if self.cursor >= len(self.rows):
                    self.finished = True
            elif self.phase == "loop" and self.step_index >= len(LOOP_STEPS):
                self.step_index = 0
                self.anexo_cursor = 0
                finished_row = self.rows[self.cursor]
                finished_rut = format_rut(finished_row.get("RUT"), finished_row.get("DV"))
                self.cursor += 1
                self.rows_done += 1
                # A RUT with multiple pagarés gets one planilla ROW per
                # pagaré (clean06's "filas de repetición"), all sharing the
                # SAME RUT — but resolve_anexo_items() already globs and
                # attaches EVERY pagaré for a RUT while processing its FIRST
                # row. The rest are now pure duplicates: skip them so
                # click_ingresar is never repeated for a causa PJUD already
                # has, instead of filing it a second/third time.
                skipped = 0
                while (
                    finished_rut
                    and self.cursor < len(self.rows)
                    and format_rut(
                        self.rows[self.cursor].get("RUT"), self.rows[self.cursor].get("DV")
                    ) == finished_rut
                ):
                    self.cursor += 1
                    self.rows_done += 1
                    skipped += 1
                if skipped:
                    self.logs.append(
                        f"Se omitieron {skipped} fila(s) repetidas del RUT {finished_rut} "
                        "(sus pagarés ya fueron adjuntados junto con la primera fila)."
                    )
                # Whatever row the cursor landed on next might itself have no
                # signed demanda (or be a repeat of one that doesn't).
                self._advance_past_unfileable_rows()
                # The loop is still partial, so the last defined step IS the
                # end of that row's work for now. The message names it so the
                # operator can see how far the bot got without opening the log.
                self.completion_message = (
                    f"Bot ha finalizado correctamente en Step {step_number}"
                )
                if HALT_AFTER_FIRST_ROW or self.cursor >= len(self.rows):
                    self.finished = True
            return self._report_reply_unlocked()

    def _report_reply_unlocked(self) -> dict[str, Any]:
        return {
            "ok": True,
            "done": self.finished,
            "message": self.completion_message or DEFAULT_DONE_MESSAGE,
            "error": self.error,
            "rowsDone": self.rows_done,
            "rowTotal": len(self.rows),
            "stepsDone": self.steps_done,
        }

    def _done_step_unlocked(self) -> dict[str, Any]:
        return {
            "action": "done",
            "message": self.completion_message or DEFAULT_DONE_MESSAGE,
            "error": self.error,
            "rowTotal": len(self.rows),
            "rowsDone": self.rows_done,
            "stepsDone": self.steps_done,
            "pdfCount": int(self.demandas.get("pdf_count", 0)),
        }

    def touch_extension(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            self.extension_seen_at = now
            self.started_at = now
            self.portal_url = str(payload.get("url") or "")[:1000]
            self.portal_title = str(payload.get("title") or "")[:300]
            self.logs.append(f"Start recibido desde {self.portal_url or 'el portal PJUD'}.")
            if PORTAL_START_PAGE.lower() not in self.portal_url.lower():
                self.logs.append(
                    "Aviso: el Start no se presionó desde "
                    f"{PORTAL_START_PAGE}. Se registró igualmente."
                )

            # Reloading the bot files does NOT reload the extension Chrome has
            # already loaded, so the two can drift: the desktop hands out a step
            # the loaded content script never heard of. Catch that HERE, before
            # anything is touched on the portal, instead of halfway through a
            # form. The expected value is read from the extension's own
            # manifest, so there is no second constant to keep in sync.
            # A MISSING build is itself proof of staleness: every extension from
            # 0.7.2 on reports it, so silence means the loaded copy predates the
            # check. That is what makes this gate work on the very first run
            # after updating, which is exactly when the drift happens.
            loaded = _normalize_build(payload.get("build"))
            on_disk = _normalize_build(extension_manifest_version())
            if on_disk and loaded != on_disk:
                came_as = loaded or "una versión anterior a 0.7.2 (no informó su versión)"
                self.error = (
                    f"La extensión cargada en Chrome es {came_as}, pero el bot "
                    f"instalado es la {on_disk}. Recarga la extensión en "
                    "chrome://extensions y luego recarga la pestaña del portal. "
                    "No se tocó el portal."
                )
                self.completion_message = (
                    f"La extensión cargada ({loaded}) es más antigua que el bot "
                    f"({on_disk}). Recárgala en chrome://extensions y luego "
                    "recarga la pestaña del portal."
                )
                self.logs.append(self.error)
                self.finished = True
                # ok=True on purpose: the request WAS handled. The extension
                # treats ok=False as a transport failure and would let the
                # /health poller overwrite this message a second later, hiding
                # the real cause behind "Bridge no conectado".
                return {"ok": True, "done": True, "error": self.error,
                        "message": self.completion_message}
            if loaded:
                self.logs.append(f"Extensión build {loaded} (bot {on_disk or '?'}).")
            return {
                "ok": True,
                "message": (
                    f"Conexión confirmada. Planilla con {len(self.rows)} fila(s) y "
                    f"{int(self.demandas.get('pdf_count', 0))} PDF(s) listos."
                ),
                "summary": self._summary_unlocked(),
            }

    def add_log(self, message: str) -> None:
        clean = " ".join(str(message or "").split())
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean[:500])
            self.logs = self.logs[-100:]

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        return {
            "bot_id": BOT_ID,
            "bot_label": BOT_LABEL,
            "extension_seen": self.extension_seen_at > 0,
            "extension_seen_at": self.extension_seen_at,
            "started": self.started_at > 0,
            "started_at": self.started_at,
            "portal_url": self.portal_url,
            "portal_title": self.portal_title,
            "input_path": self.input_path,
            "workbook": dict(self.workbook),
            "demandas": dict(self.demandas),
            "mandatos": dict(self.mandatos),
            "contratos": dict(self.contratos),
            "carpeta_ruts": dict(self.carpeta_ruts),
            "workflow_configured": True,
            "phase": self.phase,
            "step_total": len(PREP_STEPS) + len(LOOP_STEPS),
            "steps_done": self.steps_done,
            "last_step_done": self.last_step_done,
            "rows_done": self.rows_done,
            "row_total": len(self.rows),
            "completion_message": self.completion_message,
            "finished": self.finished,
            "error": self.error,
            "logs": list(self.logs),
        }


class Clean07BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], state: BridgeState):
        super().__init__(server_address, Clean07BridgeHandler)
        self.state = state


class Clean07BridgeHandler(BaseHTTPRequestHandler):
    server: Clean07BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self._send_empty(204)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "name": "Clean07 PJUD bridge",
                "summary": self.server.state.summary(),
            })
            return
        if self.path.startswith("/file"):
            self._serve_row_file()
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _serve_row_file(self) -> None:
        """Stream one of THIS row's own PDFs as raw bytes.

        GET /file?row=N (kind defaults to "demanda", the Documento Principal
        attach) or GET /file?row=N&kind=anexo&index=I (0-based index into
        resolve_anexo_items — the Documento Anexo mini-loop's combined
        pagaré/contrato/mandato list).

        background.js relays this over the mixed-content-safe extension
        channel and base64-encodes the response for content.js — the page is
        HTTPS and the bridge is plain HTTP, so a content script cannot fetch
        this endpoint directly.
        """
        query = urllib.parse.urlsplit(self.path).query
        params = urllib.parse.parse_qs(query)
        try:
            row_number = int((params.get("row") or [""])[0])
        except (TypeError, ValueError):
            row_number = 0
        kind = (params.get("kind") or ["demanda"])[0]

        if kind == "anexo":
            try:
                anexo_index = int((params.get("index") or [""])[0])
            except (TypeError, ValueError):
                anexo_index = -1
            path = self.server.state.resolve_anexo_file(row_number, anexo_index)
            missing_error = (
                f"No hay documento anexo #{anexo_index + 1} disponible para la fila {row_number}."
            )
        else:
            path = self.server.state.resolve_demanda_file(row_number)
            missing_error = f"No hay demanda firmada disponible para la fila {row_number}."

        if path is None:
            self._send_json({"ok": False, "error": missing_error}, status=404)
            return

        try:
            data = path.read_bytes()
        except OSError as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=500)
            return

        self.send_response(200)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.send_header("X-Filename", path.name)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self) -> None:
        if self.path.startswith("/start"):
            self._send_json(self.server.state.register_start(self._read_json()))
            return
        if self.path.startswith("/next"):
            self._send_json({"ok": True, "step": self.server.state.next_action()})
            return
        if self.path.startswith("/report"):
            self._send_json(self.server.state.report_action(self._read_json()))
            return
        if self.path.startswith("/log"):
            payload = self._read_json()
            message = str(payload.get("message") or "")
            self.server.state.add_log(message)
            print(f"CLEAN07[EXT]: {message}")
            self._send_json({"ok": True})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _send_empty(self, status: int) -> None:
        self.send_response(status)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


def build_bridge_state(
    planilla_path: str,
    mandatos_folder: str,
    contratos_folder: str,
    demandas_folder: str,
    carpeta_ruts_folder: str,
) -> BridgeState:
    """Validate every input and create the in-memory bridge session.

    Raises before the bridge exists, so a rejected planilla or a missing
    document never reaches the browser and the operator gets the exact cause
    in BotManager instead of a failure halfway through a real ingreso.
    """
    target = str(Path(planilla_path).expanduser().resolve())
    workbook = inspect_excel(target)
    rows = read_rows(target, workbook["sheet_name"], workbook["columns"])
    if not rows:
        raise InputError(
            "La planilla no tiene filas de datos bajo el encabezado.",
            reason="planilla_sin_filas",
            detail=workbook["filename"],
        )

    mandatos = inspect_mandatos_folder(mandatos_folder)
    contratos = inspect_contratos_folder(contratos_folder, rows)
    demandas = inspect_demandas_folder(demandas_folder, rows)
    carpeta_ruts = inspect_carpeta_ruts_folder(carpeta_ruts_folder, rows)

    # Every RUT gets a results entry up front, "No procesada", so a RUT the
    # run never reaches (stopped/crashed earlier) still shows up in the
    # output instead of silently vanishing.
    results: dict[str, dict[str, Any]] = {}
    for row in rows:
        rut = format_rut(row.get("RUT"), row.get("DV"))
        if rut and rut not in results:
            results[rut] = _blank_result(rut)

    return BridgeState(
        input_path=target,
        workbook=workbook,
        demandas=demandas,
        mandatos=mandatos,
        contratos=contratos,
        carpeta_ruts=carpeta_ruts,
        rows=rows,
        results=results,
    )


def run_bridge_session(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
    output_dir: str,
    log_every_seconds: int = 15,
) -> dict[str, Any]:
    """Serve the loopback bridge until the extension finishes the steps.

    The server must stay up after Start, because that is when the extension
    begins asking /next and working the portal. It returns as soon as the
    session reports itself finished, or once the extension has been silent for
    EXTENSION_IDLE_SECONDS (tab closed mid-run).
    """
    try:
        server = Clean07BridgeServer((host, port), state)
    except OSError as exc:
        raise InputError(
            f"No se pudo abrir el bridge local en {host}:{port}. "
            "Puede que otra ejecución de Clean07 siga abierta.",
            reason="bridge_ocupado",
            detail=str(exc),
        ) from exc

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"Clean07: bridge escuchando en http://{host}:{port}")
    # Output folder marker for the desktop run detail.
    print(f"[CLEAN07][SALIDA] {output_dir}")

    deadline = time.time() + timeout_seconds
    last_log = 0.0
    try:
        while time.time() < deadline:
            summary = state.summary()
            now = time.time()
            if summary["finished"]:
                return summary
            if summary["started"] and now - summary["extension_seen_at"] > EXTENSION_IDLE_SECONDS:
                # Start was registered but the extension went silent mid-run.
                # The handshake happened, so report what was completed instead
                # of hanging until the global timeout.
                state.add_log(
                    "La extensión dejó de responder tras Start; se cierra la "
                    f"sesión con {state.steps_done} paso(s) completado(s)."
                )
                return state.summary()
            if now - last_log >= log_every_seconds:
                seen = "si" if summary["extension_seen"] else "no"
                if summary["started"]:
                    print(
                        f"Clean07: en curso | fila={summary['rows_done'] + 1}"
                        f"/{summary['row_total']} pasos_ok={summary['steps_done']}"
                    )
                else:
                    print(f"Clean07: esperando Start | extension_conectada={seen}")
                # Refresh the audit trail on the same tick. tasks.py writes it
                # again at the end, but only if it GETS there — a hard kill
                # (process killed, machine crash, Robocorp timeout) never
                # reaches that code, and a causa already filed with no record
                # of it is exactly what this file exists to prevent.
                try:
                    write_result_excel(state.results, Path(output_dir) / RESULT_EXCEL_FILENAME)
                except Exception as exc:  # noqa: BLE001
                    # Never let a transient write failure (operator has the
                    # workbook open in Excel, locking it) kill a live run —
                    # the final write at the end gets another chance.
                    print(f"Clean07: no se pudo actualizar el resultado parcial ({exc}).")
                last_log = now
            time.sleep(0.5)
        raise TimeoutError(
            "Clean07: timeout esperando la conexión de la extensión de Chrome."
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3.0)


def write_bridge_receipt(summary: dict[str, Any], output_dir: str) -> str:
    """Persist a small receipt proving that the desktop/extension bridge worked."""
    target = Path(output_dir) / "bridge_connection.json"
    payload = dict(summary)
    payload["receipt_created_at"] = time.time()
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(target)


def _result_columns(results: dict[str, dict[str, Any]]) -> list[tuple[str, Any]]:
    """RESULT_FIXED_COLUMNS plus PAGARE-1..N, N = the widest RUT in ``results``.

    Shared by write_result_excel and build_result_summary_json so the desktop
    run-detail table can never show different columns than the actual file.
    """
    max_pagares = max((len(entry.get("pagares") or []) for entry in results.values()), default=0)
    columns: list[tuple[str, Any]] = list(RESULT_FIXED_COLUMNS)
    for position in range(1, max_pagares + 1):
        columns.append((f"PAGARE-{position}", ("pagares", position - 1)))
    return columns


def _result_cell_value(entry: dict[str, Any], key: Any) -> Any:
    if isinstance(key, tuple):
        field, pagare_index = key
        values_list = entry.get(field) or []
        return values_list[pagare_index] if pagare_index < len(values_list) else None
    return entry.get(key)


def build_result_summary_json(results: dict[str, dict[str, Any]]) -> str:
    """Compact JSON of the SAME table write_result_excel writes.

    Printed as a single [CLEAN07][DETALLE] log marker so the desktop's
    run-detail panel — a pure-QML log parser, see
    app/desktop/qml/run_summary/Clean07Summary.qml — can render the identical
    table without reading the .xlsx itself. No Python plugin is involved, so
    this ships as a bot-pack update, never a core rebuild.

    Arrays, not objects: the desktop truncates a run's log to its last
    ~20,000 characters before handing it to QML, so every byte saved here is
    margin against that limit. Callers must print this as the LAST thing in
    the run (after tasks.py's own re-print of final_summary["logs"]), or a
    long PJUD-portal run can push it out of that tail window entirely.
    """
    columns = _result_columns(results)
    headers = [header for header, _ in columns]
    rows = [
        [_result_cell_value(entry, key) for _, key in columns]
        for entry in results.values()
    ]
    return json.dumps({"columns": headers, "rows": rows}, ensure_ascii=False, separators=(",", ":"))


def write_result_excel(results: dict[str, dict[str, Any]], output_path: str | Path) -> str:
    """Write the per-RUT audit trail: which documents actually landed on PJUD.

    One row per RUT (``results`` is already keyed that way — built up front
    by build_bridge_state with every RUT "No procesada", then updated live by
    report_action as each causa files and each document confirms). Called
    unconditionally right after run_bridge_session returns, success or
    failure, so a run that stops partway still produces this file instead of
    leaving the operator guessing what was and wasn't attempted.

    Colors mirror clean06's own convention (GREEN=fila OK / YELLOW=necesita
    atención, see bots/clean06_crear-planilla-ingreso-demandas/functions.py):
    GREEN for a confirmed "Ingresado" cell AND for one genuinely not required
    for that RUT (blank); YELLOW for "No Ingresado" or an ESTADO that needs a
    manual look. PAGARE-N columns are built dynamically from whichever RUT in
    THIS run has the most pagarés, not a fixed count.
    """
    import openpyxl

    fill_green = openpyxl.styles.PatternFill("solid", fgColor="FFC6EFCE")
    fill_yellow = openpyxl.styles.PatternFill("solid", fgColor="FFFFEB9C")
    fill_header = openpyxl.styles.PatternFill("solid", fgColor="FFD9D9D9")

    columns = _result_columns(results)

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Resultado Ingreso"

    for column_index, (header, _) in enumerate(columns, start=1):
        cell = sheet.cell(row=1, column=column_index, value=header)
        cell.font = openpyxl.styles.Font(bold=True)
        cell.fill = fill_header
        cell.alignment = openpyxl.styles.Alignment(vertical="center", wrap_text=True)
        sheet.column_dimensions[openpyxl.utils.get_column_letter(column_index)].width = 16
    sheet.freeze_panes = "A2"
    sheet.row_dimensions[1].height = 24

    for row_offset, entry in enumerate(results.values(), start=2):
        for column_index, (header, key) in enumerate(columns, start=1):
            value = _result_cell_value(entry, key)
            cell = sheet.cell(row=row_offset, column=column_index, value=value)
            if header in ("RUT", "DETALLE"):
                continue
            if header == "ESTADO":
                cell.font = openpyxl.styles.Font(bold=True)
                cell.fill = fill_green if value == "Ingresada" else fill_yellow
            elif value in (None, "Ingresado"):
                cell.fill = fill_green
            else:
                cell.fill = fill_yellow

    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(str(target))
    return str(target)
