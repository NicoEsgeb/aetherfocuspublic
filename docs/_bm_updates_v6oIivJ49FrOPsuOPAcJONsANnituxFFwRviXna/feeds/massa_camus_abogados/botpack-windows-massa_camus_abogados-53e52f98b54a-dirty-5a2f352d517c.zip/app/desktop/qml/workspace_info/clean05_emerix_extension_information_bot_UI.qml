import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property color textMuted: Common.Theme.text2

    function botFolderPath() {
        if (typeof controller === "undefined" || controller === null || !controller.selectedBot)
            return ""
        return String(controller.selectedBot.workingDir || "").trim()
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
            text: "Información del bot"
            color: Common.Theme.text
            font.pixelSize: Common.Theme.fontSize(16)
            font.bold: true
            Layout.fillWidth: true
            wrapMode: Text.Wrap
        }

        Rectangle {
            radius: 6
            color: Common.Theme.accentSoft
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: cleanBadge.implicitWidth + 16
            implicitHeight: cleanBadge.implicitHeight + 8
            Label {
                id: cleanBadge
                anchors.centerIn: parent
                text: "Clean BBRR"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }

        Rectangle {
            radius: 6
            color: Common.Theme.successSoft
            border.width: 1
            border.color: Common.Theme.success
            implicitWidth: edgeBadge.implicitWidth + 16
            implicitHeight: edgeBadge.implicitHeight + 8
            Label {
                id: edgeBadge
                anchors.centerIn: parent
                text: "Edge real"
                color: Common.Theme.success
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }

        Common.InsetAlloyButton {
            id: openBotFolderButton
            text: "Abrir ubicación del Bot"
            hoverEnabled: true
            implicitHeight: 34
            leftPadding: 12
            rightPadding: 12
            enabled: root.botFolderPath().length > 0
            onClicked: {
                var targetPath = root.botFolderPath()
                if (targetPath.length > 0)
                    controller.openPathInExplorer(targetPath)
            }
            contentItem: RowLayout {
                spacing: 7

                Item {
                    Layout.preferredWidth: 17
                    Layout.preferredHeight: 15

                    Rectangle {
                        x: 1
                        y: 4
                        width: 15
                        height: 10
                        radius: 2
                        color: "transparent"
                        border.width: 1.4
                        border.color: Common.Theme.text
                    }

                    Rectangle {
                        x: 2
                        y: 1
                        width: 7
                        height: 5
                        radius: 1
                        color: "transparent"
                        border.width: 1.4
                        border.color: Common.Theme.text
                    }
                }

                Label {
                    text: openBotFolderButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.weight: Font.DemiBold
                }
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Primera etapa disponible"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "Clean05 ya recibe un único Excel, abre un bridge local independiente y se enlaza con su propia extensión dentro de la sesión real de Emerix. El usuario conserva el control del login."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: stepsLayout.implicitHeight + 20

        ColumnLayout {
            id: stepsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Cómo probar la conexión"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "1. En Edge, abre edge://extensions, activa el modo desarrollador y carga bots/clean05_emerix-extension/extension.\n" +
                      "2. Selecciona el Excel y pulsa Iniciar bot en BotManager.\n" +
                      "3. Abre https://itau.emerix.net/emerix.ui/login e inicia sesión manualmente.\n" +
                      "4. En /emerix.ui/app/dashboard, presiona Start en el panel Clean05.\n\n" +
                      "La prueba genera bridge_connection.json en la carpeta output del bot."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.warningSoft
        border.width: 1
        border.color: Common.Theme.warning
        implicitHeight: pendingLayout.implicitHeight + 20

        ColumnLayout {
            id: pendingLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 4

            Label {
                text: "Pendiente de definición"
                color: Common.Theme.warning
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "La navegación posterior a Start, las columnas del Excel y el resultado final se agregarán cuando Massa-Camus defina el recorrido de Clean05."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
