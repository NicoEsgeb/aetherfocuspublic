(() => {
  const MESSAGE_TYPE = "CLEAN08_BRIDGE_REQUEST";
  const PANEL_ID = "clean08-pjud-panel";
  const BUILD = "v0.17.1";
  const START_PAGE = "indexn.php";
  const SIBLING_PANEL_IDS = [
    "clean07-pjud-panel",
    "rpa01-pjud-panel",
    "n03-pjud-panel"
  ];

  let connected = false;
  let starting = false;
  let verified = false;
  let busy = false;
  let completed = false;
  let workTimer = 0;
  let pendingPrincipalBytes = 0;
  let pendingPrincipalFilename = "";
  let principalSizeBaseline = 0;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) return existing;

    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean08-title">Clean08 · Ampliación Domicilios · ${BUILD}</div>
      <div class="clean08-status" data-role="status">Esperando BotManager...</div>
      <div class="clean08-details" data-role="details">Planilla sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    positionPanel();
    return panel;
  }

  function positionPanel() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;
    let offset = 14;
    for (const id of SIBLING_PANEL_IDS) {
      const sibling = document.getElementById(id);
      if (sibling) offset += sibling.offsetHeight + 10;
    }
    panel.style.bottom = `${offset}px`;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean08-ok", tone === "ok");
    status.classList.toggle("clean08-error", tone === "error");
  }

  function renderSummary(summary) {
    const details = createPanel().querySelector('[data-role="details"]');
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const escritos = summary && summary.escritos ? summary.escritos : {};
    if (!workbook.filename) {
      details.textContent = "Planilla sin confirmar";
      return;
    }
    details.textContent = `${workbook.filename} · ${summary.row_total || 0} fila(s) · `
      + `${escritos.pdf_count || 0} PDF(s)`;
  }

  function foldLabel(value) {
    return String(value == null ? "" : value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function isVisible(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function tidy(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function findVisibleLabel(labelText) {
    const wanted = foldLabel(labelText);
    const labels = Array.from(document.querySelectorAll("label"));
    return labels.find((label) => (
      isVisible(label) && foldLabel(label.textContent) === wanted
    )) || null;
  }

  function findSelect2ContainerNear(label) {
    const formGroup = label.closest(".form-group") || label.parentElement;
    return formGroup ? formGroup.querySelector(".select2-container") : null;
  }

  function fireMouse(element, type) {
    element.dispatchEvent(new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window,
      button: 0
    }));
  }

  function findSelect2Drop(container) {
    // Select2 v3 links the visible control to its drop through the focusser id:
    // s2id_autogen6 -> s2id_autogen6_search. Prefer that exact relationship,
    // then fall back to the shared visible #select2-drop from the supplied DOM.
    const focusser = container.querySelector("input.select2-focusser");
    if (focusser && focusser.id) {
      const search = document.getElementById(`${focusser.id}_search`);
      const ownDrop = search && search.closest(".select2-drop");
      if (isVisible(ownDrop)) return ownDrop;
    }
    const sharedDrop = document.getElementById("select2-drop");
    return isVisible(sharedDrop) ? sharedDrop : null;
  }

  function select2Options(drop) {
    return Array.from(drop.querySelectorAll("li.select2-result-selectable"));
  }

  function chooseSelect2Option(option) {
    // Select2 v3 commits on mouseup. A bare option.click() is insufficient.
    fireMouse(option, "mousedown");
    fireMouse(option, "mouseup");
    fireMouse(option, "click");
  }

  async function selectLabeledSelect2(step, fieldName) {
    const wanted = String(step.value || "").trim();
    if (!wanted) {
      throw new Error(`No se recibió el valor requerido para ${fieldName}.`);
    }
    const label = await waitFor(
      () => findVisibleLabel(fieldName),
      15000,
      `No se cargó la página de Ingresar Escrito: no apareció ${fieldName}.`
    );
    const container = findSelect2ContainerNear(label);
    if (!container) {
      throw new Error(`El campo ${fieldName} no expone su control Select2.`);
    }
    const choice = container.querySelector("a.select2-choice");
    if (!choice) {
      throw new Error(`El campo ${fieldName} no tiene un desplegable utilizable.`);
    }

    fireMouse(choice, "mousedown");
    fireMouse(choice, "mouseup");
    fireMouse(choice, "click");
    const drop = await waitFor(
      () => findSelect2Drop(container),
      8000,
      `No se abrió el desplegable de ${fieldName}.`
    );
    await waitFor(
      () => (select2Options(drop).length ? true : null),
      8000,
      `El desplegable de ${fieldName} no cargó opciones.`
    );

    const options = select2Options(drop);
    const option = options.find((item) => foldLabel(item.textContent) === foldLabel(wanted));
    if (!option) {
      const offered = options.map((item) => tidy(item.textContent)).filter(Boolean);
      throw new Error(
        `No apareció la opción "${wanted}" en ${fieldName}. `
        + `El portal ofrece: ${offered.length ? offered.join(" · ") : "(ninguna)"}`
      );
    }
    chooseSelect2Option(option);
    await waitFor(
      () => {
        const chosen = container.querySelector(".select2-chosen");
        return chosen && foldLabel(chosen.textContent) === foldLabel(wanted) ? true : null;
      },
      8000,
      `${fieldName} no quedó en "${wanted}" después de seleccionarlo.`
    );
    return `Step ${step.step_number} completado: ${fieldName} = ${wanted}.`;
  }

  function selectCompetencia(step) {
    return selectLabeledSelect2(step, "Competencia");
  }

  function selectTribunal(step) {
    return selectLabeledSelect2(step, "Tribunal");
  }

  async function selectTipo(step) {
    const wanted = String(step.value || "C").trim();
    const label = await waitFor(
      () => findVisibleLabel("Tipo"),
      15000,
      "No apareció el campo Tipo después de seleccionar el tribunal."
    );
    const formGroup = label.closest(".form-group") || label.parentElement;
    const select = formGroup ? formGroup.querySelector("select.form-control") : null;
    if (!select) {
      throw new Error("El campo Tipo no contiene un selector utilizable.");
    }

    const options = Array.from(select.options);
    const optionIndex = options.findIndex(
      (option) => foldLabel(option.textContent) === foldLabel(wanted)
    );
    if (optionIndex < 0) {
      const offered = options.map((option) => tidy(option.textContent)).filter(Boolean);
      throw new Error(
        `No apareció la opción "${wanted}" en Tipo. `
        + `El portal ofrece: ${offered.length ? offered.join(" · ") : "(ninguna)"}`
      );
    }

    // PJUD renders every option with value="", so selecting by .value cannot
    // distinguish A/C/E/F/I/V. Select by visible-text index and notify Knockout.
    select.selectedIndex = optionIndex;
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    await waitFor(
      () => {
        const selected = select.options[select.selectedIndex];
        return selected && foldLabel(selected.textContent) === foldLabel(wanted)
          ? true
          : null;
      },
      5000,
      `Tipo no quedó en "${wanted}" después de seleccionarlo.`
    );
    return `Step ${step.step_number} completado: Tipo = ${wanted}.`;
  }

  async function fillRol(step) {
    const wanted = String(step.value || "").trim();
    if (!/^\d+$/.test(wanted)) {
      throw new Error("No se recibió un ROL numérico válido.");
    }
    const label = await waitFor(
      () => findVisibleLabel("Rol"),
      15000,
      "No apareció el campo Rol después de seleccionar Tipo."
    );
    const formGroup = label.closest(".form-group") || label.parentElement;
    const input = formGroup ? formGroup.querySelector('input[type="text"]') : null;
    if (!input) {
      throw new Error("El campo Rol no contiene una caja de texto utilizable.");
    }

    input.focus();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.value = wanted;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();
    await waitFor(
      () => String(input.value).trim() === wanted ? true : null,
      5000,
      `Rol no quedó en "${wanted}" después de ingresarlo.`
    );
    return `Step ${step.step_number} completado: ROL = ${wanted}.`;
  }

  function selectAnio(step) {
    return selectLabeledSelect2(step, "Año");
  }

  function findVisibleButton(buttonText, requireEnabled = false) {
    const wanted = foldLabel(buttonText);
    return Array.from(document.querySelectorAll('button[type="button"]')).find(
      (button) => (
        isVisible(button)
        && foldLabel(button.textContent) === wanted
        && (!requireEnabled || !button.disabled)
      )
    ) || null;
  }

  async function clickConsultaRol(step) {
    await waitFor(
      () => findVisibleButton("Consulta Rol"),
      15000,
      'No apareció el botón "Consulta Rol".'
    );
    const button = await waitFor(
      () => findVisibleButton("Consulta Rol", true),
      10000,
      'El botón "Consulta Rol" no se habilitó después de completar los campos.'
    );
    button.click();
    await waitFor(
      () => findVisibleLabel("Cuaderno"),
      30000,
      'Se pulsó "Consulta Rol", pero no apareció el resultado con el campo Cuaderno.'
    );
    return `Step ${step.step_number} completado: Consulta Rol cargó el resultado.`;
  }

  function selectCuaderno(step) {
    return selectLabeledSelect2(step, "Cuaderno");
  }

  function selectPartePresenta(step) {
    return selectLabeledSelect2(step, "Parte que Presenta");
  }

  function selectGrupoEscrito(step) {
    return selectLabeledSelect2(step, "Grupo Escrito");
  }

  function selectTipoEscrito(step) {
    return selectLabeledSelect2(step, "Tipo Escrito");
  }

  async function clickGrabarEscrito(step) {
    await waitFor(
      () => findVisibleButton("Grabar Escrito"),
      15000,
      'No apareció el botón "Grabar Escrito".'
    );
    const button = await waitFor(
      () => findVisibleButton("Grabar Escrito", true),
      10000,
      'El botón "Grabar Escrito" no se habilitó después de completar el formulario.'
    );
    button.click();
    try {
      await waitFor(
        () => {
          const element = document.getElementById("dDPrincipal");
          return isVisible(element) ? element : null;
        },
        20000,
        'Se pulsó "Grabar Escrito", pero no apareció la ventana para adjuntar archivos.'
      );
    } catch (error) {
      // The click already crossed the point of no return even if its visual
      // confirmation never arrived. Preserve that distinction for the result.
      error.filed = true;
      throw error;
    }
    return {
      message: `Step ${step.step_number} completado: Grabar Escrito abrió la ventana de adjuntos.`,
      filed: true
    };
  }

  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }

  const BYTES_PER_MB = 1048576;
  const TAMANO_EPSILON = 0.0002;

  function findDocumentoPrincipalList() {
    return Array.from(document.querySelectorAll('[data-bind*="documentoPrincipal"]'))
      .find((element) => (
        /foreach:\s*\{\s*data:\s*documentoPrincipal/.test(
          element.getAttribute("data-bind") || ""
        )
      )) || null;
  }

  function readDocumentoPrincipalCards() {
    const list = findDocumentoPrincipalList();
    if (!list) return [];
    return Array.from(list.children).map((card) => {
      const sizeElement = card.querySelector('[data-bind*="tamano()"]');
      const sizeText = tidy(sizeElement ? sizeElement.textContent : "");
      const sizeMatch = sizeText.match(/(\d+(?:[.,]\d+)?)/);
      return {
        card,
        sizeText,
        tamanoValue: sizeMatch ? Number(sizeMatch[1].replace(",", ".")) : NaN
      };
    });
  }

  function matchesUploadedSize(card, bytes) {
    if (!bytes || !Number.isFinite(card.tamanoValue)) return false;
    return Math.abs(card.tamanoValue - bytes / BYTES_PER_MB) <= TAMANO_EPSILON;
  }

  function matchingPrincipalCards(bytes) {
    return readDocumentoPrincipalCards().filter((card) => matchesUploadedSize(card, bytes));
  }

  async function uploadEscritoFile(step) {
    const dropzone = await waitFor(
      () => {
        const element = document.getElementById("dDPrincipal");
        return isVisible(element) ? element : null;
      },
      20000,
      'No apareció la ventana para adjuntar el escrito después de "Grabar Escrito".'
    );
    const input = await waitFor(
      () => dropzone.querySelector('#uploadMultiFileDocPrincipal[type="file"]'),
      8000,
      "No se encontró el selector oculto para el PDF del escrito."
    );
    const result = await bridgeRequest("/file");
    const bytes = base64ToBytes(result.content_base64);
    if (!bytes.length) {
      throw new Error(`El archivo ${result.filename || "PDF"} está vacío.`);
    }

    const file = new File([bytes], result.filename, { type: "application/pdf" });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    input.files = dataTransfer.files;

    // Verify the browser accepted the assignment before PJUD sees the change.
    // PJUD is allowed to clear the native input while consuming that event, so
    // requiring input.files to remain populated afterwards is a false failure.
    const selected = input.files && input.files[0];
    if (!selected
        || selected.name !== result.filename
        || selected.size !== bytes.length) {
      throw new Error(`Chrome no pudo preparar el PDF ${result.filename}.`);
    }

    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    const button = await waitFor(
      () => {
        const currentDropzone = document.getElementById("dDPrincipal");
        return isVisible(currentDropzone)
          ? currentDropzone.querySelector('button[data-bind*="uploadDocumentoPrincipal"]')
          : null;
      },
      8000,
      'No se encontró el botón "Adjuntar" del escrito principal.'
    );
    await waitFor(
      () => !button.disabled || null,
      10000,
      'El botón "Adjuntar" no se habilitó después de seleccionar el PDF.'
    );
    pendingPrincipalBytes = bytes.length;
    pendingPrincipalFilename = result.filename;
    principalSizeBaseline = matchingPrincipalCards(bytes.length).length;
    button.click();
    return {
      message: `Step ${step.step_number} completado: se envió ${result.filename} (${bytes.length} bytes) con Adjuntar.`,
      filed: true
    };
  }

  async function awaitEscritoUploaded(step) {
    if (!pendingPrincipalBytes || !pendingPrincipalFilename) {
      throw new Error("No hay un PDF pendiente para confirmar en PJUD.");
    }
    const uploadedCard = await waitFor(
      () => {
        const matches = matchingPrincipalCards(pendingPrincipalBytes);
        return matches.length > principalSizeBaseline
          ? matches[matches.length - 1]
          : null;
      },
      180000,
      `PJUD no confirmó la carga de ${pendingPrincipalFilename} después de 3 minutos.`
    );
    return {
      message: `Step ${step.step_number} completado: PJUD confirmó ${pendingPrincipalFilename} (${uploadedCard.sizeText}).`,
      filed: true,
      confirmed: true
    };
  }

  async function clickCerrarContinuar(step) {
    const button = await waitFor(
      () => Array.from(document.querySelectorAll('button[data-bind*="cerrarAdjuntar"]'))
        .find((element) => (
          isVisible(element)
          && foldLabel(element.textContent) === foldLabel("Cerrar y Continuar")
        )) || null,
      15000,
      'No se encontró el botón "Cerrar y Continuar" de la ventana de adjuntos.'
    );
    await waitFor(
      () => !button.disabled || null,
      10000,
      'El botón "Cerrar y Continuar" no se habilitó.'
    );
    const dropzone = document.getElementById("dDPrincipal");
    button.click();
    await waitFor(
      () => (!isVisible(button) && !isVisible(dropzone) ? true : null),
      20000,
      'La ventana de adjuntos no se cerró después de pulsar "Cerrar y Continuar".'
    );
    pendingPrincipalBytes = 0;
    pendingPrincipalFilename = "";
    principalSizeBaseline = 0;
    return {
      message: `Step ${step.step_number} completado: se cerró la ventana con "Cerrar y Continuar".`,
      filed: true,
      modal_closed: true
    };
  }

  function pressEscape() {
    const target = document.activeElement || document.body;
    for (const type of ["keydown", "keyup"]) {
      target.dispatchEvent(new KeyboardEvent(type, {
        key: "Escape",
        code: "Escape",
        keyCode: 27,
        which: 27,
        bubbles: true,
        cancelable: true
      }));
    }
  }

  function visibleCerrarContinuarButton() {
    return Array.from(document.querySelectorAll('button[data-bind*="cerrarAdjuntar"]'))
      .find((element) => (
        isVisible(element)
        && foldLabel(element.textContent) === foldLabel("Cerrar y Continuar")
      )) || null;
  }

  async function recoverAfterRowFailure(step) {
    const notes = [];
    let modalClosed = false;
    try {
      // A failed Select2 lookup can leave its dropdown above the next form.
      // Escape is harmless when no dropdown is open.
      pressEscape();
      const attachmentWindow = document.getElementById("dDPrincipal");
      const closeButton = visibleCerrarContinuarButton();
      if (isVisible(attachmentWindow) || closeButton) {
        const button = await waitFor(
          visibleCerrarContinuarButton,
          15000,
          'La recuperación no encontró "Cerrar y Continuar" en la ventana de adjuntos.'
        );
        await waitFor(
          () => !button.disabled || null,
          60000,
          'La recuperación esperó 60 segundos, pero "Cerrar y Continuar" no se habilitó.'
        );
        button.click();
        await waitFor(
          () => (!isVisible(button) && !isVisible(attachmentWindow) ? true : null),
          30000,
          "La recuperación pulsó Cerrar y Continuar, pero la ventana no desapareció."
        );
        notes.push("ventana de adjuntos cerrada");
        modalClosed = true;
      } else {
        notes.push("sin ventana de adjuntos abierta");
      }

      await waitFor(
        findIngresarEscrito,
        15000,
        'La recuperación no encontró "Ingresar Escrito" para comenzar la próxima fila.'
      );
      notes.push('menú "Ingresar Escrito" disponible');
      return {
        message: `Recuperación de fila Excel ${step.excel_row}: ${notes.join("; ")}.`,
        modal_closed: modalClosed
      };
    } finally {
      pendingPrincipalBytes = 0;
      pendingPrincipalFilename = "";
      principalSizeBaseline = 0;
    }
  }

  function findIngresarEscrito() {
    const wanted = foldLabel("Ingresar Escrito");
    const labels = Array.from(document.querySelectorAll(
      ".pg_menu_lt span, .list-group-item span"
    ));
    return labels.find((element) => (
      isVisible(element) && foldLabel(element.textContent) === wanted
    )) || null;
  }

  function waitFor(probe, timeoutMs, errorMessage) {
    return new Promise((resolve, reject) => {
      const immediate = probe();
      if (immediate) {
        resolve(immediate);
        return;
      }
      const deadline = Date.now() + timeoutMs;
      const timer = window.setInterval(() => {
        const result = probe();
        if (result) {
          window.clearInterval(timer);
          resolve(result);
        } else if (Date.now() >= deadline) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }

  async function clickIngresarEscrito() {
    const previousCompetencia = findVisibleLabel("Competencia");
    const label = await waitFor(
      findIngresarEscrito,
      15000,
      "No se encontró la opción 'Ingresar Escrito' en el menú visible."
    );
    const target = label.closest(".pg_menu_lt, .list-group-item") || label;
    target.click();
    await waitFor(
      () => {
        const current = findVisibleLabel("Competencia");
        if (!current) return null;
        if (!previousCompetencia || current !== previousCompetencia) return current;
        const container = findSelect2ContainerNear(current);
        const chosen = container ? container.querySelector(".select2-chosen") : null;
        return chosen && foldLabel(chosen.textContent) !== foldLabel("Civil")
          ? current
          : null;
      },
      20000,
      'Se pulsó "Ingresar Escrito", pero no se cargó un formulario nuevo.'
    );
    return 'Step 1 completado: "Ingresar Escrito" cargó un formulario nuevo.';
  }

  const STEP_HANDLERS = {
    click_ingresar_escrito: clickIngresarEscrito,
    select_competencia: selectCompetencia,
    select_tribunal: selectTribunal,
    select_tipo: selectTipo,
    fill_rol: fillRol,
    select_anio: selectAnio,
    click_consulta_rol: clickConsultaRol,
    select_cuaderno: selectCuaderno,
    select_parte_presenta: selectPartePresenta,
    select_grupo_escrito: selectGrupoEscrito,
    select_tipo_escrito: selectTipoEscrito,
    click_grabar_escrito: clickGrabarEscrito,
    upload_escrito_file: uploadEscritoFile,
    await_escrito_uploaded: awaitEscritoUploaded,
    click_cerrar_continuar: clickCerrarContinuar,
    recover_after_row_failure: recoverAfterRowFailure
  };

  function completionTone(payload) {
    const failedRows = Number(
      payload && payload.summary ? payload.summary.rows_failed : 0
    );
    return ((payload && payload.error) || failedRows > 0) ? "error" : "ok";
  }

  function finish(payload, tone = "ok") {
    completed = true;
    window.clearInterval(workTimer);
    const failed = tone === "error" || Boolean(payload && payload.error);
    setStatus(
      (payload && payload.message)
        || (failed ? "Clean08 se detuvo durante el recorrido." : "Steps completados."),
      failed ? "error" : "ok"
    );
    createPanel().querySelector('[data-role="details"]').textContent =
      "Revisa el resultado en BotManager.";
  }

  async function reportStep(body) {
    try {
      return await bridgeRequest("/report", { method: "POST", body });
    } catch (error) {
      completed = true;
      window.clearInterval(workTimer);
      setStatus(
        `No se pudo informar el resultado (${error.message || error}). `
          + "Se detuvo para no repetir el paso en el portal.",
        "error"
      );
      return null;
    }
  }

  async function pumpWork() {
    if (!verified || busy || completed) return;
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};
      if (step.action === "wait") return;
      if (step.action === "done") {
        finish(step, step.error ? "error" : "ok");
        return;
      }
      const handler = STEP_HANDLERS[step.action];
      if (!handler) {
        const detail = `Paso desconocido: ${step.action || "(vacío)"}. Recarga la extensión.`;
        const reply = await reportStep({ ok: false, detail });
        if (reply && reply.done) finish(reply, completionTone(reply));
        return;
      }

      setStatus(
        step.recovery
          ? `Fila ${step.row_number}/${step.row_total} · Recuperando después de Step `
            + `${step.failed_step_number}...`
          : `Fila ${step.row_number}/${step.row_total} · `
            + `Step ${step.step_number}/${step.step_total} · ${step.label || step.action}...`
      );
      try {
        const result = await handler(step);
        const richResult = result && typeof result === "object";
        const detail = richResult ? result.message : result;
        const reportBody = { ok: true, detail };
        if (richResult && Object.prototype.hasOwnProperty.call(result, "filed")) {
          reportBody.filed = Boolean(result.filed);
        }
        if (richResult && Object.prototype.hasOwnProperty.call(result, "confirmed")) {
          reportBody.confirmed = Boolean(result.confirmed);
        }
        if (richResult && Object.prototype.hasOwnProperty.call(result, "modal_closed")) {
          reportBody.modal_closed = Boolean(result.modal_closed);
        }
        logToBridge(detail);
        const reply = await reportStep(reportBody);
        if (reply && reply.done) {
          finish(reply, completionTone(reply));
        } else if (reply) {
          setStatus(reply.message || "Paso completado. Continuando...", "ok");
        }
      } catch (error) {
        const detail = `${error.message || error} [página: ${window.location.href}]`;
        logToBridge(detail);
        const reportBody = { ok: false, detail };
        if (error && Object.prototype.hasOwnProperty.call(error, "filed")) {
          reportBody.filed = Boolean(error.filed);
        }
        const reply = await reportStep(reportBody);
        if (reply && reply.done) {
          finish(reply, completionTone(reply));
        } else if (reply) {
          setStatus(reply.message || "Fila registrada con falla. Continuando...", "error");
        }
      }
    } catch (_) {
      if (!completed) {
        connected = false;
        setStatus("Se perdió la conexión con BotManager.", "error");
      }
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    positionPanel();
    if (verified || starting || completed) return;
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      setStatus(
        String(window.location.href).toLowerCase().includes(START_PAGE)
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Ve a indexN.php y presiona Start.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean08 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified || completed) return;
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) await bridgeRequest("/health");
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title, build: BUILD }
      });
      verified = true;
      renderSummary(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
