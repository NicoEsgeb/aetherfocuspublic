import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

// Run-detail table for the clean05 "Emerix (Extensión)" bot.
//
// IMPORTANT: this is a pure-QML log parser (no Python plugin), so it ships as a
// bot-pack/QML update — never a core rebuild. It receives the raw run log via
// summaryData.logText (wired as a fallback in Main.qml) and parses the bot's
// [CLEAN05][FILA] / [CLEAN05][RESUMEN] / [CLEAN05][SALIDA] / [CLEAN05][PROGRESS]
// markers itself. Shows one row per boleta with an OK (green) / Revisar (yellow)
// badge, RUT, DS and Boleta, a counts header, and an "Abrir carpeta" button.
Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarn: Common.Theme.warning

    function val(key, fallback) {
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null)
            return fallback
        return summaryData[key]
    }
    function logText() { return String(root.val("logText", "")) }
    function technicalStatus() { return String(root.val("statusTechnical", "")).toLowerCase() }
    function isSuccess() { return root.technicalStatus() === "success" }
    function isFailed() { return root.technicalStatus() === "failed" }
    function isCancelled() { return root.technicalStatus() === "cancelled" }
    function isRunning() {
        var s = root.technicalStatus()
        return s === "" || s === "running" || s === "queued"
    }

    // ---- log parsing ----
    function rows() {
        var re = /\[CLEAN05\]\[FILA\]\s+(\{.*\})/g
        var text = root.logText()
        var seen = ({})
        var order = []
        var m
        while ((m = re.exec(text)) !== null) {
            var data
            try { data = JSON.parse(m[1]) } catch (e) { continue }
            var estado = String(data.estado || "").toUpperCase()
            var isOk = estado === "OK"
            var key = String(data.excel)
            if (seen[key] === undefined) order.push(key)
            seen[key] = {
                "ok": isOk,
                "estadoLabel": isOk ? "OK" : "Revisar",
                "color": isOk ? "#31d39f" : "#ffcf5a",
                "rut": String(data.rut || ""),
                "ds": String(data.ds || ""),
                "boleta": String(data.boleta || "")
            }
        }
        var out = []
        for (var i = 0; i < order.length; i++) out.push(seen[order[i]])
        return out
    }

    function resumen() {
        var re = /\[CLEAN05\]\[RESUMEN\]\s+(.+)/g
        var text = root.logText()
        var m, last = null
        while ((m = re.exec(text)) !== null) last = m[1]
        var r = ({})
        if (last) {
            var kv = /(\w+)=(-?\d+)/g
            var k
            while ((k = kv.exec(last)) !== null) r[k[1]] = parseInt(k[2])
        }
        return r
    }

    function progressObj() {
        var re = /\[CLEAN05\]\[PROGRESS\]\s+(\d+)\s*\/\s*(\d+)/g
        var text = root.logText()
        var m, last = null
        while ((m = re.exec(text)) !== null) last = m
        return last ? { "done": parseInt(last[1]), "total": parseInt(last[2]) } : null
    }

    function outDir() {
        var re = /\[CLEAN05\]\[SALIDA\]\s+(.+)/g
        var text = root.logText()
        var m, last = ""
        while ((m = re.exec(text)) !== null) last = m[1]
        return last.replace(/\s+$/, "")
    }

    // ---- derived counts ----
    function countOk() {
        var r = root.resumen()
        if (r.ok !== undefined) return r.ok
        var n = 0, rows = root.rows()
        for (var i = 0; i < rows.length; i++) if (rows[i].ok) n++
        return n
    }
    function countRevisar() {
        var r = root.resumen()
        if (r.revisar !== undefined) return r.revisar
        var n = 0, rows = root.rows()
        for (var i = 0; i < rows.length; i++) if (!rows[i].ok) n++
        return n
    }
    function countTotal() {
        var r = root.resumen()
        if (r.boletas !== undefined) return r.boletas
        var p = root.progressObj()
        if (p) return p.total
        return root.rows().length
    }
    function doneN() {
        if (root.isSuccess()) return root.countTotal()
        var p = root.progressObj()
        return p ? p.done : root.rows().length
    }
    function frac() {
        if (root.isSuccess()) return 1
        var t = root.countTotal()
        if (t <= 0) return 0
        var f = root.doneN() / t
        if (f < 0) return 0
        if (f > 1) return 1
        return f
    }

    function statusWord() {
        if (root.isCancelled()) return "Detenido"
        if (root.isFailed()) return "Con errores"
        if (root.isSuccess()) return root.countRevisar() > 0 ? "Pendiente" : "Completado"
        return "En proceso"
    }
    function headline() {
        if (root.isCancelled()) return "Proceso detenido manualmente"
        if (root.isFailed())
            return root.countTotal() > 0 ? ("Detenido en " + root.doneN() + " de " + root.countTotal() + " boleta(s)")
                                         : "El proceso se detuvo"
        if (root.isSuccess())
            return "Listo: " + root.countOk() + " de " + root.countTotal() + " boleta(s) cargada(s)"
        return root.countTotal() > 0 ? ("Procesando " + root.doneN() + " de " + root.countTotal() + " boleta(s)")
                                     : "Comenzando el proceso..."
    }
    function statusColor() {
        if (root.isCancelled()) return Common.Theme.cancel
        if (root.isFailed()) return Common.Theme.danger
        if (root.isSuccess()) return root.countRevisar() > 0 ? root.cWarn : root.cSuccess
        return Common.Theme.accent
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 12

        // ---- Header: process name + status chip ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Label {
                text: "Emerix (Extensión)"
                color: root.cTextMain
                font.pixelSize: Common.Theme.fontSize(18)
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Rectangle {
                radius: 7
                implicitHeight: 24
                implicitWidth: statusWordLabel.implicitWidth + 22
                color: Common.Theme.panel2
                border.width: 1
                border.color: root.statusColor()

                Label {
                    id: statusWordLabel
                    anchors.centerIn: parent
                    text: root.statusWord()
                    color: root.statusColor()
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                }
            }
        }

        // ---- Live progress bar (fills as each boleta is processed) ----
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 6

            Label {
                text: root.headline()
                color: root.cTextMain
                font.pixelSize: Common.Theme.fontSize(14)
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Rectangle {
                id: barTrack
                Layout.fillWidth: true
                implicitHeight: 16
                radius: 8
                color: Common.Theme.panel2
                border.width: 1
                border.color: root.cLine
                clip: true

                Rectangle {
                    id: barFill
                    height: parent.height
                    width: Math.max(parent.height, parent.width * root.frac())
                    radius: 8
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: root.statusColor() }
                        GradientStop { position: 1.0; color: Common.Theme.accent }
                    }
                    Behavior on width {
                        NumberAnimation { duration: 450; easing.type: Easing.OutCubic }
                    }
                }

                Rectangle {
                    id: shimmer
                    visible: root.isRunning()
                    height: parent.height
                    width: 70
                    opacity: 0.18
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: "transparent" }
                        GradientStop { position: 0.5; color: Common.Theme.text }
                        GradientStop { position: 1.0; color: "transparent" }
                    }
                    SequentialAnimation on x {
                        running: shimmer.visible
                        loops: Animation.Infinite
                        NumberAnimation { from: -70; to: barTrack.width; duration: 1400; easing.type: Easing.InOutQuad }
                        PauseAnimation { duration: 350 }
                    }
                }
            }

            Label {
                text: root.doneN() + " / " + root.countTotal() + " boleta(s)"
                color: root.cTextMuted
                font.pixelSize: Common.Theme.fontSize(12)
            }
        }

        // ---- Counts row ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Repeater {
                model: [
                    { "label": "Cargadas OK", "value": root.countOk(), "color": root.cSuccess },
                    { "label": "Por revisar", "value": root.countRevisar(), "color": root.cWarn },
                    { "label": "Boletas", "value": root.countTotal(), "color": root.cTextMuted }
                ]
                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 46
                    radius: 10
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 0
                        Label {
                            text: String(modelData.value)
                            color: modelData.color
                            font.pixelSize: Common.Theme.fontSize(18)
                            font.bold: true
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Label {
                            text: modelData.label
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                }
            }
        }

        // ---- Open output folder ----
        Common.InsetAlloyButton {
            id: openButton
            alloyTone: "success"
            visible: root.outDir().length > 0
            Layout.fillWidth: true
            Layout.preferredHeight: 40
            text: "Abrir carpeta"
            hoverEnabled: true
            onClicked: controller.openPathInExplorer(root.outDir())
            background: Rectangle {
                radius: 9
                border.width: 1
                border.color: Common.Theme.success
                gradient: Gradient {
                    GradientStop { position: 0.0; color: Common.Theme.success }
                    GradientStop { position: 1.0; color: Common.Theme.success }
                }
            }
            contentItem: Text {
                text: openButton.text
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(14)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }

        // ---- Table: Estado | RUT | DS | Boleta ----
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine
            clip: true

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 1
                spacing: 0

                // header row
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 34
                    color: Common.Theme.accentSoft
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 12
                        anchors.rightMargin: 12
                        spacing: 10
                        Label {
                            text: "Estado"
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            font.bold: true
                            Layout.preferredWidth: 104
                        }
                        Label {
                            text: "RUT"
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            font.bold: true
                            Layout.preferredWidth: 130
                        }
                        Label {
                            text: "DS"
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            font.bold: true
                            Layout.fillWidth: true
                        }
                        Label {
                            text: "Boleta"
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            font.bold: true
                            horizontalAlignment: Text.AlignRight
                            Layout.preferredWidth: 84
                        }
                    }
                }

                ListView {
                    id: rowList
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    model: root.rows()
                    boundsBehavior: Flickable.StopAtBounds
                    ScrollBar.vertical: Common.StyledScrollBar { policy: ScrollBar.AsNeeded }

                    delegate: Rectangle {
                        width: ListView.view.width
                        implicitHeight: 36
                        color: (index % 2 === 0) ? "transparent" : "#10294780"

                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 12
                            anchors.rightMargin: 12
                            spacing: 10

                            // status badge (pill) with ✓ / ⚠
                            Rectangle {
                                Layout.preferredWidth: 104
                                Layout.preferredHeight: 22
                                radius: 6
                                color: modelData.color
                                Label {
                                    anchors.centerIn: parent
                                    text: (modelData.ok ? "✓ " : "⚠ ") + modelData.estadoLabel
                                    color: Common.Theme.panel2
                                    font.pixelSize: Common.Theme.fontSize(12)
                                    font.bold: true
                                }
                            }

                            Label {
                                text: modelData.rut
                                color: root.cTextMain
                                font.pixelSize: Common.Theme.fontSize(13)
                                Layout.preferredWidth: 130
                                elide: Text.ElideRight
                            }

                            Label {
                                text: modelData.ds
                                color: root.cTextMain
                                font.pixelSize: Common.Theme.fontSize(13)
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                            }

                            Label {
                                text: String(modelData.boleta)
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(12)
                                horizontalAlignment: Text.AlignRight
                                Layout.preferredWidth: 84
                            }
                        }
                    }

                    Label {
                        anchors.centerIn: parent
                        visible: rowList.count === 0
                        text: root.headline()
                        color: root.cTextMuted
                        font.pixelSize: Common.Theme.fontSize(13)
                    }
                }
            }
        }
    }
}
