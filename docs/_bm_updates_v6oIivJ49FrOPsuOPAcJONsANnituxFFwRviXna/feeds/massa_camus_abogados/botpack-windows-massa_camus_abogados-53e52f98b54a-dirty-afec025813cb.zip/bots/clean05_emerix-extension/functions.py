"""Business logic for the Clean05 Emerix Edge-extension bridge scaffold."""
from __future__ import annotations

from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import json
import threading
import time
import unicodedata

ALLOWED_EXCEL_SUFFIXES = {".xlsx", ".xlsm"}
BOT_ID = "clean05_emerix_extension"
BOT_LABEL = "Clean05"

# The ordered steps the extension performs for a single Excel row. Append to
# this tuple as the client defines more of the workflow.
# Translation from the Excel "Resultado Gestión" wording to the option shown in
# the Emerix "Tipo de Gasto" dropdown. Matching is by keyword rather than exact
# text because the Excel varies the tail per row ("ART. 44 NOT. MANDA. CF",
# "ART. 44 NOT. MANDA. CPA", "BÚSQ. POSITIVA VECINO", "2da.BÚSQ. POSITIVA ...").
# The first rule whose keywords ALL appear in the folded cell wins, so order
# matters. Values are folded by fold_gestion(): accents stripped, dots turned
# into spaces, uppercased.
GESTION_RULES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("ART 44",), "NOTIFICACION POR EL 44 CPC"),
    (("REQ DE PAGO",), "REQUERIMIENTO DE PAGO"),
    (("BUSQ", "POSITIV"), "BUSQUEDAS POSITIVAS"),
    (("BUSQ", "NEG"), "BUSQUEDAS NEGATIVAS"),
    (("OPO", "EMBARGO"), "OPOSICION AL EMBARGO"),
)

ROW_STEPS = (
    "fill_search",
    "click_search",
    "open_gestion_menu",
    "click_gastos",
    "click_nuevo",
    "select_tipo_gasto",
    "fill_proveedor",
    "fill_importe",
    "fill_boleta",
    "select_identificador",
    "fill_comentario",
    # Milestone/test step: close the dialog with the X instead of pressing
    # "Grabar", so the run never commits a real upload to the portal.
    "close_dialog",
)

# Milestone guard: when True, stop after finishing row 1 so the operator can
# watch a single row. Now that the whole per-row flow is defined and every row
# is closed with the X (never "Grabar"), the bot iterates all rows.
HALT_AFTER_FIRST_ROW = False

# Columns the planilla must expose for Clean05 to run. Matching is
# case-insensitive and whitespace-tolerant, so "Valor recibo", "VALOR RECIBO"
# and "  valor   recibo " all satisfy "Valor Recibo".
REQUIRED_COLUMNS = ("DS", "Proveedor", "Valor Recibo", "BOLETA")

# Columns the operational workflow reads. They are validated together with
# REQUIRED_COLUMNS so the operator gets a single combined missing-columns
# report, but they are listed apart because they were not part of the
# original four the client specified.
RUT_COLUMN = "RUT del notificado"
GESTION_COLUMN = "Resultado Gestión"
WORKFLOW_COLUMNS = (RUT_COLUMN, GESTION_COLUMN)
VALIDATED_COLUMNS = REQUIRED_COLUMNS + WORKFLOW_COLUMNS

HEADER_ROW = 1

# Maps a failing step to the input column whose cell is painted red in the
# result workbook. Steps not listed here are structural (menu / dialog / portal)
# rather than data-cell problems, so a failure there only paints the row yellow.
STEP_TO_COLUMN: dict[str, str] = {
    "fill_search": RUT_COLUMN,
    "select_tipo_gasto": GESTION_COLUMN,
    "fill_proveedor": "Proveedor",
    "fill_importe": "Valor Recibo",
    "fill_boleta": "BOLETA",
    "fill_comentario": "DS",
}


class MissingColumnsError(ValueError):
    """Raised when the planilla is missing one or more required columns."""

    def __init__(self, missing: list[str], sheet_name: str, found: list[str]):
        self.missing = list(missing)
        self.sheet_name = sheet_name
        self.found = list(found)
        super().__init__(
            "La planilla no tiene todas las columnas necesarias. "
            f"Faltan: {', '.join(self.missing)}."
        )


def _normalize_header(value: Any) -> str:
    """Fold a header to its comparable form: trimmed, collapsed and caseless."""
    return " ".join(str(value if value is not None else "").split()).casefold()


def _read_header_row(worksheet: Any) -> dict[str, tuple[str, int]]:
    """Map normalized header -> (original text, 1-based column index)."""
    headers: dict[str, tuple[str, int]] = {}
    for row in worksheet.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW, values_only=True):
        for index, cell in enumerate(row, start=1):
            normalized = _normalize_header(cell)
            if not normalized:
                continue
            # First occurrence wins, so a duplicated header cannot shadow it.
            headers.setdefault(normalized, (" ".join(str(cell).split()), index))
        break
    return headers


def _match_required_columns(headers: dict[str, tuple[str, int]]) -> tuple[dict[str, Any], list[str]]:
    """Resolve every required column against a header row, collecting ALL misses."""
    resolved: dict[str, Any] = {}
    missing: list[str] = []
    for required in VALIDATED_COLUMNS:
        match = headers.get(_normalize_header(required))
        if match is None:
            missing.append(required)
            continue
        original, index = match
        resolved[required] = {"header": original, "index": index}
    return resolved, missing


def inspect_excel(path: str) -> dict[str, Any]:
    """Validate a single Excel input and return non-sensitive workbook metadata.

    Every required column is checked before failing, so the operator sees the
    complete list of what is missing instead of only the first offender.
    """
    import openpyxl

    target = Path(path).expanduser()
    if not target.exists() or not target.is_file():
        raise ValueError(f"El archivo Excel no existe: {target.name}")
    if target.suffix.lower() not in ALLOWED_EXCEL_SUFFIXES:
        raise ValueError("Selecciona un archivo Excel .xlsx o .xlsm.")

    try:
        workbook = openpyxl.load_workbook(str(target), read_only=True, data_only=True)
    except Exception as exc:
        raise ValueError(f"No se pudo abrir el archivo Excel: {exc}") from exc

    try:
        sheet_names = list(workbook.sheetnames)
        if not sheet_names:
            raise ValueError("El archivo Excel no contiene hojas.")

        # The planilla may carry helper sheets, so keep the first sheet that
        # exposes every required column and fall back to the closest match.
        best: dict[str, Any] | None = None
        for name in sheet_names:
            worksheet = workbook[name]
            headers = _read_header_row(worksheet)
            resolved, missing = _match_required_columns(headers)
            candidate = {
                "sheet_name": name,
                "columns": resolved,
                "missing": missing,
                "found_headers": [original for original, _ in headers.values()],
                "data_rows": max(0, int(worksheet.max_row or 0) - HEADER_ROW),
            }
            if not missing:
                best = candidate
                break
            if best is None or len(missing) < len(best["missing"]):
                best = candidate

        assert best is not None  # sheet_names is non-empty
        if best["missing"]:
            raise MissingColumnsError(best["missing"], best["sheet_name"], best["found_headers"])
    finally:
        workbook.close()

    return {
        "filename": target.name,
        "sheet_names": sheet_names,
        "sheet_count": len(sheet_names),
        "sheet_name": best["sheet_name"],
        "columns": best["columns"],
        "data_rows": best["data_rows"],
    }


class UnmappedGestionError(ValueError):
    """Raised when a "Resultado Gestión" value has no Tipo de Gasto translation."""

    def __init__(self, unmapped: dict[str, list[int]]):
        self.unmapped = dict(unmapped)
        labels = ", ".join(sorted(self.unmapped))
        super().__init__(
            "Hay valores de 'Resultado Gestión' sin traducción a 'Tipo de Gasto': "
            f"{labels}."
        )


def fold_gestion(value: Any) -> str:
    """Fold a "Resultado Gestión" cell for keyword matching.

    Accents are stripped and dots become spaces, so "BÚSQ. POSITIVA VECINO"
    and "2da.BÚSQ. POSITIVA VECINA" both expose the words "BUSQ" and
    "POSITIVA" regardless of how the operator punctuated them.
    """
    text = unicodedata.normalize("NFD", str(value if value is not None else ""))
    text = "".join(char for char in text if not unicodedata.combining(char))
    return " ".join(text.upper().replace(".", " ").split())


def map_gestion_to_tipo_gasto(value: Any) -> str:
    """Translate an Excel "Resultado Gestión" into the Emerix dropdown option.

    Returns "" when nothing matches, so the caller can report it instead of
    silently picking a wrong option.
    """
    folded = fold_gestion(value)
    if not folded:
        return ""
    for keywords, option in GESTION_RULES:
        if all(keyword in folded for keyword in keywords):
            return option
    return ""


def normalize_monto(value: Any) -> str:
    """Normalise a "Valor recibo" cell into the plain integer the box expects.

    openpyxl usually hands back a number already (5000), because the "$5.000"
    is only Excel's display format. But a cell stored as text ("$5.000",
    "$1.234.567") must be parsed: in Chilean format "." is the thousands
    separator and "," the decimal, so dots are dropped and a comma becomes a
    decimal point. Returns "" when there is no usable number.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return ""
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else str(value)

    text = str(value).strip()
    if not text:
        return ""
    # Keep digits, separators and a leading sign; drop "$", spaces, "CLP", etc.
    text = "".join(ch for ch in text if ch.isdigit() or ch in ".,-")
    if not text:
        return ""
    text = text.replace(".", "").replace(",", ".")  # Chilean -> plain decimal
    try:
        number = float(text)
    except ValueError:
        return ""
    return str(int(number)) if number.is_integer() else str(number)


def normalize_boleta(value: Any) -> str:
    """Normalise a "BOLETA" cell into the plain text the Nro Comprobante box wants.

    openpyxl hands back an int (1831); floats that are whole numbers become
    ints so we never write "1831.0". Anything else is passed through trimmed.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return ""
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else str(value)
    return str(value).strip()


def normalize_rut(value: Any) -> str:
    """Strip a RUT down to what the Emerix search box expects.

    Dots, hyphens and spaces are removed and everything else is kept as-is,
    so "19.195.453-5" -> "191954535" and "18.342.567-k" -> "18342567k".
    The verifier character may be a letter, so case is preserved rather than
    forced, and the value is never zero-padded or otherwise reformatted.
    """
    raw = str(value if value is not None else "").strip()
    return "".join(char for char in raw if char.isalnum())


def read_rows(path: str, sheet_name: str, columns: dict[str, Any]) -> list[dict[str, Any]]:
    """Read the data sheet into one record per non-empty row, in sheet order."""
    import openpyxl

    workbook = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    try:
        worksheet = workbook[sheet_name]
        indexes = {name: int(meta["index"]) for name, meta in columns.items()}
        rows: list[dict[str, Any]] = []
        for excel_row, values in enumerate(
            worksheet.iter_rows(min_row=HEADER_ROW + 1, values_only=True),
            start=HEADER_ROW + 1,
        ):
            record: dict[str, Any] = {}
            for name, index in indexes.items():
                record[name] = values[index - 1] if index - 1 < len(values) else None
            if all(value is None or not str(value).strip() for value in record.values()):
                continue  # trailing/blank spacer row
            rut = normalize_rut(record.get(RUT_COLUMN))
            if not rut:
                # Summary rows carry a label and a total but no RUT (the sheet
                # ends with "Resultado Gestión=TOTAL, Valor recibo=<suma>").
                continue
            record["excel_row"] = excel_row
            record["rut_normalizado"] = rut
            record["tipo_gasto"] = map_gestion_to_tipo_gasto(record.get(GESTION_COLUMN))
            rows.append(record)
        return rows
    finally:
        workbook.close()


@dataclass
class BridgeState:
    input_path: str
    workbook: dict[str, Any]
    rows: list[dict[str, Any]] = field(default_factory=list)
    cursor: int = 0
    step_index: int = 0
    halted: bool = False
    finished: bool = False
    error: str = ""
    results: list[dict[str, Any]] = field(default_factory=list)
    recovering: bool = False
    pending_failed_fields: list[str] = field(default_factory=list)
    pending_error_detail: str = ""
    extension_seen_at: float = 0.0
    started_at: float = 0.0
    dashboard_url: str = ""
    dashboard_title: str = ""
    logs: list[str] = field(default_factory=list)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def next_action(self) -> dict[str, Any]:
        """Tell the extension what to do next on the Emerix page."""
        with self.lock:
            self.extension_seen_at = time.time()
            if not self.started_at:
                return {"action": "wait", "message": "Esperando Start."}
            if self.finished:
                return {"action": "done", "message": "No quedan filas por procesar."}
            if self.recovering and self.cursor < len(self.rows):
                # A step failed: abandon this row by closing the form, then the
                # next /next resumes with the following row's first step.
                row = self.rows[self.cursor]
                return {
                    "action": "abandon_row",
                    "row_number": self.cursor + 1,
                    "excel_row": row.get("excel_row"),
                    "total": len(self.rows),
                }
            if self.halted:
                return {
                    "action": "idle",
                    "message": "Fila lista. Detén el bot manualmente.",
                }
            if self.cursor >= len(self.rows):
                self.finished = True
                return {"action": "done", "message": "No quedan filas por procesar."}

            row = self.rows[self.cursor]
            step_name = ROW_STEPS[self.step_index]
            step: dict[str, Any] = {
                "action": step_name,
                "row_number": self.cursor + 1,
                "excel_row": row.get("excel_row"),
                "total": len(self.rows),
                "step_number": self.step_index + 1,
                "step_total": len(ROW_STEPS),
            }
            if step_name == "fill_search":
                step["rut"] = row.get("rut_normalizado", "")
                step["rut_original"] = str(row.get(RUT_COLUMN) or "")
            elif step_name == "fill_proveedor":
                step["proveedor"] = " ".join(str(row.get("Proveedor") or "").split())
            elif step_name == "fill_importe":
                step["importe"] = normalize_monto(row.get("Valor Recibo"))
                step["importe_original"] = " ".join(str(row.get("Valor Recibo") or "").split())
            elif step_name == "fill_boleta":
                step["boleta"] = normalize_boleta(row.get("BOLETA"))
            elif step_name == "fill_comentario":
                # The comment box is filled with the row's "DS" column text.
                step["comentario"] = " ".join(str(row.get("DS") or "").split())
            elif step_name == "select_tipo_gasto":
                step["tipo_gasto"] = row.get("tipo_gasto", "")
                step["resultado_gestion"] = " ".join(
                    str(row.get(GESTION_COLUMN) or "").split()
                )
            return step

    def report_action(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Record the outcome the extension reported for the current row.

        A step failure no longer stops the run: the row is flagged, the form is
        abandoned (X), and the loop moves to the next row. Only a failure to
        close the form during recovery is fatal, since it would strand the loop.
        """
        with self.lock:
            self.extension_seen_at = time.time()
            ok = bool(payload.get("ok"))
            detail = " ".join(str(payload.get("detail") or "").split())[:300]
            position = self.cursor + 1

            if self.recovering:
                # This report is for the abandon_row (recovery close) action.
                if ok:
                    self.logs.append(f"Fila {position}: cerrada tras error, continuo.")
                    self._finish_row_unlocked("error")
                else:
                    self.logs.append(
                        f"Fila {position}: no se pudo cerrar tras error. {detail}"
                    )
                    self._finish_row_unlocked("error")
                    self.error = (
                        f"Fila {position}: no se pudo cerrar el formulario tras un "
                        f"error. {detail}"
                    )
                    self.finished = True
                self.recovering = False
                return self._report_reply_unlocked()

            step_name = ROW_STEPS[self.step_index]

            if not ok:
                self.logs.append(f"Fila {position} [{step_name}]: ERROR {detail}")
                # Flag the culprit cell (if the step maps to one) and recover.
                column = STEP_TO_COLUMN.get(step_name)
                if column and column not in self.pending_failed_fields:
                    self.pending_failed_fields.append(column)
                self.pending_error_detail = f"[{step_name}] {detail}"
                self.recovering = True
                return self._report_reply_unlocked()

            self.logs.append(f"Fila {position} [{step_name}]: {detail}".rstrip())
            self.step_index += 1
            if self.step_index >= len(ROW_STEPS):
                # Whole row done (last step closed the form) -> OK, next row.
                self._finish_row_unlocked("ok")
            return self._report_reply_unlocked()

    def _finish_row_unlocked(self, status: str) -> None:
        """Record the current row's outcome and advance to the next one.

        Must be called while holding self.lock.
        """
        if self.cursor < len(self.rows):
            row = self.rows[self.cursor]
            self.results.append({
                "row_index": self.cursor + 1,
                "excel_row": int(row.get("excel_row") or 0),
                "rut": row.get("rut_normalizado", ""),
                "rut_original": " ".join(str(row.get(RUT_COLUMN) or "").split()),
                "ds": " ".join(str(row.get("DS") or "").split()),
                "boleta": normalize_boleta(row.get("BOLETA")),
                "status": status,
                "failed_fields": list(self.pending_failed_fields),
                "error_detail": self.pending_error_detail,
            })
        self.pending_failed_fields = []
        self.pending_error_detail = ""
        self.step_index = 0
        self.cursor += 1
        if self.cursor >= len(self.rows):
            self.finished = True
        elif HALT_AFTER_FIRST_ROW:
            self.halted = True

    def _report_reply_unlocked(self) -> dict[str, Any]:
        """Reply for /report; carries `done` + final counts so the extension can
        show a friendly "finished" message with the totals. Hold self.lock."""
        reply: dict[str, Any] = {"ok": True, "done": self.finished}
        if self.finished:
            ok = sum(1 for entry in self.results if entry.get("status") == "ok")
            reply["okCount"] = ok
            reply["revisarCount"] = len(self.results) - ok
            reply["total"] = len(self.results)
        return reply

    def touch_extension(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            self.extension_seen_at = now
            self.started_at = now
            self.dashboard_url = str(payload.get("url") or "")[:1000]
            self.dashboard_title = str(payload.get("title") or "")[:300]
            self.logs.append("Start recibido desde el dashboard de Emerix.")
            return {
                "ok": True,
                "message": (
                    f"Conexion confirmada. Procesando {len(self.rows)} fila(s); "
                    "comenzando por la primera."
                ),
                "summary": self._summary_unlocked(),
            }

    def add_log(self, message: str) -> None:
        clean = " ".join(str(message or "").split())
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean[:500])
            self.logs = self.logs[-100:]

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        return {
            "bot_id": BOT_ID,
            "bot_label": BOT_LABEL,
            "extension_seen": self.extension_seen_at > 0,
            "started": self.started_at > 0,
            "started_at": self.started_at,
            "dashboard_url": self.dashboard_url,
            "dashboard_title": self.dashboard_title,
            "input_path": self.input_path,
            "workbook": dict(self.workbook),
            "workflow_configured": True,
            "row_total": len(self.rows),
            "row_position": min(self.cursor + 1, len(self.rows)) if self.rows else 0,
            "halted": self.halted,
            "finished": self.finished,
            "error": self.error,
            "results": [dict(entry) for entry in self.results],
            "ok_count": sum(1 for entry in self.results if entry.get("status") == "ok"),
            "error_count": sum(1 for entry in self.results if entry.get("status") != "ok"),
            "logs": list(self.logs),
        }


def build_bridge_state(planilla_path: str) -> BridgeState:
    """Validate the input and create the in-memory bridge session."""
    target = str(Path(planilla_path).expanduser().resolve())
    workbook = inspect_excel(target)
    rows = read_rows(target, workbook["sheet_name"], workbook["columns"])

    # Check every row before starting: an unmappable "Resultado Gestión" halfway
    # through a run would strand the operator with rows already loaded.
    unmapped: dict[str, list[int]] = {}
    for row in rows:
        if row.get("tipo_gasto"):
            continue
        label = " ".join(str(row.get(GESTION_COLUMN) or "").split()) or "(vacío)"
        unmapped.setdefault(label, []).append(int(row["excel_row"]))
    if unmapped:
        raise UnmappedGestionError(unmapped)

    return BridgeState(input_path=target, workbook=workbook, rows=rows)


class Clean05BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], state: BridgeState):
        super().__init__(server_address, Clean05BridgeHandler)
        self.state = state


class Clean05BridgeHandler(BaseHTTPRequestHandler):
    server: Clean05BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self._send_empty(204)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "name": "Clean05 Emerix bridge",
                "summary": self.server.state.summary(),
            })
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self) -> None:
        if self.path.startswith("/start"):
            self._send_json(self.server.state.register_start(self._read_json()))
            return
        if self.path.startswith("/next"):
            self._send_json({"ok": True, "step": self.server.state.next_action()})
            return
        if self.path.startswith("/report"):
            payload = self._read_json()
            result = self.server.state.report_action(payload)
            status = "OK" if payload.get("ok") else "ERROR"
            print(f"CLEAN05[PASO]: {status} {payload.get('detail') or ''}".rstrip())
            self._send_json(result)
            return
        if self.path.startswith("/log"):
            payload = self._read_json()
            message = str(payload.get("message") or "")
            self.server.state.add_log(message)
            print(f"CLEAN05[EXT]: {message}")
            self._send_json({"ok": True})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _send_empty(self, status: int) -> None:
        self.send_response(status)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


def write_result_workbook(
    input_path: str,
    workbook_meta: dict[str, Any],
    results: list[dict[str, Any]],
    output_dir: str,
) -> str:
    """Write a styled copy of the input Excel marking each processed row.

    Green  = row processed correctly (every field filled and verified).
    Yellow = row not processed correctly.
    Red    = the specific cell that could not be found/filled (with a comment).

    The original input is never modified; a fresh copy is loaded each call so
    the file always reflects the full set of results so far.
    """
    import openpyxl
    from openpyxl.comments import Comment
    from openpyxl.styles import PatternFill

    source = Path(input_path)
    keep_vba = source.suffix.lower() == ".xlsm"
    workbook = openpyxl.load_workbook(str(source), keep_vba=keep_vba)
    try:
        worksheet = workbook[workbook_meta["sheet_name"]]
        green = PatternFill(fill_type="solid", fgColor="C6EFCE")
        yellow = PatternFill(fill_type="solid", fgColor="FFEB9C")
        red = PatternFill(fill_type="solid", fgColor="FFC7CE")

        # Paint only across the used header width, not openpyxl's inflated max.
        last_col = 0
        for cell in next(worksheet.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW)):
            if cell.value not in (None, ""):
                last_col = cell.column
        last_col = last_col or worksheet.max_column

        columns = workbook_meta.get("columns", {})
        for result in results:
            excel_row = int(result.get("excel_row") or 0)
            if excel_row <= HEADER_ROW or excel_row > worksheet.max_row:
                continue
            row_fill = green if result.get("status") == "ok" else yellow
            for column in range(1, last_col + 1):
                worksheet.cell(row=excel_row, column=column).fill = row_fill
            if result.get("status") != "ok":
                detail = str(result.get("error_detail") or "")
                for field in result.get("failed_fields", []):
                    meta = columns.get(field)
                    if not meta:
                        continue
                    cell = worksheet.cell(row=excel_row, column=int(meta["index"]))
                    cell.fill = red
                    if detail:
                        cell.comment = Comment(detail[:400], "Clean05")
                # Always leave a visible note on the row explaining the stop, even
                # when the failure maps to no specific cell (e.g. the portal-side
                # identificador choice). Do not overwrite a red cell's comment.
                if detail:
                    note_cell = worksheet.cell(row=excel_row, column=1)
                    if note_cell.comment is None:
                        note_cell.comment = Comment(detail[:400], "Clean05")

        suffix = source.suffix if keep_vba else ".xlsx"
        out_path = Path(output_dir) / f"Resultado_{source.stem}{suffix}"
        workbook.save(str(out_path))
        return str(out_path)
    finally:
        workbook.close()


def run_bridge_session(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
    output_dir: str,
    log_every_seconds: int = 15,
) -> dict[str, Any]:
    """Serve the loopback bridge for the whole attended session.

    The server must stay up after Start, because that is when the extension
    begins asking /next for work. It returns once the workflow reports itself
    finished (all rows processed). The result workbook is rewritten after every
    completed row so progress is never lost if the run is interrupted.
    """
    server = Clean05BridgeServer((host, port), state)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"Clean05: bridge escuchando en http://{host}:{port}")
    # Output folder marker (consumed by Clean05Plugin for the "Abrir carpeta"
    # button); printed once up front since the run dir is known from the start.
    print(f"[CLEAN05][SALIDA] {output_dir}")

    result_path = ""

    def _flush_results(summary: dict[str, Any]) -> None:
        nonlocal result_path
        try:
            result_path = write_result_workbook(
                state.input_path, summary["workbook"], summary["results"], output_dir
            )
        except Exception as exc:  # never let file I/O kill the attended run
            print(f"Clean05: no se pudo escribir el archivo de resultados: {exc}")

    deadline = time.time() + timeout_seconds
    last_log = 0.0
    last_results = 0
    try:
        while time.time() < deadline:
            summary = state.summary()
            now = time.time()
            done_rows = len(summary["results"])
            if done_rows > last_results:
                # One structured marker per newly-finished row, consumed by
                # Clean05Plugin to build the run-detail table.
                for entry in summary["results"][last_results:done_rows]:
                    estado = "OK" if entry.get("status") == "ok" else "REVISAR"
                    print("[CLEAN05][FILA] " + json.dumps({
                        "excel": entry.get("excel_row"),
                        "estado": estado,
                        "rut": entry.get("rut_original") or entry.get("rut") or "",
                        "ds": entry.get("ds", ""),
                        "boleta": entry.get("boleta", ""),
                        "motivo": entry.get("error_detail", "") if estado != "OK" else "",
                    }, ensure_ascii=False))
                last_results = done_rows
                print(f"[CLEAN05][PROGRESS] {done_rows}/{summary['row_total']}")
                _flush_results(summary)
            if summary["finished"]:
                _flush_results(summary)
                summary["result_path"] = result_path
                return summary
            if now - last_log >= log_every_seconds:
                if not summary["started"]:
                    seen = "si" if summary["extension_seen"] else "no"
                    print(f"Clean05: esperando Start | extension_conectada={seen}")
                elif summary["halted"]:
                    print("Clean05: en espera. Detén el bot cuando quieras.")
                else:
                    print(
                        f"Clean05: procesando fila {summary['row_position']}"
                        f"/{summary['row_total']}"
                    )
                last_log = now
            time.sleep(0.5)
        _flush_results(state.summary())
        raise TimeoutError("Clean05: timeout esperando actividad desde la extension de Edge.")
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3.0)


def write_bridge_receipt(summary: dict[str, Any], output_dir: str) -> str:
    """Persist a small receipt proving that the desktop/extension bridge worked."""
    target = Path(output_dir) / "bridge_connection.json"
    payload = dict(summary)
    payload["receipt_created_at"] = time.time()
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(target)
