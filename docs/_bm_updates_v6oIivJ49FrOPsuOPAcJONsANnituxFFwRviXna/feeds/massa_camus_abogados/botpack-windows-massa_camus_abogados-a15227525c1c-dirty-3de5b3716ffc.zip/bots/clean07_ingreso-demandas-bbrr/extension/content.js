(() => {
  const MESSAGE_TYPE = "CLEAN07_BRIDGE_REQUEST";
  const PANEL_ID = "clean07-pjud-panel";
  // The N03 bot injects its own panel on the same PJUD origin, anchored to the
  // same corner. When both are loaded, Clean07 stacks itself above N03 instead
  // of covering it.
  const N03_PANEL_ID = "n03-pjud-panel";
  // Shown in the panel title. Reloading the extension does NOT re-inject this
  // script into tabs that are already open, so this marker is the way to tell
  // whether the page is running the current build or a stale one.
  const BUILD = "v0.8.2";
  // The page the operator is meant to press Start from. Start is accepted
  // anywhere on the portal; this only drives the hint text.
  const START_PAGE = "indexn.php";

  let connected = false;
  let starting = false;
  let verified = false;
  let workTimer = 0;
  let busy = false;
  // Set once the desktop confirms the session is done, so the panel shows a
  // friendly message instead of a scary "connection lost" when the bridge
  // server shuts down right after the handshake.
  let completed = false;
  // Repeat guard. The bridge only re-issues a step it never got a report for,
  // so seeing the same one twice means the loop is stuck — and repeating a
  // click on the portal is exactly what gets the session blocked by the WAF.
  let lastStepKey = "";
  let sameStepCount = 0;
  const MAX_STEP_ATTEMPTS = 2;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  // While a step handler runs, pumpWork is busy and pollBridge returns early
  // (it stops once `verified`), so NOTHING touches the bridge — and the
  // desktop closes the session after EXTENSION_IDLE_SECONDS without a word.
  // A long upload wait would look exactly like a closed tab. GET /health
  // calls touch_extension() on the desktop, so pinging it mid-wait keeps the
  // session alive without loosening the real dead-tab detection.
  function heartbeat() {
    bridgeRequest("/health").catch(() => {});
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean07-title">Clean07 · Demandas BBRR · ${BUILD}</div>
      <div class="clean07-status" data-role="status">Esperando BotManager...</div>
      <div class="clean07-details" data-role="details">Planilla sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    positionPanel();
    return panel;
  }

  // Keep clear of the N03 panel when both extensions are enabled. Re-checked on
  // every poll because N03 injects asynchronously.
  function positionPanel() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) {
      return;
    }
    const other = document.getElementById(N03_PANEL_ID);
    const offset = other ? other.offsetHeight + 24 : 14;
    panel.style.bottom = `${offset}px`;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean07-ok", tone === "ok");
    status.classList.toggle("clean07-error", tone === "error");
  }

  function renderSummary(summary) {
    const details = createPanel().querySelector('[data-role="details"]');
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const demandas = summary && summary.demandas ? summary.demandas : {};
    if (!workbook.filename) {
      details.textContent = "Planilla sin confirmar";
      return;
    }
    const rows = summary && summary.row_total ? summary.row_total : 0;
    details.textContent = `${workbook.filename} · ${rows} fila(s) · `
      + `${demandas.pdf_count || 0} PDF(s) en demandas`;
  }

  function onStartPage() {
    return String(window.location.href || "").toLowerCase().includes(START_PAGE);
  }

  const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

  // ---------------------------------------------------------------------------
  // Page helpers
  // ---------------------------------------------------------------------------

  // Menu labels arrive padded (" Ingresar Demanda/Recurso") and accented, so
  // compare on a folded form: collapsed whitespace, lowercased, accents removed.
  function foldLabel(value) {
    return String(value == null ? "" : value)
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "");
  }

  function findByLabel(selector, label, root) {
    const target = foldLabel(label);
    const scope = root || document;
    let candidates = [];
    try {
      candidates = Array.from(scope.querySelectorAll(selector));
    } catch (_) {
      return null;
    }
    // Exact label first, so a longer menu entry containing the same words
    // cannot win over the real one.
    return candidates.find((el) => foldLabel(el.textContent) === target)
      || candidates.find((el) => foldLabel(el.textContent).includes(target))
      || null;
  }

  // The portal renders its left menu from Knockout bindings after the page
  // settles, so poll instead of assuming the item exists the moment we look.
  function waitFor(probe, errorMessage, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const immediate = probe();
      if (immediate) {
        resolve(immediate);
        return;
      }
      const deadline = Date.now() + timeoutMs;
      const timer = window.setInterval(() => {
        const found = probe();
        if (found) {
          window.clearInterval(timer);
          resolve(found);
        } else if (Date.now() > deadline) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }

  // ---------------------------------------------------------------------------
  // Step handlers — one per name in functions.py PREP_STEPS / LOOP_STEPS
  // ---------------------------------------------------------------------------

  // The label lives in a <span data-bind="text: ' ' + name">, but the Knockout
  // click binding sits on the .list-group-item wrapper around it, so clicking
  // the span alone would do nothing.
  const MENU_ITEM_SELECTOR = ".list-group-item span, .pg_menu_lt span, li span, a span";
  const MENU_ITEM_WRAPPER = ".list-group-item, .pg_menu_lt, li, a";

  async function clickIngresarDemanda(step) {
    const label = await waitFor(
      () => findByLabel(MENU_ITEM_SELECTOR, "Ingresar Demanda/Recurso"),
      "No se encontró la opción 'Ingresar Demanda/Recurso' en el menú del portal."
    );
    const target = label.closest(MENU_ITEM_WRAPPER) || label.parentElement || label;
    target.click();
    return `Fila ${step.row_number}/${step.total}: se abrió "Ingresar Demanda/Recurso".`;
  }

  // --- select2 v3 driver -----------------------------------------------------
  // The portal keeps ONE shared drop element (#select2-drop) that select2
  // repositions and refills for whichever control is open — the ids inside it
  // (select2-results-27/-28/-1, s2id_autogenN_search) belong to the control,
  // not to the drop, and can shift between page loads. So: open the control,
  // then read whatever the shared drop currently holds. Never the reverse.
  const SELECT2_DROP_ID = "select2-drop";

  function fireMouse(element, type) {
    element.dispatchEvent(new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window,
      button: 0
    }));
  }

  function select2Chosen(container) {
    const chosen = container.querySelector(".select2-chosen");
    return chosen ? foldLabel(chosen.textContent) : "";
  }

  // getComputedStyle(el).display only reflects the ELEMENT'S OWN display —
  // an ancestor's display:none does not change it, so checking .modal-content
  // (Bootstrap toggles display:none on the OUTER .modal wrapper, not the
  // inner content div) reported "visible" forever, even after Cerrar y
  // Continuar had genuinely closed the modal. getBoundingClientRect's actual
  // rendered size correctly collapses to 0x0 whenever display:none applies
  // anywhere up the ancestor chain — and unlike offsetParent, it stays
  // correct for position:fixed elements too (Bootstrap modals commonly are).
  function isVisible(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  // Find the drop that belongs to THIS control. The container's focusser carries
  // the control's autogen id (s2id_autogenN) and the open drop holds the matching
  // search input (s2id_autogenN_search) — that link is exact, whereas the
  // #select2-drop id is shared and stale `select2-drop-active` copies of other
  // fields linger in the DOM with display:none.
  function findSelect2Drop(container) {
    const focusser = container.querySelector("input.select2-focusser");
    if (focusser && focusser.id) {
      const search = document.getElementById(`${focusser.id}_search`);
      const own = search && search.closest(".select2-drop");
      if (isVisible(own)) {
        return own;
      }
    }
    const shared = document.getElementById(SELECT2_DROP_ID);
    return isVisible(shared) ? shared : null;
  }

  // Resolve a select2 container that has NO stable id. select2 v3 inserts its
  // container immediately BEFORE the element it decorates, so the Knockout
  // binding name — application source, not a per-render id — is the stable
  // anchor. Procedimiento's source div carries no id (unlike Corte's
  // #select-asientoCorte), so select2 autogenerated #s2id_autogen171 for it;
  // that number drifts between renders (its own focusser was 172) and must
  // never be hardcoded.
  function findSelect2ContainerByBinding(bindingName, root) {
    const scope = root || document;
    const bound = Array.from(scope.querySelectorAll("div[data-bind]"))
      .find((el) => el.classList.contains("select2")
        && !el.classList.contains("select2-container")
        && String(el.getAttribute("data-bind")).includes(bindingName));
    const container = bound && bound.previousElementSibling;
    return container && container.classList.contains("select2-container")
      ? container
      : null;
  }

  async function openSelect2El(container, fieldLabel) {
    await waitFor(
      () => !container.classList.contains("select2-container-disabled") || null,
      `El campo ${fieldLabel} sigue deshabilitado.`,
      10000
    );
    const choice = container.querySelector("a.select2-choice");
    if (!choice) {
      throw new Error(`El campo ${fieldLabel} no expone el control select2.`);
    }
    // select2 v3 opens on MOUSEDOWN — a bare .click() leaves it closed.
    fireMouse(choice, "mousedown");
    fireMouse(choice, "mouseup");
    fireMouse(choice, "click");
    const drop = await waitFor(
      () => findSelect2Drop(container),
      `No se abrió el desplegable de ${fieldLabel}.`,
      8000
    );
    return { container, drop };
  }

  // Knockout only renders Corte/Tribunal once Competencia is set, so the
  // container may not exist yet when the step starts.
  async function openSelect2(containerId, fieldLabel) {
    const container = await waitFor(
      () => document.getElementById(containerId),
      `No se encontró el campo ${fieldLabel} (#${containerId}).`,
      10000
    );
    return openSelect2El(container, fieldLabel);
  }

  // Option rows carry padding whitespace ("C.A. de Santiago      ", "   Juzgado
  // de Letras de Colina"), so match on the folded text — and only EXACTLY, so a
  // near neighbour like "C.A. de San Miguel" can never be picked by accident.
  function findSelect2Option(drop, optionLabel) {
    const target = foldLabel(optionLabel);
    const items = Array.from(drop.querySelectorAll("li.select2-result-selectable"));
    return items.find((li) => foldLabel(li.textContent) === target) || null;
  }

  // select2 v3 selects on MOUSEUP, not click, so a bare .click() on the row does
  // nothing. Send the full sequence a real pointer would produce.
  function chooseSelect2Option(item) {
    fireMouse(item, "mousedown");
    fireMouse(item, "mouseup");
    fireMouse(item, "click");
  }

  // Matching stays EXACT, so a near neighbour can never be picked by accident.
  // The cost is that a value whose wording is slightly off just fails — so when
  // it does, report what the portal actually offered. That turns a guessing loop
  // into a single fix.
  function listSelect2Options(drop, max = 30) {
    const items = Array.from(drop.querySelectorAll("li.select2-result-selectable"))
      .map((li) => String(li.textContent).replace(/\s+/g, " ").trim())
      .filter(Boolean);
    if (!items.length) {
      return "(ninguna)";
    }
    const shown = items.slice(0, max).join(" · ");
    return items.length > max ? `${shown} … (+${items.length - max} más)` : shown;
  }

  async function setSelect2El(container, fieldLabel, optionLabel) {
    const { drop } = await openSelect2El(container, fieldLabel);
    let item = null;
    try {
      item = await waitFor(() => findSelect2Option(drop, optionLabel), "no-match", 10000);
    } catch (_) {
      throw new Error(
        `No apareció la opción "${optionLabel}" en ${fieldLabel}. `
        + `El portal ofrece: ${listSelect2Options(drop)}`
      );
    }
    chooseSelect2Option(item);
    // Read back: never move on trusting that the click landed.
    await waitFor(
      () => select2Chosen(container) === foldLabel(optionLabel) || null,
      `${fieldLabel} no quedó en "${optionLabel}" tras seleccionarlo.`,
      8000
    );
  }

  async function setSelect2(containerId, fieldLabel, optionLabel) {
    const container = await waitFor(
      () => document.getElementById(containerId),
      `No se encontró el campo ${fieldLabel} (#${containerId}).`,
      10000
    );
    return setSelect2El(container, fieldLabel, optionLabel);
  }

  // --- steps -----------------------------------------------------------------

  // Competencia is NOT select2: it is a native <select> bound by Knockout. Every
  // <option> carries value="" (Knockout keeps the real objects itself), so
  // assigning .value does nothing — the option must be chosen by index, and the
  // change event dispatched by hand or Knockout never learns about it.
  const COMPETENCIA_SELECT = 'select[data-bind*="options: competencias"]';
  const CORTE_CONTAINER_ID = "s2id_select-asientoCorte";
  const TRIBUNAL_CONTAINER_ID = "s2id_select-tribunales";
  const DIRIGIDO_A_CONTAINER_ID = "s2id_select-usuarios";

  async function selectCompetencia(step) {
    const wanted = String(step.value || "");
    const select = await waitFor(
      () => document.querySelector(COMPETENCIA_SELECT),
      "No se cargó el formulario de ingreso (no apareció Competencia)."
    );
    // Knockout fills `competencias` asynchronously, so the <select> can exist
    // for a moment holding nothing but its "Seleccione Competencia" caption.
    // Without this wait a slow load is indistinguishable from a missing value.
    let option = null;
    try {
      option = await waitFor(
        () => Array.from(select.options)
          .find((opt) => foldLabel(opt.textContent) === foldLabel(wanted)) || null,
        "no-match",
        10000
      );
    } catch (_) {
      const offered = Array.from(select.options)
        .map((opt) => String(opt.textContent).replace(/\s+/g, " ").trim())
        .filter(Boolean);
      throw new Error(
        `La competencia "${wanted}" no existe en el formulario. `
        + `El portal ofrece: ${offered.length ? offered.join(" · ") : "(ninguna)"}`
      );
    }
    select.selectedIndex = option.index;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    await waitFor(
      () => foldLabel(select.options[select.selectedIndex].textContent)
        === foldLabel(wanted) || null,
      `Competencia no quedó en "${wanted}".`,
      8000
    );
    return `Fila ${step.row_number}/${step.total}: Competencia = ${wanted}.`;
  }

  async function selectCorte(step) {
    const wanted = String(step.value || "");
    await setSelect2(CORTE_CONTAINER_ID, "Corte", wanted);
    return `Fila ${step.row_number}/${step.total}: Corte = ${wanted}.`;
  }

  async function selectTribunal(step) {
    const wanted = String(step.value || "");
    await setSelect2(TRIBUNAL_CONTAINER_ID, "Tribunal", wanted);
    return `Fila ${step.row_number}/${step.total}: Tribunal = ${wanted}.`;
  }

  // "Dirigido a" arrives pre-selected with the patrocinating abogado. Touching a
  // field that is already correct only risks changing it, so this reads first
  // and selects only when the portal defaulted to somebody else.
  async function ensureDirigidoA(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => document.getElementById(DIRIGIDO_A_CONTAINER_ID),
      "No se encontró el campo Dirigido a."
    );
    if (select2Chosen(container) === foldLabel(wanted)) {
      return `Fila ${step.row_number}/${step.total}: Dirigido a ya estaba en ${wanted}.`;
    }
    await setSelect2(DIRIGIDO_A_CONTAINER_ID, "Dirigido a", wanted);
    return `Fila ${step.row_number}/${step.total}: Dirigido a corregido a ${wanted}.`;
  }

  // "Fijar Datos" is a real <input type="checkbox"> paired with a <label for=...>
  // styled as a button — not a select2 widget. Clicking the label toggles the
  // checkbox and fires Knockout's native "checked" binding via the browser's
  // own for/id association, so no synthetic mousedown/mouseup dance is needed
  // here. Only click when it is not already checked, so a re-issued step (a
  // reloaded tab re-asking for this step) never un-checks it by accident.
  // There is MORE THAN ONE "Fijar Datos" on the form — the tribunal block, the
  // Ingreso de Demanda card, and the litigante card each have their own, and
  // all three render exactly that text. Never find them by label; the
  // checkbox id is the only thing that tells them apart, and it arrives as
  // the step value.
  const FIJAR_DATOS_MODULES = {
    id_check_fijar_mod_tribunal: "tribunal",
    id_check_fijar_mod_materia: "materias",
    id_check_fijar_mod_lit: "litigante",
    // Not a "Fijar Datos" checkbox at all — the Documento Anexo card's
    // "Original Papel" toggle — but same shape (checked: binding, own id),
    // so it reuses this handler instead of a near-duplicate one.
    id_check_muestra_especie: "original papel"
  };

  async function clickFijarDatos(step) {
    const checkboxId = String(step.value || "").trim();
    if (!checkboxId) {
      throw new Error("El paso 'Fijar Datos' llegó sin el id del checkbox.");
    }
    const where = FIJAR_DATOS_MODULES[checkboxId] || checkboxId;
    const checkbox = await waitFor(
      () => document.getElementById(checkboxId),
      `No se encontró el botón 'Fijar Datos' de ${where} (#${checkboxId}).`
    );
    if (checkbox.checked) {
      return `Fila ${step.row_number}/${step.total}: Fijar Datos (${where}) ya estaba marcado.`;
    }
    const label = document.querySelector(`label[for="${checkboxId}"]`) || checkbox;
    label.click();
    await waitFor(
      () => checkbox.checked || null,
      `'Fijar Datos' (${where}) no quedó marcado tras hacer click.`,
      8000
    );
    return `Fila ${step.row_number}/${step.total}: se marcó "Fijar Datos" (${where}).`;
  }

  // Procedimiento lives in the "Ingreso de Demanda" card, which Knockout renders
  // only for competencias 1/2/3/7/8/9 — Civil is one of them. It has no stable
  // id, so it is reached through its binding (see findSelect2ContainerByBinding).
  const PROCEDIMIENTO_BINDING = "procedimientoSeleccionado";

  async function selectProcedimiento(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => findSelect2ContainerByBinding(PROCEDIMIENTO_BINDING),
      "No se encontró el campo Procedimiento (¿se cargó la tarjeta 'Ingreso de Demanda'?)."
    );
    await setSelect2El(container, "Procedimiento", wanted);
    return `Fila ${step.row_number}/${step.total}: Procedimiento = ${wanted}.`;
  }

  // Materia sits in the same card as Procedimiento and is reached the same way.
  // Unlike Procedimiento it keeps its OWN nested .select2-drop inside the
  // container; while closed that copy is select2-display-none, so the isVisible
  // guard in findSelect2Drop skips it and falls through to the shared drop.
  const MATERIA_BINDING = "materiaSeleccionada";

  async function selectMateria(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => findSelect2ContainerByBinding(MATERIA_BINDING),
      "No se encontró el campo Materia."
    );
    await setSelect2El(container, "Materia", wanted);
    return `Fila ${step.row_number}/${step.total}: Materia = ${wanted}.`;
  }

  // "Agregar" has no stable id either, so it is reached the same way — through
  // its Knockout click binding (agregarMateria), not a selector guess. It stays
  // disabled until Knockout's "valid" binding turns true (a materia is picked),
  // so a click before that would silently do nothing; the button element and
  // Knockout's binding element are the SAME node here (unlike the select2
  // fields), so a plain querySelector on the binding attribute is enough.
  const AGREGAR_MATERIA_BINDING = "agregarMateria";
  const MATERIAS_LIST_ID = "listaMateriasCausa";

  function findByBinding(selector, bindingName) {
    return Array.from(document.querySelectorAll(selector))
      .find((el) => String(el.getAttribute("data-bind") || "").includes(bindingName))
      || null;
  }

  async function clickAgregarMateria(step) {
    const button = await waitFor(
      () => findByBinding("button[data-bind]", AGREGAR_MATERIA_BINDING),
      "No se encontró el botón 'Agregar' de Materia."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Agregar' de Materia sigue deshabilitado (¿Materia sin seleccionar?).",
      8000
    );
    // materiasCausa renders straight into this container via a Knockout
    // "foreach" binding, so counting its children before/after is a direct
    // read of whether the add actually landed — not just that the click fired.
    const list = document.querySelector(
      `#${MATERIAS_LIST_ID} [data-bind*="foreach: materiasCausa"]`
    );
    const before = list ? list.children.length : 0;
    button.click();
    await waitFor(
      () => (list && list.children.length > before) || null,
      "'Agregar' no sumó la materia a la lista (listaMateriasCausa sin cambios).",
      8000
    );
    return `Fila ${step.row_number}/${step.total}: se agregó la materia a la causa.`;
  }

  // Litigantes section, opened by Agregar Materia. "Tipo Sujeto" has no stable
  // id (Knockout renders one litigante block per entry in litigantesCausa), so
  // it is reached the same way as Procedimiento/Materia: through its binding.
  // This targets whichever litigante block renders FIRST — today that is the
  // only one on the page.
  const TIPO_SUJETO_BINDING = "tipoLitiganteSel";

  async function selectTipoSujeto(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => findSelect2ContainerByBinding(TIPO_SUJETO_BINDING),
      "No se encontró el campo Tipo Sujeto (¿se abrió la sección de litigantes?)."
    );
    await setSelect2El(container, "Tipo Sujeto", wanted);
    return `Fila ${step.row_number}/${step.total}: Tipo Sujeto = ${wanted}.`;
  }

  // Rut of the litigante selected above. Plain Knockout `value` binding (not
  // select2), gated by `disable: bloqueoRutComp` — wait for it to clear rather
  // than assume Tipo Sujeto already unlocked it by the time this step starts.
  const RUT_INPUT_SELECTOR = 'input[name="rut"][data-bind*="rutSel"]';

  function dispatchKey(input, type, key) {
    input.dispatchEvent(new KeyboardEvent(type, {
      key,
      bubbles: true,
      cancelable: true
    }));
  }

  // The field carries its own RUT mask that inserts the dots and dash live as
  // digits arrive, and only finishes formatting once the verification digit
  // lands (which is also what reveals the next two fields) — so setting
  // .value in one shot leaves it unformatted. Replay a real key sequence per
  // character instead, same approach as Clean05's Emerix input.
  async function fillRut(step) {
    const wanted = String(step.value || "").trim();
    const input = await waitFor(
      () => document.querySelector(RUT_INPUT_SELECTOR),
      "No se encontró el campo Rut del litigante."
    );
    await waitFor(
      () => !input.disabled || null,
      "El campo Rut sigue deshabilitado (¿Tipo Sujeto sin seleccionar?).",
      8000
    );
    input.focus();
    input.click();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    for (const char of wanted) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      input.value += char;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(25);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();

    // The mask rewrites the display ("97.023.000-9"), so compare on digits
    // only rather than expecting the raw typed string back.
    const onlyDigits = (value) => String(value || "").replace(/\D/g, "");
    await waitFor(
      () => onlyDigits(input.value) === onlyDigits(wanted) || null,
      `Rut no quedó en "${wanted}" (quedó "${input.value}").`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: Rut = ${input.value}.`;
  }

  // After the Rut's verification digit lands, the portal runs its own RUT
  // lookup and reveals "Tipo Persona" (select2, tipoPersonaSel binding) and
  // "Razón Social" (plain input, perNombres) already filled in — nothing to
  // click or type here. The lookup animation can take 10+ seconds, well past
  // the ~8-10s timeout used elsewhere, so this step polls with a longer one.
  const TIPO_PERSONA_BINDING = "tipoPersonaSel";
  const RAZON_SOCIAL_INPUT_SELECTOR = 'input[name="nombres"][data-bind*="perNombres"]';
  const LOOKUP_TIMEOUT_MS = 25000;

  async function awaitLitiganteLookup(step) {
    const raw = String(step.value || "");
    const [tipoPersonaWanted, razonSocialWanted] = raw.split("::").map((s) => s.trim());
    const razonesSocialesAceptadas = String(razonSocialWanted || "")
      .split("||")
      .map((s) => s.trim())
      .filter(Boolean);

    const tipoPersonaContainer = await waitFor(
      () => findSelect2ContainerByBinding(TIPO_PERSONA_BINDING),
      "No se encontró el campo Tipo Persona.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => select2Chosen(tipoPersonaContainer) === foldLabel(tipoPersonaWanted) || null,
      `Tipo Persona no quedó en "${tipoPersonaWanted}" (la búsqueda del Rut puede haber demorado `
      + "más de lo esperado).",
      LOOKUP_TIMEOUT_MS
    );

    const razonInput = await waitFor(
      () => document.querySelector(RAZON_SOCIAL_INPUT_SELECTOR),
      "No se encontró el campo Razón Social.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => razonesSocialesAceptadas.some(
        (nombre) => foldLabel(razonInput.value) === foldLabel(nombre)
      ) || null,
      `Razón Social no coincidió con "${razonesSocialesAceptadas.join('" o "')}" `
      + `(quedó "${razonInput.value}").`,
      LOOKUP_TIMEOUT_MS
    );

    return `Fila ${step.row_number}/${step.total}: Tipo Persona = ${tipoPersonaWanted}, `
      + `Razón Social = ${razonInput.value}.`;
  }

  // The abogado's Rut lookup reveals a natural person instead: Tipo Persona
  // (same binding as above) plus three name fields, all auto-filled and
  // disabled — nothing to click or type. Nombres reuses the SAME selector as
  // Razón Social above (PJUD binds both to perNombres; only the disable
  // binding's suffix — J vs P — differs, which the selector doesn't need).
  const AP_PATERNO_INPUT_SELECTOR = 'input[data-bind*="perApPaterno"]';
  const AP_MATERNO_INPUT_SELECTOR = 'input[data-bind*="perApMaterno"]';

  async function awaitAbogadoLookup(step) {
    const raw = String(step.value || "");
    const [tipoPersonaWanted, nombresWanted, apPaternoWanted, apMaternoWanted] =
      raw.split("::").map((s) => s.trim());

    const tipoPersonaContainer = await waitFor(
      () => findSelect2ContainerByBinding(TIPO_PERSONA_BINDING),
      "No se encontró el campo Tipo Persona del abogado.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => select2Chosen(tipoPersonaContainer) === foldLabel(tipoPersonaWanted) || null,
      `Tipo Persona no quedó en "${tipoPersonaWanted}" (la búsqueda del Rut puede haber demorado `
      + "más de lo esperado).",
      LOOKUP_TIMEOUT_MS
    );

    const nombresInput = await waitFor(
      () => document.querySelector(RAZON_SOCIAL_INPUT_SELECTOR),
      "No se encontró el campo Nombres.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => foldLabel(nombresInput.value) === foldLabel(nombresWanted) || null,
      `Nombres no quedó en "${nombresWanted}" (quedó "${nombresInput.value}").`,
      LOOKUP_TIMEOUT_MS
    );

    const apPaternoInput = await waitFor(
      () => document.querySelector(AP_PATERNO_INPUT_SELECTOR),
      "No se encontró el campo Primer apellido.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => foldLabel(apPaternoInput.value) === foldLabel(apPaternoWanted) || null,
      `Primer apellido no quedó en "${apPaternoWanted}" (quedó "${apPaternoInput.value}").`,
      LOOKUP_TIMEOUT_MS
    );

    const apMaternoInput = await waitFor(
      () => document.querySelector(AP_MATERNO_INPUT_SELECTOR),
      "No se encontró el campo Segundo apellido.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => foldLabel(apMaternoInput.value) === foldLabel(apMaternoWanted) || null,
      `Segundo apellido no quedó en "${apMaternoWanted}" (quedó "${apMaternoInput.value}").`,
      LOOKUP_TIMEOUT_MS
    );

    return `Fila ${step.row_number}/${step.total}: Tipo Persona = ${tipoPersonaWanted}, `
      + `Nombres = ${nombresInput.value}, Primer apellido = ${apPaternoInput.value}, `
      + `Segundo apellido = ${apMaternoInput.value}.`;
  }

  // The DEMANDADO's Rut lookup (LOOP_STEPS) is the SAME shape as the abogado's
  // — Tipo Persona + three name fields — but unlike Itaú/the abogado, the
  // expected NAME is not known ahead of time: it is the debtor's own name,
  // looked up by the portal from a Rut this bot did not choose. So this only
  // confirms Tipo Persona resolved (left its placeholder) and all three name
  // fields came back non-empty, never comparing against expected text.
  // NATURAL only for now — a JURIDICA demandado would render Razón Social
  // instead of these three fields and this step would time out; no case for
  // that has been defined yet.
  const TIPO_PERSONA_PLACEHOLDER = foldLabel("Seleccione Tipo Persona");

  async function awaitDdoLookup(step) {
    const tipoPersonaContainer = await waitFor(
      () => findSelect2ContainerByBinding(TIPO_PERSONA_BINDING),
      "No se encontró el campo Tipo Persona del demandado.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => {
        const chosen = select2Chosen(tipoPersonaContainer);
        return (chosen && chosen !== TIPO_PERSONA_PLACEHOLDER) || null;
      },
      "Tipo Persona del demandado no se resolvió (la búsqueda del Rut puede "
      + "haber demorado más de lo esperado).",
      LOOKUP_TIMEOUT_MS
    );
    const tipoPersona = select2Chosen(tipoPersonaContainer);

    const nombresInput = await waitFor(
      () => document.querySelector(RAZON_SOCIAL_INPUT_SELECTOR),
      "No se encontró el campo Nombres del demandado.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => (nombresInput.value || "").trim() !== "" || null,
      "Nombres del demandado no llegó a llenarse.",
      LOOKUP_TIMEOUT_MS
    );

    const apPaternoInput = await waitFor(
      () => document.querySelector(AP_PATERNO_INPUT_SELECTOR),
      "No se encontró el campo Primer apellido del demandado.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => (apPaternoInput.value || "").trim() !== "" || null,
      "Primer apellido del demandado no llegó a llenarse.",
      LOOKUP_TIMEOUT_MS
    );

    const apMaternoInput = await waitFor(
      () => document.querySelector(AP_MATERNO_INPUT_SELECTOR),
      "No se encontró el campo Segundo apellido del demandado.",
      LOOKUP_TIMEOUT_MS
    );
    await waitFor(
      () => (apMaternoInput.value || "").trim() !== "" || null,
      "Segundo apellido del demandado no llegó a llenarse.",
      LOOKUP_TIMEOUT_MS
    );

    return `Fila ${step.row_number}/${step.total}: Tipo Persona = ${tipoPersona}, `
      + `Nombres = ${nombresInput.value}, Primer apellido = ${apPaternoInput.value}, `
      + `Segundo apellido = ${apMaternoInput.value}.`;
  }

  // The SII lookup above fills the FULL legal name; the client wants the
  // shorter form filed instead, so this overwrites it — same typing approach
  // as fillRut, since it is a plain Knockout `value` binding (perNombres),
  // not a mask, but replaying real keys keeps Knockout's own change handling
  // consistent either way.
  async function editRazonSocial(step) {
    const wanted = String(step.value || "").trim();
    const input = await waitFor(
      () => document.querySelector(RAZON_SOCIAL_INPUT_SELECTOR),
      "No se encontró el campo Razón Social."
    );
    if (foldLabel(input.value) === foldLabel(wanted)) {
      return `Fila ${step.row_number}/${step.total}: Razón Social ya estaba en "${wanted}".`;
    }
    input.focus();
    input.click();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    for (const char of wanted) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      input.value += char;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(15);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();

    await waitFor(
      () => foldLabel(input.value) === foldLabel(wanted) || null,
      `Razón Social no quedó en "${wanted}" (quedó "${input.value}").`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: Razón Social corregida a "${input.value}".`;
  }

  // Same shape as Agregar Materia: no stable id, reached by its Knockout
  // click binding. litigantesCausa is the SAME foreach container that renders
  // the Tipo Sujeto/Rut/Razón Social block being edited, so a successful add
  // is read the same way — counting its children before/after the click.
  const AGREGAR_LITIGANTE_BINDING = "validarIngresoLitigante";
  const LITIGANTES_LIST_SELECTOR = 'div[data-bind*="foreach: litigantesCausa"]';

  // Just the digits of a Rut, however it was written — "97.023.000-9" and
  // "970230009" fold to the same key, so a Rut read off a PJUD card compares
  // with one this bot typed without caring which format either side used.
  // Mirrors rut_digits() in functions.py.
  function rutDigits(value) {
    return String(value == null ? "" : value).replace(/\D/g, "");
  }

  // Every Rut currently showing on a litigante SUMMARY card, as digits.
  // rutFormateado() is what those cards render; see awaitDdoSummary below,
  // which reads the same selector for a single Rut.
  function litiganteCardRuts() {
    return Array.from(document.querySelectorAll(RUT_FORMATEADO_SELECTOR))
      .map((el) => rutDigits(el.textContent))
      .filter(Boolean);
  }

  function countLitiganteBlocks() {
    const list = document.querySelector(LITIGANTES_LIST_SELECTOR);
    return list ? list.children.length : 0;
  }

  // Opens the per-causa litigante-data modal. This is intentionally anchored
  // to PJUD's Knockout click binding rather than to the visible label or the
  // surrounding Bootstrap layout: the text/layout may move, while
  // showModalDatosMultipleLitigante is the action that actually opens the
  // modal. The button's enable binding (bloqueoDatosLitigante) becomes false
  // while the current litigante data is not ready, so clicking before the
  // native disabled state clears would be a silent no-op.
  //
  // This handler begins the conditional missing-address recovery. The bridge
  // only emits it after clickAgregarLitigante observes PJUD's exact validation
  // toast; after the modal steps finish, the bridge retries that add once.
  const DATOS_LITIGANTE_BINDING = "showModalDatosMultipleLitigante";
  const DIRECCION_FORM_ID = "formularioDireccion";
  const TIPO_DIRECCION_BINDING = "value: tipoDireccion,";
  const REGION_DIRECCION_BINDING = "value: region,";
  const COMUNA_DIRECCION_BINDING = "value: comuna,";
  const TIPO_CALLE_DIRECCION_BINDING = "value: tipoCalle,";
  const DIRECCION_INPUT_BINDING = "value: direccion,";
  const NUMERO_DIRECCION_INPUT_BINDING = "value: numero,";
  const INGRESAR_DIRECCION_BINDING = "validarCamposDireccion";
  const GUARDAR_DATOS_LITIGANTE_BINDING = "guardarEditarDatosMultiplesLitigante";
  const LISTA_DIRECCIONES_ID = "listaTemporalDirecciones";
  const MISSING_ADDRESS_TOAST =
    "Debe ingresar una dirección particular o comercial para este litigante.";

  async function clickDatosLitigante(step) {
    const button = await waitFor(
      () => findByBinding("button[data-bind]", DATOS_LITIGANTE_BINDING),
      "No se encontró el botón 'Datos Litigante'."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Datos Litigante' siguió deshabilitado.",
      LOOKUP_TIMEOUT_MS
    );
    button.click();
    return `Fila ${step.row_number}/${step.total}: se hizo clic en "Datos Litigante".`;
  }

  // PJUD's address-modal select2 ids drift on every render, so resolve each
  // control through its underlying Knockout value binding inside the VISIBLE
  // address form. Treating an already-selected value as success makes every
  // field step idempotent and avoids reopening a dropdown unnecessarily.
  async function selectDireccionOption(step, bindingName, fieldLabel) {
    const wanted = String(step.value || "").trim();
    if (!wanted) {
      throw new Error(`${fieldLabel} llegó sin valor esperado.`);
    }
    const container = await waitFor(
      () => {
        const form = document.getElementById(DIRECCION_FORM_ID);
        if (!isVisible(form)) return null;
        const found = findSelect2ContainerByBinding(bindingName, form);
        return isVisible(found) ? found : null;
      },
      `No se encontró el campo '${fieldLabel}' en Datos Litigante.`
    );
    if (select2Chosen(container) !== foldLabel(wanted)) {
      await setSelect2El(container, fieldLabel, wanted);
    }
    await waitFor(
      () => select2Chosen(container) === foldLabel(wanted) || null,
      `${fieldLabel} no quedó en "${wanted}".`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: ${fieldLabel} = ${wanted}.`;
  }

  // First field inside Datos Litigante > Direcciones. The captured page may
  // already default it to Particular, which the generic driver simply verifies.
  function selectTipoDireccion(step) {
    return selectDireccionOption(step, TIPO_DIRECCION_BINDING, "Tipo de Dirección");
  }

  // Second field in the same modal. Selecting Región also drives PJUD's
  // dependent Comuna list, so this step verifies the exact chosen text before
  // the future Comuna step is allowed to start.
  function selectRegionDireccion(step) {
    return selectDireccionOption(step, REGION_DIRECCION_BINDING, "Región");
  }

  // PJUD populates this dependent list after Región changes. The shared
  // select2 driver waits for the control to enable and for the exact option
  // to appear, then reads the chosen value back before continuing.
  function selectComunaDireccion(step) {
    return selectDireccionOption(step, COMUNA_DIRECCION_BINDING, "Comuna");
  }

  // The full modal DOM exposes this control through value: tipoCalle. It may
  // already default to Calle; the generic driver verifies that state without
  // opening the dropdown, or selects the exact option when needed.
  function selectTipoCalleDireccion(step) {
    return selectDireccionOption(step, TIPO_CALLE_DIRECCION_BINDING, "Tipo de Calle");
  }

  // Plain Knockout inputs in the address modal use valueUpdate: afterkeydown,
  // so assign-through-JS alone is not enough. Replay the same key/input event
  // sequence used by the bot's other text fields and read the final value back.
  async function fillDireccionInput(step, bindingName, fieldLabel) {
    const wanted = String(step.value || "").trim();
    if (!wanted) {
      throw new Error(`${fieldLabel} llegó sin valor esperado.`);
    }
    const input = await waitFor(
      () => {
        const form = document.getElementById(DIRECCION_FORM_ID);
        if (!isVisible(form)) return null;
        const found = Array.from(form.querySelectorAll("input[data-bind]"))
          .find((el) => String(el.getAttribute("data-bind") || "").includes(bindingName));
        return isVisible(found) && !found.disabled ? found : null;
      },
      `No se encontró el campo '${fieldLabel}' habilitado en Datos Litigante.`
    );
    if (String(input.value || "").trim() !== wanted) {
      input.focus();
      input.click();
      input.value = "";
      input.dispatchEvent(new Event("input", { bubbles: true }));
      for (const char of wanted) {
        dispatchKey(input, "keydown", char);
        dispatchKey(input, "keypress", char);
        input.value += char;
        input.dispatchEvent(new InputEvent("input", {
          bubbles: true,
          data: char,
          inputType: "insertText"
        }));
        dispatchKey(input, "keyup", char);
        await sleep(15);
      }
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.blur();
    }
    await waitFor(
      () => String(input.value || "").trim() === wanted || null,
      `${fieldLabel} no quedó en "${wanted}".`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: ${fieldLabel} = ${wanted}.`;
  }

  function fillDireccionProvisional(step) {
    return fillDireccionInput(step, DIRECCION_INPUT_BINDING, "Dirección");
  }

  function fillNumeroProvisional(step) {
    return fillDireccionInput(step, NUMERO_DIRECCION_INPUT_BINDING, "Número");
  }

  function direccionTemporalCount() {
    const root = document.getElementById(LISTA_DIRECCIONES_ID);
    if (!root) return null;
    const badge = Array.from(root.querySelectorAll("[data-bind]"))
      .find((el) => String(el.getAttribute("data-bind") || "")
        .includes("listaDireccionesTemporal().length"));
    if (!badge) return null;
    const count = Number.parseInt(String(badge.textContent || "").trim(), 10);
    return Number.isFinite(count) ? count : null;
  }

  // "Ingresar" inside the address card only adds the provisional address to
  // the modal's temporary list; it is not the causa-level Ingresar button.
  // Confirm the Knockout list count grows so a validation rejection can never
  // be mistaken for a successful click.
  async function clickIngresarDireccionProvisional(step) {
    const button = await waitFor(
      () => Array.from(document.querySelectorAll("button[data-bind]"))
        .find((el) => isVisible(el)
          && String(el.getAttribute("data-bind") || "").includes(INGRESAR_DIRECCION_BINDING))
        || null,
      "No se encontró el botón 'Ingresar' de la dirección."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Ingresar' de la dirección siguió deshabilitado.",
      10000
    );
    const before = await waitFor(
      () => {
        const count = direccionTemporalCount();
        return count == null ? null : { count };
      },
      "No se pudo leer la lista temporal de direcciones."
    );
    button.click();
    const after = await waitFor(
      () => {
        const count = direccionTemporalCount();
        return count != null && count > before.count ? { count } : null;
      },
      "'Ingresar' no agregó la dirección a la lista temporal.",
      LOOKUP_TIMEOUT_MS
    );
    return `Fila ${step.row_number}/${step.total}: dirección provisional agregada `
      + `a la lista (${before.count} → ${after.count}).`;
  }

  // Persists the modal's temporary address list back into this causa's
  // litigante data. A click alone is not proof: validation can reject it while
  // leaving the modal open, so success requires the visible address form to
  // close/disappear after Guardar.
  async function clickGuardarDatosLitigante(step) {
    const button = await waitFor(
      () => Array.from(document.querySelectorAll("button[data-bind]"))
        .find((el) => isVisible(el)
          && String(el.getAttribute("data-bind") || "")
            .includes(GUARDAR_DATOS_LITIGANTE_BINDING))
        || null,
      "No se encontró el botón 'Guardar' de Datos Litigante."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Guardar' de Datos Litigante siguió deshabilitado.",
      10000
    );
    const addressCount = direccionTemporalCount();
    if (addressCount == null || addressCount < 1) {
      throw new Error(
        "No se guardará Datos Litigante: la lista temporal no contiene la dirección provisional."
      );
    }
    button.click();
    await waitFor(
      () => {
        const form = document.getElementById(DIRECCION_FORM_ID);
        return !form || !isVisible(form) ? true : null;
      },
      "'Guardar' no cerró Datos Litigante; la dirección puede no haberse guardado.",
      LOOKUP_TIMEOUT_MS
    );
    return `Fila ${step.row_number}/${step.total}: Datos Litigante guardado y modal cerrado.`;
  }

  // Rewritten 2026-08-21 after row 8 of a 57-row run died here and took the
  // remaining 39 RUTs with it. The old version clicked immediately, then
  // watched ONE node's child count for 8 seconds. Three separate ways for
  // that to report failure on a litigante that was actually added — all of
  // them indistinguishable in the log — are fixed here:
  //
  //   1. it never waited for the button to go enabled, and a click on a
  //      Knockout-disabled button is a SILENT no-op (clickAgregarMateria and
  //      clickCerrarContinuar both wait; this one did not);
  //   2. 8s is far too short for an action PJUD validates server-side —
  //      every lookup step in this file already uses LOOKUP_TIMEOUT_MS, and
  //      this one fired right after the run's heaviest upload row;
  //   3. the container was captured BEFORE the click and then polled by
  //      reference, so a Knockout re-render that REPLACES it leaves a
  //      detached node whose children.length can never change.
  //
  // No BLIND click retry on purpose: a second click on an add that actually
  // landed would duplicate the litigante. The only click retry is owned by
  // the bridge after the exact missing-address toast and a confirmed Guardar;
  // a generic timeout still fails the row without changing its address.
  function watchAgregarLitiganteOutcome(landed, timeoutMs) {
    const normalizeToast = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const initialAddressToasts = new Set(
      Array.from(document.querySelectorAll(".toast-message"))
        .filter((el) => normalizeToast(el.textContent) === MISSING_ADDRESS_TOAST)
    );
    let armed = false;
    let settled = false;
    let observer = null;
    let pollTimer = null;
    let timeoutTimer = null;
    let resolveOutcome = null;

    const promise = new Promise((resolve) => {
      resolveOutcome = resolve;
    });
    const finish = (outcome) => {
      if (settled) return;
      settled = true;
      if (observer) observer.disconnect();
      if (pollTimer) window.clearInterval(pollTimer);
      if (timeoutTimer) window.clearTimeout(timeoutTimer);
      resolveOutcome(outcome);
    };
    const check = () => {
      if (!armed || settled) return;
      // If the card and a toast happen to render in the same browser turn,
      // the actual added card wins: the litigante is already on the causa.
      if (landed()) {
        finish({ kind: "landed" });
        return;
      }
      const addressToast = Array.from(document.querySelectorAll(".toast-message"))
        .find((el) => (
          !initialAddressToasts.has(el)
          && normalizeToast(el.textContent) === MISSING_ADDRESS_TOAST
        ));
      if (addressToast) {
        finish({ kind: "missing-address" });
      }
    };

    observer = new MutationObserver(check);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true
    });
    pollTimer = window.setInterval(check, 100);
    timeoutTimer = window.setTimeout(() => finish({ kind: "timeout" }), timeoutMs);

    return {
      promise,
      // Arming happens immediately before button.click(). MutationObserver
      // callbacks run after the click stack, so even a synchronous toast
      // insertion is captured while stale pre-existing toasts stay ignored.
      arm() {
        armed = true;
      },
      cancel() {
        finish({ kind: "cancelled" });
      }
    };
  }

  async function clickAgregarLitigante(step) {
    const wanted = rutDigits(step.value);
    const button = await waitFor(
      () => findByBinding("button[data-bind]", AGREGAR_LITIGANTE_BINDING),
      "No se encontró el botón 'Agregar Litigante'."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Agregar Litigante' siguió deshabilitado (la búsqueda del Rut "
      + "puede no haber terminado de validarse).",
      LOOKUP_TIMEOUT_MS
    );

    // Two independent readings of "it landed", either of which is enough: the
    // foreach container grew (re-queried every poll, never held), or THIS
    // Rut gained a summary card. The count is a proxy; the card is the fact.
    const beforeBlocks = countLitiganteBlocks();
    const beforeCards = wanted
      ? litiganteCardRuts().filter((rut) => rut === wanted).length
      : 0;
    const landed = () => {
      if (countLitiganteBlocks() > beforeBlocks) return true;
      if (!wanted) return false;
      return litiganteCardRuts().filter((rut) => rut === wanted).length > beforeCards;
    };

    const outcomeWatcher = watchAgregarLitiganteOutcome(landed, LOOKUP_TIMEOUT_MS);
    outcomeWatcher.arm();
    try {
      button.click();
    } catch (error) {
      outcomeWatcher.cancel();
      throw error;
    }
    const outcome = await outcomeWatcher.promise;
    if (outcome.kind === "missing-address") {
      return {
        message: `Fila ${step.row_number}/${step.total}: PJUD indicó que el `
          + "litigante necesita una dirección particular o comercial.",
        addressRequired: true
      };
    }
    if (outcome.kind !== "landed") {
      // One last look after a settle: a render that arrived a moment late is
      // still a success, and reading again costs nothing.
      await sleep(2000);
      if (!landed()) {
        throw new Error(
          "'Agregar Litigante' no sumó el litigante a la lista"
          + (wanted ? ` (Rut ${step.value})` : "")
          + `: ni litigantesCausa ni las tarjetas de litigantes cambiaron en `
          + `${Math.round(LOOKUP_TIMEOUT_MS / 1000)}s.`
        );
      }
    }
    return `Fila ${step.row_number}/${step.total}: se agregó el litigante a la causa.`;
  }

  // Reads the litigante SUMMARY card rather than trusting clickAgregarLitigante's
  // count-based check alone — confirms THIS row's own Rut (rutFormateado(), as
  // step.value from the backend) shows up tagged "Demandado" (tipoLitigante().
  // descripcion()), not just that some card was added. Worth the extra read
  // right before Ingresar, which files the demanda for real.
  const RUT_FORMATEADO_SELECTOR = '[data-bind*="rutFormateado()"]';
  const TIPO_LITIGANTE_SELECTOR = '[data-bind*="tipoLitigante().descripcion()"]';
  const CARD_CONTAINER_SELECTOR = ".pg_card_td_content";

  async function awaitDdoSummary(step) {
    const wantedRut = String(step.value || "").trim();
    const rutEl = await waitFor(
      () => {
        const candidates = Array.from(document.querySelectorAll(RUT_FORMATEADO_SELECTOR));
        return candidates.find((el) => foldLabel(el.textContent) === foldLabel(wantedRut)) || null;
      },
      `No se encontró el litigante con Rut ${wantedRut} en el resumen de Litigantes.`,
      LOOKUP_TIMEOUT_MS
    );
    const card = rutEl.closest(CARD_CONTAINER_SELECTOR) || rutEl.parentElement;
    const tipoEl = card && card.querySelector(TIPO_LITIGANTE_SELECTOR);
    const tipo = tipoEl ? tipoEl.textContent.trim() : "";
    if (foldLabel(tipo) !== foldLabel("Demandado")) {
      throw new Error(
        `El litigante con Rut ${wantedRut} aparece como "${tipo || "(vacío)"}", no como "Demandado".`
      );
    }
    return `Fila ${step.row_number}/${step.total}: litigante Demandado confirmado en el `
      + `resumen (Rut ${wantedRut}).`;
  }

  // THE SUBMIT BUTTON. No stable id, same "reach it by its Knockout binding"
  // pattern as Agregar Materia / Agregar Litigante — but unlike those, there
  // is no local confirmation to read back: a successful click NAVIGATES the
  // page (the causa is filed), so this step's own success is exactly the
  // click landing on an enabled button, and the row's completion message in
  // BotManager IS the confirmation the operator gets.
  const INGRESAR_BINDING = "ingresarCausa";

  async function clickIngresar(step) {
    const button = await waitFor(
      () => findByBinding("button[data-bind]", INGRESAR_BINDING),
      "No se encontró el botón 'Ingresar'."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Ingresar' sigue deshabilitado (¿faltan datos del litigante?).",
      8000
    );
    button.click();
    return `Fila ${step.row_number}/${step.total}: se presionó 'Ingresar'.`;
  }

  // PJUD opens this modal automatically right after a successful Ingresar.
  // No id, so it is found by its header text — same approach as
  // clickIngresarDemanda's menu lookup. The page can take a few seconds to
  // render it, hence the long lookup timeout instead of the default 15s.
  const MODAL_HEADER_SELECTOR = ".modal-header";

  async function awaitAdjuntarModal(step) {
    await waitFor(
      () => {
        const headers = Array.from(document.querySelectorAll(MODAL_HEADER_SELECTOR));
        const match = headers.find((el) => foldLabel(el.textContent) === foldLabel("Adjuntar Archivo"));
        return (match && isVisible(match.closest(".modal-content") || match)) || null;
      },
      "No apareció la ventana 'Adjuntar Archivo' tras presionar Ingresar.",
      LOOKUP_TIMEOUT_MS
    );
    return `Fila ${step.row_number}/${step.total}: se abrió la ventana 'Adjuntar Archivo'.`;
  }

  // Documento Principal's required Referencia field. Plain Knockout `value`
  // binding, same key-replay approach as edit_razon_social so Knockout's own
  // change handling stays consistent.
  const REFERENCIA_PRINCIPAL_SELECTOR = 'input[data-bind*="referenciaPrincipal"]';

  async function fillReferenciaPrincipal(step) {
    const wanted = String(step.value || "").trim();
    const input = await waitFor(
      () => document.querySelector(REFERENCIA_PRINCIPAL_SELECTOR),
      "No se encontró el campo 'Referencia.' del Documento Principal."
    );
    if (foldLabel(input.value) === foldLabel(wanted)) {
      return `Fila ${step.row_number}/${step.total}: Referencia ya estaba en "${wanted}".`;
    }
    input.focus();
    input.click();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    for (const char of wanted) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      input.value += char;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(15);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();

    await waitFor(
      () => foldLabel(input.value) === foldLabel(wanted) || null,
      `Referencia no quedó en "${wanted}" (quedó "${input.value}").`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: Referencia = "${input.value}".`;
  }

  // Documento Anexo card's Referencia field — plain `value: referencia`
  // binding. EXACT match, not *=: "referencia" is itself a substring of
  // "referenciaPrincipal", so a *= selector here would also match the OTHER
  // card's field above and silently type into the wrong one.
  const REFERENCIA_ANEXO_SELECTOR = 'input[data-bind="value: referencia"]';

  async function fillReferenciaAnexo(step) {
    const wanted = String(step.value || "").trim();
    const input = await waitFor(
      () => document.querySelector(REFERENCIA_ANEXO_SELECTOR),
      "No se encontró el campo 'Referencia.' del Documento Anexo."
    );
    if (foldLabel(input.value) === foldLabel(wanted)) {
      return `Fila ${step.row_number}/${step.total}: Referencia (Anexo) ya estaba en "${wanted}".`;
    }
    input.focus();
    input.click();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    for (const char of wanted) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      input.value += char;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(15);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();

    await waitFor(
      () => foldLabel(input.value) === foldLabel(wanted) || null,
      `Referencia (Anexo) no quedó en "${wanted}" (quedó "${input.value}").`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: Referencia (Anexo) = "${input.value}".`;
  }

  // "Tipo de Documento" on the Documento Anexo card — appears only once a
  // file has been staged on that card's dropzone. select2 with no stable
  // container id (autogen ids drift between renders), so it is reached the
  // same way as Materia/Procedimiento: through its Knockout `value` binding.
  const TIPO_DOCUMENTO_ANEXO_BINDING = "tipoEspecie";

  async function selectTipoDocumentoAnexo(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => findSelect2ContainerByBinding(TIPO_DOCUMENTO_ANEXO_BINDING),
      "No se encontró el campo 'Tipo de Documento' del Documento Anexo."
    );
    await setSelect2El(container, "Tipo de Documento", wanted);
    return `Fila ${step.row_number}/${step.total}: Tipo de Documento (Anexo) = ${wanted}.`;
  }

  // Fetches THIS row's own signed demanda PDF from the bridge (functions.py's
  // GET /file?row=N, relayed through background.js as base64 — the page is
  // HTTPS and the bridge is plain HTTP, so a direct fetch here would be
  // blocked as mixed content) and stages it on the hidden file input via
  // DataTransfer. A synthetic click alone cannot open PJUD's native file
  // dialog (Chrome requires a trusted user gesture for that), so this is the
  // only way to attach the file without a human picking it by hand.
  const DEMANDA_FILE_INPUT_ID = "uploadMultiFileDocPrincipal";

  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  async function attachDemandaFile(step) {
    const result = await bridgeRequest(`/file?row=${step.row_number}`);
    const bytes = base64ToBytes(result.content_base64);
    const file = new File([bytes], result.filename, { type: "application/pdf" });

    const input = await waitFor(
      () => document.getElementById(DEMANDA_FILE_INPUT_ID),
      "No se encontró el input de archivo del Documento Principal."
    );
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    input.files = dataTransfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    // Remembered so the confirm step can recognise THIS file by its size.
    pendingPrincipalBytes = bytes.length;
    // First upload of the row — start this row's ledger fresh.
    rowUploads = { principal: bytes.length, anexos: {} };

    return `Fila ${step.row_number}/${step.total}: se adjuntó ${result.filename} (${bytes.length} bytes).`;
  }

  // Documento Principal dropzone's "Adjuntar" button. No local confirmation
  // read here — that is await_documento_principal_attached's job.
  const ADJUNTAR_BINDING = "uploadDocumentoPrincipal";

  async function clickAdjuntar(step) {
    const button = await waitFor(
      () => findByBinding("button[data-bind]", ADJUNTAR_BINDING),
      "No se encontró el botón 'Adjuntar' del Documento Principal."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Adjuntar' sigue deshabilitado.",
      8000
    );
    // Snapshot BEFORE the click: how many cards already show this exact
    // size. Confirmation is one MORE than this, so a card left over from an
    // earlier document of identical size can never be mistaken for ours.
    principalSizeBaseline = countCardsWithSize(readDocumentoPrincipalCards(), pendingPrincipalBytes);
    button.click();
    return `Fila ${step.row_number}/${step.total}: se presionó 'Adjuntar'.`;
  }

  // Per-file confirmation is BEST EFFORT and deliberately short: PJUD is
  // slow to accept the first uploads of a session (on a real run the first
  // three "failed" here and were on the portal all along), but blocking for
  // minutes on each one is unusable across hundreds of files. So this waits
  // only briefly, and whatever it misses is picked up by
  // verify_documentos_adjuntos, which re-checks EVERY document for the row
  // in one pass just before the modal closes — by then the slow uploads have
  // had the whole rest of the row to land, at no extra cost.
  //
  // Re-clicking Adjuntar as a "retry" was REMOVED: it never once rescued a
  // confirmation, and firing it while an upload is still in flight risks a
  // duplicate document on a real court filing.
  const DOC_PRINCIPAL_CONFIRM_TIMEOUT_MS = 20000;
  const CONFIRM_HEARTBEAT_EVERY_MS = 10000;

  // PJUD's tamano() is EXACTLY bytes / 1048576 rounded to 4 decimals —
  // verified against every confirmed upload of the 19-08-2026 runs:
  //   177989 B -> 0.1697   182206 -> 0.1738   481817 -> 0.4595
  //   367004   -> 0.3500  1419609 -> 1.3538   392520 -> 0.3743
  //   169712   -> 0.1618    38752 -> 0.0370  8267160 -> 7.8842
  // We know the exact byte length of the file we injected, so that number is
  // a fingerprint of THIS upload. Confirming on it answers the real question
  // ("did MY file land?") instead of the weaker one the card-count check
  // asked ("did some card show up?"), and it does not care whether PJUD
  // appends or prepends the card, nor how it renders the Referencia.
  const BYTES_PER_MB = 1048576;
  // ±0.0002 MB ≈ ±210 B: absorbs any rounding-direction difference without
  // being wide enough to confuse two genuinely different documents.
  const TAMANO_EPSILON = 0.0002;

  function matchesUploadedSize(card, bytes) {
    if (!bytes || !Number.isFinite(card.tamanoValue)) return false;
    return Math.abs(card.tamanoValue - bytes / BYTES_PER_MB) <= TAMANO_EPSILON;
  }

  // Counting (not just finding) keeps this correct when a causa legitimately
  // carries two documents of identical size: confirmation means one MORE
  // card of that size than before this Adjuntar, not merely that one exists.
  function countCardsWithSize(cards, bytes) {
    return cards.filter((card) => matchesUploadedSize(card, bytes)).length;
  }

  function findDocumentoPrincipalList() {
    return Array.from(document.querySelectorAll('[data-bind*="documentoPrincipal"]'))
      .find((el) => /foreach:\s*\{\s*data:\s*documentoPrincipal/.test(el.getAttribute("data-bind") || ""))
      || null;
  }

  function readDocumentoPrincipalCards() {
    const list = findDocumentoPrincipalList();
    if (!list) return [];
    return Array.from(list.children).map((card) => {
      const referenciaEl = card.querySelector('p[data-bind*="referencia()"]');
      const tamanoEl = card.querySelector('p[data-bind*="tamano()"]');
      const tamanoText = tamanoEl ? tamanoEl.textContent.trim() : "";
      const tamanoValue = parseFloat((tamanoText.match(/[\d.,]+/) || [""])[0].replace(",", "."));
      return {
        referencia: referenciaEl ? referenciaEl.textContent.trim() : "",
        tamanoText,
        tamanoValue
      };
    });
  }

  // Byte length of the file attach_demanda_file staged, and how many cards
  // of that exact size were already on the page before Adjuntar was pressed.
  // Captured in clickAdjuntar so a re-render between steps cannot move them.
  let pendingPrincipalBytes = 0;
  let principalSizeBaseline = 0;

  // Everything THIS row injected, so verify_documentos_adjuntos can re-check
  // all of it in one pass before the modal closes. Reset by
  // attach_demanda_file, which runs exactly once per row, ahead of any anexo.
  let rowUploads = { principal: 0, anexos: {} };

  async function waitForDocumentoPrincipalCard(wantedReferencia, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    let lastBeat = Date.now();
    while (Date.now() < deadline) {
      const cards = readDocumentoPrincipalCards();
      // Primary: OUR file, identified by its own size.
      if (countCardsWithSize(cards, pendingPrincipalBytes) > principalSizeBaseline) {
        return cards.filter((card) => matchesUploadedSize(card, pendingPrincipalBytes)).pop();
      }
      // Fallback: if PJUD ever changes how it computes tamano(), the size
      // fingerprint stops matching and we would never confirm anything. The
      // older Referencia+positive-size check keeps working in that case.
      const byReferencia = cards.find(
        (card) => foldLabel(card.referencia) === foldLabel(wantedReferencia)
          && Number.isFinite(card.tamanoValue) && card.tamanoValue > 0
      );
      if (byReferencia) return byReferencia;
      if (Date.now() - lastBeat >= CONFIRM_HEARTBEAT_EVERY_MS) {
        heartbeat();
        lastBeat = Date.now();
      }
      await sleep(500);
    }
    return null;
  }

  async function awaitDocumentoPrincipalAttached(step) {
    const wantedReferencia = String(step.value || "").trim();

    {
      const card = await waitForDocumentoPrincipalCard(wantedReferencia, DOC_PRINCIPAL_CONFIRM_TIMEOUT_MS);
      if (card) {
        return {
          confirmed: true,
          message: `Fila ${step.row_number}/${step.total}: Documento Principal confirmado `
            + `("${card.referencia}", ${card.tamanoText} MB).`
        };
      }
    }
    // No fatal error here on purpose: click_ingresar already filed the causa
    // for this row, so there is no recovery route regardless — stopping the
    // whole run over an unconfirmed (possibly just slow) render would be
    // worse than continuing and letting the operator check manually.
    // confirmed: false is what tells the result Excel this needs a manual
    // check on the portal.
    return {
      confirmed: false,
      message: `Fila ${step.row_number}/${step.total}: no se pudo confirmar el Documento `
        + `Principal tras ${Math.round(DOC_PRINCIPAL_CONFIRM_TIMEOUT_MS / 1000)}s; `
        + "puede haberse adjuntado igual — revisar en el portal. Se continúa."
    };
  }

  // --- Documento Anexo (pagaré) mini-loop -------------------------------
  // Fill Referencia/Original Papel/Tipo de Documento are already built above
  // (fillReferenciaAnexo, click_original_papel reusing clickFijarDatos,
  // selectTipoDocumentoAnexo). What's left: Observación (the per-pagaré
  // ordinal), staging+attaching the file, and confirming it landed — same
  // shapes as the Documento Principal steps, but this card can hold SEVERAL
  // cards with the identical Referencia ("PAGARE"), so confirmation has to
  // diff the card COUNT, not just find any matching card.

  const OBSERVACION_ANEXO_SELECTOR = 'input[data-bind="value: observacion"]';

  async function fillObservacionPagare(step) {
    const wanted = String(step.value || "").trim();
    const input = await waitFor(
      () => document.querySelector(OBSERVACION_ANEXO_SELECTOR),
      "No se encontró el campo 'Observación' del Documento Anexo."
    );
    input.focus();
    input.click();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));

    for (const char of wanted) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      input.value += char;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(15);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();

    await waitFor(
      () => input.value.trim() === wanted || null,
      `Observación no quedó en "${wanted}" (quedó "${input.value}").`,
      5000
    );
    return `Fila ${step.row_number}/${step.total}: Observación = "${input.value}".`;
  }

  // Fetches THIS anexo item (0-based step.anexo_index, into the combined
  // pagaré/contrato/mandato list functions.py's resolve_anexo_items builds)
  // from the bridge and stages it on the Anexo card's OWN hidden input — a
  // different element from Documento Principal's — same DataTransfer
  // technique as attachDemandaFile, same reason (no trusted gesture for a
  // native dialog).
  const ANEXO_FILE_INPUT_ID = "uploadMultiFileDocAnexo";

  async function attachAnexoFile(step) {
    const anexoIndex = Number.isFinite(step.anexo_index) ? step.anexo_index : 0;
    const result = await bridgeRequest(`/file?row=${step.row_number}&kind=anexo&index=${anexoIndex}`);
    const bytes = base64ToBytes(result.content_base64);
    const file = new File([bytes], result.filename, { type: "application/pdf" });

    const input = await waitFor(
      () => document.getElementById(ANEXO_FILE_INPUT_ID),
      "No se encontró el input de archivo del Documento Anexo."
    );
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    input.files = dataTransfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    // Remembered so the confirm step can recognise THIS file by its size.
    pendingAnexoBytes = bytes.length;
    rowUploads.anexos[anexoIndex] = bytes.length;

    return `Fila ${step.row_number}/${step.total}: se adjuntó anexo #${anexoIndex + 1} `
      + `(${result.filename}, ${bytes.length} bytes).`;
  }

  // Documento Anexo card's OWN "Adjuntar" button — DIFFERENT Knockout
  // binding from Documento Principal's uploadDocumentoPrincipal. Snapshots
  // the card list right before clicking so awaitDocumentoAnexoAttached can
  // tell THIS attach's new card apart from the ones already there — every
  // pagaré on a row renders with the identical Referencia ("PAGARE"), so
  // the card's own size is what actually distinguishes them.
  const ADJUNTAR_ANEXO_BINDING = "uploadDocumentoAnexo";
  let anexoCardBaselineCount = 0;
  // Byte length of the file attach_anexo_file staged, and how many cards of
  // that exact size were on the page before Adjuntar was pressed.
  let pendingAnexoBytes = 0;
  let anexoSizeBaseline = 0;

  function findDocumentosAnexosList() {
    return Array.from(document.querySelectorAll('[data-bind*="documentosAnexos"]'))
      .find((el) => /foreach:\s*\{\s*data:\s*documentosAnexos/.test(el.getAttribute("data-bind") || ""))
      || null;
  }

  function readDocumentosAnexosCards() {
    const list = findDocumentosAnexosList();
    if (!list) return [];
    return Array.from(list.children).map((card) => {
      const referenciaEl = card.querySelector('p[data-bind*="referencia()"]');
      const tamanoEl = card.querySelector('p[data-bind*="tamano()"]');
      const tamanoText = tamanoEl ? tamanoEl.textContent.trim() : "";
      const tamanoValue = parseFloat((tamanoText.match(/[\d.,]+/) || [""])[0].replace(",", "."));
      return {
        referencia: referenciaEl ? referenciaEl.textContent.trim() : "",
        tamanoText,
        tamanoValue
      };
    });
  }

  async function clickAdjuntarAnexo(step) {
    const button = await waitFor(
      () => findByBinding("button[data-bind]", ADJUNTAR_ANEXO_BINDING),
      "No se encontró el botón 'Adjuntar' del Documento Anexo."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Adjuntar' del Documento Anexo sigue deshabilitado.",
      8000
    );
    const before = readDocumentosAnexosCards();
    anexoCardBaselineCount = before.length;
    anexoSizeBaseline = countCardsWithSize(before, pendingAnexoBytes);
    button.click();
    return `Fila ${step.row_number}/${step.total}: se presionó 'Adjuntar' (Anexo).`;
  }

  // Same short best-effort window as the Documento Principal above, same
  // reason: this is where it bit us (pagaré #1, pagaré #2 and the contrato
  // all reported "no se pudo confirmar" and were on the portal the whole
  // time), and verify_documentos_adjuntos is what actually settles it.
  const DOC_ANEXO_CONFIRM_TIMEOUT_MS = 20000;

  async function waitForNewDocumentoAnexoCard(wantedReferencia, baselineCount, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    let lastBeat = Date.now();
    while (Date.now() < deadline) {
      const cards = readDocumentosAnexosCards();
      // Primary: one MORE card carrying OUR file's exact size than there
      // was before the click. Independent of where PJUD inserts the card
      // and of the Referencia text, which repeats across pagarés anyway.
      if (countCardsWithSize(cards, pendingAnexoBytes) > anexoSizeBaseline) {
        return cards.filter((card) => matchesUploadedSize(card, pendingAnexoBytes)).pop();
      }
      // Fallback for the day PJUD changes how tamano() is computed: the
      // original "a new card appeared and it carries this Referencia" test,
      // so a size-format change degrades the check instead of breaking it.
      if (cards.length > baselineCount) {
        const newest = cards[cards.length - 1];
        if (foldLabel(newest.referencia) === foldLabel(wantedReferencia)
          && Number.isFinite(newest.tamanoValue) && newest.tamanoValue > 0) {
          return newest;
        }
      }
      if (Date.now() - lastBeat >= CONFIRM_HEARTBEAT_EVERY_MS) {
        heartbeat();
        lastBeat = Date.now();
      }
      await sleep(500);
    }
    return null;
  }

  async function awaitDocumentoAnexoAttached(step) {
    const wantedReferencia = String(step.value || "").trim();

    const card = await waitForNewDocumentoAnexoCard(
      wantedReferencia, anexoCardBaselineCount, DOC_ANEXO_CONFIRM_TIMEOUT_MS
    );
    if (card) {
      return {
        confirmed: true,
        message: `Fila ${step.row_number}/${step.total}: documento anexo confirmado `
          + `("${card.referencia}", ${card.tamanoText} MB).`
      };
    }
    // Same reasoning as await_documento_principal_attached: click_ingresar
    // already filed the causa, so there is no recovery route regardless —
    // continuing unconfirmed beats aborting the whole run. confirmed: false
    // is what tells the result Excel this needs a manual check on the portal.
    return {
      confirmed: false,
      message: `Fila ${step.row_number}/${step.total}: no se pudo confirmar el documento `
        + `anexo ("${wantedReferencia}") tras ${Math.round(DOC_ANEXO_CONFIRM_TIMEOUT_MS / 1000)}s; `
        + "puede haberse adjuntado igual — revisar en el portal. Se continúa."
    };
  }

  // Final audit of the row, run while the modal is still open: re-check
  // EVERY file this row injected against the cards actually on the page.
  //
  // This is what makes the short per-file timeouts safe. A pagaré that PJUD
  // was still chewing on when its own confirm gave up has, by now, had the
  // whole rest of the row to finish — so it shows up here and the row's
  // result is corrected from "No Ingresado" to "Ingresado". The cost is one
  // DOM read instead of minutes of blocking per file.
  //
  // Matching is by size fingerprint (see BYTES_PER_MB above) and counted per
  // distinct size, so two documents of identical size are both required to
  // be present before either is called confirmed.
  const VERIFY_SETTLE_MS = 2000;

  async function verifyDocumentosAdjuntos(step) {
    // A brief settle so a card that landed moments ago is rendered.
    await sleep(VERIFY_SETTLE_MS);

    const principalCards = readDocumentoPrincipalCards();
    const anexoCards = readDocumentosAnexosCards();

    const principalOk = rowUploads.principal > 0
      && countCardsWithSize(principalCards, rowUploads.principal) > 0;

    // Expected count per distinct size, so duplicates need duplicate cards.
    const expectedBySize = new Map();
    for (const bytes of Object.values(rowUploads.anexos)) {
      expectedBySize.set(bytes, (expectedBySize.get(bytes) || 0) + 1);
    }
    const presentBySize = new Map();
    for (const [bytes] of expectedBySize) {
      presentBySize.set(bytes, countCardsWithSize(anexoCards, bytes));
    }
    const remaining = new Map(presentBySize);
    const anexos = {};
    for (const [index, bytes] of Object.entries(rowUploads.anexos)) {
      const left = remaining.get(bytes) || 0;
      anexos[index] = left > 0;
      if (left > 0) remaining.set(bytes, left - 1);
    }

    const missing = Object.entries(anexos).filter(([, ok]) => !ok).length;
    const total = Object.keys(anexos).length;
    return {
      verified: { principal: principalOk, anexos },
      message: `Fila ${step.row_number}/${step.total}: verificación final — `
        + `demanda ${principalOk ? "OK" : "NO ENCONTRADA"}, `
        + `anexos ${total - missing}/${total} confirmados`
        + (missing ? ` (${missing} sin confirmar; revisar en el portal).` : ".")
    };
  }

  // Closes the "Adjuntar Archivo" modal once every document for this row has
  // been attached — the last step of a row's own work, for now. Confirms by
  // waiting for the SAME modal-header lookup awaitAdjuntarModal used to
  // confirm it opened, just inverted: this time waiting for it to go away.
  const CERRAR_CONTINUAR_BINDING = "cerrarAdjuntar";

  function isAdjuntarModalOpen() {
    const headers = Array.from(document.querySelectorAll(MODAL_HEADER_SELECTOR));
    const match = headers.find((el) => foldLabel(el.textContent) === foldLabel("Adjuntar Archivo"));
    return Boolean(match && isVisible(match.closest(".modal-content") || match));
  }

  async function clickCerrarContinuar(step) {
    const button = await waitFor(
      () => findByBinding("button[data-bind]", CERRAR_CONTINUAR_BINDING),
      "No se encontró el botón 'Cerrar y Continuar'."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Cerrar y Continuar' sigue deshabilitado.",
      8000
    );
    button.click();
    await waitFor(
      () => (!isAdjuntarModalOpen()) || null,
      "La ventana 'Adjuntar Archivo' sigue abierta tras 'Cerrar y Continuar'.",
      LOOKUP_TIMEOUT_MS
    );
    return `Fila ${step.row_number}/${step.total}: se presionó 'Cerrar y Continuar'.`;
  }

  // ---------------------------------------------------------------------------
  // Recovery steps — RECOVER_STEPS in functions.py
  //
  // These run after a ROW failed, to put the portal back on a screen the bot
  // recognises so the run can carry on with the NEXT row. Before this existed,
  // any failed step ended the whole run: on 2026-08-21 one row died at
  // 'Agregar Litigante' and 39 untouched RUTs went down with it.
  // ---------------------------------------------------------------------------

  // Deliberately NOT a reload. Repeated F5s are what tripped PJUD's own bot
  // protection while this bot was being built, and closing the dialog is the
  // same move a human makes. Best effort by design — "nothing was open" is a
  // perfectly good outcome — but it DOES fail if something is still covering
  // the page afterwards, because every later step would then click into a
  // modal backdrop and report something far more confusing.
  const MODAL_SELECTOR = ".modal";
  const MODAL_DISMISS_SELECTOR = '[data-dismiss="modal"], .modal-header .close';

  function visibleModals() {
    return Array.from(document.querySelectorAll(MODAL_SELECTOR)).filter(isVisible);
  }

  async function closeBlockingDialogs(step) {
    const open = visibleModals();
    if (!open.length) {
      // A leftover backdrop with no modal above it makes the whole page
      // unclickable while looking completely normal in a screenshot.
      const orphans = Array.from(document.querySelectorAll(".modal-backdrop"));
      orphans.forEach((el) => el.remove());
      return `Fila ${step.row_number}/${step.total}: no había ventanas abiertas`
        + (orphans.length ? ` (se quitaron ${orphans.length} fondo(s) sobrantes).` : ".");
    }

    let closed = 0;
    for (const modal of open) {
      // Prefer the portal's OWN exit when this is the "Adjuntar Archivo"
      // modal: cerrarAdjuntar is the button the flow is built around (it is
      // click_cerrar_continuar's target), so it leaves PJUD's own state
      // machine where it expects to be. The generic X is the fallback.
      const proper = Array.from(modal.querySelectorAll("button[data-bind]"))
        .find((el) => String(el.getAttribute("data-bind") || "")
          .includes(CERRAR_CONTINUAR_BINDING) && isVisible(el) && !el.disabled);
      const dismiss = proper
        || Array.from(modal.querySelectorAll(MODAL_DISMISS_SELECTOR)).find(isVisible);
      if (dismiss) {
        dismiss.click();
        closed += 1;
      }
    }
    // Escape catches anything with no dismiss control of its own.
    document.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true
    }));

    await waitFor(
      () => (visibleModals().length === 0) || null,
      "Quedó una ventana abierta en el portal que el bot no pudo cerrar.",
      10000
    );
    // Bootstrap sometimes leaves the backdrop behind after the modal itself
    // is gone; it still swallows every click.
    Array.from(document.querySelectorAll(".modal-backdrop")).forEach((el) => el.remove());
    return `Fila ${step.row_number}/${step.total}: se cerraron ${closed || open.length} `
      + "ventana(s) abierta(s) del portal.";
  }

  // Reports what the RE-ENTERED causa form is already carrying, so the bridge
  // knows which parts of PREP_STEPS still need running. PJUD's three "Fijar
  // Datos" checkboxes keep the tribunal/materia block and the two fixed
  // litigantes (Itaú, the abogado) attached to the next causa — which is
  // exactly why rows 2..N normally skip prep entirely — so re-running prep
  // blindly after a recovery would file a causa listing them TWICE.
  //
  // Reads only; every judgement about what it means is made in
  // functions.py (_apply_causa_state_unlocked), including the one case this
  // cannot fix: a leftover demandado from the row that just failed.
  async function readCausaState(step) {
    const materiasList = document.querySelector(
      `#${MATERIAS_LIST_ID} [data-bind*="foreach: materiasCausa"]`
    );
    const materias = materiasList ? materiasList.children.length : 0;

    const litigantes = Array.from(document.querySelectorAll(RUT_FORMATEADO_SELECTOR))
      .map((rutEl) => {
        const card = rutEl.closest(CARD_CONTAINER_SELECTOR) || rutEl.parentElement;
        const tipoEl = card && card.querySelector(TIPO_LITIGANTE_SELECTOR);
        return {
          rut: rutEl.textContent.trim(),
          tipo: tipoEl ? tipoEl.textContent.trim() : ""
        };
      })
      .filter((item) => item.rut);

    const shown = litigantes.map((item) => `${item.rut}${item.tipo ? ` (${item.tipo})` : ""}`);
    return {
      message: `Fila ${step.row_number}/${step.total}: el formulario quedó con `
        + `${materias} materia(s) y ${litigantes.length} litigante(s)`
        + (shown.length ? `: ${shown.join("; ")}.` : "."),
      causa: { materias, litigantes }
    };
  }

  const STEP_HANDLERS = {
    click_ingresar_demanda: clickIngresarDemanda,
    select_competencia: selectCompetencia,
    select_corte: selectCorte,
    select_tribunal: selectTribunal,
    ensure_dirigido_a: ensureDirigidoA,
    click_fijar_datos: clickFijarDatos,
    select_procedimiento: selectProcedimiento,
    select_materia: selectMateria,
    click_agregar_materia: clickAgregarMateria,
    // Same handler; the checkbox id comes from STEP_VALUES.
    click_fijar_datos_materia: clickFijarDatos,
    select_tipo_sujeto: selectTipoSujeto,
    fill_rut: fillRut,
    await_litigante_lookup: awaitLitiganteLookup,
    edit_razon_social: editRazonSocial,
    click_fijar_datos_litigante: clickFijarDatos,
    // Conditional missing-address recovery, emitted only after the exact
    // PJUD toast is observed during the demandado's Agregar Litigante step.
    click_datos_litigante: clickDatosLitigante,
    select_tipo_direccion: selectTipoDireccion,
    select_region_direccion: selectRegionDireccion,
    select_comuna_direccion: selectComunaDireccion,
    select_tipo_calle_direccion: selectTipoCalleDireccion,
    fill_direccion_provisional: fillDireccionProvisional,
    fill_numero_provisional: fillNumeroProvisional,
    click_ingresar_direccion_provisional: clickIngresarDireccionProvisional,
    click_guardar_datos_litigante: clickGuardarDatosLitigante,
    click_agregar_litigante: clickAgregarLitigante,
    // Same handler; the second litigante block re-renders the identical
    // tipoLitiganteSel select2, so only the wanted option (from STEP_VALUES)
    // differs.
    select_tipo_sujeto_abogado: selectTipoSujeto,
    // Same handler; the second litigante block re-renders the identical Rut
    // input, so only the wanted digits (from STEP_VALUES) differ.
    fill_rut_abogado: fillRut,
    await_abogado_lookup: awaitAbogadoLookup,
    // Same handler; the THIRD litigante block (the demandado, LOOP_STEPS'
    // first step) re-renders the identical tipoLitiganteSel select2.
    select_tipo_sujeto_ddo: selectTipoSujeto,
    // Same handler; this row's own digits arrive as step.value from the
    // backend (see next_action's fill_rut_ddo branch), not from STEP_VALUES.
    fill_rut_ddo: fillRut,
    await_ddo_lookup: awaitDdoLookup,
    await_ddo_summary: awaitDdoSummary,
    click_ingresar: clickIngresar,
    await_adjuntar_modal: awaitAdjuntarModal,
    fill_referencia_principal: fillReferenciaPrincipal,
    attach_demanda_file: attachDemandaFile,
    click_adjuntar: clickAdjuntar,
    await_documento_principal_attached: awaitDocumentoPrincipalAttached,
    fill_referencia_anexo: fillReferenciaAnexo,
    // Same handler as click_fijar_datos; "Original Papel" is just another
    // checked: binding with its own id (see FIJAR_DATOS_MODULES above).
    click_original_papel: clickFijarDatos,
    select_tipo_documento_anexo: selectTipoDocumentoAnexo,
    fill_observacion_pagare: fillObservacionPagare,
    attach_anexo_file: attachAnexoFile,
    click_adjuntar_anexo: clickAdjuntarAnexo,
    await_documento_anexo_attached: awaitDocumentoAnexoAttached,
    verify_documentos_adjuntos: verifyDocumentosAdjuntos,
    click_cerrar_continuar: clickCerrarContinuar,
    // --- recovery phase (RECOVER_STEPS) ---
    close_blocking_dialogs: closeBlockingDialogs,
    read_causa_state: readCausaState
  };

  // End of session. Stops the work loop BEFORE the bridge server shuts down, so
  // the panel keeps the result message instead of flipping to "connection lost".
  function finish(payload, tone) {
    completed = true;
    window.clearInterval(workTimer);
    const failed = tone === "error" || Boolean(payload && payload.error);
    const message = (payload && payload.message)
      || (failed ? "El bot se detuvo por un error." : "Conexión verificada con BotManager.");
    // The desktop message is shown verbatim; the hint goes on the second line so
    // the operator reads the outcome first.
    setStatus(message, failed ? "error" : "ok");
    createPanel().querySelector('[data-role="details"]').textContent =
      "Revisa el resultado en BotManager.";
  }

  // Hard stop: no more work is pulled from the bridge. Used whenever continuing
  // could repeat an action on the portal. Recovery is deliberately manual
  // (reload the page and press Start again) so nothing touches PJUD by itself.
  function stopPump(message) {
    completed = true;
    window.clearInterval(workTimer);
    setStatus(message, "error");
    logToBridge(message);
  }

  // Reporting is what lets the bridge advance, so a failed report means the
  // next /next would hand out the SAME step again. Stop instead of looping.
  async function reportStep(body) {
    try {
      return await bridgeRequest("/report", { method: "POST", body });
    } catch (error) {
      const detail = String(error && error.message ? error.message : error);
      stopPump(
        `No se pudo informar el resultado a BotManager (${detail}). `
        + "El bot se detuvo para no repetir el paso en el portal. "
        + "Recarga la página y presiona Start de nuevo."
      );
      return null;
    }
  }

  async function pumpWork() {
    if (!verified || busy || completed) {
      return;
    }
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};

      if (step.action === "wait") {
        return;
      }
      if (step.action === "done") {
        finish(step);
        return;
      }

      const handler = STEP_HANDLERS[step.action];
      if (!handler) {
        // The desktop asked for a step this build does not know, so the loaded
        // extension is older than the bot files on disk. This MUST be reported:
        // returning without reporting leaves the bridge re-issuing the step
        // until its repeat guard trips, which blames "the same step 3 times"
        // instead of naming the real cause. The guard below is never reached
        // from here either, because it lives after this branch.
        const detail = `Paso desconocido "${step.action}": la extensión cargada `
          + `(${BUILD}) es más antigua que el bot. Recárgala en chrome://extensions `
          + "y luego recarga la pestaña del portal.";
        setStatus(detail, "error");
        logToBridge(detail);
        const staleReply = await reportStep({ ok: false, detail });
        if (staleReply && staleReply.done) {
          finish(staleReply, "error");
        }
        return;
      }

      const stepKey = `${step.row_number}:${step.step_number}:${step.action}`;
      if (stepKey === lastStepKey) {
        sameStepCount += 1;
      } else {
        lastStepKey = stepKey;
        sameStepCount = 1;
      }
      if (sameStepCount > MAX_STEP_ATTEMPTS) {
        stopPump(
          `El paso ${step.step_number} se repitió sin avanzar. El bot se detuvo `
          + "para no insistir sobre el portal. Revisa BotManager."
        );
        return;
      }

      setStatus(
        `Fila ${step.row_number}/${step.total} · paso ${step.step_number}/${step.step_total}...`
      );
      try {
        const result = await handler(step);
        // Most handlers return a plain string. The confirm steps
        // (awaitDocumentoPrincipalAttached / awaitDocumentoAnexoAttached)
        // return {message, confirmed} instead, since "the click landed" and
        // "PJUD actually confirmed it" are different things the bridge
        // needs to tell apart for the result Excel — everything else stays
        // exactly as before.
        const isRich = result && typeof result === "object";
        const detail = isRich ? result.message : result;
        setStatus(detail, "ok");
        logToBridge(detail);
        const reportBody = { ok: true, detail };
        if (isRich && "confirmed" in result) {
          reportBody.confirmed = result.confirmed;
        }
        if (isRich && "verified" in result) {
          // verify_documentos_adjuntos' per-document sweep, which the bridge
          // uses to correct results it had already written pessimistically.
          reportBody.verified = result.verified;
        }
        if (isRich && "causa" in result) {
          // read_causa_state's reading of the re-entered form, which the
          // bridge turns into "which PREP_STEPS blocks still need running".
          reportBody.causa = result.causa;
        }
        if (isRich && "addressRequired" in result) {
          // The exact transient PJUD toast. This is not a generic failure:
          // the bridge detours through the provisional-address modal and
          // returns to Agregar Litigante for one controlled retry.
          reportBody.address_required = result.addressRequired;
        }
        const reply = await reportStep(reportBody);
        if (reply && reply.done) {
          finish(reply);
        }
      } catch (error) {
        // Always report WHERE it failed. A step can fail simply because the tab
        // is on a different OJV app than the one the route was built against,
        // and that is invisible from the message alone.
        const detail = `${String(error && error.message ? error.message : error)}`
          + ` [pagina: ${window.location.href}]`;
        setStatus(`Error: ${detail}`, "error");
        logToBridge(detail);
        // The desktop decides what a failure costs: a row that fails inside
        // LOOP_STEPS is now recorded and recovered from (RECOVER_STEPS puts
        // the portal back on a known screen and the run continues with the
        // next row), while a failure during prep or recovery itself still
        // ends the run — in which case the reply comes back done.
        const reply = await reportStep({ ok: false, detail });
        if (reply && reply.done) {
          finish(reply, "error");
        }
      }
    } catch (_) {
      if (completed) {
        return; // finished cleanly; the server just shut down.
      }
      connected = false;
      setStatus("Se perdió la conexión con BotManager.", "error");
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    positionPanel();
    if (verified || starting || completed) {
      return;
    }
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      setStatus(
        onStartPage()
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Ve a indexN.php y presiona Start.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean07 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified) {
      return;
    }
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) {
        await bridgeRequest("/health");
      }
      // BUILD travels with Start so the desktop can refuse a stale extension
      // before anything is touched on the portal.
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title, build: BUILD }
      });
      if (payload.done || payload.ok === false) {
        // Rejected at the handshake (almost always: this extension is older
        // than the installed bot). Do not start the work loop.
        finish(payload, "error");
        button.disabled = false;
        return;
      }
      verified = true;
      renderSummary(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
