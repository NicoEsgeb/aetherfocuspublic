const BRIDGE_BASE_URL = "http://127.0.0.1:8769";
const MESSAGE_TYPE = "CLEAN08_BRIDGE_REQUEST";
const ALLOWED_PATHS = new Set(["/health", "/start", "/log", "/next", "/report"]);

function isFileRoute(path) {
  return path === "/file";
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

async function bridgeRequest(path, options = {}) {
  if (!ALLOWED_PATHS.has(path) && !isFileRoute(path)) {
    return { ok: false, error: `Ruta de bridge no permitida: ${path}` };
  }
  const response = await fetch(`${BRIDGE_BASE_URL}${path}`, {
    method: options.method || "GET",
    headers: { "Content-Type": "application/json" },
    body: Object.prototype.hasOwnProperty.call(options, "body")
      ? JSON.stringify(options.body)
      : undefined
  });
  if (isFileRoute(path)) {
    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      return { ok: false, error: payload.error || `Bridge ${response.status}` };
    }
    const buffer = await response.arrayBuffer();
    return {
      ok: true,
      filename: response.headers.get("X-Filename") || "escrito.pdf",
      content_base64: arrayBufferToBase64(buffer)
    };
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    return { ok: false, error: payload.error || `Bridge ${response.status}` };
  }
  return payload;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== MESSAGE_TYPE) {
    return false;
  }
  bridgeRequest(message.path || "/health", message.options || {})
    .then(sendResponse)
    .catch((error) => sendResponse({
      ok: false,
      error: String(error && error.message ? error.message : error)
    }));
  return true;
});
