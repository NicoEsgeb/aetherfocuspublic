# Clean08 Chrome extension (local)

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select this `extension` folder.
4. Start Clean08 in BotManager after selecting the workbook.
5. In the authenticated PJUD `indexN.php` page, press **Start** in the Clean08 panel.

The extension talks only to the Clean08 loopback bridge at
`http://127.0.0.1:8769`. Build `0.17.6` executes the following fifteen guarded
steps for every populated Excel row, in sheet order:

1. Click the visible menu item **Ingresar Escrito**.
2. Open the **Competencia** Select2 control and select **Civil**, with an exact
   visible-text match and read-back verification.
3. Read **Tribunal** from the current Excel row, convert (for example) `15` to
   **15º Juzgado Civil de Santiago**, and select that exact option with read-back
   verification.
4. Select **C** in the native **Tipo** dropdown by visible option text and verify
   the selected option.
5. Read **ROL** from the current Excel row, enter it in the numeric **Rol** field,
   and verify the resulting field value.
6. Read **Año** from the current Excel row, select that exact year in the **Año**
   Select2 control, and verify the visible selection.
7. Wait until **Consulta Rol** is visible and enabled, then click it once.
8. Wait for the result form, select **1 Principal** in **Cuaderno**, and verify
   the visible selection.
9. Select **AB.DTE-JOAQUÍN MAURICIO CARRILLO MORENO** in **Parte que Presenta**
   and verify the visible selection.
10. Select **Escritos Generales** in **Grupo Escrito** and verify the visible
    selection.
11. Select **Señala domicilio** in **Tipo Escrito** and verify the visible
    selection.
12. Wait until **Grabar Escrito** is visible and enabled, then click it exactly
    once. This is treated as the point of no return: after the click, the
    extension stops if it cannot report the result instead of repeating it.
13. Read the current row's **Archivo** value, fetch that PDF from
    `input/escritos-pdfs` through the local bridge, inject it into the hidden
    `#uploadMultiFileDocPrincipal` input with `DataTransfer`, verify the staged
    filename and byte size, and click the scoped **Adjuntar** button once.
14. Wait up to three minutes for PJUD to add a new Documento Principal card.
    Confirm it by matching the card's displayed `tamano()` in MB against the
    exact uploaded byte count, including a pre-click count baseline so an older
    same-sized card cannot be mistaken for this upload.
15. Find the visible button with Knockout binding `cerrarAdjuntar`, verify its
    text is **Cerrar y Continuar**, click it once, and wait until both the button
    and `#dDPrincipal` are no longer visible before reporting success.

If PJUD reloads the page after step 15, the newly loaded content script reads
the active bridge state and resumes the next Excel row automatically. The user
presses **Start** only once, at the beginning of the workbook run.

All rows and their referenced PDFs are validated before the bridge starts. Each
step reports success or failure with its number, action, label, and portal detail.
When a portal step fails, the bridge records that row (including whether it had
already passed **Grabar Escrito**), runs a best-effort cleanup of open Select2 or
attachment UI, advances the bridge cursor, and then reloads PJUD before starting
the next row. The new content script reconnects through `/health` and resumes at
Step 1 on a clean form. Outside the limited empty-dropdown case below, it never
retries the failed row, which avoids creating a duplicate after the point of no
return.

There is one narrow pre-submit exception: if a Select2 dropdown opens but PJUD
returns no options, Clean08 reloads the portal and retries that same Excel row
once from **Ingresar Escrito**. A second empty-options response, a missing
requested option, any other portal error, or any failure after **Grabar Escrito**
is not retried and is recorded normally. This avoids duplicates while tolerating
the transient empty menus observed in Run 65.

Every injected page script also owns its issued action through a unique page
instance ID. If PJUD reloads while an action is still in flight, the new script
cannot remain stuck behind the dead page's instruction. Before **Grabar
Escrito**, Clean08 uses the same one-retry-per-row budget and restarts at Step 1.
If that budget is already spent, the row is marked failed and processing moves
on. At or after **Grabar Escrito**, the row is never replayed: it is marked for
manual review unless the PDF had already been confirmed, in which case it stays
`Ingresado`. Late reports from the replaced page are ignored.

Input/preflight errors and loss of the bridge connection remain fatal because
the extension cannot safely determine whether an unreported action happened.

When the bridge reports the run as finished, the extension stores that final
state locally for seven days. If BotManager then closes the bridge or PJUD
reloads the page, the panel keeps showing **Proceso finalizado correctamente**
(or **Proceso finalizado con observaciones**) with a disabled **Finalizado**
button instead of falling back to the pre-run red disconnection message. A new
BotManager run clears the stored result automatically.

After all rows have been attempted, the bot writes
`output/Resultado_<nombre original>.xlsx`. It is a copy of the selected workbook
with `ESTADO ESCRITO` as the first column and `NOTAS` as the second:

- **Ingresado** (green): PJUD displayed the uploaded PDF as a confirmed
  Documento Principal. A later failure to close the attachment window does not
  erase this confirmation.
- **No ingresado** (yellow): the row failed before `Grabar Escrito` was pressed.
- **Revisar manualmente** (orange): `Grabar Escrito` was pressed, so the escrito
  may exist, but the PDF was not confirmed. The row must be checked before any
  retry.

For failed or ambiguous rows, `NOTAS` explains the portal location in plain
language without internal step numbers. Successful rows leave `NOTAS` empty
unless PJUD confirmed the PDF and a later cleanup action failed.
