import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

// Pure-QML run summary for Clean08. It parses structured markers written by
// bridge.py, so it ships in the bot pack and does not require a frozen plugin.
Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cText: Common.Theme.text
    readonly property color cMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarn: Common.Theme.warning
    readonly property color cDanger: Common.Theme.danger
    readonly property color cReview: "#f59e0b"

    function val(key, fallback) {
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null)
            return fallback
        return summaryData[key]
    }
    function logText() { return String(root.val("logText", "")) }

    function lastCapture(pattern) {
        var text = root.logText()
        var last = ""
        var match
        pattern.lastIndex = 0
        while ((match = pattern.exec(text)) !== null)
            last = String(match[1] || "").trim()
        return last
    }

    function statusTechnical() { return String(root.val("statusTechnical", "")).toLowerCase() }
    function isSuccess() { return root.statusTechnical() === "success" }
    function isFailed() { return root.statusTechnical() === "failed" }
    function isCancelled() { return root.statusTechnical() === "cancelled" }

    function totalRows() {
        var value = root.lastCapture(/\[CLEAN08\]\[VALIDACION_OK\]\s+filas=(\d+)/g)
        return value.length > 0 ? Number(value) : root.resultRows().length
    }
    function buildVersion() {
        return root.lastCapture(/\[CLEAN08\]\[VERSION\]\s+([^\r\n]+)/g)
    }
    function workbookName() {
        var value = root.lastCapture(/\[CLEAN08\]\[PLANILLA\]\s+([^\r\n]+)/g)
        if (value.length > 0) return value
        return root.lastCapture(/Planilla seleccionada:\s*([^\r\n]+)/g).split(/[\\/]/).pop()
    }
    function outputPath() {
        return root.lastCapture(/\[CLEAN08\]\[OUTPUT\]\s+([^\r\n]+)/g)
    }
    function failureCause() {
        var missing = root.lastCapture(/\[CLEAN08\]\[COLUMNAS_FALTANTES\]\s+([^\r\n]+)/g)
        if (missing.length > 0) return "Faltan columnas: " + missing
        var incomplete = root.lastCapture(/\[CLEAN08\]\[FILA_INCOMPLETA\]\s+([^\r\n]+)/g)
        if (incomplete.length > 0) return incomplete
        var invalid = root.lastCapture(/\[CLEAN08\]\[ENTRADA_INVALIDA\]\s+([^\r\n]+)/g)
        return invalid
    }

    // The bridge may emit the same Excel row twice: first when it fails and
    // again after recovery. Keep its last snapshot while preserving row order.
    function resultRows() {
        var text = root.logText()
        var pattern = /\[CLEAN08\]\[FILA_RESULTADO\]\s+([^\r\n]+)/g
        var byRow = ({})
        var order = []
        var match
        while ((match = pattern.exec(text)) !== null) {
            try {
                var item = JSON.parse(String(match[1] || ""))
                var key = String(item.excel_row || "")
                if (key.length === 0) continue
                if (byRow[key] === undefined) order.push(key)
                byRow[key] = item
            } catch (error) {
                // Keep rendering any other valid row markers.
            }
        }
        var rows = []
        for (var i = 0; i < order.length; i++) rows.push(byRow[order[i]])
        return rows
    }

    function countState(state) {
        var rows = root.resultRows()
        var count = 0
        for (var i = 0; i < rows.length; i++)
            if (String(rows[i].estado || "") === state) count++
        return count
    }
    function countIngresados() { return root.countState("Ingresado") }
    function countNoIngresados() { return root.countState("No ingresado") }
    function countRevisar() { return root.countState("Revisar manualmente") }
    function countRegistered() { return root.resultRows().length }

    function statusWord() {
        if (root.isCancelled()) return "Detenido"
        if (root.isFailed()) return "Con error"
        if (root.isSuccess())
            return (root.countNoIngresados() + root.countRevisar()) > 0 ? "Con pendientes" : "Completado"
        return "En proceso"
    }
    function statusColor() {
        if (root.isCancelled()) return Common.Theme.cancel
        if (root.isFailed()) return root.cDanger
        if (root.isSuccess())
            return (root.countNoIngresados() + root.countRevisar()) > 0 ? root.cWarn : root.cSuccess
        return Common.Theme.accent
    }
    function headline() {
        if (root.isCancelled())
            return "Proceso detenido: " + root.countRegistered() + " de " + root.totalRows() + " fila(s) registradas"
        if (root.isFailed()) {
            var cause = root.failureCause()
            return cause.length > 0 ? cause : "Clean08 terminó con un error"
        }
        if (root.isSuccess())
            return "Resultado: " + root.countIngresados() + " ingresado(s), "
                + root.countNoIngresados() + " no ingresado(s), "
                + root.countRevisar() + " para revisión manual"
        return "Procesando: " + root.countRegistered() + " de " + root.totalRows() + " fila(s) registradas"
    }

    function stateColor(value) {
        if (value === "Ingresado") return root.cSuccess
        if (value === "Revisar manualmente") return root.cReview
        return root.cWarn
    }
    function cellText(value) {
        return value === null || value === undefined || String(value).length === 0 ? "—" : String(value)
    }
    function columns() {
        return [
            { "key": "estado", "label": "ESTADO ESCRITO", "width": 155 },
            { "key": "excel_row", "label": "FILA EXCEL", "width": 90 },
            { "key": "tribunal", "label": "TRIBUNAL", "width": 220 },
            { "key": "rol", "label": "ROL", "width": 90 },
            { "key": "anio", "label": "AÑO", "width": 75 },
            { "key": "archivo", "label": "ARCHIVO", "width": 210 },
            { "key": "detalle", "label": "DETALLE", "width": 320 }
        ]
    }
    function tableWidth() {
        var cols = root.columns()
        var width = 0
        for (var i = 0; i < cols.length; i++) width += cols[i].width
        return width
    }
    function tableRows() {
        var cols = root.columns()
        var source = root.resultRows()
        var rows = []
        for (var r = 0; r < source.length; r++) {
            var cells = []
            for (var c = 0; c < cols.length; c++) {
                cells.push({
                    "key": cols[c].key,
                    "width": cols[c].width,
                    "value": source[r][cols[c].key]
                })
            }
            rows.push({ "rowIndex": r, "estado": source[r].estado, "cells": cells })
        }
        return rows
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 12

        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Label {
                    text: "Ingreso Escrito · Ampliación de Domicilios"
                    color: root.cText
                    font.pixelSize: Common.Theme.fontSize(18)
                    font.bold: true
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }
                Label {
                    text: (root.workbookName().length > 0 ? root.workbookName() : "Planilla sin identificar")
                        + (root.buildVersion().length > 0 ? " · " + root.buildVersion() : "")
                    color: root.cMuted
                    font.pixelSize: Common.Theme.fontSize(12)
                    Layout.fillWidth: true
                    elide: Text.ElideMiddle
                }
            }

            Rectangle {
                radius: 7
                implicitHeight: 24
                implicitWidth: statusLabel.implicitWidth + 22
                color: root.cPanel
                border.width: 1
                border.color: root.statusColor()
                Label {
                    id: statusLabel
                    anchors.centerIn: parent
                    text: root.statusWord()
                    color: root.statusColor()
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                }
            }
        }

        Label {
            text: root.headline()
            color: root.cText
            font.pixelSize: Common.Theme.fontSize(14)
            font.bold: true
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: [
                    { "label": "Ingresados", "value": root.countIngresados(), "color": root.cSuccess },
                    { "label": "No ingresados", "value": root.countNoIngresados(), "color": root.cWarn },
                    { "label": "Revisar", "value": root.countRevisar(), "color": root.cReview },
                    { "label": "Registrados", "value": root.countRegistered(), "color": root.cText },
                    { "label": "Total Excel", "value": root.totalRows(), "color": root.cMuted }
                ]
                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 46
                    radius: 10
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine
                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 0
                        Label {
                            text: String(modelData.value)
                            color: modelData.color
                            font.pixelSize: Common.Theme.fontSize(18)
                            font.bold: true
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Label {
                            text: modelData.label
                            color: root.cMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                }
            }
        }

        Common.InsetAlloyButton {
            id: outputButton
            visible: root.outputPath().length > 0
            Layout.fillWidth: true
            Layout.preferredHeight: 40
            alloyTone: "success"
            text: "Abrir planilla de resultado"
            onClicked: controller.openPathInExplorer(root.outputPath())
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine
            clip: true

            Flickable {
                anchors.fill: parent
                anchors.margins: 1
                contentWidth: Math.max(width, tableContent.implicitWidth)
                contentHeight: tableContent.implicitHeight
                boundsBehavior: Flickable.StopAtBounds
                clip: true
                ScrollBar.horizontal: Common.StyledScrollBar { policy: ScrollBar.AsNeeded }
                ScrollBar.vertical: Common.StyledScrollBar { policy: ScrollBar.AsNeeded }

                Column {
                    id: tableContent
                    Row {
                        Repeater {
                            model: root.columns()
                            delegate: Rectangle {
                                width: modelData.width
                                height: 34
                                color: Common.Theme.accentSoft
                                Label {
                                    anchors.fill: parent
                                    anchors.leftMargin: 9
                                    anchors.rightMargin: 6
                                    verticalAlignment: Text.AlignVCenter
                                    text: modelData.label
                                    color: root.cMuted
                                    font.pixelSize: Common.Theme.fontSize(12)
                                    font.bold: true
                                    elide: Text.ElideRight
                                }
                            }
                        }
                    }
                    Repeater {
                        model: root.tableRows()
                        delegate: Rectangle {
                            width: root.tableWidth()
                            height: 34
                            color: modelData.rowIndex % 2 === 0 ? "transparent" : "#10294780"
                            Row {
                                anchors.fill: parent
                                Repeater {
                                    model: modelData.cells
                                    delegate: Rectangle {
                                        width: modelData.width
                                        height: parent.height
                                        color: "transparent"
                                        Label {
                                            id: cellLabel
                                            anchors.fill: parent
                                            anchors.leftMargin: 9
                                            anchors.rightMargin: 6
                                            verticalAlignment: Text.AlignVCenter
                                            text: root.cellText(modelData.value)
                                            color: modelData.key === "estado"
                                                ? root.stateColor(String(modelData.value || ""))
                                                : root.cText
                                            font.bold: modelData.key === "estado"
                                            font.pixelSize: Common.Theme.fontSize(12)
                                            elide: Text.ElideRight
                                        }
                                        MouseArea {
                                            anchors.fill: parent
                                            hoverEnabled: cellLabel.truncated
                                            acceptedButtons: Qt.NoButton
                                            ToolTip.visible: containsMouse
                                            ToolTip.text: cellLabel.text
                                            ToolTip.delay: 300
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Label {
                anchors.centerIn: parent
                visible: root.countRegistered() === 0
                text: root.isCancelled()
                    ? "El run fue detenido antes de registrar una fila completa."
                    : "Todavía no hay filas terminadas para mostrar."
                color: root.cMuted
                font.pixelSize: Common.Theme.fontSize(13)
            }
        }
    }
}
