"""Loopback bridge for Clean08's attended Chrome extension."""
from __future__ import annotations

import json
import threading
import time
import unicodedata
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


EXTENSION_BUILD = "v0.17.4"
RECOVERY_ACTION = "recover_after_row_failure"
MAX_EMPTY_DROPDOWN_ROW_RETRIES = 1
ROW_STEPS: tuple[dict[str, Any], ...] = (
    {
        "action": "click_ingresar_escrito",
        "label": "Ingresar Escrito",
    },
    {
        "action": "select_competencia",
        "label": "Competencia = Civil",
        "value": "Civil",
        "match": "exact",
    },
    {
        "action": "select_tribunal",
        "label": "Tribunal de la fila actual",
        "value_key": "tribunal",
        "match": "exact",
    },
    {
        "action": "select_tipo",
        "label": "Tipo = C",
        "value": "C",
        "match": "exact",
    },
    {
        "action": "fill_rol",
        "label": "ROL de la fila actual",
        "value_key": "rol",
        "match": "exact",
    },
    {
        "action": "select_anio",
        "label": "Año de la fila actual",
        "value_key": "anio",
        "match": "exact",
    },
    {
        "action": "click_consulta_rol",
        "label": "Consulta Rol",
    },
    {
        "action": "select_cuaderno",
        "label": "Cuaderno = 1 Principal",
        "value": "1 Principal",
        "match": "exact",
    },
    {
        "action": "select_parte_presenta",
        "label": "Parte que Presenta = AB.DTE-JOAQUÍN MAURICIO CARRILLO MORENO",
        "value": "AB.DTE-JOAQUÍN MAURICIO CARRILLO MORENO",
        "match": "exact",
    },
    {
        "action": "select_grupo_escrito",
        "label": "Grupo Escrito = Escritos Generales",
        "value": "Escritos Generales",
        "match": "exact",
    },
    {
        "action": "select_tipo_escrito",
        "label": "Tipo Escrito = Señala domicilio",
        "value": "Señala domicilio",
        "match": "exact",
    },
    {
        "action": "click_grabar_escrito",
        "label": "Grabar Escrito",
        "point_of_no_return": True,
    },
    {
        "action": "upload_escrito_file",
        "label": "Adjuntar PDF indicado en Archivo",
        "point_of_no_return": True,
    },
    {
        "action": "await_escrito_uploaded",
        "label": "Confirmar PDF cargado en PJUD",
        "point_of_no_return": True,
    },
    {
        "action": "click_cerrar_continuar",
        "label": "Cerrar y Continuar",
        "point_of_no_return": True,
    },
)


class BridgeError(RuntimeError):
    """Raised when an attended bridge session cannot complete safely."""


@dataclass
class BridgeState:
    """Ordered, guarded per-row instructions shared with the extension."""

    summary_data: dict[str, Any]
    rows: tuple[dict[str, Any], ...]
    file_paths: dict[int, str]
    started_at: float = 0.0
    extension_seen_at: float = 0.0
    finished: bool = False
    cursor: int = 0
    step_index: int = 0
    total_steps_completed: int = 0
    step_in_flight: bool = False
    phase: str = "row"
    failed_step_number: int = 0
    failed_step_action: str = ""
    failed_step_label: str = ""
    failed_detail: str = ""
    error: str = ""
    completion_message: str = ""
    portal_url: str = ""
    portal_title: str = ""
    submitted_excel_rows: set[int] = field(default_factory=set)
    confirmed_upload_excel_rows: set[int] = field(default_factory=set)
    closed_modal_excel_rows: set[int] = field(default_factory=set)
    row_results: dict[int, dict[str, Any]] = field(default_factory=dict)
    row_step_checks: dict[int, list[dict[str, Any]]] = field(default_factory=dict)
    row_retry_counts: dict[int, int] = field(default_factory=dict)
    retry_same_row_after_recovery: bool = False
    logs: list[str] = field(default_factory=list)
    lock: threading.Lock = field(default_factory=threading.Lock)
    done_event: threading.Event = field(default_factory=threading.Event)

    def touch(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def resolve_file(self) -> Path | None:
        """Return the prevalidated PDF for the current Excel row."""
        with self.lock:
            row = self._current_row_unlocked()
            if row is None:
                return None
            raw_path = self.file_paths.get(int(row["excel_row"]), "")
            if not raw_path:
                return None
            path = Path(raw_path)
            return path if path.is_file() else None

    def _current_row_unlocked(self) -> dict[str, Any] | None:
        if 0 <= self.cursor < len(self.rows):
            return self.rows[self.cursor]
        return None

    def _print_row_result_unlocked(self, excel_row: int) -> None:
        """Emit one machine-readable row snapshot for the QML run detail."""
        row = next(
            (
                candidate
                for candidate in self.rows
                if int(candidate["excel_row"]) == int(excel_row)
            ),
            {},
        )
        result = self.row_results.get(int(excel_row), {})
        upload_confirmed = bool(result.get("upload_confirmed"))
        submission_started = bool(result.get("submission_started"))
        if upload_confirmed:
            estado = "Ingresado"
        elif submission_started:
            estado = "Revisar manualmente"
        else:
            estado = "No ingresado"

        detail = str(result.get("detail") or "").strip()
        if " [página:" in detail:
            detail = detail.split(" [página:", 1)[0].strip()
        failed_label = str(result.get("failed_step_label") or "").strip()
        if failed_label and detail:
            detail = f"{failed_label}: {detail}"
        elif failed_label:
            detail = failed_label
        elif not detail and upload_confirmed:
            detail = "PJUD confirmó el PDF como Documento Principal."

        payload = {
            "excel_row": int(excel_row),
            "estado": estado,
            "tribunal": str(row.get("tribunal") or ""),
            "rol": str(row.get("rol") or ""),
            "anio": str(row.get("anio") or ""),
            "archivo": str(row.get("archivo") or ""),
            "detalle": detail,
            "recovery_ok": result.get("recovery_ok"),
        }
        print(
            "[CLEAN08][FILA_RESULTADO] "
            + json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            flush=True,
        )

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        row = self._current_row_unlocked()
        current_excel_row = int(row["excel_row"]) if row is not None else 0
        if row is not None:
            current_row_number = self.cursor + 1
        elif self.rows:
            current_row_number = len(self.rows)
        else:
            current_row_number = 0
        result_rows: list[dict[str, Any]] = []
        for position, source_row in enumerate(self.rows, start=1):
            excel_row = int(source_row["excel_row"])
            stored = self.row_results.get(excel_row, {})
            result_rows.append(
                {
                    "row_number": position,
                    "excel_row": excel_row,
                    "tribunal": str(source_row.get("tribunal") or ""),
                    "rol": str(source_row.get("rol") or ""),
                    "anio": str(source_row.get("anio") or ""),
                    "archivo": str(source_row.get("archivo") or ""),
                    "status": stored.get("status", "pending"),
                    "completed_steps": int(stored.get("completed_steps", 0)),
                    "failed_step_number": int(stored.get("failed_step_number", 0)),
                    "failed_step_action": str(stored.get("failed_step_action", "")),
                    "failed_step_label": str(stored.get("failed_step_label", "")),
                    "detail": str(stored.get("detail", "")),
                    "submission_started": bool(stored.get("submission_started", False)),
                    "upload_confirmed": bool(stored.get("upload_confirmed", False)),
                    "attachment_modal_closed": bool(
                        stored.get("attachment_modal_closed", False)
                    ),
                    "step_checks": list(self.row_step_checks.get(excel_row, [])),
                    "recovery_ok": stored.get("recovery_ok"),
                    "recovery_detail": str(stored.get("recovery_detail", "")),
                    "retry_count": int(self.row_retry_counts.get(excel_row, 0)),
                }
            )
        completed_rows = sum(
            1 for result in result_rows if result["status"] == "completed"
        )
        failed_rows = sum(
            1 for result in result_rows if result["status"] == "failed"
        )
        all_rows_ok = (
            self.finished
            and completed_rows == len(self.rows)
            and failed_rows == 0
            and not self.error
        )
        return {
            **self.summary_data,
            "started": bool(self.started_at),
            "finished": self.finished,
            "row_total": len(self.rows),
            "rows_completed": self.cursor,
            "rows_ok": completed_rows,
            "rows_failed": failed_rows,
            "current_row_number": current_row_number,
            "current_excel_row": current_excel_row,
            "steps_completed": len(ROW_STEPS) if all_rows_ok else self.step_index,
            "step_total": len(ROW_STEPS),
            "step_completed": all_rows_ok,
            "total_steps_completed": self.total_steps_completed,
            "total_step_count": len(self.rows) * len(ROW_STEPS),
            "submission_started": bool(self.submitted_excel_rows),
            "upload_confirmed": bool(self.confirmed_upload_excel_rows),
            "attachment_modal_closed": bool(self.closed_modal_excel_rows),
            "submitted_rows": len(self.submitted_excel_rows),
            "confirmed_upload_rows": len(self.confirmed_upload_excel_rows),
            "closed_modal_rows": len(self.closed_modal_excel_rows),
            "current_row_submission_started": (
                current_excel_row in self.submitted_excel_rows
            ),
            "current_row_upload_confirmed": (
                current_excel_row in self.confirmed_upload_excel_rows
            ),
            "phase": self.phase,
            "result_rows": result_rows,
            "error": self.error,
            "message": self.completion_message,
        }

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.extension_seen_at = time.time()
            build = str(payload.get("build") or "").strip()
            if build != EXTENSION_BUILD:
                self.error = (
                    f"La extension Clean08 cargada ({build or 'sin version'}) no "
                    f"coincide con el bot ({EXTENSION_BUILD}). Recargala en "
                    "chrome://extensions y vuelve a cargar la pagina del portal."
                )
                self.completion_message = "Clean08 se detuvo antes de tocar el portal."
                self.finished = True
                self.done_event.set()
                return {
                    "ok": False,
                    "done": True,
                    "error": self.error,
                    "message": self.completion_message,
                    "summary": self._summary_unlocked(),
                }

            if not self.started_at:
                self.started_at = time.time()
                self.portal_url = str(payload.get("url") or "")
                self.portal_title = str(payload.get("title") or "")
                self.logs.append(f"Start recibido desde {self.portal_url or '(sin URL)'}")
            return {
                "ok": True,
                "done": False,
                "message": (
                    f"Conexion confirmada. Fila 1/{len(self.rows)} · "
                    f"Step 1/{len(ROW_STEPS)}..."
                ),
                "summary": self._summary_unlocked(),
            }

    def next_action(self) -> dict[str, Any]:
        with self.lock:
            self.extension_seen_at = time.time()
            if self.finished:
                return {
                    "action": "done",
                    "error": self.error,
                    "message": self.completion_message,
                }
            if not self.started_at:
                return {"action": "wait", "message": "Esperando Start."}
            if self.step_in_flight:
                # The extension has the instruction and has not reported it yet.
                # Never issue the same portal action twice while its result is
                # unknown; a repeated click/select can corrupt the form.
                return {
                    "action": "wait",
                    "message": (
                        f"Esperando resultado de fila {self.cursor + 1}/{len(self.rows)}, "
                        f"Step {self.step_index + 1}."
                    ),
                }

            row = self._current_row_unlocked()
            if row is None:
                self.finished = True
                self.completion_message = (
                    f"{len(self.rows)} fila(s) procesada(s) correctamente."
                )
                self.done_event.set()
                return {"action": "done", "message": self.completion_message}

            if self.phase == "recover":
                self.step_in_flight = True
                return {
                    "action": RECOVERY_ACTION,
                    "label": "Preparar portal para la siguiente fila",
                    "recovery": True,
                    "row_number": self.cursor + 1,
                    "row_total": len(self.rows),
                    "excel_row": int(row["excel_row"]),
                    "failed_step_number": self.failed_step_number,
                    "failed_step_action": self.failed_step_action,
                    "failed_step_label": self.failed_step_label,
                    "failed_detail": self.failed_detail,
                    "retry_same_row": self.retry_same_row_after_recovery,
                    "step_number": self.failed_step_number,
                    "step_total": len(ROW_STEPS),
                }

            step = dict(ROW_STEPS[self.step_index])
            value_key = str(step.pop("value_key", "") or "")
            if value_key:
                value = row.get(value_key)
                if value is None or not str(value).strip():
                    self.error = f'Falta el valor requerido para el paso "{value_key}".'
                    self.completion_message = (
                        f"Clean08 se detuvo en fila {self.cursor + 1}/{len(self.rows)}, "
                        f"Step {self.step_index + 1}."
                    )
                    self.finished = True
                    self.done_event.set()
                    return {
                        "action": "done",
                        "error": self.error,
                        "message": self.completion_message,
                    }
                step["value"] = value
                if step["action"] == "select_tribunal":
                    step["label"] = f"Tribunal = {value}"
                elif step["action"] == "fill_rol":
                    step["label"] = f"ROL = {value}"
                elif step["action"] == "select_anio":
                    step["label"] = f"Año = {value}"

            self.step_in_flight = True
            return {
                **step,
                "row_number": self.cursor + 1,
                "row_total": len(self.rows),
                "excel_row": int(row["excel_row"]),
                "step_number": self.step_index + 1,
                "step_total": len(ROW_STEPS),
            }

    def report(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.extension_seen_at = time.time()
            if self.finished:
                return {
                    "ok": True,
                    "done": True,
                    "error": self.error,
                    "message": self.completion_message,
                }
            if not self.step_in_flight:
                return {
                    "ok": False,
                    "done": False,
                    "error": "La extension informo un resultado sin un paso activo.",
                }

            if self.phase == "recover":
                return self._report_recovery_unlocked(payload)
            if self.step_index >= len(ROW_STEPS):
                return {
                    "ok": False,
                    "done": False,
                    "error": "La extension informo un paso fuera del recorrido de la fila.",
                }

            current_step_number = self.step_index + 1
            row_number = self.cursor + 1
            row = self._current_row_unlocked()
            if row is None:
                return {
                    "ok": False,
                    "done": False,
                    "error": "No hay una fila activa para registrar el resultado.",
                }
            excel_row = int(row["excel_row"])
            detail = str(payload.get("detail") or "").strip()
            step_definition = ROW_STEPS[self.step_index]
            step_action = str(step_definition["action"])
            step_label = str(step_definition.get("label") or step_action)
            value_key = str(step_definition.get("value_key") or "")
            if value_key:
                value = row.get(value_key)
                if step_action == "select_tribunal":
                    step_label = f"Tribunal = {value}"
                elif step_action == "fill_rol":
                    step_label = f"ROL = {value}"
                elif step_action == "select_anio":
                    step_label = f"Año = {value}"
            response_message = ""
            self.row_step_checks.setdefault(excel_row, []).append(
                {
                    "step_number": current_step_number,
                    "action": step_action,
                    "label": step_label,
                    "ok": bool(payload.get("ok")),
                    "detail": detail,
                }
            )
            if bool(payload.get("ok")):
                if bool(payload.get("filed")):
                    self.submitted_excel_rows.add(excel_row)
                if bool(payload.get("confirmed")):
                    self.confirmed_upload_excel_rows.add(excel_row)
                if bool(payload.get("modal_closed")):
                    self.closed_modal_excel_rows.add(excel_row)
                step_message = detail or f"Step {current_step_number} completado."
                self.logs.append(
                    f"Fila {row_number}/{len(self.rows)} (Excel {excel_row}): {step_message}"
                )
                self.step_index += 1
                self.total_steps_completed += 1
                self.step_in_flight = False
                if self.step_index >= len(ROW_STEPS):
                    self.row_results[excel_row] = {
                        "status": "completed",
                        "completed_steps": len(ROW_STEPS),
                        "failed_step_number": 0,
                        "failed_step_action": "",
                        "failed_step_label": "",
                        "detail": "",
                        "submission_started": excel_row in self.submitted_excel_rows,
                        "upload_confirmed": (
                            excel_row in self.confirmed_upload_excel_rows
                        ),
                        "attachment_modal_closed": (
                            excel_row in self.closed_modal_excel_rows
                        ),
                        "recovery_ok": None,
                        "recovery_detail": "",
                    }
                    self._print_row_result_unlocked(excel_row)
                    self.cursor += 1
                    self.step_index = 0
                    if self.cursor >= len(self.rows):
                        self.completion_message = self._completion_message_unlocked()
                        self.finished = True
                        self.done_event.set()
                    else:
                        response_message = (
                            f"Fila {row_number}/{len(self.rows)} completada. "
                            f"Continuando con fila {self.cursor + 1}/{len(self.rows)}..."
                        )
                else:
                    response_message = (
                        f"Fila {row_number}/{len(self.rows)} · "
                        f"Step {current_step_number} completado. Continuando..."
                    )
            else:
                if bool(payload.get("filed")):
                    self.submitted_excel_rows.add(excel_row)
                if bool(payload.get("confirmed")):
                    self.confirmed_upload_excel_rows.add(excel_row)
                if bool(payload.get("modal_closed")):
                    self.closed_modal_excel_rows.add(excel_row)
                row_error = detail or (
                    f"La extension no pudo completar Step {current_step_number} "
                    f"de la fila {row_number}."
                )
                self.logs.append(
                    f"Fila {row_number}/{len(self.rows)} (Excel {excel_row}): {row_error}"
                )
                retry_count = int(self.row_retry_counts.get(excel_row, 0))
                folded_error = "".join(
                    character
                    for character in unicodedata.normalize("NFD", row_error.casefold())
                    if unicodedata.category(character) != "Mn"
                )
                retryable_empty_dropdown = (
                    step_action.startswith("select_")
                    and "desplegable" in folded_error
                    and "no cargo opciones" in folded_error
                    and excel_row not in self.submitted_excel_rows
                )
                if (
                    retryable_empty_dropdown
                    and retry_count < MAX_EMPTY_DROPDOWN_ROW_RETRIES
                ):
                    retry_number = retry_count + 1
                    self.row_retry_counts[excel_row] = retry_number
                    self.retry_same_row_after_recovery = True
                    self.total_steps_completed = max(
                        0,
                        self.total_steps_completed - self.step_index,
                    )
                    self.phase = "recover"
                    self.failed_step_number = current_step_number
                    self.failed_step_action = step_action
                    self.failed_step_label = step_label
                    self.failed_detail = row_error
                    self.step_in_flight = False
                    print(
                        "[CLEAN08][FILA_REINTENTO] "
                        + json.dumps(
                            {
                                "excel_row": excel_row,
                                "reintento": retry_number,
                                "max_reintentos": MAX_EMPTY_DROPDOWN_ROW_RETRIES,
                                "failed_step_number": current_step_number,
                                "failed_step_action": step_action,
                                "detail": row_error,
                            },
                            ensure_ascii=False,
                            separators=(",", ":"),
                        ),
                        flush=True,
                    )
                    response_message = (
                        f"El menú no cargó opciones en la fila {row_number}. "
                        f"Reiniciando la misma fila (reintento {retry_number}/"
                        f"{MAX_EMPTY_DROPDOWN_ROW_RETRIES})..."
                    )
                    return {
                        "ok": True,
                        "done": False,
                        "error": "",
                        "message": response_message,
                        "summary": self._summary_unlocked(),
                    }

                if retryable_empty_dropdown and retry_count:
                    retry_exhausted = (
                        "El desplegable volvió a no cargar opciones después del "
                        "único reintento automático permitido."
                    )
                    page_marker = " [página:"
                    if page_marker in row_error:
                        clean_error, page_suffix = row_error.split(page_marker, 1)
                        row_error = (
                            f"{clean_error} {retry_exhausted}"
                            f"{page_marker}{page_suffix}"
                        )
                    else:
                        row_error = f"{row_error} {retry_exhausted}"
                self.row_results[excel_row] = {
                    "status": "failed",
                    "completed_steps": self.step_index,
                    "failed_step_number": current_step_number,
                    "failed_step_action": step_action,
                    "failed_step_label": step_label,
                    "detail": row_error,
                    "submission_started": excel_row in self.submitted_excel_rows,
                    "upload_confirmed": excel_row in self.confirmed_upload_excel_rows,
                    "attachment_modal_closed": excel_row in self.closed_modal_excel_rows,
                    "recovery_ok": None,
                    "recovery_detail": "",
                }
                self._print_row_result_unlocked(excel_row)
                self.retry_same_row_after_recovery = False
                self.phase = "recover"
                self.failed_step_number = current_step_number
                self.failed_step_action = step_action
                self.failed_step_label = step_label
                self.failed_detail = row_error
                self.step_in_flight = False
                response_message = (
                    f"Fila {row_number}/{len(self.rows)} con falla en Step "
                    f"{current_step_number}. Preparando la siguiente fila..."
                )
            return {
                # The HTTP exchange succeeded even when the portal action did
                # not. Keep transport success separate from action failure so
                # the panel can render the desktop's final error cleanly.
                "ok": True,
                "done": self.finished,
                "error": self.error,
                "message": self.completion_message or response_message,
                "summary": self._summary_unlocked(),
            }

    def _report_recovery_unlocked(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Finish recovery, then retry this row once or advance to the next."""
        row = self._current_row_unlocked()
        if row is None:
            return {
                "ok": False,
                "done": False,
                "error": "No hay una fila activa para cerrar la recuperación.",
            }
        row_number = self.cursor + 1
        excel_row = int(row["excel_row"])
        recovery_ok = bool(payload.get("ok"))
        detail = str(payload.get("detail") or "").strip()
        if bool(payload.get("modal_closed")):
            self.closed_modal_excel_rows.add(excel_row)
        if self.retry_same_row_after_recovery:
            retry_number = int(self.row_retry_counts.get(excel_row, 0))
            self.logs.append(
                f"Fila {row_number}/{len(self.rows)} (Excel {excel_row}) "
                f"preparada para reintento {retry_number}/"
                f"{MAX_EMPTY_DROPDOWN_ROW_RETRIES}: "
                f"{detail or '(sin detalle)'}"
            )
            self.step_index = 0
            self.step_in_flight = False
            self.phase = "row"
            self.failed_step_number = 0
            self.failed_step_action = ""
            self.failed_step_label = ""
            self.failed_detail = ""
            self.retry_same_row_after_recovery = False
            self.row_step_checks[excel_row] = []
            return {
                "ok": True,
                "done": False,
                "error": "",
                "message": (
                    f"Fila {row_number}/{len(self.rows)} preparada. "
                    f"Reiniciando la misma fila desde Ingresar Escrito "
                    f"(reintento {retry_number}/{MAX_EMPTY_DROPDOWN_ROW_RETRIES})..."
                ),
                "summary": self._summary_unlocked(),
            }

        result = self.row_results.setdefault(excel_row, {"status": "failed"})
        result["recovery_ok"] = recovery_ok
        result["recovery_detail"] = detail
        result["submission_started"] = excel_row in self.submitted_excel_rows
        result["upload_confirmed"] = excel_row in self.confirmed_upload_excel_rows
        result["attachment_modal_closed"] = excel_row in self.closed_modal_excel_rows
        self._print_row_result_unlocked(excel_row)
        self.logs.append(
            f"Fila {row_number}/{len(self.rows)} (Excel {excel_row}) recuperación "
            f"{'OK' if recovery_ok else 'FALLÓ'}: {detail or '(sin detalle)'}"
        )

        self.cursor += 1
        self.step_index = 0
        self.step_in_flight = False
        self.phase = "row"
        self.failed_step_number = 0
        self.failed_step_action = ""
        self.failed_step_label = ""
        self.failed_detail = ""
        self.retry_same_row_after_recovery = False

        if self.cursor >= len(self.rows):
            self.completion_message = self._completion_message_unlocked()
            self.finished = True
            self.done_event.set()
            response_message = self.completion_message
        else:
            response_message = (
                f"Fila {row_number}/{len(self.rows)} registrada con falla. "
                f"Continuando con fila {self.cursor + 1}/{len(self.rows)}..."
            )
        return {
            "ok": True,
            "done": self.finished,
            "error": "",
            "message": response_message,
            "summary": self._summary_unlocked(),
        }

    def _completion_message_unlocked(self) -> str:
        completed = sum(
            1 for result in self.row_results.values()
            if result.get("status") == "completed"
        )
        failed = sum(
            1 for result in self.row_results.values()
            if result.get("status") == "failed"
        )
        return (
            f"{len(self.rows)} fila(s) procesada(s): "
            f"{completed} completa(s), {failed} con falla."
        )

    def add_log(self, message: str) -> None:
        clean = str(message or "").strip()
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean)


class Clean08BridgeServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], state: BridgeState):
        super().__init__(address, Clean08BridgeHandler)
        self.state = state


class Clean08BridgeHandler(BaseHTTPRequestHandler):
    server: Clean08BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self) -> None:
        if self.path == "/health":
            self.server.state.touch()
            self._json({
                "ok": True,
                "name": "Clean08 PJUD bridge",
                "build": EXTENSION_BUILD,
                "summary": self.server.state.summary(),
            })
            return
        if self.path == "/file":
            self._serve_file()
            return
        self._json({"ok": False, "error": "Ruta no encontrada."}, 404)

    def _serve_file(self) -> None:
        """Stream the current row's PDF for the extension background worker."""
        path = self.server.state.resolve_file()
        if path is None:
            self._json(
                {"ok": False, "error": "No hay un PDF disponible para la fila actual."},
                404,
            )
            return
        try:
            data = path.read_bytes()
        except OSError as exc:
            self._json({"ok": False, "error": str(exc)}, 500)
            return

        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.send_header("X-Filename", path.name)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self) -> None:
        if self.path == "/start":
            self._json(self.server.state.register_start(self._read_json()))
            return
        if self.path == "/next":
            self._json({"ok": True, "step": self.server.state.next_action()})
            return
        if self.path == "/report":
            self._json(self.server.state.report(self._read_json()))
            return
        if self.path == "/log":
            message = str(self._read_json().get("message") or "")
            self.server.state.add_log(message)
            print(f"[CLEAN08][EXT] {message}")
            self._json({"ok": True})
            return
        self._json({"ok": False, "error": "Ruta no encontrada."}, 404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return value if isinstance(value, dict) else {}

    def _json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Expose-Headers", "X-Filename")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


def run_bridge_session(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
) -> dict[str, Any]:
    """Run the bridge until all currently defined steps finish or fail."""
    try:
        server = Clean08BridgeServer((host, port), state)
    except OSError as exc:
        raise BridgeError(
            f"No se pudo abrir el bridge local en {host}:{port}. "
            "Puede que otra ejecucion de Clean08 siga abierta."
        ) from exc

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"[CLEAN08][BRIDGE_LISTO] http://{host}:{port}")
    print("[CLEAN08][ESPERANDO_START] Abre indexN.php y presiona Start en la extension.")
    try:
        if not state.done_event.wait(timeout_seconds):
            raise BridgeError(
                "Tiempo de espera agotado: no se completaron los pasos "
                "desde la extension Clean08."
            )
        result = state.summary()
        if result["error"]:
            raise BridgeError(result["error"])
        return result
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
