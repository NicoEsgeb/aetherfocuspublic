import QtQuick
import QtQuick.Controls

// Primary action button on the shared inset-alloy surface. Busy state adds three
// pulsing dots in a FIXED-width slot (no width jitter). Disabled: 40% opacity.
InsetAlloyButton {
    id: control

    property bool running: false
    property string idleText: "Iniciar bot"
    property string busyText: "Ejecutando"

    text: running ? busyText : idleText
    hoverEnabled: true
    opacity: enabled ? 1.0 : 0.40
    implicitHeight: 40

    property real pulse: 0
    NumberAnimation on pulse {
        running: control.running && control.visible
        from: 0; to: 1; duration: 1200
        loops: Animation.Infinite
    }

    contentItem: Row {
        spacing: 9
        leftPadding: 26
        rightPadding: 26
        topPadding: 11
        bottomPadding: 11

        Label {
            text: control.text
            color: Theme.text
            font.pixelSize: Theme.fontSize(15)
            font.weight: Font.Bold
            font.letterSpacing: 0.2
            anchors.verticalCenter: parent.verticalCenter
        }

        // Fixed-width dots slot: reserved even when idle so text never shifts.
        Row {
            width: 26
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            opacity: control.running ? 1 : 0

            Repeater {
                model: 3
                Rectangle {
                    width: 5
                    height: 5
                    radius: 2.5
                    anchors.verticalCenter: parent.verticalCenter
                    color: Theme.text
                    property real phase: Math.max(0, Math.sin((control.pulse + index * 0.2) * 2 * Math.PI))
                    opacity: 0.25 + 0.75 * phase
                    scale: 0.8 + 0.2 * phase
                }
            }
        }
    }
}
