import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var dependencies: []
    property bool expanded: false

    visible: Array.isArray(dependencies) && dependencies.length > 0
    width: parent ? parent.width : implicitWidth
    implicitHeight: visible ? warningColumn.implicitHeight + 22 : 0
    radius: Theme.radiusInner
    color: Qt.alpha(Theme.warning, pulse.running ? 0.18 + pulseLevel * 0.10 : 0.18)
    border.width: 1
    border.color: Qt.alpha(Theme.warning, 0.65 + pulseLevel * 0.30)
    clip: true

    property real pulseLevel: 0.0

    SequentialAnimation on pulseLevel {
        id: pulse
        running: root.visible
        loops: Animation.Infinite
        NumberAnimation { to: 1.0; duration: 850; easing.type: Easing.InOutQuad }
        NumberAnimation { to: 0.0; duration: 850; easing.type: Easing.InOutQuad }
    }

    ColumnLayout {
        id: warningColumn
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 11
        spacing: root.expanded ? 12 : 0

        InsetAlloyButton {
            id: headerButton
            Layout.fillWidth: true
            implicitHeight: 32
            text: "Dependencias externas que necesitan instalarse"
            hoverEnabled: true
            onClicked: root.expanded = !root.expanded

            background: Rectangle {
                radius: Theme.radiusInner
                color: headerButton.hovered ? Qt.alpha(Theme.warning, 0.18) : "transparent"
            }

            contentItem: RowLayout {
                spacing: 9

                Label {
                    text: "!"
                    color: Theme.warning
                    font.pixelSize: Theme.fontSize(16)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    Layout.preferredWidth: 18
                }

                Label {
                    text: headerButton.text
                    color: Theme.warning
                    font.pixelSize: Theme.fontSize(13)
                    font.weight: Font.DemiBold
                    elide: Text.ElideRight
                    Layout.fillWidth: true
                }

                Label {
                    text: root.expanded ? "^" : "v"
                    color: Theme.warning
                    font.pixelSize: Theme.fontSize(15)
                }
            }
        }

        ColumnLayout {
            visible: root.expanded
            Layout.fillWidth: true
            spacing: 12

            Repeater {
                model: root.dependencies

                delegate: ColumnLayout {
                    id: dependencyBlock

                    required property var modelData
                    Layout.fillWidth: true
                    spacing: 7

                    Label {
                        text: String(dependencyBlock.modelData.name || "")
                        color: Theme.text
                        font.pixelSize: Theme.fontSize(13)
                        font.weight: Font.DemiBold
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                    }

                    Label {
                        text: String(dependencyBlock.modelData.why || "")
                        color: Theme.text2
                        font.pixelSize: Theme.fontSize(12)
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                    }

                    Repeater {
                        model: Array.isArray(dependencyBlock.modelData.installSteps)
                            ? dependencyBlock.modelData.installSteps : []

                        delegate: RowLayout {
                            id: stepRow

                            required property int index
                            required property string modelData
                            Layout.fillWidth: true
                            spacing: 8

                            Label {
                                text: String(stepRow.index + 1) + "."
                                color: Theme.warning
                                font.pixelSize: Theme.fontSize(12)
                                font.weight: Font.DemiBold
                                Layout.preferredWidth: 18
                                horizontalAlignment: Text.AlignRight
                                verticalAlignment: Text.AlignTop
                            }

                            Label {
                                text: stepRow.modelData
                                color: Theme.text2
                                font.pixelSize: Theme.fontSize(12)
                                Layout.fillWidth: true
                                wrapMode: Text.WordWrap
                            }
                        }
                    }

                    InsetAlloyButton {
                        id: downloadButton

                        text: "Abrir descarga oficial"
                        visible: String(dependencyBlock.modelData.downloadUrl || "").length > 0
                        implicitHeight: 30
                        onClicked: Qt.openUrlExternally(String(dependencyBlock.modelData.downloadUrl))

                        background: Rectangle {
                            radius: Theme.radiusInner
                            color: downloadButton.hovered ? Qt.alpha(Theme.warning, 0.20) : "transparent"
                            border.width: 1
                            border.color: Theme.warning
                        }

                        contentItem: Label {
                            text: downloadButton.text
                            color: Theme.warning
                            font.pixelSize: Theme.fontSize(12)
                            font.weight: Font.DemiBold
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                            leftPadding: 12
                            rightPadding: 12
                        }
                    }
                }
            }
        }
    }
}
