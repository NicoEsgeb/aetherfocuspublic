import QtQuick
import QtQuick.Controls

// Dense, tactile button surface shared by every bot-workspace action.
// Hover lifts the control and sends a restrained highlight across the alloy;
// press compresses it into the inset shadow. Instances may keep a custom
// contentItem without losing the shared motion layer.
Button {
    id: control

    property color alloyAccent: Theme.accent

    hoverEnabled: true
    opacity: enabled ? 1.0 : 0.42
    implicitHeight: 40
    leftPadding: 18
    rightPadding: 18

    scale: !enabled ? 1.0 : (down ? 0.98 : (hovered ? 1.01 : 1.0))
    Behavior on scale {
        NumberAnimation {
            duration: control.down ? 65 : 150
            easing.type: control.down ? Easing.OutCubic : Easing.OutBack
            easing.overshoot: 0.35
        }
    }

    transform: Translate {
        y: !control.enabled ? 0 : (control.down ? 1 : (control.hovered ? -1 : 0))
        Behavior on y {
            NumberAnimation {
                duration: control.down ? 65 : 150
                easing.type: Easing.OutCubic
            }
        }
    }

    background: Item { }

    contentItem: Label {
        text: control.text
        color: control.enabled ? Theme.text : Theme.text3
        font.family: control.font.family
        font.pixelSize: Theme.fontSize(13)
        font.weight: Font.DemiBold
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }

    // The layer sits above any legacy background supplied by an instance and
    // below its contentItem, which lets existing bot buttons migrate safely.
    Item {
        id: alloyLayer
        anchors.fill: parent
        z: -0.5

        Rectangle {
            anchors.fill: parent
            anchors.topMargin: control.down ? 2 : 4
            radius: Theme.radiusInner + 1
            color: Theme.isDark ? "#10151b" : "#b8c1cd"
            opacity: control.enabled ? (control.down ? 0.34 : 0.58) : 0.20

            Behavior on anchors.topMargin { NumberAnimation { duration: 80 } }
            Behavior on opacity { NumberAnimation { duration: 120 } }
        }

        Rectangle {
            id: alloyFace
            anchors.fill: parent
            anchors.bottomMargin: control.down ? 0 : 2
            radius: Theme.radiusInner
            clip: true
            border.width: 1
            border.color: control.down
                          ? Qt.alpha(control.alloyAccent, 0.42)
                          : (control.hovered
                             ? Qt.alpha(control.alloyAccent, 0.58)
                             : (Theme.isDark ? "#3a4a5b" : "#c6ced8"))
            gradient: Gradient {
                GradientStop {
                    position: 0.0
                    color: Theme.isDark
                           ? (control.hovered ? "#2b3948" : "#263342")
                           : (control.hovered ? "#ffffff" : "#f9fafb")
                }
                GradientStop {
                    position: 1.0
                    color: Theme.isDark
                           ? (control.down ? "#18212a" : "#1d2732")
                           : (control.down ? "#dfe4ea" : "#edf0f4")
                }
            }

            Behavior on anchors.bottomMargin { NumberAnimation { duration: 80 } }
            Behavior on border.color { ColorAnimation { duration: 140 } }

            Rectangle {
                x: control.hovered ? alloyFace.width * 1.25 : -width * 1.4
                y: -alloyFace.height * 0.65
                width: Math.max(44, alloyFace.width * 0.42)
                height: alloyFace.height * 2.3
                rotation: 18
                opacity: control.hovered && control.enabled && !control.down ? 0.52 : 0
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0.0; color: "transparent" }
                    GradientStop { position: 0.5; color: Qt.alpha(control.alloyAccent, Theme.isDark ? 0.22 : 0.14) }
                    GradientStop { position: 1.0; color: "transparent" }
                }

                Behavior on x {
                    NumberAnimation { duration: 360; easing.type: Easing.OutCubic }
                }
                Behavior on opacity { NumberAnimation { duration: 110 } }
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.leftMargin: Theme.radiusInner
                anchors.rightMargin: Theme.radiusInner
                height: 1
                color: Theme.isDark ? "#ffffff" : "#ffffff"
                opacity: control.down ? 0.03 : (control.hovered ? 0.16 : 0.09)
                Behavior on opacity { NumberAnimation { duration: 120 } }
            }

            Rectangle {
                anchors.fill: parent
                radius: parent.radius
                color: Theme.isDark ? "#000000" : "#506070"
                opacity: control.down ? (Theme.isDark ? 0.20 : 0.10) : 0
                Behavior on opacity { NumberAnimation { duration: 65 } }
            }
        }
    }
}
