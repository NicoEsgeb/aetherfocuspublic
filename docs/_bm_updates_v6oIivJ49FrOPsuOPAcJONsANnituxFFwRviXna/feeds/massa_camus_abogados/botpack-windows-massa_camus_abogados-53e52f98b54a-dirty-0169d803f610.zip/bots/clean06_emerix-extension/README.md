# Clean06 - Emerix (Edge extension)

This provisional bot contains the attended-browser foundation for Clean06:

1. BotManager receives one `.xlsx` or `.xlsm` input.
2. The user opens normal Microsoft Edge and logs into Emerix manually.
3. BotManager starts a local bridge on `http://127.0.0.1:8767`.
4. On `https://itau.emerix.net/emerix.ui/app/dashboard`, the user presses
   **Start** in the Clean06 panel.
5. The task records a `bridge_connection.json` receipt under `output/`.

The future Emerix navigation and Excel row-processing logic intentionally is not
implemented yet. It will stay local to this bot once the client defines the
workflow.

## Load the extension in Edge

Open `edge://extensions`, enable **Developer mode**, choose **Load unpacked**,
and select:

```text
bots/clean06_emerix-extension/extension
```
