"""Business logic for the Clean06 Emerix Edge-extension bridge scaffold."""
from __future__ import annotations

from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import json
import threading
import time

ALLOWED_EXCEL_SUFFIXES = {".xlsx", ".xlsm"}
BOT_ID = "clean06_emerix_extension"
BOT_LABEL = "Clean06"


def inspect_excel(path: str) -> dict[str, Any]:
    """Validate a single Excel input and return non-sensitive workbook metadata."""
    import openpyxl

    target = Path(path).expanduser()
    if not target.exists() or not target.is_file():
        raise ValueError(f"El archivo Excel no existe: {target.name}")
    if target.suffix.lower() not in ALLOWED_EXCEL_SUFFIXES:
        raise ValueError("Selecciona un archivo Excel .xlsx o .xlsm.")

    try:
        workbook = openpyxl.load_workbook(str(target), read_only=True, data_only=True)
    except Exception as exc:
        raise ValueError(f"No se pudo abrir el archivo Excel: {exc}") from exc

    try:
        sheet_names = list(workbook.sheetnames)
        data_rows = sum(max(0, int(workbook[name].max_row or 0) - 1) for name in sheet_names)
    finally:
        workbook.close()

    if not sheet_names:
        raise ValueError("El archivo Excel no contiene hojas.")
    return {
        "filename": target.name,
        "sheet_names": sheet_names,
        "sheet_count": len(sheet_names),
        "data_rows": data_rows,
    }


@dataclass
class BridgeState:
    input_path: str
    workbook: dict[str, Any]
    extension_seen_at: float = 0.0
    started_at: float = 0.0
    dashboard_url: str = ""
    dashboard_title: str = ""
    logs: list[str] = field(default_factory=list)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def touch_extension(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            self.extension_seen_at = now
            self.started_at = now
            self.dashboard_url = str(payload.get("url") or "")[:1000]
            self.dashboard_title = str(payload.get("title") or "")[:300]
            self.logs.append("Start recibido desde el dashboard de Emerix.")
            return {
                "ok": True,
                "message": (
                    "Conexion confirmada. Clean06 quedo enlazado con BotManager; "
                    "el flujo operativo se configurara en la siguiente etapa."
                ),
                "summary": self._summary_unlocked(),
            }

    def add_log(self, message: str) -> None:
        clean = " ".join(str(message or "").split())
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean[:500])
            self.logs = self.logs[-100:]

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        return {
            "bot_id": BOT_ID,
            "bot_label": BOT_LABEL,
            "extension_seen": self.extension_seen_at > 0,
            "started": self.started_at > 0,
            "started_at": self.started_at,
            "dashboard_url": self.dashboard_url,
            "dashboard_title": self.dashboard_title,
            "input_path": self.input_path,
            "workbook": dict(self.workbook),
            "workflow_configured": False,
            "logs": list(self.logs),
        }


def build_bridge_state(planilla_path: str) -> BridgeState:
    """Validate the input and create the in-memory bridge session."""
    target = str(Path(planilla_path).expanduser().resolve())
    return BridgeState(input_path=target, workbook=inspect_excel(target))


class Clean06BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], state: BridgeState):
        super().__init__(server_address, Clean06BridgeHandler)
        self.state = state


class Clean06BridgeHandler(BaseHTTPRequestHandler):
    server: Clean06BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self._send_empty(204)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "name": "Clean06 Emerix bridge",
                "summary": self.server.state.summary(),
            })
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self) -> None:
        if self.path.startswith("/start"):
            self._send_json(self.server.state.register_start(self._read_json()))
            return
        if self.path.startswith("/log"):
            payload = self._read_json()
            message = str(payload.get("message") or "")
            self.server.state.add_log(message)
            print(f"CLEAN06[EXT]: {message}")
            self._send_json({"ok": True})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _send_empty(self, status: int) -> None:
        self.send_response(status)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


def run_bridge_until_started(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
    log_every_seconds: int = 15,
) -> dict[str, Any]:
    """Serve the loopback bridge until the extension sends Start."""
    server = Clean06BridgeServer((host, port), state)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"Clean06: bridge escuchando en http://{host}:{port}")

    deadline = time.time() + timeout_seconds
    last_log = 0.0
    try:
        while time.time() < deadline:
            summary = state.summary()
            now = time.time()
            if summary["started"]:
                return summary
            if now - last_log >= log_every_seconds:
                seen = "si" if summary["extension_seen"] else "no"
                print(f"Clean06: esperando Start | extension_conectada={seen}")
                last_log = now
            time.sleep(0.5)
        raise TimeoutError("Clean06: timeout esperando Start desde la extension de Edge.")
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3.0)


def write_bridge_receipt(summary: dict[str, Any], output_dir: str) -> str:
    """Persist a small receipt proving that the desktop/extension bridge worked."""
    target = Path(output_dir) / "bridge_connection.json"
    payload = dict(summary)
    payload["receipt_created_at"] = time.time()
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(target)
