"""
Clean06 - Emerix attended Edge extension bridge.

The human opens normal Edge and logs into Emerix. This task validates the
selected Excel and exposes a localhost bridge. The bot-specific browser route
will be added once the client defines the operational workflow.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from robocorp.tasks import task

from functions import build_bridge_state, run_bridge_until_started, write_bridge_receipt

PATH_BOT = str(Path(__file__).parent)
PLANILLA_PATH = os.getenv(
    "PLANILLA_PATH",
    str(Path(PATH_BOT) / "input" / "planilla.xlsx"),
)
CLEAN06_BRIDGE_HOST = os.getenv("CLEAN06_BRIDGE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    CLEAN06_BRIDGE_PORT = max(1, min(65535, int(os.getenv("CLEAN06_BRIDGE_PORT", "8767"))))
except ValueError:
    CLEAN06_BRIDGE_PORT = 8767
try:
    CLEAN06_TIMEOUT_MINUTES = max(5, int(os.getenv("CLEAN06_TIMEOUT_MINUTES", "120")))
except ValueError:
    CLEAN06_TIMEOUT_MINUTES = 120


def _new_run_dir() -> str:
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M")
    run_dir = output_root / f"Clean06_Emerix_{timestamp}"
    suffix = 2
    while run_dir.exists():
        run_dir = output_root / f"Clean06_Emerix_{timestamp}_{suffix}"
        suffix += 1
    run_dir.mkdir(parents=True, exist_ok=True)
    return str(run_dir)


@task
def CLEAN06_EMERIX_EXTENSION():
    """Validate the Excel and wait for Clean06 Start from the Emerix dashboard."""
    run_dir = _new_run_dir()
    state = build_bridge_state(PLANILLA_PATH)
    summary = state.summary()

    print("=" * 72)
    print("CLEAN06_EMERIX_EXTENSION")
    print(f"  Excel: {PLANILLA_PATH}")
    print(f"  Hojas: {summary['workbook']['sheet_count']}")
    print(f"  Filas de datos estimadas: {summary['workbook']['data_rows']}")
    print(f"  Extension Edge: {Path(PATH_BOT) / 'extension'}")
    print(f"  Bridge: http://{CLEAN06_BRIDGE_HOST}:{CLEAN06_BRIDGE_PORT}")
    print(f"  Evidencia: {run_dir}")
    print("")
    print("Pasos:")
    print("  1. Abre Edge normal e inicia sesion manualmente en Emerix.")
    print("  2. Llega al dashboard de Emerix.")
    print("  3. Presiona Start en el panel Clean06 de la pagina.")
    print("=" * 72)

    final_summary = run_bridge_until_started(
        state=state,
        host=CLEAN06_BRIDGE_HOST,
        port=CLEAN06_BRIDGE_PORT,
        timeout_seconds=CLEAN06_TIMEOUT_MINUTES * 60,
    )
    receipt_path = write_bridge_receipt(final_summary, run_dir)
    print("Clean06: extension enlazada correctamente con BotManager.")
    print("Clean06: el recorrido operativo queda pendiente de la definicion del cliente.")
    print(f"Clean06: evidencia={receipt_path}")
    print("Done")
