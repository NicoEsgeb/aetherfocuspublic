const statusEl = document.getElementById("status");

chrome.runtime.sendMessage({
  type: "CLEAN05_BRIDGE_REQUEST",
  path: "/health",
  options: {}
})
  .then((payload) => {
    if (!payload || payload.ok === false) {
      statusEl.textContent = "Bridge no conectado.";
      return;
    }
    const workbook = payload.summary && payload.summary.workbook ? payload.summary.workbook : {};
    statusEl.textContent = workbook.filename
      ? `Bridge conectado: ${workbook.filename}`
      : "Bridge conectado.";
  })
  .catch(() => {
    statusEl.textContent = "Bridge no conectado. Inicia Clean05 en BotManager.";
  });
