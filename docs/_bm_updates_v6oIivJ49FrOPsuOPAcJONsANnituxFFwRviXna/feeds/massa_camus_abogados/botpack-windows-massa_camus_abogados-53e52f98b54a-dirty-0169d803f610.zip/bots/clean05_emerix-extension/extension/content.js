(() => {
  const MESSAGE_TYPE = "CLEAN05_BRIDGE_REQUEST";
  const PANEL_ID = "clean05-emerix-panel";
  const DASHBOARD_PATH = "/emerix.ui/app/dashboard";

  let connected = false;
  let starting = false;
  let verified = false;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean05-title">Clean05 · Emerix</div>
      <div class="clean05-status" data-role="status">Esperando BotManager...</div>
      <div class="clean05-details" data-role="details">Excel sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    return panel;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean05-ok", tone === "ok");
    status.classList.toggle("clean05-error", tone === "error");
  }

  function renderWorkbook(summary) {
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const details = createPanel().querySelector('[data-role="details"]');
    details.textContent = workbook.filename
      ? `${workbook.filename} · ${workbook.sheet_count || 0} hoja(s) · ${workbook.data_rows || 0} fila(s)`
      : "Excel sin confirmar";
  }

  function isDashboard() {
    return window.location.pathname.toLowerCase().startsWith(DASHBOARD_PATH);
  }

  async function pollBridge() {
    if (verified || starting) {
      return;
    }
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderWorkbook(payload.summary);
      setStatus(
        isDashboard()
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Abre el dashboard de Emerix.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean05 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified) {
      return;
    }
    if (!isDashboard()) {
      setStatus("Abre el dashboard de Emerix antes de presionar Start.", "error");
      return;
    }

    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) {
        await bridgeRequest("/health");
      }
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title }
      });
      verified = true;
      renderWorkbook(payload.summary);
      setStatus(payload.message || "Conexion confirmada.", "ok");
      button.textContent = "Conectado";
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
