import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    property string planillaPath: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal planillaPathEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            workspaceTaskNameEdited("CLEAN06_EMERIX_EXTENSION")
        }
    }

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona el archivo Excel que utilizará Clean06."
        }
        var lower = path.toLowerCase()
        if (!lower.endsWith(".xlsx") && !lower.endsWith(".xlsm")) {
            return "El archivo debe estar en formato .xlsx o .xlsm."
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim()
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: mainLayout.implicitHeight + 20

        ColumnLayout {
            id: mainLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Label {
                text: "Excel de entrada"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    Layout.fillWidth: true
                    text: root.planillaPath
                    color: Common.Theme.text
                    placeholderText: "Selecciona un archivo .xlsx o .xlsm"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Common.InsetAlloyButton {
                    id: selectExcelButton
                    text: "Seleccionar Excel"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            excelFileDialog.currentFolder = root.toFileUrl(folder)
                        }
                        excelFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: Common.Theme.accent
                        color: selectExcelButton.down ? Common.Theme.accent : Common.Theme.accentSoft
                    }
                    contentItem: Text {
                        text: selectExcelButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }

            Label {
                text: "Ejecuta Clean06, inicia sesión manualmente en itau.emerix.net y, ya en el dashboard, presiona Start en el panel Clean06. La extensión usa el bridge local 127.0.0.1:8767."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Extensión Edge: bots/clean06_emerix-extension/extension"
                color: Common.Theme.accent
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.WrapAnywhere
            }
        }
    }

    FileDialog {
        id: excelFileDialog
        title: "Seleccionar Excel para Clean06"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: root.planillaPathEdited(root.toLocalPath(selectedFile))
    }
}
