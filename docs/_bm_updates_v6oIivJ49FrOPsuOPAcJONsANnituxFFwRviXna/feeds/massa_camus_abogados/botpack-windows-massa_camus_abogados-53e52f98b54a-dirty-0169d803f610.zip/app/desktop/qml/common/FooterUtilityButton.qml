import QtQuick
import QtQuick.Controls

// Footer utility control: a generous target at rest, then a concise label on
// hover or keyboard focus. It keeps the shared inset-alloy press feedback while
// making low-frequency system actions easier to identify and click.
InsetAlloyButton {
    id: control

    property string iconText: ""
    property string labelText: ""
    property string toolTipText: labelText
    property real hoverIconRotation: 0
    property int compactWidth: 42
    property int expandedWidth: 112
    readonly property bool labelRevealed: hovered || activeFocus

    implicitWidth: labelRevealed ? expandedWidth : compactWidth
    implicitHeight: 42
    leftPadding: 10
    rightPadding: 10

    ToolTip.visible: hovered && toolTipText.length > 0
    ToolTip.text: toolTipText
    ToolTip.delay: 650

    Behavior on implicitWidth {
        NumberAnimation {
            duration: 220
            easing.type: Easing.OutCubic
        }
    }

    contentItem: Item {
        Row {
            anchors.centerIn: parent
            spacing: control.labelRevealed ? 7 : 0

            Behavior on spacing {
                NumberAnimation { duration: 180; easing.type: Easing.OutCubic }
            }

            Label {
                width: 18
                height: 22
                text: control.iconText
                color: control.enabled
                       ? (control.hovered ? Theme.text : Theme.text2)
                       : Theme.text3
                font.pixelSize: Theme.fontSize(17)
                font.weight: Font.DemiBold
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                rotation: control.labelRevealed ? control.hoverIconRotation : 0

                Behavior on color { ColorAnimation { duration: 150 } }
                Behavior on rotation {
                    NumberAnimation { duration: 220; easing.type: Easing.OutCubic }
                }
            }

            Item {
                width: control.labelRevealed ? utilityLabel.implicitWidth : 0
                height: 22
                clip: true
                opacity: control.labelRevealed ? 1 : 0

                Behavior on width {
                    NumberAnimation { duration: 220; easing.type: Easing.OutCubic }
                }
                Behavior on opacity { NumberAnimation { duration: 140 } }

                Label {
                    id: utilityLabel
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: control.labelText
                    color: control.enabled ? Theme.text : Theme.text3
                    font.pixelSize: Theme.fontSize(12)
                    font.weight: Font.DemiBold
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }
}
