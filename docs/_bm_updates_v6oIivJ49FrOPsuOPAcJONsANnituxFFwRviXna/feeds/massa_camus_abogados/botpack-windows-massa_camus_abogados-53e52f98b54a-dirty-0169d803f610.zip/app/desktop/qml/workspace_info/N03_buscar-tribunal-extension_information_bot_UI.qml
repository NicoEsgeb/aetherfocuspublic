import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
            text: "N03 · Buscar Tribunal (Extension)"
            color: Common.Theme.text
            font.pixelSize: Common.Theme.fontSize(16)
            font.bold: true
            Layout.fillWidth: true
            wrapMode: Text.Wrap
        }

        Rectangle {
            radius: 6
            color: Common.Theme.successSoft
            border.width: 1
            border.color: Common.Theme.success
            implicitWidth: badge.implicitWidth + 16
            implicitHeight: badge.implicitHeight + 8
            Label {
                id: badge
                anchors.centerIn: parent
                text: "Edge real"
                color: Common.Theme.success
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Qué hace"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "Usa una extension de Edge dentro de tu sesion real de PJUD. Tu haces el login y cualquier CAPTCHA manualmente; la extension solo automatiza la busqueda repetitiva posterior y devuelve los resultados al bridge local de BotManager."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: stepsLayout.implicitHeight + 20

        ColumnLayout {
            id: stepsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Cómo usarlo"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "1. En Edge abre edge://extensions, activa Developer mode y carga la carpeta bots/N03_buscar-tribunal-extension/extension.\n" +
                      "2. Ejecuta la task N03 desde BotManager con tu planilla.\n" +
                      "3. Abre Edge normal, entra a oficinajudicialvirtual.pjud.cl e inicia sesion a mano.\n" +
                      "4. En la pagina PJUD, presiona Start en el panel 'N03 Buscar Tribunal'.\n\n" +
                      "El archivo de salida queda en bots/N03_buscar-tribunal-extension/output."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
