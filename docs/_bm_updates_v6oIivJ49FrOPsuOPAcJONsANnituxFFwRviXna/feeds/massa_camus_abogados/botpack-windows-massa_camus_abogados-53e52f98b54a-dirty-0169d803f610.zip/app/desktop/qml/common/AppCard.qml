import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Themed card container: panel bg, 1px lineSoft border, radius 10, padding ~20.
// Optional title/subtitle header. Injected children stack below the header.
// fillContent=true makes the content area stretch (lists/detail); false (default)
// makes the card hug its content height (config card in an auto grid row).
Rectangle {
    id: card

    property real pad: 20
    property string title: ""
    property string subtitle: ""
    property bool fillContent: false
    default property alias content: body.data

    color: Theme.panel
    radius: Theme.radiusCard
    border.width: 1
    border.color: Theme.lineSoft
    implicitHeight: body.implicitHeight + card.pad * 2
    clip: true

    ColumnLayout {
        id: body
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: card.fillContent ? parent.bottom : undefined
        anchors.margins: card.pad
        spacing: 14

        RowLayout {
            Layout.fillWidth: true
            visible: card.title.length > 0
            spacing: 8

            Label {
                text: card.title
                color: Theme.text
                font.pixelSize: Theme.fontSize(15)
                font.weight: Font.DemiBold
                elide: Text.ElideRight
                Layout.fillWidth: card.subtitle.length === 0
            }

            Item { Layout.fillWidth: card.subtitle.length > 0 }

            Label {
                text: card.subtitle
                visible: card.subtitle.length > 0
                color: Theme.text3
                font.pixelSize: Theme.fontSize(13)
                elide: Text.ElideRight
            }
        }
    }
}
