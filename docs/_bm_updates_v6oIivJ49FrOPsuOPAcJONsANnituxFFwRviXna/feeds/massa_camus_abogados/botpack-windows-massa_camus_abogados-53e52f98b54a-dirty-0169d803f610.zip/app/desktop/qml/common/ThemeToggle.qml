import QtQuick
import QtQuick.Controls

// Segmented theme selector: ☀ Claro / ☾ Oscuro / Auto. Emits modeSelected with
// "light" | "dark" | "auto". Active segment = panel bg + primary text.
Rectangle {
    id: toggle

    property string mode: "light"
    signal modeSelected(string value)

    radius: 9
    color: Theme.panel2
    border.width: 1
    border.color: Theme.lineSoft
    implicitHeight: 34
    implicitWidth: row.implicitWidth + 6

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 2

        Repeater {
            model: [
                { key: "light", label: "☀ Claro" },
                { key: "dark", label: "☾ Oscuro" },
                { key: "auto", label: "Auto" }
            ]

            Rectangle {
                required property var modelData
                readonly property bool active: toggle.mode === modelData.key
                width: seg.implicitWidth + 32
                height: 28
                radius: 7
                color: active ? Theme.panel : "transparent"
                border.width: active ? 1 : 0
                border.color: Theme.lineSoft

                Label {
                    id: seg
                    anchors.centerIn: parent
                    text: parent.modelData.label
                    color: parent.active ? Theme.text : Theme.text3
                    font.pixelSize: Theme.fontSize(13)
                    font.weight: Font.DemiBold
                }

                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: toggle.modeSelected(parent.modelData.key)
                }
            }
        }
    }
}
