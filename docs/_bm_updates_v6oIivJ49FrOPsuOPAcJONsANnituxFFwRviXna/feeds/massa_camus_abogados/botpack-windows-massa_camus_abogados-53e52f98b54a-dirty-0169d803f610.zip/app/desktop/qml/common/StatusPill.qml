import QtQuick
import QtQuick.Controls

// Soft-fill status pill. variant = ok | fail | running | queued | cancel.
// `running` adds a pulsing live dot. radius 99, 11.5px/700.
Rectangle {
    id: pill

    property string variant: "ok"
    property string text: ""

    readonly property color fg: {
        if (variant === "fail") return Theme.danger
        if (variant === "running" || variant === "info") return Theme.accent
        if (variant === "queued") return Theme.warning
        if (variant === "cancel") return Theme.cancel
        return Theme.success
    }
    readonly property color bgSoft: {
        if (variant === "fail") return Theme.dangerSoft
        if (variant === "running" || variant === "info") return Theme.accentSoft
        if (variant === "queued") return Theme.warningSoft
        if (variant === "cancel") return Theme.cancelSoft
        return Theme.successSoft
    }

    radius: Theme.radiusPill
    color: bgSoft
    implicitHeight: 24
    implicitWidth: row.implicitWidth + 24

    property real pulse: 0
    NumberAnimation on pulse {
        running: pill.variant === "running" && pill.visible
        from: 0; to: 1; duration: 1400
        loops: Animation.Infinite
    }

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 7

        Rectangle {
            width: 7
            height: 7
            radius: 3.5
            anchors.verticalCenter: parent.verticalCenter
            visible: pill.variant === "running"
            color: pill.fg
            opacity: 1.0 - 0.45 * Math.abs(Math.sin(pill.pulse * Math.PI))
        }

        Label {
            text: pill.text
            color: pill.fg
            font.pixelSize: Theme.fontSize(12)
            font.weight: Font.Bold
            font.letterSpacing: 0.3
        }
    }
}
