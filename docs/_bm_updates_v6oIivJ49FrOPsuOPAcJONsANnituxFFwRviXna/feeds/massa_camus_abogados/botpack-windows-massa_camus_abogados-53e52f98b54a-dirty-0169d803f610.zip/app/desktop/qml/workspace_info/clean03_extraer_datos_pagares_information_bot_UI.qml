import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color accentStrong: Common.Theme.accent
    property color success: Common.Theme.success
    property int infoTabIndex: 0

    Label {
        text: "Informacion del Bot"
        color: root.textMain
        font.pixelSize: Common.Theme.fontSize(16)
        font.bold: true
        width: root.width
    }

    Common.ExternalDependencyWarning {
        width: root.width
        dependencies: root.botInfo && root.botInfo.missingExternalDependencies
            ? root.botInfo.missingExternalDependencies : []
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: processLabel.implicitWidth + 20
        color: Common.Theme.successSoft
        border.width: 1
        border.color: Common.Theme.success

        Label {
            id: processLabel
            anchors.centerIn: parent
            text: "Proceso CLEAN_BBRR"
            color: Common.Theme.success
            font.pixelSize: Common.Theme.fontSize(12)
            font.bold: true
        }
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: localLabel.implicitWidth + 20
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.accent

        Label {
            id: localLabel
            anchors.centerIn: parent
            text: "100% local - sin nube"
            color: Common.Theme.accent
            font.pixelSize: Common.Theme.fontSize(12)
            font.bold: true
        }
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Extraer Datos Pagarés"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: extraerInfoComponent
    }

    Component {
        id: extraerInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: CLEAN03_EXTRAER_DATOS_PAGARES"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Lee la carpeta de RUTs (lo que produce Clean02 tras la revisión humana) y la matriz de entrada, y genera la matriz final con los datos de cada pagaré extraídos por OCR — tal como lo haría una persona. Todo el procesamiento ocurre de forma local en este equipo."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "input/ruts: una subcarpeta por RUT (cada una con PAGARE_*, INFORME_DEUDA, HOJA_DE_FIRMA, etc.). El bot SIEMPRE procesa esta carpeta (botón 'Abrir carpeta' para revisarla o pegar las carpetas).",
                    "input/matriz: la matriz de entrada (.xlsx) con las filas por RUT/pagaré (RUT, DV, NOMBRE, OPERACIÓN, CARTERA, MORA). Se elige con 'Seleccionar Matriz'.",
                    "La matriz de entrada NO se modifica: el bot trabaja sobre una copia nueva."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Un único Excel Matriz_Asignacion_[fecha-hora].xlsx en output/.",
                    "Una fila por pagaré, con montos, tasa, cuotas, fechas, domicilio, comuna, hoja de firma y código de contrato.",
                    "Celdas en amarillo (NO_ENCONTRADO / REVISAR) cuando un dato esperado no se pudo leer.",
                    "Filas en rojo cuando faltó un pagaré esperado; filas en amarillo para un pagaré extra no listado en la matriz.",
                    "REGION_DEUDOR, NOTARIO, FECHA_PROTOCOLI, NOTA y COD_FORM_DDA se dejan en blanco (las completa la persona)."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }
        }
    }
}
