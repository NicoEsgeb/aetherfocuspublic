import QtQuick
import QtQuick.Controls

// Indeterminate progress: a 34%-wide accent segment sweeping left to right on the
// same track style as ProgressBarLive. Used for phases without a count.
Item {
    id: bar

    property string label: ""
    property bool running: true

    implicitHeight: (bar.label.length > 0 ? labelText.implicitHeight + 7 : 0) + 9

    Label {
        id: labelText
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        visible: bar.label.length > 0
        text: bar.label
        color: Theme.text2
        font.pixelSize: Theme.fontSize(13)
        font.weight: Font.DemiBold
        elide: Text.ElideRight
    }

    Rectangle {
        id: track
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 9
        radius: Theme.radiusPill
        color: Theme.panel2
        clip: true

        Rectangle {
            id: seg
            height: parent.height
            width: parent.width * 0.34
            radius: Theme.radiusPill
            color: Theme.accent
            opacity: 0.85

            NumberAnimation on x {
                running: bar.running && bar.visible
                from: -seg.width
                to: track.width
                duration: 1500
                loops: Animation.Infinite
                easing.type: Easing.InOutSine
            }
        }
    }
}
