import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color accentStrong: Common.Theme.accent
    property color success: Common.Theme.success
    property int infoTabIndex: 0

    Label {
        text: "Informacion del Bot"
        color: root.textMain
        font.pixelSize: Common.Theme.fontSize(16)
        font.bold: true
        width: root.width
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: processLabel.implicitWidth + 20
        color: Common.Theme.successSoft
        border.width: 1
        border.color: Common.Theme.success

        Label {
            id: processLabel
            anchors.centerIn: parent
            text: "Proceso CLEAN_BBRR"
            color: Common.Theme.success
            font.pixelSize: Common.Theme.fontSize(12)
            font.bold: true
        }
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: localLabel.implicitWidth + 20
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.accent

        Label {
            id: localLabel
            anchors.centerIn: parent
            text: "100% local - sin nube"
            color: Common.Theme.accent
            font.pixelSize: Common.Theme.fontSize(12)
            font.bold: true
        }
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Generar Demandas"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: generarInfoComponent
    }

    Component {
        id: generarInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: CLEAN04_GENERAR_DEMANDAS"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Lee la matriz que produce Clean03 (una fila por pagaré) y genera un PDF de demanda por cada RUT — un RUT con varios pagarés se convierte en una sola demanda con un párrafo por pagaré. Todo el procesamiento ocurre de forma local en este equipo."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "input/matriz: la matriz de Clean03 (.xlsx) con las columnas CARTERA_A_PROCESAR, PAGARE_FIRMADO_CLIENTE, CONTRATO_MANDATO_FIRMADO_CLIENTE, HOJA_DE_FIRMA, montos, cuotas y fechas. Se elige con 'Seleccionar Matriz'.",
                    "El bot elige la plantilla de cada pagaré según CARTERA_A_PROCESAR (MP → en cuotas) y las columnas firmado (a la Vista / plazo fijo). Las celdas RE (moradas de Clean03) las debe resolver la persona a MP o VI antes de correr.",
                    "El bot NO modifica el original: escribe una COPIA anotada (con la columna ESTADO) dentro de la carpeta de salida, junto a los PDFs."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Dos versiones de cada demanda (RUT válido) en output/Demandas_[fecha-hora]/: el PDF en la subcarpeta demandas_pdf/ y el Word editable (.docx) en demandas_word/, ambos con el nombre {RUT}-{DV}_DEMANDA. El Word sirve para ajustar la redacción antes de presentar.",
                    "Una COPIA de la matriz ([nombre]_ESTADO.xlsx) en esa misma carpeta de salida, con la columna ESTADO al inicio: OK (verde), REVISAR (amarillo) o ERROR (rojo), uniforme por RUT. El original queda intacto.",
                    "Solo se genera el PDF de los RUT completos (OK). Si falta un dato requerido, el RUT queda en REVISAR y se pintan de amarillo las celdas que faltan (con comentario).",
                    "Reanudable: para corregir un REVISAR, edita la COPIA anotada (la del output), arregla las celdas amarillas y vuélvela a correr; los RUT que ya están OK se omiten y solo se reprocesan los REVISAR/ERROR.",
                    "Nunca emite una demanda incompleta: si algo no cuadra, lo marca y no genera el PDF."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }
        }
    }
}
