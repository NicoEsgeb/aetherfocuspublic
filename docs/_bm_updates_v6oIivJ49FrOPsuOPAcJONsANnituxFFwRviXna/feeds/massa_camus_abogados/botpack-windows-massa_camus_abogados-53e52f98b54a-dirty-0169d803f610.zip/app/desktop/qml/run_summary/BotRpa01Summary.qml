import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cDanger: Common.Theme.danger
    readonly property color cWarning: Common.Theme.warning
    readonly property int statusColumnWidth: 220

    readonly property var rowsModel: {
        if (!summaryData || summaryData.escritosRows === undefined || summaryData.escritosRows === null) {
            return []
        }
        return summaryData.escritosRows
    }

    function hasData() {
        return !!summaryData && summaryData.hasData === true
    }

    function metricValue(key) {
        if (!hasData()) {
            return "-"
        }
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null) {
            return "0"
        }
        return String(summaryData[key])
    }

    function hasRows() {
        return root.rowsModel.length > 0
    }

    function rowsError() {
        if (!summaryData || summaryData.escritosRowsError === undefined || summaryData.escritosRowsError === null) {
            return ""
        }
        return String(summaryData.escritosRowsError).trim()
    }

    function isRowOk(rowData) {
        return !!rowData && rowData.ok === true
    }

    function rowStatusLabel(rowData) {
        return root.isRowOk(rowData) ? "Ok" : "Error"
    }

    function rowStatusColor(rowData) {
        return root.isRowOk(rowData) ? root.cSuccess : root.cDanger
    }

    function rolLabel(rowData) {
        if (!rowData || rowData.rol === undefined || rowData.rol === null) {
            return "-"
        }
        var value = String(rowData.rol).trim()
        return value.length > 0 ? value : "-"
    }

    ScrollView {
        anchors.fill: parent
        clip: true
        contentWidth: availableWidth
        background: Rectangle { color: "transparent" }
        ScrollBar.vertical: Common.StyledScrollBar {
            policy: ScrollBar.AsNeeded
        }
        ScrollBar.horizontal: Common.StyledScrollBar {
            policy: ScrollBar.AlwaysOff
            visible: false
            interactive: false
        }

        ColumnLayout {
            width: parent.width
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.preferredHeight: 108
                    radius: 12
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    Column {
                        anchors.fill: parent
                        anchors.margins: 12
                        spacing: 8

                        Label {
                            text: "Escritos Procesados"
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                        }

                        Label {
                            text: root.metricValue("escritosProcesados")
                            color: root.cTextMain
                            font.pixelSize: Common.Theme.fontSize(34)
                            font.bold: true
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.preferredHeight: 108
                    radius: 12
                    color: root.cPanel
                    border.width: 1
                    border.color: Common.Theme.success

                    Column {
                        anchors.fill: parent
                        anchors.margins: 12
                        spacing: 8

                        Row {
                            spacing: 6

                            Label {
                                text: "✓"
                                color: root.cSuccess
                                font.pixelSize: Common.Theme.fontSize(14)
                                font.bold: true
                            }

                            Label {
                                text: "Escritos Ingresados"
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(12)
                            }
                        }

                        Label {
                            text: root.metricValue("escritosIngresados")
                            color: root.cSuccess
                            font.pixelSize: Common.Theme.fontSize(34)
                            font.bold: true
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.preferredHeight: 108
                    radius: 12
                    color: root.cPanel
                    border.width: 1
                    border.color: Common.Theme.dangerSoft

                    Column {
                        anchors.fill: parent
                        anchors.margins: 12
                        spacing: 8

                        Row {
                            spacing: 6

                            Label {
                                text: "✕"
                                color: root.cDanger
                                font.pixelSize: Common.Theme.fontSize(14)
                                font.bold: true
                            }

                            Label {
                                text: "Escritos Fallidos"
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(12)
                            }
                        }

                        Label {
                            text: root.metricValue("escritosFallidos")
                            color: root.cDanger
                            font.pixelSize: Common.Theme.fontSize(34)
                            font.bold: true
                        }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.max(260, Math.min(460, 72 + (root.rowsModel.length * 38)))
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: root.cLine

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 10
                    spacing: 8

                    Label {
                        text: "Detalle de Ingresos por Escrito"
                        color: root.cTextMain
                        font.pixelSize: Common.Theme.fontSize(13)
                        font.bold: true
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 34
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: root.cLine

                        RowLayout {
                            anchors.fill: parent
                            anchors.margins: 8
                            spacing: 10

                            Label {
                                Layout.preferredWidth: root.statusColumnWidth
                                text: "Ingreso"
                                color: root.cTextMain
                                font.bold: true
                                font.pixelSize: Common.Theme.fontSize(12)
                            }

                            Label {
                                Layout.fillWidth: true
                                text: "ROL"
                                color: root.cTextMain
                                font.bold: true
                                font.pixelSize: Common.Theme.fontSize(12)
                                elide: Text.ElideRight
                            }
                        }
                    }

                    Item {
                        Layout.fillWidth: true
                        Layout.fillHeight: true

                        ListView {
                            id: rowsView
                            anchors.fill: parent
                            model: root.rowsModel
                            clip: true
                            spacing: 4
                            visible: root.hasRows()

                            ScrollBar.vertical: Common.StyledScrollBar {
                                policy: ScrollBar.AsNeeded
                            }

                            delegate: Rectangle {
                                width: ListView.view.width
                                height: 34
                                radius: 8
                                color: index % 2 === 0 ? Common.Theme.panel2 : Common.Theme.panel2
                                border.width: 1
                                border.color: Common.Theme.line

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 8
                                    spacing: 10

                                    RowLayout {
                                        Layout.preferredWidth: root.statusColumnWidth
                                        spacing: 6

                                        Label {
                                            text: root.isRowOk(modelData) ? "✓" : "•"
                                            color: root.rowStatusColor(modelData)
                                            font.pixelSize: Common.Theme.fontSize(13)
                                            font.bold: true
                                        }

                                        Label {
                                            text: root.rowStatusLabel(modelData)
                                            color: root.rowStatusColor(modelData)
                                            font.pixelSize: Common.Theme.fontSize(12)
                                            font.bold: true
                                            elide: Text.ElideRight
                                        }
                                    }

                                    Label {
                                        Layout.fillWidth: true
                                        text: root.rolLabel(modelData)
                                        color: root.cTextMain
                                        font.pixelSize: Common.Theme.fontSize(12)
                                        elide: Text.ElideRight
                                    }
                                }
                            }
                        }

                        Label {
                            anchors.centerIn: parent
                            visible: !rowsView.visible
                            text: {
                                var errorText = root.rowsError()
                                return errorText.length > 0
                                    ? errorText
                                    : "Sin filas disponibles para esta corrida."
                            }
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(13)
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.Wrap
                            width: parent.width - 24
                        }
                    }
                }
            }
        }
    }
}
