import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarning: Common.Theme.warning
    readonly property color cDanger: Common.Theme.danger

    function val(key, fallback) {
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null)
            return fallback
        return summaryData[key]
    }
    function logText() { return String(root.val("logText", "")) }
    function lastMatch(pattern) {
        pattern.lastIndex = 0
        var current = null
        var latest = null
        while ((current = pattern.exec(root.logText())) !== null) {
            latest = current
            if (current[0].length === 0)
                pattern.lastIndex += 1
        }
        return latest
    }
    function matchedInt(pattern, groupIndex) {
        var match = root.lastMatch(pattern)
        if (!match)
            return 0
        var value = Number(match[groupIndex === undefined ? 1 : groupIndex])
        return isNaN(value) ? 0 : value
    }
    function finalMatch() {
        return root.lastMatch(/^N03:\s*proceso completado\s*\|\s*ok=(\d+)\s+failed=(\d+)\s+output=(.+?\.xlsx)\s*$/gmi)
    }
    function stateMatch() {
        return root.lastMatch(/^N03:\s*estado\s+extension=(si|no)\s+pending=(\d+)\s+in_progress=(\d+)\s+ok=(\d+)\s+failed=(\d+)\s*$/gmi)
    }
    function outputFile() {
        var finalState = root.finalMatch()
        if (finalState)
            return String(finalState[3]).trim()
        var output = root.lastMatch(/^\s*Output:\s*(.+?\.xlsx)\s*$/gmi)
        return output ? String(output[1]).trim() : ""
    }
    function outputDir() {
        var path = root.outputFile()
        var slash = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"))
        return slash > 0 ? path.slice(0, slash) : path
    }
    function technicalStatus() { return String(root.val("statusTechnical", "")).toLowerCase() }
    function isSuccess() { return root.technicalStatus() === "success" }
    function isFailed() { return root.technicalStatus() === "failed" }
    function isCancelled() { return root.technicalStatus() === "cancelled" }
    function totalRows() { return root.matchedInt(/^\s*Filas totales:\s*(\d+)\s*$/gmi) }
    function targetRows() { return root.matchedInt(/^\s*Filas E-\* a procesar:\s*(\d+)\s*$/gmi) }
    function skippedRows() { return root.matchedInt(/^\s*Omitidas\/no E:\s*(\d+)\s*\|\s*invalidas:\s*(\d+)\s*$/gmi, 1) }
    function invalidRows() { return root.matchedInt(/^\s*Omitidas\/no E:\s*(\d+)\s*\|\s*invalidas:\s*(\d+)\s*$/gmi, 2) }
    function successfulRows() {
        var finalState = root.finalMatch()
        if (finalState)
            return Number(finalState[1])
        var state = root.stateMatch()
        return state ? Number(state[4]) : 0
    }
    function failedRows() {
        var finalState = root.finalMatch()
        if (finalState)
            return Number(finalState[2])
        var state = root.stateMatch()
        return state ? Number(state[5]) : 0
    }
    function pendingRows() {
        var state = root.stateMatch()
        return state ? Number(state[2]) : Math.max(0, root.targetRows() - root.processedRows())
    }
    function processedRows() { return root.successfulRows() + root.failedRows() }
    function extensionSeen() {
        var state = root.stateMatch()
        return !!root.finalMatch() || (!!state && String(state[1]).toLowerCase() === "si")
    }
    function fraction() {
        return root.targetRows() > 0 ? Math.min(1, root.processedRows() / root.targetRows()) : 0
    }
    function hasData() { return root.outputFile().length > 0 || root.totalRows() > 0 || root.targetRows() > 0 || !!root.stateMatch() }
    function statusWord() {
        if (root.isSuccess()) return "Completado"
        if (root.isFailed()) return "Con errores"
        if (root.isCancelled()) return "Detenido"
        if (root.technicalStatus() === "queued") return "En cola"
        return root.extensionSeen() ? "En proceso" : "Esperando"
    }
    function headline() {
        if (root.isSuccess()) return "Listo: " + root.processedRows() + " de " + root.targetRows() + " filas procesadas"
        if (root.isFailed()) return "El proceso se detuvo en " + root.processedRows() + " de " + root.targetRows() + " filas"
        if (root.isCancelled()) return "Proceso detenido manualmente"
        if (root.extensionSeen()) return "Extensión conectada · " + root.processedRows() + " de " + root.targetRows() + " filas"
        return "Esperando conexión de la extensión de Edge..."
    }
    function statusColor() {
        if (root.isCancelled()) return Common.Theme.cancel
        if (root.isFailed()) return root.cDanger
        if (root.isSuccess()) return root.cSuccess
        if (!root.extensionSeen()) return root.cWarning
        return Common.Theme.accent
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 12

        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Label {
                text: "N03 · Buscar Tribunal (Extensión)"
                color: root.cTextMain
                font.pixelSize: Common.Theme.fontSize(18)
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Label {
                text: root.val("startedAt", "-") + " → " + root.val("finishedAt", "-")
                color: root.cTextMuted
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Rectangle {
                radius: 7
                implicitHeight: 24
                implicitWidth: statusLabel.implicitWidth + 22
                color: root.cPanel
                border.width: 1
                border.color: root.statusColor()

                Label {
                    id: statusLabel
                    anchors.centerIn: parent
                    text: root.statusWord()
                    color: root.statusColor()
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                }
            }
        }

        Label {
            text: root.headline()
            color: root.cTextMain
            font.pixelSize: Common.Theme.fontSize(14)
            font.bold: true
            Layout.fillWidth: true
            elide: Text.ElideRight
        }

        Rectangle {
            id: progressTrack
            Layout.fillWidth: true
            implicitHeight: 16
            radius: 8
            color: root.cPanel
            border.width: 1
            border.color: root.cLine
            clip: true

            Rectangle {
                height: parent.height
                width: Math.max(parent.height, parent.width * root.fraction())
                radius: 8
                color: root.statusColor()

                Behavior on width {
                    NumberAnimation { duration: 450; easing.type: Easing.OutCubic }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Repeater {
                model: [
                    { label: "Objetivo E-*", value: root.targetRows(), color: root.cTextMain },
                    { label: "Procesadas", value: root.processedRows(), color: Common.Theme.accent },
                    { label: "Encontradas", value: root.successfulRows(), color: root.cSuccess },
                    { label: "Sin resultado", value: root.failedRows(), color: root.cWarning }
                ]

                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 64
                    radius: 10
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 1

                        Label {
                            text: String(modelData.value)
                            color: modelData.color
                            font.pixelSize: Common.Theme.fontSize(22)
                            font.bold: true
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Label {
                            text: modelData.label
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: detailRow.implicitHeight + 22
            radius: 10
            color: root.cPanel
            border.width: 1
            border.color: root.cLine

            RowLayout {
                id: detailRow
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 14
                anchors.rightMargin: 14
                spacing: 18

                Label {
                    text: "Planilla: " + root.totalRows() + " filas"
                    color: root.cTextMuted
                    font.pixelSize: Common.Theme.fontSize(12)
                }
                Label {
                    text: "Omitidas/no E: " + root.skippedRows()
                    color: root.cTextMuted
                    font.pixelSize: Common.Theme.fontSize(12)
                }
                Label {
                    text: "Inválidas: " + root.invalidRows()
                    color: root.cTextMuted
                    font.pixelSize: Common.Theme.fontSize(12)
                }
                Item { Layout.fillWidth: true }
                Label {
                    text: root.extensionSeen() ? "● Extensión conectada" : "○ Esperando extensión"
                    color: root.extensionSeen() ? root.cSuccess : root.cWarning
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                }
            }
        }

        Common.InsetAlloyButton {
            id: openOutputButton
            alloyTone: "success"
            visible: root.outputFile().length > 0
            Layout.fillWidth: true
            Layout.preferredHeight: 42
            text: "Abrir carpeta de salida"
            onClicked: controller.openPathInExplorer(root.outputDir())
        }

        Rectangle {
            visible: !root.hasData()
            Layout.fillWidth: true
            Layout.preferredHeight: 90
            radius: 10
            color: root.cPanel
            border.width: 1
            border.color: root.cLine

            Label {
                anchors.centerIn: parent
                text: "Todavía no hay información disponible para esta corrida."
                color: root.cTextMuted
                font.pixelSize: Common.Theme.fontSize(13)
            }
        }

        Item { Layout.fillHeight: true }
    }
}
