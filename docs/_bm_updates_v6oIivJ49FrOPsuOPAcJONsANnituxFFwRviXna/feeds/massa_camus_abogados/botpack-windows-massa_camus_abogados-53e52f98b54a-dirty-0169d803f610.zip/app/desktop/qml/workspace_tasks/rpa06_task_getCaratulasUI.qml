import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property string matrixPath: ""
    property string fechaDesde: ""
    property string fechaHasta: ""
    property string informePath: ""
    property string caratulasFolderPath: ""
    property string demandasPath: ""
    property var workspaceConfig: ({})
    property var helpers: ({})

    property int minYear: 2000
    property int maxYear: 2040
    property int defaultYear: 2026
    property int desdeDay: 1
    property int desdeMonth: 1
    property int desdeYear: 2026
    property int hastaDay: 1
    property int hastaMonth: 1
    property int hastaYear: 2026
    property bool syncingDateSelectors: false

    readonly property var dayOptions: buildNumberOptions(1, 31, true)
    readonly property var monthOptions: buildNumberOptions(1, 12, true)
    readonly property var yearOptions: buildNumberOptions(minYear, maxYear, false)

    signal matrixPathEdited(string value)
    signal fechaDesdeEdited(string value)
    signal fechaHastaEdited(string value)
    signal informePathEdited(string value)

    onFechaDesdeChanged: syncSelectorsFromText()
    onFechaHastaChanged: syncSelectorsFromText()

    Component.onCompleted: {
        syncSelectorsFromText()
        if (!String(fechaDesde || "").trim()) {
            emitDesde()
        }
        if (!String(fechaHasta || "").trim()) {
            emitHasta()
        }
    }

    function buildNumberOptions(start, end, padTwo) {
        var options = []
        for (var i = start; i <= end; i++) {
            var text = String(i)
            if (padTwo && i < 10) {
                text = "0" + text
            }
            options.push({ text: text, value: i })
        }
        return options
    }

    function optionIndexForValue(options, value) {
        for (var i = 0; i < options.length; i++) {
            if (Number(options[i].value) === Number(value)) {
                return i
            }
        }
        return 0
    }

    function daysInMonth(month, year) {
        return new Date(year, month, 0).getDate()
    }

    function pad2(value) {
        return value < 10 ? "0" + value : String(value)
    }

    function clamp(value, min, max, fallback) {
        if (isNaN(value)) {
            return fallback
        }
        if (value < min) {
            return min
        }
        if (value > max) {
            return max
        }
        return value
    }

    function formatDmy(day, month, year) {
        return pad2(day) + "/" + pad2(month) + "/" + String(year)
    }

    function parseDmyOrDefault(value) {
        var text = String(value || "").trim()
        var match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
        if (!match) {
            return ({ day: 1, month: 1, year: defaultYear })
        }
        var parsedDay = Number(match[1])
        var parsedMonth = Number(match[2])
        var parsedYear = Number(match[3])
        var safeYear = clamp(parsedYear, minYear, maxYear, defaultYear)
        var safeMonth = clamp(parsedMonth, 1, 12, 1)
        var safeDay = clamp(parsedDay, 1, daysInMonth(safeMonth, safeYear), 1)
        return ({ day: safeDay, month: safeMonth, year: safeYear })
    }

    function syncSelectorsFromText() {
        if (syncingDateSelectors) {
            return
        }
        syncingDateSelectors = true

        var parsedDesde = parseDmyOrDefault(fechaDesde)
        desdeDay = parsedDesde.day
        desdeMonth = parsedDesde.month
        desdeYear = parsedDesde.year

        var parsedHasta = parseDmyOrDefault(fechaHasta)
        hastaDay = parsedHasta.day
        hastaMonth = parsedHasta.month
        hastaYear = parsedHasta.year

        syncingDateSelectors = false
    }

    function emitDesde() {
        if (syncingDateSelectors) {
            return
        }
        var maxDay = daysInMonth(desdeMonth, desdeYear)
        if (desdeDay > maxDay) {
            syncingDateSelectors = true
            desdeDay = maxDay
            syncingDateSelectors = false
        }
        fechaDesdeEdited(formatDmy(desdeDay, desdeMonth, desdeYear))
    }

    function emitHasta() {
        if (syncingDateSelectors) {
            return
        }
        var maxDay = daysInMonth(hastaMonth, hastaYear)
        if (hastaDay > maxDay) {
            syncingDateSelectors = true
            hastaDay = maxDay
            syncingDateSelectors = false
        }
        fechaHastaEdited(formatDmy(hastaDay, hastaMonth, hastaYear))
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function pathDirectory(pathText) {
        if (helpers && typeof helpers.pathDirectory === "function") {
            return helpers.pathDirectory(pathText)
        }
        var value = String(pathText || "")
        var slashIndex = Math.max(value.lastIndexOf("/"), value.lastIndexOf("\\"))
        if (slashIndex < 0) {
            return ""
        }
        return value.substring(0, slashIndex)
    }

    function isValidDateDmy(value) {
        if (helpers && typeof helpers.isValidDateDmy === "function") {
            return helpers.isValidDateDmy(value)
        }
        var text = String(value || "").trim()
        var match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
        if (!match) {
            return false
        }
        var day = Number(match[1])
        var month = Number(match[2])
        var year = Number(match[3])
        var date = new Date(year, month - 1, day)
        return date.getFullYear() === year
            && date.getMonth() === (month - 1)
            && date.getDate() === day
    }

    function compareDateDmy(dateA, dateB) {
        if (helpers && typeof helpers.compareDateDmy === "function") {
            return helpers.compareDateDmy(dateA, dateB)
        }
        var a = String(dateA || "").trim().split("/")
        var b = String(dateB || "").trim().split("/")
        if (a.length !== 3 || b.length !== 3) {
            return 0
        }
        var aKey = Number(a[2]) * 10000 + Number(a[1]) * 100 + Number(a[0])
        var bKey = Number(b[2]) * 10000 + Number(b[1]) * 100 + Number(b[0])
        if (aKey < bKey) {
            return -1
        }
        if (aKey > bKey) {
            return 1
        }
        return 0
    }

    function defaultMatrixFolder() {
        if (workspaceConfig && workspaceConfig.defaultGetCaratulasMatrixFolder) {
            var specificFolder = String(workspaceConfig.defaultGetCaratulasMatrixFolder || "").trim()
            if (specificFolder.length > 0) {
                return specificFolder
            }
        }
        if (workspaceConfig && workspaceConfig.defaultMatrixFolder) {
            return String(workspaceConfig.defaultMatrixFolder || "").trim()
        }
        return ""
    }

    function defaultInformeFolder() {
        if (workspaceConfig && workspaceConfig.defaultInformeFolder) {
            return String(workspaceConfig.defaultInformeFolder || "").trim()
        }
        var currentInforme = String(informePath || "").trim()
        if (currentInforme.length > 0) {
            return pathDirectory(currentInforme)
        }
        return ""
    }

    function demandasRootFolder() {
        var demandasFolder = String(demandasPath || "").trim()
        if (demandasFolder.length > 0) {
            return demandasFolder
        }
        var matrixFolder = String(defaultMatrixFolder() || "").trim()
        if (matrixFolder.length === 0) {
            return ""
        }
        return pathDirectory(matrixFolder)
    }

    function pathJoin(basePath, tailPath) {
        var base = String(basePath || "").trim()
        var tail = String(tailPath || "").trim()
        if (base.length === 0) {
            return tail
        }
        if (tail.length === 0) {
            return base
        }
        var separator = base.indexOf("\\") >= 0 ? "\\" : "/"
        if (base.endsWith("/") || base.endsWith("\\")) {
            return base + tail
        }
        return base + separator + tail
    }

    function isAbsolutePath(pathText) {
        var value = String(pathText || "").trim()
        if (value.length === 0) {
            return false
        }
        if (value.startsWith("/") || value.startsWith("\\\\")) {
            return true
        }
        return /^[A-Za-z]:[\\/]/.test(value)
    }

    function absoluteMatrixPath() {
        var configured = String(matrixPath || "").trim()
        if (configured.length === 0) {
            configured = "Matriz_Demandas/BOT_MATRIZ_DEMANDAS_ingreso.xlsx"
        }
        if (configured.startsWith("file://")) {
            return toLocalPath(configured)
        }
        if (isAbsolutePath(configured)) {
            return configured
        }
        var rootFolder = demandasRootFolder()
        if (rootFolder.length === 0) {
            return configured
        }
        return pathJoin(rootFolder, configured)
    }

    function openInformeFolder() {
        var folderPath = String(defaultInformeFolder() || "").trim()
        if (folderPath.length <= 0) {
            return
        }
        if (typeof controller !== "undefined" && controller !== null) {
            controller.openPathInExplorer(folderPath)
        }
    }

    function validate() {
        var matrix = String(matrixPath || "").trim()
        var informe = String(informePath || "").trim()
        var desde = formatDmy(desdeDay, desdeMonth, desdeYear)
        var hasta = formatDmy(hastaDay, hastaMonth, hastaYear)
        if (!matrix && !sinCompararCheck.checked) {
            return "Selecciona la matriz para GET_CARATULAS."
        }
        if (!informe) {
            missingInformeDialog.text = "Por favor seleccione Informe Excel"
            missingInformeDialog.open()
            return "Por favor seleccione Informe Excel"
        }
        if (!isValidDateDmy(desde) || !isValidDateDmy(hasta)) {
            return "Las fechas deben usar formato dd/mm/yyyy."
        }
        if (compareDateDmy(desde, hasta) > 0) {
            return "Fecha desde no puede ser mayor que Fecha hasta."
        }
        return ""
    }

    function buildPayload() {
        var payload = {
            matriz_get_caratulas_path: String(matrixPath || "").trim(),
            informe_causas_path: String(informePath || "").trim(),
            fecha_desde_caratulas: formatDmy(desdeDay, desdeMonth, desdeYear),
            fecha_hasta_caratulas: formatDmy(hastaDay, hastaMonth, hastaYear),
            descargar_sin_comparar: sinCompararCheck.checked
        }
        var caratulas = String(caratulasFolderPath || "").trim()
        if (caratulas.length > 0) {
            payload.caratulas_folder_path = caratulas
        }
        return payload
    }

    Label {
        text: "Fecha desde / Fecha hasta"
        color: Common.Theme.text2
        Layout.fillWidth: true
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        RowLayout {
            Layout.fillWidth: true
            spacing: 6

            Label {
                text: "Desde"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.preferredWidth: 42
            }

            Common.StyledComboBox {
                id: desdeDayCombo
                Layout.preferredWidth: 68
                model: root.dayOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.dayOptions, root.desdeDay)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.dayOptions.length) {
                        return
                    }
                    root.desdeDay = root.dayOptions[currentIndex].value
                    root.emitDesde()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Common.StyledComboBox {
                id: desdeMonthCombo
                Layout.preferredWidth: 68
                model: root.monthOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.monthOptions, root.desdeMonth)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.monthOptions.length) {
                        return
                    }
                    root.desdeMonth = root.monthOptions[currentIndex].value
                    root.emitDesde()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Common.StyledComboBox {
                id: desdeYearCombo
                Layout.fillWidth: true
                Layout.minimumWidth: 96
                model: root.yearOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.yearOptions, root.desdeYear)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.yearOptions.length) {
                        return
                    }
                    root.desdeYear = root.yearOptions[currentIndex].value
                    root.emitDesde()
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 6

            Label {
                text: "Hasta"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.preferredWidth: 42
            }

            Common.StyledComboBox {
                id: hastaDayCombo
                Layout.preferredWidth: 68
                model: root.dayOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.dayOptions, root.hastaDay)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.dayOptions.length) {
                        return
                    }
                    root.hastaDay = root.dayOptions[currentIndex].value
                    root.emitHasta()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Common.StyledComboBox {
                id: hastaMonthCombo
                Layout.preferredWidth: 68
                model: root.monthOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.monthOptions, root.hastaMonth)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.monthOptions.length) {
                        return
                    }
                    root.hastaMonth = root.monthOptions[currentIndex].value
                    root.emitHasta()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Common.StyledComboBox {
                id: hastaYearCombo
                Layout.fillWidth: true
                Layout.minimumWidth: 96
                model: root.yearOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.yearOptions, root.hastaYear)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.yearOptions.length) {
                        return
                    }
                    root.hastaYear = root.yearOptions[currentIndex].value
                    root.emitHasta()
                }
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: matrixCardLayout.implicitHeight + 18

        ColumnLayout {
            id: matrixCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Matriz a utilizar para Descargar Carátulas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Usa este acceso para abir y modificar la matriz que vas a utilizar"
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openMatrixButton
                text: "Matriz Demandas para Descarga de Carátulas"
                hoverEnabled: true
                Layout.alignment: Qt.AlignLeft
                onClicked: {
                    var targetPath = root.absoluteMatrixPath()
                    if (targetPath.length <= 0) {
                        return
                    }
                    var opened = Qt.openUrlExternally(root.toFileUrl(targetPath))
                    if (!opened && typeof controller !== "undefined" && controller !== null) {
                        controller.openPathInExplorer(targetPath)
                    }
                }
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: openMatrixButton.down ? Common.Theme.accent : Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: openMatrixButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: openMatrixButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: openMatrixButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Descargar sin comparar (omitir cruce de RUT contra la matriz)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: sinCompararLayout.implicitHeight + 18

        ColumnLayout {
            id: sinCompararLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: sinCompararCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: sinCompararCheck.leftPadding
                    y: sinCompararCheck.height / 2 - height / 2
                    radius: 5
                    color: sinCompararCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: sinCompararCheck.checked ? 2 : 1
                    border.color: sinCompararCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(14)
                        font.bold: true
                        visible: sinCompararCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Descargar sin comparar (omitir cruce con la matriz)"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: sinCompararCheck.indicator.width + sinCompararCheck.spacing
                }
            }

            Label {
                text: "Normalmente el bot descarga las caratulas del informe y luego elimina las que no coinciden con un RUT de la matriz (INGRESO=OK). Marca esta casilla para conservar TODAS las caratulas del informe sin compararlas con la matriz ni borrar ninguna. La matriz pasa a ser opcional."
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Label {
        text: "Informe Excel a utilizar para Descarga de Carátulas"
        color: Common.Theme.text2
        Layout.fillWidth: true
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        TextField {
            id: informeField
            Layout.fillWidth: true
            text: root.informePath
            color: Common.Theme.text
            placeholderText: "Informe_Causas_*.xlsx"
            placeholderTextColor: Common.Theme.text3
            onTextChanged: root.informePathEdited(text)
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: informeField.activeFocus ? 2 : 1
                border.color: informeField.activeFocus ? Common.Theme.accent : Common.Theme.line
            }
        }

        Common.InsetAlloyButton {
            id: selectInformeButton
            text: "Seleccionar informe Excel"
            hoverEnabled: true
            onClicked: {
                informeFileDialog.currentFolder = root.toFileUrl(root.defaultInformeFolder())
                informeFileDialog.open()
            }
            background: Rectangle {
                radius: 8
                border.width: 1
                border.color: selectInformeButton.down ? Common.Theme.accent : Common.Theme.accent
                gradient: Gradient {
                    GradientStop { position: 0.0; color: selectInformeButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                    GradientStop { position: 1.0; color: selectInformeButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                }
            }
            contentItem: Text {
                text: selectInformeButton.text
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(12)
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }
    }

    FileDialog {
        id: informeFileDialog
        title: "Seleccionar Informe Causas"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.informePathEdited(root.toLocalPath(selectedFile))
    }

    MessageDialog {
        id: missingInformeDialog
        title: "Validacion"
        text: "Por favor seleccione Informe Excel"
        buttons: MessageDialog.Ok
    }

}
