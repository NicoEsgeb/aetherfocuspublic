import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Popup {
    id: dialog

    property real uiScaleValue: 1.0
    property real fontScaleValue: 1.0
    property string currentThemeMode: "light"
    // Legacy colour props kept for compatibility with Main.qml; the dialog now
    // themes itself from the Theme singleton.
    property color cGlass: Theme.panel2
    property color cPanel: Theme.panel
    property color cPanelSoft: Theme.panel2
    property color cLine: Theme.line
    property color cTextMain: Theme.text
    property color cTextMuted: Theme.text2
    property color cAccent: Theme.accent
    property color cAccentStrong: Theme.accent
    property color cSuccess: Theme.success
    property color cDanger: Theme.danger
    property var controllerObject: null
    property string currentPjudLoginUsername: ""
    property string currentPjudPassword: ""
    property string currentPjudProfileLabel: ""
    property string credentialsFeedbackText: ""
    property color credentialsFeedbackColor: Theme.success

    signal uiScaleEdited(real value)
    signal resetUiScale()
    signal fontScaleEdited(real value)
    signal resetFontScale()
    signal themeModeEdited(string value)

    function syncCredentialInputsFromCurrent() {
        if (loginUsernameField) {
            loginUsernameField.text = currentPjudLoginUsername
        }
        if (passwordField) {
            passwordField.text = currentPjudPassword
        }
        if (profileLabelField) {
            profileLabelField.text = currentPjudProfileLabel
        }
    }

    function resetCredentialFeedback() {
        credentialsFeedbackText = ""
        credentialsFeedbackColor = Theme.success
    }

    parent: Overlay.overlay
    modal: true
    focus: true
    padding: 0
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
    width: Math.min(980, (parent ? parent.width : 980) - 72)
    height: Math.min(dialogLayout.implicitHeight + 2, (parent ? parent.height : 820) - 72)
    x: Math.round(((parent ? parent.width : width) - width) / 2)
    y: Math.round(((parent ? parent.height : height) - height) / 2)

    onOpened: {
        scaleSlider.value = uiScaleValue
        fontScaleSlider.value = fontScaleValue
        syncCredentialInputsFromCurrent()
        resetCredentialFeedback()
    }
    onUiScaleValueChanged: {
        if (!scaleSlider.pressed) {
            scaleSlider.value = uiScaleValue
        }
    }
    onFontScaleValueChanged: {
        if (!fontScaleSlider.pressed) {
            fontScaleSlider.value = fontScaleValue
        }
    }

    Overlay.modal: Rectangle {
        color: "#7f000000"
    }

    background: Rectangle {
        radius: 16
        color: Theme.panel
        border.width: 1
        border.color: Theme.line

        Rectangle {
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: 24
            anchors.rightMargin: 24
            height: 2
            radius: 1
            color: Theme.accent
            opacity: 0.82
        }
    }

    contentItem: ColumnLayout {
        id: dialogLayout
        spacing: 0

        // ---- header ----
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 102
            color: "transparent"

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 1
                color: Theme.lineSoft
            }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 30
                anchors.rightMargin: 30
                spacing: 18

                Rectangle {
                    Layout.alignment: Qt.AlignVCenter
                    implicitWidth: 48
                    implicitHeight: 48
                    radius: 12
                    color: Theme.accentSoft
                    border.width: 1
                    border.color: Theme.accent

                    Label {
                        anchors.centerIn: parent
                        text: "⚙"
                        color: Theme.accent
                        font.pixelSize: Theme.fontSize(22)
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 3

                    Label {
                        text: "SISTEMA · PREFERENCIAS"
                        color: Theme.accent
                        font.pixelSize: Theme.fontSize(11)
                        font.weight: Font.Bold
                        font.letterSpacing: 1.1
                    }

                    Label {
                        text: "Configuración"
                        color: Theme.text
                        font.pixelSize: Theme.fontSize(22)
                        font.weight: Font.DemiBold
                    }
                    Label {
                        Layout.fillWidth: true
                        text: "Ajusta la interfaz y las credenciales del portal."
                        color: Theme.text2
                        font.pixelSize: Theme.fontSize(13)
                        wrapMode: Text.Wrap
                    }
                }

                Button {
                    id: headerCloseButton
                    Layout.alignment: Qt.AlignVCenter
                    implicitWidth: 34
                    implicitHeight: 34
                    text: "✕"
                    hoverEnabled: true
                    onClicked: dialog.close()

                    contentItem: Label {
                        text: headerCloseButton.text
                        color: Theme.text2
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        font.pixelSize: Theme.fontSize(14)
                    }
                    background: Rectangle {
                        radius: Theme.radiusInner
                        color: headerCloseButton.hovered ? Theme.panel2 : "transparent"
                        border.width: 1
                        border.color: Theme.line
                    }
                }
            }
        }

        ScrollView {
            id: settingsScroll
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.preferredHeight: Math.min(settingsBody.implicitHeight + 36, 580)
            clip: true
            leftPadding: 28
            rightPadding: 28
            topPadding: 24
            bottomPadding: 24
            contentWidth: availableWidth
            background: Rectangle { color: "transparent" }
            ScrollBar.vertical: StyledScrollBar {
                policy: ScrollBar.AsNeeded
            }
            ScrollBar.horizontal: StyledScrollBar {
                policy: ScrollBar.AlwaysOff
                visible: false
                interactive: false
            }

            GridLayout {
                id: settingsBody
                width: settingsScroll.availableWidth
                columns: settingsScroll.availableWidth >= 820 ? 2 : 1
                columnSpacing: 18
                rowSpacing: 18

                // ================= INTERFAZ =================
                Rectangle {
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignTop
                    radius: Theme.radiusCard
                    color: Theme.panel2
                    border.width: 1
                    border.color: Theme.lineSoft
                    implicitHeight: interfaceSection.implicitHeight + 36

                    ColumnLayout {
                        id: interfaceSection
                        anchors.fill: parent
                        anchors.margins: 18
                        spacing: 14

                        RowLayout {
                            Layout.fillWidth: true

                            Label {
                                text: "Interfaz"
                                color: Theme.text
                                font.pixelSize: Theme.fontSize(16)
                                font.weight: Font.DemiBold
                            }
                            Item { Layout.fillWidth: true }
                            Rectangle {
                                implicitWidth: 32
                                implicitHeight: 24
                                radius: Theme.radiusPill
                                color: Theme.accentSoft
                                Label {
                                    anchors.centerIn: parent
                                    text: "01"
                                    color: Theme.accent
                                    font.pixelSize: Theme.fontSize(11)
                                    font.weight: Font.Bold
                                }
                            }
                        }

                        // ---- theme ----
                        Label {
                            Layout.fillWidth: true
                            text: "Tema"
                            color: Theme.text
                            font.pixelSize: Theme.fontSize(14)
                            font.weight: Font.DemiBold
                        }
                        Label {
                            Layout.fillWidth: true
                            text: "Elige el aspecto claro u oscuro. «Auto» sigue el tema del sistema operativo."
                            color: Theme.text2
                            font.pixelSize: Theme.fontSize(13)
                            wrapMode: Text.Wrap
                        }
                        ThemeToggle {
                            mode: dialog.currentThemeMode
                            onModeSelected: function(value) { dialog.themeModeEdited(value) }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.topMargin: 2
                            implicitHeight: 1
                            color: Theme.lineSoft
                        }

                        // ---- scale ----
                        Label {
                            Layout.fillWidth: true
                            text: "Escala de contenido"
                            color: Theme.text
                            font.pixelSize: Theme.fontSize(14)
                            font.weight: Font.DemiBold
                        }
                        Label {
                            Layout.fillWidth: true
                            text: "Controla el tamaño general de la app. El cambio se aplica en vivo y queda guardado."
                            color: Theme.text2
                            font.pixelSize: Theme.fontSize(13)
                            wrapMode: Text.Wrap
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 12

                            Slider {
                                id: scaleSlider
                                Layout.fillWidth: true
                                from: 0.60
                                to: 1.40
                                stepSize: 0.01
                                value: dialog.uiScaleValue
                                onMoved: dialog.uiScaleEdited(value)
                                onValueChanged: {
                                    if (pressed) {
                                        dialog.uiScaleEdited(value)
                                    }
                                }

                                background: Rectangle {
                                    x: scaleSlider.leftPadding
                                    y: scaleSlider.topPadding + scaleSlider.availableHeight / 2 - height / 2
                                    width: scaleSlider.availableWidth
                                    height: 6
                                    radius: 3
                                    color: Theme.line

                                    Rectangle {
                                        width: scaleSlider.visualPosition * parent.width
                                        height: parent.height
                                        radius: parent.radius
                                        color: Theme.accent
                                    }
                                }

                                handle: Rectangle {
                                    x: scaleSlider.leftPadding + scaleSlider.visualPosition * (scaleSlider.availableWidth - width)
                                    y: scaleSlider.topPadding + scaleSlider.availableHeight / 2 - height / 2
                                    implicitWidth: 22
                                    implicitHeight: 22
                                    radius: 11
                                    color: Theme.accent
                                    border.width: 2
                                    border.color: Theme.panel
                                }
                            }

                            Rectangle {
                                implicitWidth: 60
                                implicitHeight: 28
                                radius: Theme.radiusInner
                                color: Theme.panel
                                border.width: 1
                                border.color: Theme.line
                                Label {
                                    anchors.centerIn: parent
                                    text: Math.round(dialog.uiScaleValue * 100) + "%"
                                    color: Theme.text
                                    font.pixelSize: Theme.fontSize(13)
                                    font.weight: Font.DemiBold
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 12

                            Label {
                                Layout.fillWidth: true
                                text: "Escala actual: " + Math.round(dialog.uiScaleValue * 100) + "%."
                                color: Theme.text2
                                font.pixelSize: Theme.fontSize(13)
                                wrapMode: Text.Wrap
                            }

                            Button {
                                id: resetScaleButton
                                text: "Restablecer"
                                hoverEnabled: true
                                onClicked: dialog.resetUiScale()

                                contentItem: Label {
                                    text: resetScaleButton.text
                                    color: Theme.text2
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                    font.pixelSize: Theme.fontSize(13)
                                    font.weight: Font.DemiBold
                                }
                                background: Rectangle {
                                    radius: Theme.radiusInner
                                    color: resetScaleButton.hovered ? Theme.panel : "transparent"
                                    border.width: 1
                                    border.color: Theme.line
                                }
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.topMargin: 2
                            implicitHeight: 1
                            color: Theme.lineSoft
                        }

                        // ---- independent text scale ----
                        Label {
                            Layout.fillWidth: true
                            text: "Tamaño del texto"
                            color: Theme.text
                            font.pixelSize: Theme.fontSize(14)
                            font.weight: Font.DemiBold
                        }
                        Label {
                            Layout.fillWidth: true
                            text: "Ajusta solo las fuentes. Los paneles conservan su tamaño y adaptan el texto con espacios, saltos de línea y desplazamiento cuando corresponde."
                            color: Theme.text2
                            font.pixelSize: Theme.fontSize(13)
                            wrapMode: Text.Wrap
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 12

                            Slider {
                                id: fontScaleSlider
                                Layout.fillWidth: true
                                from: 0.85
                                to: 1.25
                                stepSize: 0.05
                                value: dialog.fontScaleValue
                                onMoved: dialog.fontScaleEdited(value)
                                onValueChanged: {
                                    if (pressed) {
                                        dialog.fontScaleEdited(value)
                                    }
                                }

                                background: Rectangle {
                                    x: fontScaleSlider.leftPadding
                                    y: fontScaleSlider.topPadding + fontScaleSlider.availableHeight / 2 - height / 2
                                    width: fontScaleSlider.availableWidth
                                    height: 6
                                    radius: 3
                                    color: Theme.line

                                    Rectangle {
                                        width: fontScaleSlider.visualPosition * parent.width
                                        height: parent.height
                                        radius: parent.radius
                                        color: Theme.accent
                                    }
                                }

                                handle: Rectangle {
                                    x: fontScaleSlider.leftPadding + fontScaleSlider.visualPosition * (fontScaleSlider.availableWidth - width)
                                    y: fontScaleSlider.topPadding + fontScaleSlider.availableHeight / 2 - height / 2
                                    implicitWidth: 22
                                    implicitHeight: 22
                                    radius: 11
                                    color: Theme.accent
                                    border.width: 2
                                    border.color: Theme.panel
                                }
                            }

                            Rectangle {
                                implicitWidth: 60
                                implicitHeight: 28
                                radius: Theme.radiusInner
                                color: Theme.panel
                                border.width: 1
                                border.color: Theme.line
                                Label {
                                    anchors.centerIn: parent
                                    text: Math.round(dialog.fontScaleValue * 100) + "%"
                                    color: Theme.text
                                    font.pixelSize: Theme.fontSize(13)
                                    font.weight: Font.DemiBold
                                }
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 12

                            Label {
                                Layout.fillWidth: true
                                text: "Texto actual: " + Math.round(dialog.fontScaleValue * 100) + "%."
                                color: Theme.text2
                                font.pixelSize: Theme.fontSize(13)
                                wrapMode: Text.Wrap
                            }

                            Button {
                                id: resetFontScaleButton
                                text: "Restablecer"
                                hoverEnabled: true
                                onClicked: dialog.resetFontScale()

                                contentItem: Label {
                                    text: resetFontScaleButton.text
                                    color: Theme.text2
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                    font.pixelSize: Theme.fontSize(13)
                                    font.weight: Font.DemiBold
                                }
                                background: Rectangle {
                                    radius: Theme.radiusInner
                                    color: resetFontScaleButton.hovered ? Theme.panel : "transparent"
                                    border.width: 1
                                    border.color: Theme.line
                                }
                            }
                        }
                    }
                }

                // ================= CREDENCIALES PJUD =================
                Rectangle {
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignTop
                    radius: Theme.radiusCard
                    color: Theme.panel2
                    border.width: 1
                    border.color: Theme.lineSoft
                    implicitHeight: credentialsSection.implicitHeight + 32

                    ColumnLayout {
                        id: credentialsSection
                        anchors.fill: parent
                        anchors.margins: 18
                        spacing: 12

                        RowLayout {
                            Layout.fillWidth: true

                            Label {
                                text: "Credenciales PJUD"
                                color: Theme.text
                                font.pixelSize: Theme.fontSize(16)
                                font.weight: Font.DemiBold
                            }
                            Item { Layout.fillWidth: true }
                            Rectangle {
                                implicitWidth: 32
                                implicitHeight: 24
                                radius: Theme.radiusPill
                                color: Theme.accentSoft
                                Label {
                                    anchors.centerIn: parent
                                    text: "02"
                                    color: Theme.accent
                                    font.pixelSize: Theme.fontSize(11)
                                    font.weight: Font.Bold
                                }
                            }
                        }

                        Label {
                            Layout.fillWidth: true
                            text: "Estas credenciales se guardan en un solo lugar y se reutilizan en todos los bots que ingresan al portal PJUD."
                            color: Theme.text2
                            font.pixelSize: Theme.fontSize(13)
                            wrapMode: Text.Wrap
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            radius: Theme.radiusInner
                            color: Theme.panel
                            border.width: 1
                            border.color: Theme.lineSoft
                            implicitHeight: currentCredentialsPanel.implicitHeight + 24

                            ColumnLayout {
                                id: currentCredentialsPanel
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 6

                                Label {
                                    Layout.fillWidth: true
                                    text: "Usuario login actual: " + (dialog.currentPjudLoginUsername.length > 0 ? dialog.currentPjudLoginUsername : "-")
                                    color: Theme.text
                                    font.pixelSize: Theme.fontSize(13)
                                    wrapMode: Text.Wrap
                                }
                                Label {
                                    Layout.fillWidth: true
                                    text: "Contraseña actual: " + (dialog.currentPjudPassword.length > 0 ? dialog.currentPjudPassword : "-")
                                    color: Theme.text
                                    font.pixelSize: Theme.fontSize(13)
                                    wrapMode: Text.Wrap
                                }
                                Label {
                                    Layout.fillWidth: true
                                    text: "Perfil PJUD actual: " + (dialog.currentPjudProfileLabel.length > 0 ? dialog.currentPjudProfileLabel : "-")
                                    color: Theme.text
                                    font.pixelSize: Theme.fontSize(13)
                                    wrapMode: Text.Wrap
                                }
                            }
                        }

                        Label { text: "Usuario login"; color: Theme.text; font.pixelSize: Theme.fontSize(13); font.weight: Font.DemiBold }
                        TextField {
                            id: loginUsernameField
                            Layout.fillWidth: true
                            color: Theme.text
                            font.pixelSize: Theme.fontSize(14)
                            placeholderText: "Ingresa el usuario login PJUD"
                            placeholderTextColor: Theme.text3
                            selectByMouse: true
                            onTextChanged: dialog.resetCredentialFeedback()
                            background: Rectangle {
                                radius: Theme.radiusInner
                                color: Theme.panel
                                border.width: loginUsernameField.activeFocus ? 2 : 1
                                border.color: loginUsernameField.activeFocus ? Theme.accent : Theme.line
                            }
                        }

                        Label { text: "Contraseña"; color: Theme.text; font.pixelSize: Theme.fontSize(13); font.weight: Font.DemiBold }
                        TextField {
                            id: passwordField
                            Layout.fillWidth: true
                            color: Theme.text
                            font.pixelSize: Theme.fontSize(14)
                            placeholderText: "Ingresa la contraseña PJUD"
                            placeholderTextColor: Theme.text3
                            selectByMouse: true
                            onTextChanged: dialog.resetCredentialFeedback()
                            background: Rectangle {
                                radius: Theme.radiusInner
                                color: Theme.panel
                                border.width: passwordField.activeFocus ? 2 : 1
                                border.color: passwordField.activeFocus ? Theme.accent : Theme.line
                            }
                        }

                        Label { text: "Perfil PJUD"; color: Theme.text; font.pixelSize: Theme.fontSize(13); font.weight: Font.DemiBold }
                        TextField {
                            id: profileLabelField
                            Layout.fillWidth: true
                            color: Theme.text
                            font.pixelSize: Theme.fontSize(14)
                            placeholderText: "Ingresa el perfil PJUD visible"
                            placeholderTextColor: Theme.text3
                            selectByMouse: true
                            onTextChanged: dialog.resetCredentialFeedback()
                            background: Rectangle {
                                radius: Theme.radiusInner
                                color: Theme.panel
                                border.width: profileLabelField.activeFocus ? 2 : 1
                                border.color: profileLabelField.activeFocus ? Theme.accent : Theme.line
                            }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 12

                            Button {
                                id: confirmCredentialsButton
                                text: "Confirmar credenciales"
                                hoverEnabled: true
                                onClicked: {
                                    dialog.resetCredentialFeedback()
                                    if (!dialog.controllerObject) {
                                        dialog.credentialsFeedbackColor = Theme.danger
                                        dialog.credentialsFeedbackText = "No se pudo acceder al controlador de configuración."
                                        return
                                    }

                                    var result = dialog.controllerObject.updatePjudCredentials(
                                        loginUsernameField.text,
                                        passwordField.text,
                                        profileLabelField.text
                                    )
                                    if (result && result.length > 0) {
                                        dialog.credentialsFeedbackColor = Theme.danger
                                        dialog.credentialsFeedbackText = result
                                        return
                                    }

                                    dialog.syncCredentialInputsFromCurrent()
                                    dialog.credentialsFeedbackColor = Theme.success
                                    dialog.credentialsFeedbackText = "Las credenciales han sido actualizadas"
                                }

                                contentItem: Label {
                                    text: confirmCredentialsButton.text
                                    color: Theme.onAccent
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                    font.pixelSize: Theme.fontSize(13)
                                    font.weight: Font.DemiBold
                                }
                                background: Rectangle {
                                    radius: Theme.radiusInner
                                    color: Theme.accent
                                    opacity: confirmCredentialsButton.hovered ? 0.92 : 1.0
                                }
                            }

                            Item { Layout.fillWidth: true }

                            Label {
                                Layout.fillWidth: true
                                visible: dialog.credentialsFeedbackText.length > 0
                                text: dialog.credentialsFeedbackText
                                color: dialog.credentialsFeedbackColor
                                font.pixelSize: Theme.fontSize(13)
                                wrapMode: Text.Wrap
                                horizontalAlignment: Text.AlignRight
                            }
                        }
                    }
                }
            }
        }

        // ---- footer ----
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 72
            color: "transparent"

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                height: 1
                color: Theme.lineSoft
            }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 28
                anchors.rightMargin: 28
                spacing: 12

                Item { Layout.fillWidth: true }

                Button {
                    id: footerCloseButton
                    text: "Cerrar"
                    hoverEnabled: true
                    onClicked: dialog.close()

                    contentItem: Label {
                        text: footerCloseButton.text
                        color: Theme.onAccent
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        font.pixelSize: Theme.fontSize(13)
                        font.weight: Font.DemiBold
                    }
                    background: Rectangle {
                        radius: Theme.radiusInner
                        color: Theme.accent
                        opacity: footerCloseButton.hovered ? 0.92 : 1.0
                    }
                }
            }
        }
    }
}
