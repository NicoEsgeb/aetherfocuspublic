import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cDanger: Common.Theme.danger
    readonly property color cWarning: Common.Theme.warning
    readonly property int ingresoStatusColumnWidth: 250
    readonly property int caratulaStatusColumnWidth: 260
    readonly property var ingresoRowsModel: {
        if (!summaryData || summaryData.ingresoRows === undefined || summaryData.ingresoRows === null) {
            return []
        }
        return summaryData.ingresoRows
    }
    readonly property var getCaratulasRowsModel: {
        if (!summaryData || summaryData.getCaratulasRows === undefined || summaryData.getCaratulasRows === null) {
            return []
        }
        return summaryData.getCaratulasRows
    }

    function hasData() {
        return !!summaryData && summaryData.hasData === true
    }

    function metricValue(key) {
        if (!hasData()) {
            return "-"
        }
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null) {
            return "0"
        }
        return String(summaryData[key])
    }

    function summaryKind() {
        if (!summaryData || summaryData.summaryKind === undefined || summaryData.summaryKind === null) {
            return "unknown"
        }
        return String(summaryData.summaryKind)
    }

    function isIngresoSummary() {
        return summaryKind() === "ingreso"
    }

    function isGetCaratulasSummary() {
        return summaryKind() === "get_caratulas"
    }

    function isDescargarInformeSummary() {
        return summaryKind() === "descargar_informe"
    }

    function taskNameLabel() {
        if (!summaryData || summaryData.taskName === undefined || summaryData.taskName === null) {
            return "task desconocida"
        }
        var taskName = String(summaryData.taskName).trim()
        return taskName.length > 0 ? taskName : "task desconocida"
    }

    function ingresoRowsError() {
        if (!summaryData || summaryData.ingresoRowsError === undefined || summaryData.ingresoRowsError === null) {
            return ""
        }
        return String(summaryData.ingresoRowsError).trim()
    }

    function hasIngresoRows() {
        return root.isIngresoSummary() && root.ingresoRowsModel.length > 0
    }

    function getCaratulasRowsError() {
        if (!summaryData || summaryData.getCaratulasRowsError === undefined || summaryData.getCaratulasRowsError === null) {
            return ""
        }
        return String(summaryData.getCaratulasRowsError).trim()
    }

    function hasGetCaratulasRows() {
        return root.isGetCaratulasSummary() && root.getCaratulasRowsModel.length > 0
    }

    function descargarInformeDownloaded() {
        return !!summaryData && summaryData.descargarInformeDownloaded === true
    }

    function descargarInformeFilePath() {
        if (!summaryData || summaryData.descargarInformeFilePath === undefined || summaryData.descargarInformeFilePath === null) {
            return ""
        }
        return String(summaryData.descargarInformeFilePath).trim()
    }

    function descargarInformeFileName() {
        if (!!summaryData && summaryData.descargarInformeFileName !== undefined && summaryData.descargarInformeFileName !== null) {
            var explicitName = String(summaryData.descargarInformeFileName).trim()
            if (explicitName.length > 0) {
                return explicitName
            }
        }
        var filePath = root.descargarInformeFilePath()
        if (filePath.length === 0) {
            return "-"
        }
        var normalized = filePath.replace(/\\/g, "/")
        var slashIndex = normalized.lastIndexOf("/")
        return slashIndex >= 0 ? normalized.substring(slashIndex + 1) : normalized
    }

    function descargarInformeOutputDir() {
        if (!!summaryData && summaryData.descargarInformeOutputDir !== undefined && summaryData.descargarInformeOutputDir !== null) {
            var explicitDir = String(summaryData.descargarInformeOutputDir).trim()
            if (explicitDir.length > 0) {
                return explicitDir
            }
        }
        var filePath = root.descargarInformeFilePath()
        if (filePath.length === 0) {
            return ""
        }
        var normalized = filePath.replace(/\\/g, "/")
        var slashIndex = normalized.lastIndexOf("/")
        if (slashIndex < 0) {
            return ""
        }
        return filePath.substring(0, slashIndex)
    }

    function descargarInformeStatusText() {
        return root.descargarInformeDownloaded()
            ? "Informe descargado"
            : "Informe no descargado"
    }

    function descargarInformeStatusIcon() {
        return root.descargarInformeDownloaded() ? "✓" : "✕"
    }

    function descargarInformeStatusColor() {
        return root.descargarInformeDownloaded() ? root.cSuccess : root.cDanger
    }

    function descargarInformeCanOpenFolder() {
        return root.descargarInformeDownloaded() && root.descargarInformeOutputDir().length > 0
    }

    function isIngresoOk(rowData) {
        return !!rowData && rowData.ok === true
    }

    function ingresoStatusLabel(rowData) {
        if (root.isIngresoOk(rowData)) {
            return "Ok"
        }
        return root.ingresoErrorLabel(rowData)
    }

    function ingresoStatusColor(rowData) {
        return root.isIngresoOk(rowData) ? root.cSuccess : root.cDanger
    }

    function ingresoErrorLabel(rowData) {
        if (!rowData || rowData.ingreso === undefined || rowData.ingreso === null) {
            return "Error Desconocido"
        }

        var rawError = String(rowData.ingreso).trim()
        if (rawError.length === 0) {
            return "Error Desconocido"
        }

        var normalized = rawError.toUpperCase()
        normalized = normalized
            .replace(/Á/g, "A")
            .replace(/É/g, "E")
            .replace(/Í/g, "I")
            .replace(/Ó/g, "O")
            .replace(/Ú/g, "U")

        if (normalized.indexOf("NOMBRES NO COINCIDEN EN EL PJUD") >= 0) {
            return "Nombres no coinciden en PJUD"
        }
        if (normalized.indexOf("ERROR ADJUNTANDO DEMANDA") >= 0) {
            return "Error Adjuntando Demanda"
        }
        if (normalized.indexOf("ERROR ADJUNTANDO ") >= 0) {
            return "Error Adjuntando Archivo"
        }
        if (normalized.indexOf("ERROR EN LA ACCION ELIMINAR") >= 0) {
            return "Error en la accion ELIMINAR"
        }
        if (normalized.indexOf("ERROR EN LA ACCION ENVIAR") >= 0) {
            return "Error en la accion ENVIAR"
        }
        if (normalized.indexOf("NO EXISTE EL ARCHIVO A ADJUNTAR") >= 0) {
            return "No existe archivo a adjuntar"
        }
        if (
            normalized.indexOf("TIMEOUT") >= 0
            || normalized.indexOf("TIEMPO DE ESPERA") >= 0
            || normalized.indexOf("EXCEEDED WHILE WAITING") >= 0
        ) {
            return "Tiempo de espera superado"
        }
        return "Error Desconocido"
    }

    function demandaLabel(rowData) {
        if (!rowData || rowData.demanda === undefined || rowData.demanda === null) {
            return "-"
        }
        var value = String(rowData.demanda).trim()
        return value.length > 0 ? value : "-"
    }

    function isCaratulaOk(rowData) {
        return !!rowData && rowData.ok === true
    }

    function caratulaStatusLabel(rowData) {
        return root.isCaratulaOk(rowData) ? "Ok" : "Pendiente"
    }

    function caratulaStatusColor(rowData) {
        return root.isCaratulaOk(rowData) ? root.cSuccess : root.cWarning
    }

    function ritLabel(rowData) {
        if (!rowData || rowData.rit === undefined || rowData.rit === null) {
            return "-"
        }
        var value = String(rowData.rit).trim()
        return value.length > 0 ? value : "-"
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 10

        ScrollView {
            id: ingresoSummaryScroll
            visible: root.isIngresoSummary()
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            contentWidth: availableWidth
            background: Rectangle { color: "transparent" }
            ScrollBar.vertical: Common.StyledScrollBar {
                policy: ScrollBar.AsNeeded
            }
            ScrollBar.horizontal: Common.StyledScrollBar {
                policy: ScrollBar.AlwaysOff
                visible: false
                interactive: false
            }

            ColumnLayout {
                width: ingresoSummaryScroll.availableWidth
                spacing: 10

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 108
                        radius: 12
                        color: root.cPanel
                        border.width: 1
                        border.color: root.cLine

                        Column {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            Label {
                                text: "Deudores Procesados"
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(12)
                            }

                            Label {
                                text: root.metricValue("deudoresProcesados")
                                color: root.cTextMain
                                font.pixelSize: Common.Theme.fontSize(34)
                                font.bold: true
                            }
                        }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 108
                        radius: 12
                        color: root.cPanel
                        border.width: 1
                        border.color: Common.Theme.success

                        Column {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            Row {
                                spacing: 6

                                Label {
                                    text: "✓"
                                    color: root.cSuccess
                                    font.pixelSize: Common.Theme.fontSize(14)
                                    font.bold: true
                                }

                                Label {
                                    text: "Ingresos Completados"
                                    color: root.cTextMuted
                                    font.pixelSize: Common.Theme.fontSize(12)
                                }
                            }

                            Label {
                                text: root.metricValue("ingresosCompletados")
                                color: root.cSuccess
                                font.pixelSize: Common.Theme.fontSize(34)
                                font.bold: true
                            }
                        }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 108
                        radius: 12
                        color: root.cPanel
                        border.width: 1
                        border.color: Common.Theme.dangerSoft

                        Column {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            Row {
                                spacing: 6

                                Label {
                                    text: "✕"
                                    color: root.cDanger
                                    font.pixelSize: Common.Theme.fontSize(14)
                                    font.bold: true
                                }

                                Label {
                                    text: "Ingresos Fallidos"
                                    color: root.cTextMuted
                                    font.pixelSize: Common.Theme.fontSize(12)
                                }
                            }

                            Label {
                                text: root.metricValue("ingresosFallidos")
                                color: root.cDanger
                                font.pixelSize: Common.Theme.fontSize(34)
                                font.bold: true
                            }
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: Math.max(260, Math.min(460, 72 + (root.ingresoRowsModel.length * 38)))
                    radius: 12
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 8

                        Label {
                            text: "Detalle de Ingresos por Demanda"
                            color: root.cTextMain
                            font.pixelSize: Common.Theme.fontSize(13)
                            font.bold: true
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 34
                            radius: 8
                            color: Common.Theme.panel2
                            border.width: 1
                            border.color: root.cLine

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 8
                                spacing: 10

                                Label {
                                    Layout.preferredWidth: root.ingresoStatusColumnWidth
                                    text: "Ingreso"
                                    color: root.cTextMain
                                    font.bold: true
                                    font.pixelSize: Common.Theme.fontSize(12)
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: "Demanda"
                                    color: root.cTextMain
                                    font.bold: true
                                    font.pixelSize: Common.Theme.fontSize(12)
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        Item {
                            Layout.fillWidth: true
                            Layout.fillHeight: true

                            ListView {
                                id: ingresoRowsView
                                anchors.fill: parent
                                model: root.ingresoRowsModel
                                clip: true
                                spacing: 4
                                visible: root.hasIngresoRows()

                                ScrollBar.vertical: Common.StyledScrollBar {
                                    policy: ScrollBar.AsNeeded
                                }

                                delegate: Rectangle {
                                    width: ListView.view.width
                                    height: 34
                                    radius: 8
                                    color: index % 2 === 0 ? Common.Theme.panel2 : Common.Theme.panel2
                                    border.width: 1
                                    border.color: Common.Theme.line

                                    RowLayout {
                                        anchors.fill: parent
                                        anchors.margins: 8
                                        spacing: 10

                                        RowLayout {
                                            Layout.preferredWidth: root.ingresoStatusColumnWidth
                                            spacing: 6

                                            Label {
                                                text: root.isIngresoOk(modelData) ? "✓" : "•"
                                                color: root.ingresoStatusColor(modelData)
                                                font.pixelSize: Common.Theme.fontSize(13)
                                                font.bold: true
                                            }

                                            Label {
                                                text: root.ingresoStatusLabel(modelData)
                                                color: root.ingresoStatusColor(modelData)
                                                font.pixelSize: Common.Theme.fontSize(12)
                                                font.bold: true
                                                elide: Text.ElideRight
                                            }
                                        }

                                        Label {
                                            Layout.fillWidth: true
                                            text: root.demandaLabel(modelData)
                                            color: root.cTextMain
                                            font.pixelSize: Common.Theme.fontSize(12)
                                            elide: Text.ElideRight
                                        }
                                    }
                                }
                            }

                            Label {
                                anchors.centerIn: parent
                                visible: !ingresoRowsView.visible
                                text: {
                                    var errorText = root.ingresoRowsError()
                                    return errorText.length > 0
                                        ? errorText
                                        : "Sin filas disponibles para esta corrida."
                                }
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(13)
                                horizontalAlignment: Text.AlignHCenter
                                wrapMode: Text.Wrap
                                width: parent.width - 24
                            }
                        }
                    }
                }
            }
        }

        ScrollView {
            id: getCaratulasSummaryScroll
            visible: root.isGetCaratulasSummary()
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            contentWidth: availableWidth
            background: Rectangle { color: "transparent" }
            ScrollBar.vertical: Common.StyledScrollBar {
                policy: ScrollBar.AsNeeded
            }
            ScrollBar.horizontal: Common.StyledScrollBar {
                policy: ScrollBar.AlwaysOff
                visible: false
                interactive: false
            }

            ColumnLayout {
                width: getCaratulasSummaryScroll.availableWidth
                spacing: 10

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 108
                        radius: 12
                        color: root.cPanel
                        border.width: 1
                        border.color: root.cLine

                        Column {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            Label {
                                text: "Carátulas Buscadas"
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(12)
                            }

                            Label {
                                text: root.metricValue("caratulasBuscadas")
                                color: root.cTextMain
                                font.pixelSize: Common.Theme.fontSize(34)
                                font.bold: true
                            }
                        }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 108
                        radius: 12
                        color: root.cPanel
                        border.width: 1
                        border.color: Common.Theme.success

                        Column {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            Row {
                                spacing: 6

                                Label {
                                    text: "✓"
                                    color: root.cSuccess
                                    font.pixelSize: Common.Theme.fontSize(14)
                                    font.bold: true
                                }

                                Label {
                                    text: "Carátulas Descargadas"
                                    color: root.cTextMuted
                                    font.pixelSize: Common.Theme.fontSize(12)
                                }
                            }

                            Label {
                                text: root.metricValue("caratulasDescargadas")
                                color: root.cSuccess
                                font.pixelSize: Common.Theme.fontSize(34)
                                font.bold: true
                            }
                        }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 1
                        Layout.preferredHeight: 108
                        radius: 12
                        color: root.cPanel
                        border.width: 1
                        border.color: Common.Theme.dangerSoft

                        Column {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            Row {
                                spacing: 6

                                Label {
                                    text: "✕"
                                    color: root.cDanger
                                    font.pixelSize: Common.Theme.fontSize(14)
                                    font.bold: true
                                }

                                Label {
                                    text: "Carátulas No Encontradas"
                                    color: root.cTextMuted
                                    font.pixelSize: Common.Theme.fontSize(12)
                                }
                            }

                            Label {
                                text: root.metricValue("caratulasNoEncontradas")
                                color: root.cDanger
                                font.pixelSize: Common.Theme.fontSize(34)
                                font.bold: true
                            }
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: Math.max(260, Math.min(560, 72 + (root.getCaratulasRowsModel.length * 38)))
                    radius: 12
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 8

                        Label {
                            text: "Detalle de Descarga de Carátulas"
                            color: root.cTextMain
                            font.pixelSize: Common.Theme.fontSize(13)
                            font.bold: true
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 34
                            radius: 8
                            color: Common.Theme.panel2
                            border.width: 1
                            border.color: root.cLine

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 8
                                spacing: 10

                                Label {
                                    Layout.preferredWidth: root.caratulaStatusColumnWidth
                                    Layout.minimumWidth: root.caratulaStatusColumnWidth
                                    Layout.maximumWidth: root.caratulaStatusColumnWidth
                                    text: "Descarga de Carátula"
                                    color: root.cTextMain
                                    font.bold: true
                                    font.pixelSize: Common.Theme.fontSize(12)
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: "RIT"
                                    color: root.cTextMain
                                    font.bold: true
                                    font.pixelSize: Common.Theme.fontSize(12)
                                    horizontalAlignment: Text.AlignLeft
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        Item {
                            Layout.fillWidth: true
                            Layout.fillHeight: true

                            ListView {
                                id: caratulasRowsView
                                anchors.fill: parent
                                model: root.getCaratulasRowsModel
                                clip: true
                                spacing: 4
                                visible: root.hasGetCaratulasRows()

                                ScrollBar.vertical: Common.StyledScrollBar {
                                    policy: ScrollBar.AsNeeded
                                }

                                delegate: Rectangle {
                                    width: ListView.view.width
                                    height: 34
                                    radius: 8
                                    color: index % 2 === 0 ? Common.Theme.panel2 : Common.Theme.panel2
                                    border.width: 1
                                    border.color: Common.Theme.line

                                    RowLayout {
                                        anchors.fill: parent
                                        anchors.margins: 8
                                        spacing: 10

                                        RowLayout {
                                            Layout.preferredWidth: root.caratulaStatusColumnWidth
                                            Layout.minimumWidth: root.caratulaStatusColumnWidth
                                            Layout.maximumWidth: root.caratulaStatusColumnWidth
                                            spacing: 6

                                            Label {
                                                Layout.preferredWidth: 20
                                                Layout.minimumWidth: 20
                                                text: root.isCaratulaOk(modelData) ? "✓" : "•"
                                                color: root.caratulaStatusColor(modelData)
                                                font.pixelSize: Common.Theme.fontSize(13)
                                                font.bold: true
                                                horizontalAlignment: Text.AlignHCenter
                                                verticalAlignment: Text.AlignVCenter
                                            }

                                            Label {
                                                Layout.fillWidth: true
                                                text: root.caratulaStatusLabel(modelData)
                                                color: root.caratulaStatusColor(modelData)
                                                font.pixelSize: Common.Theme.fontSize(12)
                                                font.bold: true
                                                horizontalAlignment: Text.AlignLeft
                                                elide: Text.ElideRight
                                            }
                                        }

                                        Label {
                                            Layout.fillWidth: true
                                            text: root.ritLabel(modelData)
                                            color: root.cTextMain
                                            font.pixelSize: Common.Theme.fontSize(12)
                                            horizontalAlignment: Text.AlignLeft
                                            elide: Text.ElideRight
                                        }
                                    }
                                }
                            }

                            Label {
                                anchors.centerIn: parent
                                visible: !caratulasRowsView.visible
                                text: {
                                    var errorText = root.getCaratulasRowsError()
                                    return errorText.length > 0
                                        ? errorText
                                        : "Sin filas disponibles para esta corrida."
                                }
                                color: root.cTextMuted
                                font.pixelSize: Common.Theme.fontSize(13)
                                horizontalAlignment: Text.AlignHCenter
                                wrapMode: Text.Wrap
                                width: parent.width - 24
                            }
                        }
                    }
                }
            }
        }

        ScrollView {
            id: descargarInformeSummaryScroll
            visible: root.isDescargarInformeSummary()
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            contentWidth: availableWidth
            background: Rectangle { color: "transparent" }
            ScrollBar.vertical: Common.StyledScrollBar {
                policy: ScrollBar.AsNeeded
            }
            ScrollBar.horizontal: Common.StyledScrollBar {
                policy: ScrollBar.AlwaysOff
                visible: false
                interactive: false
            }

            ColumnLayout {
                width: descargarInformeSummaryScroll.availableWidth
                spacing: 10

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: root.descargarInformeDownloaded() ? 178 : 138
                    radius: 12
                    color: root.cPanel
                    border.width: 1
                    border.color: root.descargarInformeDownloaded() ? Common.Theme.success : Common.Theme.dangerSoft

                    Item {
                        anchors.fill: parent
                        anchors.margins: 14

                        Column {
                            anchors.centerIn: parent
                            width: Math.min(parent.width, 760)
                            spacing: 12

                            Row {
                                anchors.horizontalCenter: parent.horizontalCenter
                                spacing: 8

                                Label {
                                    text: root.descargarInformeStatusIcon()
                                    color: root.descargarInformeStatusColor()
                                    font.pixelSize: Common.Theme.fontSize(18)
                                    font.bold: true
                                }

                                Label {
                                    text: root.descargarInformeStatusText()
                                    color: root.descargarInformeStatusColor()
                                    font.pixelSize: Common.Theme.fontSize(15)
                                    font.bold: true
                                    horizontalAlignment: Text.AlignHCenter
                                }
                            }

                            Label {
                                visible: root.descargarInformeDownloaded()
                                width: parent.width
                                text: root.descargarInformeFileName()
                                color: "#ffffff"
                                font.pixelSize: Common.Theme.fontSize(16)
                                font.bold: true
                                horizontalAlignment: Text.AlignHCenter
                                wrapMode: Text.Wrap
                            }

                            Common.InsetAlloyButton {
                                id: abrirCarpetaButton
                                visible: root.descargarInformeCanOpenFolder()
                                text: "Abrir Carpeta"
                                anchors.horizontalCenter: parent.horizontalCenter
                                hoverEnabled: true
                                onClicked: {
                                    var outputDir = root.descargarInformeOutputDir()
                                    if (outputDir.length <= 0) {
                                        return
                                    }
                                    if (typeof controller !== "undefined" && controller !== null) {
                                        controller.openPathInExplorer(outputDir)
                                    }
                                }
                                background: Rectangle {
                                    radius: 8
                                    border.width: 1
                                    border.color: abrirCarpetaButton.down ? Common.Theme.accent : Common.Theme.accent
                                    gradient: Gradient {
                                        GradientStop { position: 0.0; color: abrirCarpetaButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                                        GradientStop { position: 1.0; color: abrirCarpetaButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                                    }
                                }
                                contentItem: Text {
                                    text: abrirCarpetaButton.text
                                    color: Common.Theme.text
                                    font.pixelSize: Common.Theme.fontSize(12)
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                }
                            }
                        }
                    }
                }
            }
        }

        Rectangle {
            visible: !root.isIngresoSummary() && !root.isGetCaratulasSummary() && !root.isDescargarInformeSummary()
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine

            Label {
                anchors.centerIn: parent
                text: "Resumen Logica " + root.taskNameLabel() + " en Construction"
                color: root.cTextMain
                font.pixelSize: Common.Theme.fontSize(20)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.Wrap
            }
        }
    }
}
