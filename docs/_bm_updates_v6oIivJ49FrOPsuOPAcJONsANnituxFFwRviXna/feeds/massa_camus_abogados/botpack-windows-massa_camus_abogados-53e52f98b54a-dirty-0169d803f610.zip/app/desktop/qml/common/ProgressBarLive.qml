import QtQuick
import QtQuick.Controls

// Determinate progress: label + "N / M" above a 9px track. Accent fill animates
// width on value change; a shimmer sweeps while running.
Item {
    id: bar

    property string label: ""
    property int value: 0
    property int total: 0
    property bool running: true

    readonly property real ratio: total > 0 ? Math.max(0, Math.min(1, value / total)) : 0

    implicitHeight: topRow.implicitHeight + 7 + 9

    Item {
        id: topRow
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        implicitHeight: Math.max(labelText.implicitHeight, countText.implicitHeight)

        Label {
            id: labelText
            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter
            text: bar.label
            color: Theme.text2
            font.pixelSize: Theme.fontSize(13)
            font.weight: Font.DemiBold
            elide: Text.ElideRight
            width: Math.max(0, parent.width - countText.width - 10)
        }

        Label {
            id: countText
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            text: bar.total > 0 ? (bar.value + " / " + bar.total) : ""
            color: Theme.text
            font.pixelSize: Theme.fontSize(13)
            font.weight: Font.Bold
        }
    }

    Rectangle {
        id: track
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 9
        radius: Theme.radiusPill
        color: Theme.panel2
        clip: true

        Rectangle {
            id: fill
            height: parent.height
            width: parent.width * bar.ratio
            radius: Theme.radiusPill
            color: Theme.accent
            Behavior on width { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }

            Rectangle {
                id: shimmer
                height: parent.height
                width: 60
                visible: bar.running && fill.width > 4
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0.0; color: "#00ffffff" }
                    GradientStop { position: 0.5; color: "#59ffffff" }
                    GradientStop { position: 1.0; color: "#00ffffff" }
                }
                NumberAnimation on x {
                    running: bar.running && bar.visible
                    from: -60; to: fill.width
                    duration: 1600
                    loops: Animation.Infinite
                }
            }
        }
    }
}
