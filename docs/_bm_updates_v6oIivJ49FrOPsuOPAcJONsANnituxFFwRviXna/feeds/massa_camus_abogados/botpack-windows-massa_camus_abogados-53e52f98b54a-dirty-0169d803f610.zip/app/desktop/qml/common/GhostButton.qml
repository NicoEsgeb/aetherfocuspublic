import QtQuick
import QtQuick.Controls

// Secondary action using the same inset-alloy motion with a muted label.
InsetAlloyButton {
    id: control

    hoverEnabled: true
    opacity: enabled ? 1.0 : 0.45
    implicitHeight: 40

    contentItem: Label {
        text: control.text
        color: Theme.text2
        font.pixelSize: Theme.fontSize(14)
        font.weight: Font.DemiBold
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        leftPadding: 18
        rightPadding: 18
    }
}
