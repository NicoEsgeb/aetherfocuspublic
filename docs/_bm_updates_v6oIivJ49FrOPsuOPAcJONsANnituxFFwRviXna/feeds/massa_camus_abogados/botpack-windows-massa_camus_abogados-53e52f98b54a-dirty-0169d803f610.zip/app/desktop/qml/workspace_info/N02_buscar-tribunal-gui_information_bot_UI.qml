import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2

    // ── Header ───────────────────────────────────────────────────────────────
    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
            text: "N02 · Buscar Tribunal (GUI)"
            color: Common.Theme.text
            font.pixelSize: Common.Theme.fontSize(16)
            font.bold: true
            Layout.fillWidth: true
            wrapMode: Text.Wrap
        }

        Rectangle {
            radius: 6
            color: Common.Theme.successSoft
            border.width: 1
            border.color: Common.Theme.success
            implicitWidth: badge.implicitWidth + 16
            implicitHeight: badge.implicitHeight + 8
            Label {
                id: badge
                anchors.centerIn: parent
                text: "Sin conexión al navegador"
                color: Common.Theme.success
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }
    }

    // ── What it is ─────────────────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Qué hace"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "Igual que N01 (busca el tribunal de cada Rol de la planilla Estado Diario), pero SIN abrir ni conectarse al navegador. Tú abres tu Edge normal y entras a PJUD a mano; el bot maneja esa ventana a través de la capa de accesibilidad de Windows (UIA), como lo haría un lector de pantalla. Como no hay nada 'conectado', el portal no lo detecta."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // ── How to use ─────────────────────────────────────────────────────────────
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: stepsLayout.implicitHeight + 20

        ColumnLayout {
            id: stepsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Cómo usarlo"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "1. Abre tu Edge NORMAL, entra a oficinajudicialvirtual.pjud.cl e inicia sesión a mano.\n" +
                      "2. Deja esa ventana abierta en 'Mis Causas'.\n" +
                      "3. (La primera vez) Ejecuta la task 'Diagnóstico UIA' y envía el archivo uia_tree.txt para afinar el bot.\n" +
                      "4. Ejecuta 'Buscar Tribunal (GUI)' con tu planilla seleccionada.\n\n" +
                      "No muevas el mouse ni cambies de ventana mientras el bot trabaja."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
