import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property string planillaPath: ""
    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2

    signal planillaPathEdited(string value)

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona la planilla Excel a utilizar."
        }
        if (typeof controller !== "undefined" && controller !== null) {
            var errorMsg = controller.validatePlanilla(path)
            if (errorMsg && errorMsg.length > 0) {
                var lines = errorMsg.split("\n")
                validationNotification.titleText = lines[0]
                validationNotification.messageText = lines.length > 1 ? lines.slice(1).join("\n") : ""
                validationNotification.open()
                return errorMsg
            }
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim(),
            connect_manual_chrome: connectManualChromeCheck.checked,
            use_patchright: usePatchrightCheck.checked,
            patchright_real_edge: patchrightRealEdgeCheck.checked
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaCardLayout.implicitHeight + 18

        ColumnLayout {
            id: planillaCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Planilla 'Estado Diario' a utilizar"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: planillaField
                    Layout.fillWidth: true
                    text: root.planillaPath
                    color: Common.Theme.text
                    placeholderText: "estado_diario.xlsx"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Common.InsetAlloyButton {
                    id: selectPlanillaButton
                    text: "Seleccionar Planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            planillaFileDialog.currentFolder = root.toFileUrl(folder)
                        }
                        planillaFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: selectPlanillaButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    // ── Conectar a Chrome abierto manualmente ────────────────────────────────
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: connectChromeLayout.implicitHeight + 18

        ColumnLayout {
            id: connectChromeLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: connectManualChromeCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: connectManualChromeCheck.leftPadding
                    y: connectManualChromeCheck.height / 2 - height / 2
                    radius: 5
                    color: connectManualChromeCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: connectManualChromeCheck.checked ? 2 : 1
                    border.color: connectManualChromeCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(14)
                        font.bold: true
                        visible: connectManualChromeCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Conectar a Chrome abierto manualmente"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: connectManualChromeCheck.indicator.width + connectManualChromeCheck.spacing
                }
            }

            Label {
                text: "Úsalo cuando el portal bloquea el navegador automático. El bot NO abre el navegador: se conecta a un Chrome o Edge que abres TÚ a mano con el acceso directo de depuración (Abrir_Chrome_Para_N01.bat o Abrir_Edge_Para_N01.bat, puerto 9222) y donde ya iniciaste sesión en PJUD. En esta máquina usa Edge si Chrome está bloqueado. Abre ese navegador, inicia sesión, y recién ahí presiona Iniciar."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // ── Modo stealth avanzado (Patchright) ───────────────────────────────────
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: patchrightLayout.implicitHeight + 18

        ColumnLayout {
            id: patchrightLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: usePatchrightCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: usePatchrightCheck.leftPadding
                    y: usePatchrightCheck.height / 2 - height / 2
                    radius: 5
                    color: usePatchrightCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: usePatchrightCheck.checked ? 2 : 1
                    border.color: usePatchrightCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(14)
                        font.bold: true
                        visible: usePatchrightCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Modo stealth avanzado (Patchright)"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: usePatchrightCheck.indicator.width + usePatchrightCheck.spacing
                }
            }

            Label {
                text: "El bot abre un Edge/Chrome 'sigiloso' que oculta las señales de automatización que el portal detecta, con un perfil propio que queda con sesión iniciada. Úsalo si el modo normal es bloqueado. La primera vez inicia sesión a mano en la ventana que se abre; el bot sigue solo al ver 'Mis Causas'. (No lo combines con la casilla de arriba.)"
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            CheckBox {
                id: patchrightRealEdgeCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true
                Layout.leftMargin: 10

                indicator: Rectangle {
                    implicitWidth: 18
                    implicitHeight: 18
                    x: patchrightRealEdgeCheck.leftPadding
                    y: patchrightRealEdgeCheck.height / 2 - height / 2
                    radius: 5
                    color: patchrightRealEdgeCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: patchrightRealEdgeCheck.checked ? 2 : 1
                    border.color: patchrightRealEdgeCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(13)
                        font.bold: true
                        visible: patchrightRealEdgeCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Clonar mi perfil de Edge (usa su confianza)"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: patchrightRealEdgeCheck.indicator.width + patchrightRealEdgeCheck.spacing
                }
            }

            Label {
                text: "Recomendado si el perfil nuevo es bloqueado: copia (1 vez) tu perfil de Edge —donde YA entras al portal— a una carpeta que el bot SÍ puede manejar, conservando su sesión/confianza. CIERRA todas las ventanas de Edge antes de iniciar (la primera vez, para copiar bien las cookies)."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                Layout.leftMargin: 10
                wrapMode: Text.Wrap
            }
        }
    }

    FileDialog {
        id: planillaFileDialog
        title: "Seleccionar Planilla Estado Diario"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.planillaPathEdited(root.toLocalPath(selectedFile))
    }

    Common.NotificationToast {
        id: validationNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
        confirmTone: "primary"
    }
}
