"""
Clean05 - Emerix attended Edge extension bridge.

The human opens normal Edge and logs into Emerix. This task validates the
selected Excel and exposes a localhost bridge. The bot-specific browser route
will be added once the client defines the operational workflow.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from robocorp.tasks import task

from functions import (
    VALIDATED_COLUMNS,
    MissingColumnsError,
    build_bridge_state,
    run_bridge_session,
    write_bridge_receipt,
)

PATH_BOT = str(Path(__file__).parent)
PLANILLA_PATH = os.getenv(
    "PLANILLA_PATH",
    str(Path(PATH_BOT) / "input" / "planilla.xlsx"),
)
CLEAN05_BRIDGE_HOST = os.getenv("CLEAN05_BRIDGE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    CLEAN05_BRIDGE_PORT = max(1, min(65535, int(os.getenv("CLEAN05_BRIDGE_PORT", "8766"))))
except ValueError:
    CLEAN05_BRIDGE_PORT = 8766
try:
    CLEAN05_TIMEOUT_MINUTES = max(5, int(os.getenv("CLEAN05_TIMEOUT_MINUTES", "120")))
except ValueError:
    CLEAN05_TIMEOUT_MINUTES = 120


def _new_run_dir() -> str:
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M")
    run_dir = output_root / f"Clean05_Emerix_{timestamp}"
    suffix = 2
    while run_dir.exists():
        run_dir = output_root / f"Clean05_Emerix_{timestamp}_{suffix}"
        suffix += 1
    run_dir.mkdir(parents=True, exist_ok=True)
    return str(run_dir)


def _run_clean05(*, test_mode: bool) -> None:
    """Run the shared Clean05 orchestration in production or test mode."""
    # Validate before creating the run folder so a rejected planilla leaves no
    # empty evidence directory behind.
    try:
        state = build_bridge_state(PLANILLA_PATH, test_mode=test_mode)
    except MissingColumnsError as exc:
        print("=" * 72)
        print("CLEAN05: LA PLANILLA NO TIENE LAS COLUMNAS NECESARIAS")
        print(f"  Excel: {PLANILLA_PATH}")
        print(f"  Hoja revisada: {exc.sheet_name}")
        print("")
        print(f"  Faltan {len(exc.missing)} columna(s):")
        for column in exc.missing:
            print(f"    - {column}")
        print("")
        print(f"  Columnas requeridas: {', '.join(VALIDATED_COLUMNS)}")
        print(f"  Columnas encontradas: {', '.join(exc.found) or '(ninguna)'}")
        print("")
        print("  Corrige la planilla y vuelve a iniciar el bot.")
        print("=" * 72)
        # Structured markers consumed by Clean05Plugin to build the desktop
        # notification. Keep the format stable.
        print(f"[CLEAN05][COLUMNAS_FALTANTES] {' | '.join(exc.missing)}")
        print(f"[CLEAN05][COLUMNAS_HOJA] {exc.sheet_name}")
        print(f"[CLEAN05][ARCHIVO] {Path(PLANILLA_PATH).name}")
        raise
    run_dir = _new_run_dir()
    summary = state.summary()

    print("=" * 72)
    print("CLEAN05_EMERIX_EXTENSION")
    print(f"  Excel: {PLANILLA_PATH}")
    print(f"  Hoja de datos: {summary['workbook']['sheet_name']}")
    print(f"  Columnas requeridas: OK ({', '.join(VALIDATED_COLUMNS)})")
    print(f"  Filas de datos estimadas: {summary['workbook']['data_rows']}")
    print(f"  Filas que iniciarán Pendiente: {summary['preflight_pending_count']}")
    print(f"  Extension Edge: {Path(PATH_BOT) / 'extension'}")
    print(f"  Bridge: http://{CLEAN05_BRIDGE_HOST}:{CLEAN05_BRIDGE_PORT}")
    print(
        "  Modo: PRUEBA (cierra con X, no graba)"
        if test_mode
        else "  Modo: PRODUCCION (presiona Grabar)"
    )
    print(f"  Evidencia: {run_dir}")
    print("")
    print("Pasos:")
    print("  1. Abre Edge normal e inicia sesion manualmente en Emerix.")
    print("  2. Presiona Start en el panel Clean05 (funciona en cualquier pagina).")
    print("  3. El bot procesara todas las filas y generara un Excel de resultados")
    print("     (verde=OK, amarillo=con problema, rojo=celda que no se pudo cargar).")
    print("=" * 72)

    final_summary = run_bridge_session(
        state=state,
        host=CLEAN05_BRIDGE_HOST,
        port=CLEAN05_BRIDGE_PORT,
        timeout_seconds=CLEAN05_TIMEOUT_MINUTES * 60,
        output_dir=run_dir,
    )
    receipt_path = write_bridge_receipt(final_summary, run_dir)
    print("Clean05: sesion finalizada.")
    for entry in final_summary.get("logs", []):
        print(f"Clean05: {entry}")
    ok_count = int(final_summary.get("ok_count", 0))
    pending_count = int(final_summary.get("pending_count", 0))
    print(f"Clean05: filas OK={ok_count} | filas Pendiente={pending_count}")
    # Structured totals consumed by Clean05Plugin for the summary + notification.
    print(
        f"[CLEAN05][RESUMEN] boletas={ok_count + pending_count} "
        f"ok={ok_count} pendientes={pending_count} revisar={pending_count}"
    )
    result_path = str(final_summary.get("result_path") or "")
    if result_path:
        print(f"Clean05: archivo de resultados={result_path}")
    print(f"Clean05: evidencia={receipt_path}")

    step_error = str(final_summary.get("error") or "")
    if step_error:
        # Only a fatal error (e.g. the form could not be closed during recovery,
        # or a timeout) fails the run. Row-level data problems are recorded in
        # the result workbook and do NOT fail the whole run.
        print(f"[CLEAN05][PASO_ERROR] {step_error}")
        raise RuntimeError(f"Clean05 se detuvo por un error grave. {step_error}")

    print("Done")


@task
def CLEAN05_EMERIX_EXTENSION():
    """Process Clean05 rows and save each completed boleta in Emerix."""
    _run_clean05(test_mode=False)


@task
def CLEAN05_EMERIX_EXTENSION_TEST():
    """Process Clean05 rows but close each completed form without saving."""
    _run_clean05(test_mode=True)
