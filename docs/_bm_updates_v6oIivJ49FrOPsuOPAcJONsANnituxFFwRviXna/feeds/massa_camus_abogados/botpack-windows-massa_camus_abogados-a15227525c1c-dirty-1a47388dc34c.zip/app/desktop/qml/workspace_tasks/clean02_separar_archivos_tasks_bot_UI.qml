import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    property string inputPath: ""
    property string runtimePython: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal inputPathEdited(string value)
    signal runtimePythonEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            var fallbackValue = taskValueAt(workspaceTaskCombo.currentIndex)
            if (fallbackValue.length > 0) {
                workspaceTaskNameEdited(fallbackValue)
            }
        }
    }

    function normalizedTask(taskName) {
        return String(taskName || "").replace(/[^A-Za-z0-9]/g, "").toLowerCase()
    }

    function taskLabel(taskName) {
        var labels = {
            clean02separararchivos: "Separar Archivos"
        }
        var key = normalizedTask(taskName)
        if (labels[key] !== undefined) {
            return labels[key]
        }
        return String(taskName || "")
    }

    function taskDisplayOptions() {
        var options = workspaceConfig && workspaceConfig.taskOptions ? workspaceConfig.taskOptions : []
        var display = []
        for (var i = 0; i < options.length; i++) {
            var value = String(options[i] || "").trim()
            if (value.length === 0) {
                continue
            }
            display.push({
                value: value,
                label: taskLabel(value)
            })
        }
        return display
    }

    function taskValueAt(index) {
        var options = taskDisplayOptions()
        if (index < 0 || index >= options.length) {
            return ""
        }
        return String(options[index].value || "")
    }

    function taskModuleSource() {
        var task = normalizedTask(workspaceTaskName)
        if (task.length === 0) {
            task = normalizedTask(taskValueAt(workspaceTaskCombo.currentIndex))
        }
        if (task === "clean02separararchivos") {
            return String(Qt.resolvedUrl("clean02_separar_archivos_task_separarUI.qml"))
        }
        return ""
    }

    function validate() {
        var selectedTask = String(workspaceTaskName || "").trim()
        if (selectedTask.length === 0) {
            return "Selecciona la task a ejecutar."
        }
        if (taskInputLoader.item && taskInputLoader.item["validate"]) {
            var validationMessage = taskInputLoader.item["validate"]()
            if (validationMessage && validationMessage.length > 0) {
                return validationMessage
            }
        }
        return ""
    }

    function buildPayload() {
        var payload = {}
        if (taskInputLoader.item && taskInputLoader.item["buildPayload"]) {
            var taskPayload = taskInputLoader.item["buildPayload"]()
            for (var key in taskPayload) {
                payload[key] = taskPayload[key]
            }
        }
        return payload
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 10

        Label {
            text: "Task"
            color: root.textMuted
            Layout.preferredWidth: 38
        }

        Common.StyledComboBox {
            id: workspaceTaskCombo
            Layout.fillWidth: true
            textRole: "label"
            model: root.taskDisplayOptions()
            currentIndex: {
                var options = root.taskDisplayOptions()
                if (options.length === 0) {
                    return -1
                }
                for (var i = 0; i < options.length; i++) {
                    if (String(options[i].value || "") === root.workspaceTaskName) {
                        return i
                    }
                }
                return 0
            }
            onActivated: {
                var value = root.taskValueAt(currentIndex)
                if (value.length > 0) {
                    root.workspaceTaskNameEdited(value)
                }
            }
            onCurrentIndexChanged: {
                if (!visible) {
                    return
                }
                var value = root.taskValueAt(currentIndex)
                if (value.length > 0) {
                    root.workspaceTaskNameEdited(value)
                }
            }
        }
    }

    Loader {
        id: taskInputLoader
        Layout.fillWidth: true
        Layout.preferredHeight: item ? Math.max(item.implicitHeight, item.childrenRect.height) : 0
        source: root.taskModuleSource()
        onLoaded: {
            if (item) {
                item.width = width
            }
        }
        onWidthChanged: {
            if (item) {
                item.width = width
            }
        }
    }

    Binding {
        target: taskInputLoader.item
        property: "workspaceConfig"
        value: root.workspaceConfig
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "helpers"
        value: root.helpers
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "textMuted"
        value: root.textMuted
        when: taskInputLoader.item !== null
    }

    Connections {
        target: taskInputLoader.item
        ignoreUnknownSignals: true

        function onInputPathEdited(value) {
            root.inputPath = value
            root.inputPathEdited(value)
        }
    }
}
