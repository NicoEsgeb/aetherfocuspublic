import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property color textMuted: Common.Theme.text2

    Common.BotInfoHeader {
        themeSource: Common.Theme
        Layout.fillWidth: true

        Rectangle {
            radius: 6
            color: Common.Theme.accentSoft
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: cleanBadge.implicitWidth + 16
            implicitHeight: cleanBadge.implicitHeight + 8

            Label {
                id: cleanBadge
                anchors.centerIn: parent
                text: "Clean BBRR"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }

        Rectangle {
            radius: 6
            color: "#163d4d"
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: chromeBadge.implicitWidth + 16
            implicitHeight: chromeBadge.implicitHeight + 8

            Label {
                id: chromeBadge
                anchors.centerIn: parent
                text: "Chrome + bridge"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Qué hace este bot"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Clean08 valida la planilla y luego se conecta, mediante una extensión local de Chrome, a la sesión abierta de la Oficina Judicial Virtual. El recorrido implementado completa la consulta y selecciona Cuaderno, Parte que Presenta, Escritos Generales y Señala domicilio."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: inputsLayout.implicitHeight + 20

        ColumnLayout {
            id: inputsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Entradas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "1. input/escritos-pdfs — carpeta fija para los escritos en PDF.\n" +
                      "2. input/planilla — carpeta inicial del selector de la planilla Excel.\n\n" +
                      "La planilla debe incluir una hoja Hoja1 y las columnas Tribunal, ROL, Año y Archivo. Los nombres se validan sin distinguir mayúsculas y minúsculas."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.warningSoft
        border.width: 1
        border.color: Common.Theme.warning
        implicitHeight: pendingLayout.implicitHeight + 20

        ColumnLayout {
            id: pendingLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 4

            Label {
                text: "Validación inicial"
                color: Common.Theme.warning
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Antes de abrir el bridge, Clean08 comprueba la hoja Hoja1, las cuatro columnas obligatorias, que exista al menos una fila con información y que ninguna fila tenga celdas obligatorias vacías. Si encuentra un problema, se detiene y muestra el detalle en una notificación."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: outputLayout.implicitHeight + 20

        ColumnLayout {
            id: outputLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Planilla de resultado"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Clean08 guarda en output una copia de la planilla con ESTADO ESCRITO como primera columna y NOTAS como segunda. Verde significa Ingresado y exige que PJUD haya confirmado el PDF. Amarillo significa No ingresado, antes de Grabar Escrito. Naranjo significa Revisar manualmente: se presionó Grabar Escrito, pero el PDF no quedó confirmado. Las filas con problemas explican el motivo directamente en la columna NOTAS. Antes de Grabar Escrito, una fila puede reiniciarse automáticamente una sola vez si un menú aparece vacío o PJUD recarga la página durante un paso."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: extensionLayout.implicitHeight + 20

        ColumnLayout {
            id: extensionLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Extensión atendida · 15 steps por fila"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Carga como extensión descomprimida la carpeta extension de Clean08. Después de pulsar Iniciar y superar la validación, abre la página indexN.php del portal y pulsa Start en el panel Clean08. El bridge local usa 127.0.0.1:8769. Para cada fila, en orden, la extensión completa la causa, pulsa Grabar Escrito, inyecta y confirma el PDF indicado por Archivo, y cierra la ventana con Cerrar y Continuar. Si falla un paso del portal, registra exactamente cuál fue y su detalle, limpia la interfaz de forma segura y continúa con la fila siguiente sin reintentar la fila fallida."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
