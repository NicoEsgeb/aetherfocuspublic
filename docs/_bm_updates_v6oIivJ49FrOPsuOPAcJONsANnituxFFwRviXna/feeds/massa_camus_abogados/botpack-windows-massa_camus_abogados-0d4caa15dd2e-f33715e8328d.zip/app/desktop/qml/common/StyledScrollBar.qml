import QtQuick
import QtQuick.Controls

ScrollBar {
    id: control
    padding: 1
    minimumSize: 0.1
    hoverEnabled: true
    clip: true
    implicitWidth: orientation === Qt.Vertical ? 10 : 64
    implicitHeight: orientation === Qt.Horizontal ? 10 : 64
    visible: policy === ScrollBar.AlwaysOn || size < 1.0 || active || hovered

    // Keep bars on the expected side regardless of platform style quirks.
    LayoutMirroring.enabled: false
    LayoutMirroring.childrenInherit: false
    anchors.right: parent ? parent.right : undefined
    anchors.bottom: parent ? parent.bottom : undefined
    anchors.top: orientation === Qt.Vertical && parent ? parent.top : undefined
    anchors.left: orientation === Qt.Horizontal && parent ? parent.left : undefined

    background: Rectangle {
        anchors.fill: parent
        radius: control.orientation === Qt.Vertical ? width / 2 : height / 2
        antialiasing: true
        border.width: 0
        color: Theme.line
        opacity: control.size < 1.0 ? ((control.hovered || control.active) ? 0.70 : 0.55) : 0.0
    }

    contentItem: Rectangle {
        implicitWidth: control.orientation === Qt.Vertical ? 8 : 48
        implicitHeight: control.orientation === Qt.Horizontal ? 8 : 48
        radius: control.orientation === Qt.Vertical ? width / 2 : height / 2
        antialiasing: true
        border.width: 0
        color: Theme.text3
        opacity: control.size < 1.0 ? (control.pressed ? 0.95 : ((control.hovered || control.active) ? 0.9 : 0.82)) : 0.0
    }
}
