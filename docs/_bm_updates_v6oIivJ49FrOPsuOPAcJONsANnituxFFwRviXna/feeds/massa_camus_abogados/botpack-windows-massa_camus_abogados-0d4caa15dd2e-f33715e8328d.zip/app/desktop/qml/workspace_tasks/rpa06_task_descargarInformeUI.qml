import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property string fechaDesde: ""
    property string fechaHasta: ""
    property var workspaceConfig: ({})
    property var helpers: ({})

    property int minYear: 2000
    property int maxYear: 2040
    property int defaultYear: new Date().getFullYear()
    property int desdeDay: 1
    property int desdeMonth: 1
    property int desdeYear: defaultYear
    property int hastaDay: 1
    property int hastaMonth: 1
    property int hastaYear: defaultYear
    property bool syncingDateSelectors: false
    property bool desdeTouched: false
    property bool hastaTouched: false

    readonly property var dayOptions: buildNumberOptions(1, 31, true)
    readonly property var monthOptions: buildNumberOptions(1, 12, true)
    readonly property var yearOptions: buildNumberOptions(minYear, maxYear, false)

    signal fechaDesdeEdited(string value)
    signal fechaHastaEdited(string value)

    onFechaDesdeChanged: syncSelectorsFromText()
    onFechaHastaChanged: syncSelectorsFromText()

    Component.onCompleted: {
        syncSelectorsFromText()
        desdeTouched = String(fechaDesde || "").trim().length > 0
        hastaTouched = String(fechaHasta || "").trim().length > 0
    }

    function buildNumberOptions(start, end, padTwo) {
        var options = []
        for (var i = start; i <= end; i++) {
            var text = String(i)
            if (padTwo && i < 10) {
                text = "0" + text
            }
            options.push({ text: text, value: i })
        }
        return options
    }

    function optionIndexForValue(options, value) {
        for (var i = 0; i < options.length; i++) {
            if (Number(options[i].value) === Number(value)) {
                return i
            }
        }
        return 0
    }

    function daysInMonth(month, year) {
        return new Date(year, month, 0).getDate()
    }

    function pad2(value) {
        return value < 10 ? "0" + value : String(value)
    }

    function clamp(value, min, max, fallback) {
        if (isNaN(value)) {
            return fallback
        }
        if (value < min) {
            return min
        }
        if (value > max) {
            return max
        }
        return value
    }

    function formatDmy(day, month, year) {
        return pad2(day) + "/" + pad2(month) + "/" + String(year)
    }

    function parseDmyOrDefault(value) {
        var text = String(value || "").trim()
        var match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
        if (!match) {
            return ({ day: 1, month: 1, year: defaultYear })
        }
        var parsedDay = Number(match[1])
        var parsedMonth = Number(match[2])
        var parsedYear = Number(match[3])
        var safeYear = clamp(parsedYear, minYear, maxYear, defaultYear)
        var safeMonth = clamp(parsedMonth, 1, 12, 1)
        var safeDay = clamp(parsedDay, 1, daysInMonth(safeMonth, safeYear), 1)
        return ({ day: safeDay, month: safeMonth, year: safeYear })
    }

    function syncSelectorsFromText() {
        if (syncingDateSelectors) {
            return
        }
        syncingDateSelectors = true

        var parsedDesde = parseDmyOrDefault(fechaDesde)
        desdeDay = parsedDesde.day
        desdeMonth = parsedDesde.month
        desdeYear = parsedDesde.year

        var parsedHasta = parseDmyOrDefault(fechaHasta)
        hastaDay = parsedHasta.day
        hastaMonth = parsedHasta.month
        hastaYear = parsedHasta.year

        syncingDateSelectors = false
    }

    function emitDesde() {
        if (syncingDateSelectors) {
            return
        }
        var maxDay = daysInMonth(desdeMonth, desdeYear)
        if (desdeDay > maxDay) {
            syncingDateSelectors = true
            desdeDay = maxDay
            syncingDateSelectors = false
        }
        desdeTouched = true
        fechaDesdeEdited(formatDmy(desdeDay, desdeMonth, desdeYear))
    }

    function emitHasta() {
        if (syncingDateSelectors) {
            return
        }
        var maxDay = daysInMonth(hastaMonth, hastaYear)
        if (hastaDay > maxDay) {
            syncingDateSelectors = true
            hastaDay = maxDay
            syncingDateSelectors = false
        }
        hastaTouched = true
        fechaHastaEdited(formatDmy(hastaDay, hastaMonth, hastaYear))
    }

    function isValidDateDmy(value) {
        if (helpers && typeof helpers.isValidDateDmy === "function") {
            return helpers.isValidDateDmy(value)
        }
        var text = String(value || "").trim()
        var match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
        if (!match) {
            return false
        }
        var day = Number(match[1])
        var month = Number(match[2])
        var year = Number(match[3])
        var date = new Date(year, month - 1, day)
        return date.getFullYear() === year
            && date.getMonth() === (month - 1)
            && date.getDate() === day
    }

    function compareDateDmy(dateA, dateB) {
        if (helpers && typeof helpers.compareDateDmy === "function") {
            return helpers.compareDateDmy(dateA, dateB)
        }
        var a = String(dateA || "").trim().split("/")
        var b = String(dateB || "").trim().split("/")
        if (a.length !== 3 || b.length !== 3) {
            return 0
        }
        var aKey = Number(a[2]) * 10000 + Number(a[1]) * 100 + Number(a[0])
        var bKey = Number(b[2]) * 10000 + Number(b[1]) * 100 + Number(b[0])
        if (aKey < bKey) {
            return -1
        }
        if (aKey > bKey) {
            return 1
        }
        return 0
    }

    function validate() {
        if (!desdeTouched || !hastaTouched) {
            return "Selecciona Fecha desde y Fecha hasta para Descargar Informe."
        }

        var desde = formatDmy(desdeDay, desdeMonth, desdeYear)
        var hasta = formatDmy(hastaDay, hastaMonth, hastaYear)
        if (!isValidDateDmy(desde) || !isValidDateDmy(hasta)) {
            return "Las fechas deben usar formato dd/mm/yyyy."
        }
        if (compareDateDmy(desde, hasta) > 0) {
            return "Fecha desde no puede ser mayor que Fecha hasta."
        }
        return ""
    }

    function buildPayload() {
        return {
            fecha_desde_caratulas: formatDmy(desdeDay, desdeMonth, desdeYear),
            fecha_hasta_caratulas: formatDmy(hastaDay, hastaMonth, hastaYear)
        }
    }

    Label {
        text: "Fecha desde / Fecha hasta"
        color: Common.Theme.text2
        Layout.fillWidth: true
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        RowLayout {
            Layout.fillWidth: true
            spacing: 6

            Label {
                text: "Desde"
                color: Common.Theme.text2
                font.pixelSize: 12
                Layout.preferredWidth: 42
            }

            Common.StyledComboBox {
                id: desdeDayCombo
                Layout.preferredWidth: 68
                model: root.dayOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.dayOptions, root.desdeDay)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.dayOptions.length) {
                        return
                    }
                    root.desdeDay = root.dayOptions[currentIndex].value
                    root.emitDesde()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: 12
            }

            Common.StyledComboBox {
                id: desdeMonthCombo
                Layout.preferredWidth: 68
                model: root.monthOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.monthOptions, root.desdeMonth)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.monthOptions.length) {
                        return
                    }
                    root.desdeMonth = root.monthOptions[currentIndex].value
                    root.emitDesde()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: 12
            }

            Common.StyledComboBox {
                id: desdeYearCombo
                Layout.fillWidth: true
                Layout.minimumWidth: 96
                model: root.yearOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.yearOptions, root.desdeYear)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.yearOptions.length) {
                        return
                    }
                    root.desdeYear = root.yearOptions[currentIndex].value
                    root.emitDesde()
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 6

            Label {
                text: "Hasta"
                color: Common.Theme.text2
                font.pixelSize: 12
                Layout.preferredWidth: 42
            }

            Common.StyledComboBox {
                id: hastaDayCombo
                Layout.preferredWidth: 68
                model: root.dayOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.dayOptions, root.hastaDay)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.dayOptions.length) {
                        return
                    }
                    root.hastaDay = root.dayOptions[currentIndex].value
                    root.emitHasta()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: 12
            }

            Common.StyledComboBox {
                id: hastaMonthCombo
                Layout.preferredWidth: 68
                model: root.monthOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.monthOptions, root.hastaMonth)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.monthOptions.length) {
                        return
                    }
                    root.hastaMonth = root.monthOptions[currentIndex].value
                    root.emitHasta()
                }
            }

            Label {
                text: "/"
                color: Common.Theme.text2
                font.pixelSize: 12
            }

            Common.StyledComboBox {
                id: hastaYearCombo
                Layout.fillWidth: true
                Layout.minimumWidth: 96
                model: root.yearOptions
                textRole: "text"
                currentIndex: root.optionIndexForValue(root.yearOptions, root.hastaYear)
                onActivated: {
                    if (currentIndex < 0 || currentIndex >= root.yearOptions.length) {
                        return
                    }
                    root.hastaYear = root.yearOptions[currentIndex].value
                    root.emitHasta()
                }
            }
        }
    }
}
