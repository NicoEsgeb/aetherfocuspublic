import QtQuick
import QtQuick.Controls

ComboBox {
    id: control

    implicitHeight: 36
    hoverEnabled: true
    leftPadding: 12
    rightPadding: 28
    topPadding: 7
    bottomPadding: 7

    property color textColor: Theme.text
    property color disabledTextColor: Theme.text3
    property color baseColor: Theme.panel
    property color baseHoverColor: Theme.panel2
    property color basePressedColor: Theme.panel2
    property color borderColor: Theme.line
    property color borderHoverColor: Theme.line
    property color borderFocusColor: Theme.accent
    property color popupColor: Theme.panel
    property color popupBorderColor: Theme.lineSoft
    property color popupItemHoverColor: Theme.panel2
    property color popupItemSelectedColor: Theme.accentSoft
    property int cornerRadius: 8

    function optionText(optionValue) {
        if (optionValue === undefined || optionValue === null) {
            return ""
        }
        var role = String(control.textRole || "")
        if (role.length > 0 && typeof optionValue === "object" && optionValue[role] !== undefined) {
            return String(optionValue[role])
        }
        return String(optionValue)
    }

    contentItem: Text {
        text: control.displayText
        color: control.enabled ? control.textColor : control.disabledTextColor
        font: control.font
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }

    background: Rectangle {
        radius: control.cornerRadius
        color: !control.enabled
            ? Theme.panel2
            : (control.pressed
                ? control.basePressedColor
                : (control.hovered ? control.baseHoverColor : control.baseColor))
        border.width: control.visualFocus ? 2 : 1
        border.color: control.visualFocus
            ? control.borderFocusColor
            : (control.hovered ? control.borderHoverColor : control.borderColor)

        Behavior on color {
            ColorAnimation { duration: 110 }
        }
        Behavior on border.color {
            ColorAnimation { duration: 110 }
        }
    }

    indicator: Canvas {
        id: arrow
        x: control.width - width - 10
        y: (control.height - height) / 2
        width: 10
        height: 6
        contextType: "2d"

        Connections {
            target: control

            function onPressedChanged() {
                arrow.requestPaint()
            }
            function onEnabledChanged() {
                arrow.requestPaint()
            }
        }

        onPaint: {
            var ctx = getContext("2d")
            ctx.clearRect(0, 0, width, height)
            ctx.beginPath()
            ctx.moveTo(0, 0)
            ctx.lineTo(width, 0)
            ctx.lineTo(width / 2, height)
            ctx.closePath()
            ctx.fillStyle = control.enabled ? control.textColor : control.disabledTextColor
            ctx.fill()
        }
    }

    delegate: ItemDelegate {
        id: optionDelegate
        width: ListView.view ? ListView.view.width : control.width
        height: 34
        padding: 0
        leftPadding: 10
        rightPadding: 10
        highlighted: control.highlightedIndex === index
        hoverEnabled: true
        text: {
            if (modelData !== undefined && modelData !== null) {
                return control.optionText(modelData)
            }
            var role = String(control.textRole || "")
            if (role.length > 0 && model && model[role] !== undefined) {
                return String(model[role])
            }
            return ""
        }

        background: Rectangle {
            radius: 6
            color: optionDelegate.down || optionDelegate.highlighted
                ? control.popupItemSelectedColor
                : (optionDelegate.hovered ? control.popupItemHoverColor : "transparent")
        }

        contentItem: Text {
            text: optionDelegate.text
            color: control.textColor
            font: control.font
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }
    }

    popup: Popup {
        y: control.height + 4
        width: control.width
        padding: 4
        implicitHeight: Math.min(contentItem.implicitHeight + 8, 230)

        background: Rectangle {
            radius: control.cornerRadius
            color: control.popupColor
            border.width: 1
            border.color: control.popupBorderColor
        }

        contentItem: ListView {
            clip: true
            implicitHeight: contentHeight
            model: control.delegateModel
            currentIndex: control.highlightedIndex
            boundsBehavior: Flickable.StopAtBounds
            ScrollIndicator.vertical: ScrollIndicator {}
        }
    }
}
