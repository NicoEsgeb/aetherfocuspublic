import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

// Run-detail table for the clean04 "Generar Demandas" bot. Rendered in the
// "Resumen del proceso" tab and refreshed every ~2s from the run log. Shows one
// row per RUT with an OK (green) / REVISAR (yellow) / ERROR (red) status badge,
// a counts header, and an "Abrir Resultados" button that opens the output folder.
Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarn: Common.Theme.warning
    readonly property color cDanger: Common.Theme.danger

    function val(key, fallback) {
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null)
            return fallback
        return summaryData[key]
    }
    function isTrue(key) { return root.val(key, false) === true }
    function num(key) { var v = Number(root.val(key, 0)); return isNaN(v) ? 0 : v }
    function rows() { var r = root.val("rows", []); return r ? r : [] }
    function frac() {
        var f = Number(root.val("fraction", 0))
        if (isNaN(f) || f < 0) return 0
        if (f > 1) return 1
        return f
    }
    function statusColor() {
        if (root.isTrue("cancelled")) return Common.Theme.cancel
        if (root.isTrue("failed")) return root.cDanger
        if (root.isTrue("success")) return root.cSuccess
        return Common.Theme.accent
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 12

        // ---- Header: process name + status chip ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Label {
                text: root.val("processLabel", "Generar Demandas")
                color: root.cTextMain
                font.pixelSize: 18
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Label {
                text: "Tiempo: " + root.val("elapsedText", "-")
                color: root.cTextMuted
                font.pixelSize: 12
            }

            Rectangle {
                radius: 7
                implicitHeight: 24
                implicitWidth: statusWordLabel.implicitWidth + 22
                color: Common.Theme.panel2
                border.width: 1
                border.color: root.statusColor()

                Label {
                    id: statusWordLabel
                    anchors.centerIn: parent
                    text: root.val("statusWord", "-")
                    color: root.statusColor()
                    font.pixelSize: 12
                    font.bold: true
                }
            }
        }

        // ---- Live progress bar (fills as each RUT is processed) ----
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 6

            Label {
                text: root.val("headline", "Preparando el proceso...")
                color: root.cTextMain
                font.pixelSize: 14
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Rectangle {
                id: barTrack
                Layout.fillWidth: true
                implicitHeight: 16
                radius: 8
                color: Common.Theme.panel2
                border.width: 1
                border.color: root.cLine
                clip: true

                Rectangle {
                    id: barFill
                    height: parent.height
                    width: Math.max(parent.height, parent.width * root.frac())
                    radius: 8
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: root.statusColor() }
                        GradientStop { position: 1.0; color: Common.Theme.accent }
                    }
                    // Smoothly glide between the 2s refreshes instead of jumping.
                    Behavior on width {
                        NumberAnimation { duration: 450; easing.type: Easing.OutCubic }
                    }
                }

                // Sweeping highlight so the bar looks alive even when one big RUT
                // keeps the count steady for a while (running only).
                Rectangle {
                    id: shimmer
                    visible: root.isTrue("running")
                    height: parent.height
                    width: 70
                    opacity: 0.18
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: "transparent" }
                        GradientStop { position: 0.5; color: Common.Theme.text }
                        GradientStop { position: 1.0; color: "transparent" }
                    }
                    SequentialAnimation on x {
                        running: shimmer.visible
                        loops: Animation.Infinite
                        NumberAnimation { from: -70; to: barTrack.width; duration: 1400; easing.type: Easing.InOutQuad }
                        PauseAnimation { duration: 350 }
                    }
                }
            }

            Label {
                text: root.num("done") + " / " + root.num("total") + " RUT"
                color: root.cTextMuted
                font.pixelSize: 12
            }
        }

        // ---- Counts row ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Repeater {
                model: [
                    { label: "OK", value: root.num("countOk"), color: root.cSuccess },
                    { label: "REVISAR", value: root.num("countRevisar"), color: root.cWarn },
                    { label: "ERROR", value: root.num("countError"), color: root.cDanger },
                    { label: "Total RUT", value: root.num("countTotal"), color: root.cTextMuted }
                ]
                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 46
                    radius: 10
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 0
                        Label {
                            text: String(modelData.value)
                            color: modelData.color
                            font.pixelSize: 18
                            font.bold: true
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Label {
                            text: modelData.label
                            color: root.cTextMuted
                            font.pixelSize: 12
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                }
            }
        }

        // ---- Open output folder ----
        Button {
            id: openButton
            visible: String(root.val("outputDir", "")).length > 0
            Layout.fillWidth: true
            Layout.preferredHeight: 40
            text: "Abrir Resultados"
            hoverEnabled: true
            onClicked: controller.openPathInExplorer(String(root.val("outputDir", "")))
            background: Rectangle {
                radius: 9
                border.width: 1
                border.color: openButton.down ? Common.Theme.success : Common.Theme.success
                gradient: Gradient {
                    GradientStop { position: 0.0; color: openButton.down ? Common.Theme.success : Common.Theme.success }
                    GradientStop { position: 1.0; color: openButton.down ? Common.Theme.success : Common.Theme.success }
                }
            }
            contentItem: Text {
                text: openButton.text
                color: Common.Theme.text
                font.pixelSize: 14
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }

        // ---- Table: Estado | RUT ----
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine
            clip: true

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 1
                spacing: 0

                // header row
                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 34
                    color: Common.Theme.accentSoft
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 12
                        anchors.rightMargin: 12
                        spacing: 10
                        Label {
                            text: "Estado"
                            color: root.cTextMuted
                            font.pixelSize: 12
                            font.bold: true
                            Layout.preferredWidth: 110
                        }
                        Label {
                            text: "RUT"
                            color: root.cTextMuted
                            font.pixelSize: 12
                            font.bold: true
                            Layout.fillWidth: true
                        }
                        Label {
                            text: "Pagarés"
                            color: root.cTextMuted
                            font.pixelSize: 12
                            font.bold: true
                            horizontalAlignment: Text.AlignRight
                            Layout.preferredWidth: 64
                        }
                    }
                }

                ListView {
                    id: rutList
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    model: root.rows()
                    boundsBehavior: Flickable.StopAtBounds
                    ScrollBar.vertical: Common.StyledScrollBar { policy: ScrollBar.AsNeeded }

                    delegate: Rectangle {
                        width: ListView.view.width
                        implicitHeight: 36
                        color: (index % 2 === 0) ? "transparent" : "#10294780"

                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 12
                            anchors.rightMargin: 12
                            spacing: 10

                            // status badge (pill)
                            Rectangle {
                                Layout.preferredWidth: 96
                                Layout.preferredHeight: 22
                                radius: 6
                                color: modelData.color
                                Label {
                                    anchors.centerIn: parent
                                    text: modelData.estadoLabel
                                    color: Common.Theme.panel2
                                    font.pixelSize: 12
                                    font.bold: true
                                }
                            }

                            Label {
                                text: modelData.rut
                                color: root.cTextMain
                                font.pixelSize: 13
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                            }

                            Label {
                                text: String(modelData.pagares)
                                color: root.cTextMuted
                                font.pixelSize: 12
                                horizontalAlignment: Text.AlignRight
                                Layout.preferredWidth: 64
                            }
                        }
                    }

                    // Empty state before any RUT marker arrives.
                    Label {
                        anchors.centerIn: parent
                        visible: rutList.count === 0
                        text: root.val("headline", "Preparando el proceso...")
                        color: root.cTextMuted
                        font.pixelSize: 13
                    }
                }
            }
        }
    }
}
