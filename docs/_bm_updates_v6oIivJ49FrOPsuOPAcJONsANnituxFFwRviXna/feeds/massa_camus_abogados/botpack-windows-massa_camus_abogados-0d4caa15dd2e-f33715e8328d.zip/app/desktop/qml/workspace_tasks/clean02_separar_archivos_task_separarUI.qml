import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2

    function validate() {
        // The input is FIXED at the bot's input/ folder — nothing to validate.
        return ""
    }

    function buildPayload() {
        // The input folder is fixed (input/); only the toggles travel.
        return {
            separar_force_fresh: forceFreshCheck.checked,
            separar_parallel: parallelCheck.checked
        }
    }

    function inputFolderUrl() {
        var base = String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
        if (base.length === 0)
            return "file:///"
        if (helpers && typeof helpers.localPathToFileUrl === "function")
            return helpers.localPathToFileUrl(base)
        return "file:///"
    }

    // -----------------------------------------------------------------------
    // Carpeta de PDFs (fija: input/) — botón para abrirla
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: pdfsCardLayout.implicitHeight + 18

        ColumnLayout {
            id: pdfsCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Carpeta de PDFs a separar"
                color: Common.Theme.text
                font.pixelSize: 13
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "El bot siempre procesa la carpeta input. Pega ahí los PDF escaneados (cada uno nombrado por su RUT). Usa el botón para abrirla, revisar su contenido o pegar los archivos."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Button {
                id: openPdfsButton
                text: "Abrir carpeta de pdfs"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.inputFolderUrl())
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: openPdfsButton.down ? Common.Theme.accent : Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: openPdfsButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: openPdfsButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: openPdfsButton.text
                    color: Common.Theme.text
                    font.pixelSize: 12
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Re-procesar desde cero (ignorar cache OCR)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: forceFreshLayout.implicitHeight + 18

        ColumnLayout {
            id: forceFreshLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: forceFreshCheck
                checked: true
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: forceFreshCheck.leftPadding
                    y: forceFreshCheck.height / 2 - height / 2
                    radius: 5
                    color: forceFreshCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: forceFreshCheck.checked ? 2 : 1
                    border.color: forceFreshCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: 14
                        font.bold: true
                        visible: forceFreshCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Re-procesar desde cero (ignorar cache)"
                    color: Common.Theme.text
                    font.pixelSize: 13
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: forceFreshCheck.indicator.width + forceFreshCheck.spacing
                }
            }

            Label {
                text: "Normalmente el bot reutiliza el OCR ya hecho para que volver a correr sea instantaneo. Marca esta casilla para volver a leer (OCR) todos los PDF desde cero, util si una corrida quedo a medias. Es mas lento."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // -----------------------------------------------------------------------
    // Procesar en paralelo (varios PDF a la vez)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: parallelLayout.implicitHeight + 18

        ColumnLayout {
            id: parallelLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: parallelCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: parallelCheck.leftPadding
                    y: parallelCheck.height / 2 - height / 2
                    radius: 5
                    color: parallelCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: parallelCheck.checked ? 2 : 1
                    border.color: parallelCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: 14
                        font.bold: true
                        visible: parallelCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Procesar en paralelo"
                    color: Common.Theme.text
                    font.pixelSize: 13
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: parallelCheck.indicator.width + parallelCheck.spacing
                }
            }

            Label {
                text: "Procesa varios PDF a la vez usando todos los nucleos del computador (deja uno libre). El resultado es identico al modo normal, solo que mas rapido. Marca esta casilla cuando tengas muchos PDF en la carpeta. El computador puede ir mas lento mientras corre."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Common.NotificationToast {
        id: errorNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
    }
}
