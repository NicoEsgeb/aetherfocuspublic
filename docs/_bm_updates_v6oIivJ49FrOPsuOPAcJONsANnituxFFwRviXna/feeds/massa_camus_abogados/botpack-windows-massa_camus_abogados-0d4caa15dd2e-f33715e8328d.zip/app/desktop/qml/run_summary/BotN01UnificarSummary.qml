import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Item {
    id: root
    clip: true
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarning: Common.Theme.warning

    readonly property var duplicateRowsModel: {
        if (!summaryData || summaryData.duplicateRows === undefined || summaryData.duplicateRows === null) {
            return []
        }
        return summaryData.duplicateRows
    }

    function hasData() {
        return !!summaryData && summaryData.hasData === true
    }

    function metricValue(key) {
        if (!hasData()) return "-"
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null) return "0"
        return String(summaryData[key])
    }

    function outputPath() {
        if (!summaryData || !summaryData.outputPath) return ""
        return String(summaryData.outputPath).trim()
    }

    function outputFolder() {
        var p = outputPath()
        if (p.length === 0) return ""
        var sep = p.lastIndexOf("\\")
        if (sep < 0) sep = p.lastIndexOf("/")
        if (sep < 0) return ""
        return p.substring(0, sep)
    }

    function hasDuplicates() {
        return root.duplicateRowsModel.length > 0
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 10
        visible: root.hasData()

        // ── Success banner ─────────────────────────────────────────────
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: successBannerCol.implicitHeight + 24
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: Common.Theme.success

            ColumnLayout {
                id: successBannerCol
                anchors.fill: parent
                anchors.margins: 12
                spacing: 10

                Row {
                    spacing: 8

                    Label {
                        text: "\u2714"
                        color: root.cSuccess
                        font.pixelSize: 20
                        font.bold: true
                    }

                    Label {
                        text: "Planilla Unificada creada"
                        color: root.cSuccess
                        font.pixelSize: 16
                        font.bold: true
                    }
                }

                Button {
                    id: abrirUbicacionButton
                    visible: root.outputFolder().length > 0
                    text: "Abrir ubicacion de Planilla Unificada"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.outputFolder()
                        if (folder.length > 0 && typeof controller !== "undefined" && controller !== null) {
                            controller.openPathInExplorer(folder)
                        }
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: abrirUbicacionButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: abrirUbicacionButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: abrirUbicacionButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: abrirUbicacionButton.text
                        color: Common.Theme.text
                        font.pixelSize: 12
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }

        // ── Metric cards ───────────────────────────────────────────────
        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            // Total Roles procesados
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.preferredHeight: 108
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: root.cLine

                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    Label {
                        text: "Roles Procesados"
                        color: root.cTextMuted
                        font.pixelSize: 12
                    }

                    Label {
                        text: root.metricValue("totalCombined")
                        color: root.cTextMain
                        font.pixelSize: 34
                        font.bold: true
                    }
                }
            }

            // Filas duplicadas
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.preferredHeight: 108
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: Common.Theme.warningSoft

                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    Row {
                        spacing: 6

                        Label {
                            text: "\u2022"
                            color: root.cWarning
                            font.pixelSize: 14
                            font.bold: true
                        }

                        Label {
                            text: "Filas Duplicadas"
                            color: root.cTextMuted
                            font.pixelSize: 12
                        }
                    }

                    Label {
                        text: root.metricValue("totalDuplicates")
                        color: root.cWarning
                        font.pixelSize: 34
                        font.bold: true
                    }
                }
            }

            // Filas en archivo final
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.preferredHeight: 108
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: Common.Theme.success

                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    Row {
                        spacing: 6

                        Label {
                            text: "\u2714"
                            color: root.cSuccess
                            font.pixelSize: 14
                            font.bold: true
                        }

                        Label {
                            text: "Filas en Archivo Final"
                            color: root.cTextMuted
                            font.pixelSize: 12
                        }
                    }

                    Label {
                        text: root.metricValue("totalUnique")
                        color: root.cSuccess
                        font.pixelSize: 34
                        font.bold: true
                    }
                }
            }
        }

        // ── Duplicates table ───────────────────────────────────────────
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 10
                spacing: 8

                Label {
                    text: "Detalle de Filas Duplicadas"
                    color: root.cTextMain
                    font.pixelSize: 13
                    font.bold: true
                }

                // Table header
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 34
                    radius: 8
                    color: Common.Theme.panel2
                    border.width: 1
                    border.color: root.cLine

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 10

                        Label {
                            Layout.preferredWidth: 120
                            text: "Rol"
                            color: root.cTextMain
                            font.bold: true
                            font.pixelSize: 12
                        }

                        Label {
                            Layout.preferredWidth: 100
                            text: "Fecha Ingreso"
                            color: root.cTextMain
                            font.bold: true
                            font.pixelSize: 12
                        }

                        Label {
                            Layout.fillWidth: true
                            text: "Caratulado"
                            color: root.cTextMain
                            font.bold: true
                            font.pixelSize: 12
                            elide: Text.ElideRight
                        }

                        Label {
                            Layout.preferredWidth: 160
                            text: "Tribunal"
                            color: root.cTextMain
                            font.bold: true
                            font.pixelSize: 12
                            elide: Text.ElideRight
                        }
                    }
                }

                // Table rows
                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    ListView {
                        id: dupRowsView
                        anchors.fill: parent
                        model: root.duplicateRowsModel
                        clip: true
                        spacing: 4
                        visible: root.hasDuplicates()

                        ScrollBar.vertical: Common.StyledScrollBar {
                            policy: ScrollBar.AsNeeded
                        }

                        delegate: Rectangle {
                            width: ListView.view.width
                            height: 34
                            radius: 8
                            color: index % 2 === 0 ? Common.Theme.panel2 : Common.Theme.panel2
                            border.width: 1
                            border.color: Common.Theme.line

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 8
                                spacing: 10

                                Label {
                                    Layout.preferredWidth: 120
                                    text: modelData.rol || "-"
                                    color: root.cWarning
                                    font.pixelSize: 12
                                    font.bold: true
                                    elide: Text.ElideRight
                                }

                                Label {
                                    Layout.preferredWidth: 100
                                    text: modelData.fechaIngreso || "-"
                                    color: root.cTextMain
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                }

                                Label {
                                    Layout.fillWidth: true
                                    text: modelData.caratulado || "-"
                                    color: root.cTextMain
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                }

                                Label {
                                    Layout.preferredWidth: 160
                                    text: modelData.tribunal || "-"
                                    color: root.cTextMain
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                }
                            }
                        }
                    }

                    Label {
                        anchors.centerIn: parent
                        visible: !dupRowsView.visible
                        text: "No se encontraron filas duplicadas."
                        color: root.cTextMuted
                        font.pixelSize: 13
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
            }
        }
    }

    // ── No data fallback ───────────────────────────────────────────
    Rectangle {
        visible: !root.hasData()
        anchors.fill: parent
        radius: 12
        color: root.cPanel
        border.width: 1
        border.color: root.cLine

        Label {
            anchors.centerIn: parent
            text: "Sin datos disponibles para esta corrida."
            color: root.cTextMuted
            font.pixelSize: 13
            horizontalAlignment: Text.AlignHCenter
        }
    }
}
