"""
Clean07 - Ingresar Demandas BBRR (PJUD, atendido con extensión de Chrome).

El humano abre su Chrome normal e inicia sesión a mano en la Oficina Judicial
Virtual. Esta task valida las entradas y expone un bridge en localhost al que se
conecta la extensión Clean07. La navegación dentro del portal se agregará cuando
el cliente defina el recorrido.

tasks.py se mantiene DELGADO: toda la lógica vive en functions.py.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from robocorp.tasks import task

from functions import (
    REQUIRED_COLUMNS,
    RESULT_EXCEL_FILENAME,
    InputError,
    MissingColumnsError,
    build_bridge_state,
    run_bridge_session,
    write_bridge_receipt,
    write_result_excel,
)

PATH_BOT = str(Path(__file__).parent)
PLANILLA_DIR = Path(PATH_BOT) / "input" / "planilla_ingreso"


def _default_planilla() -> str:
    """Fall back to the single workbook in input/planilla_ingreso.

    The desktop panel always sends PLANILLA_PATH; this only matters when the
    task is run straight from the command line.
    """
    candidates = sorted(
        p for p in PLANILLA_DIR.glob("*.xls*")
        if p.is_file() and not p.name.startswith("~$")
    )
    if candidates:
        return str(candidates[0])
    return str(PLANILLA_DIR / "Planilla_Ingreso_Demandas.xlsx")


PLANILLA_PATH = os.getenv("PLANILLA_PATH", "").strip() or _default_planilla()
# All four folders are FIXED (the planilla points at their files with
# relative paths), so the panel only offers buttons to open each one:
#   01_mandatos     — the 5 shared documents, same on every filing
#   02_contratos    — per-row contratos, referenced by 6_Contrato_CPSB
#   03_demandas     — flat, one signed demanda PDF per RUT (<RUT-DV>_DEMANDA_firmado.pdf)
#   04_Carpeta-Ruts — per-RUT subfolders with the rest of that row's documents
#                     (this is what "03_demandas" used to be, before it split)
MANDATOS_FOLDER_PATH = os.getenv(
    "MANDATOS_FOLDER_PATH", ""
).strip() or str(Path(PATH_BOT) / "input" / "01_mandatos")
CONTRATOS_FOLDER_PATH = os.getenv(
    "CONTRATOS_FOLDER_PATH", ""
).strip() or str(Path(PATH_BOT) / "input" / "02_contratos")
DEMANDAS_FOLDER_PATH = os.getenv(
    "DEMANDAS_FOLDER_PATH", ""
).strip() or str(Path(PATH_BOT) / "input" / "03_demandas")
CARPETA_RUTS_FOLDER_PATH = os.getenv(
    "CARPETA_RUTS_FOLDER_PATH", ""
).strip() or str(Path(PATH_BOT) / "input" / "04_Carpeta-Ruts")

CLEAN07_BRIDGE_HOST = os.getenv("CLEAN07_BRIDGE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    CLEAN07_BRIDGE_PORT = max(1, min(65535, int(os.getenv("CLEAN07_BRIDGE_PORT", "8768"))))
except ValueError:
    CLEAN07_BRIDGE_PORT = 8768
try:
    CLEAN07_TIMEOUT_MINUTES = max(5, int(os.getenv("CLEAN07_TIMEOUT_MINUTES", "120")))
except ValueError:
    CLEAN07_TIMEOUT_MINUTES = 120


def _new_run_dir() -> str:
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M")
    run_dir = output_root / f"Clean07_Demandas_{timestamp}"
    suffix = 2
    while run_dir.exists():
        run_dir = output_root / f"Clean07_Demandas_{timestamp}_{suffix}"
        suffix += 1
    run_dir.mkdir(parents=True, exist_ok=True)
    return str(run_dir)


@task
def CLEAN07_INGRESAR_DEMANDAS_BBRR():
    """Validar planilla + demandas y enlazar con la extensión de Chrome."""
    # Validate before creating the run folder so a rejected input leaves no
    # empty evidence directory behind.
    try:
        state = build_bridge_state(
            PLANILLA_PATH,
            MANDATOS_FOLDER_PATH,
            CONTRATOS_FOLDER_PATH,
            DEMANDAS_FOLDER_PATH,
            CARPETA_RUTS_FOLDER_PATH,
        )
    except MissingColumnsError as exc:
        print("=" * 72)
        print("CLEAN07: LA PLANILLA NO TIENE LAS COLUMNAS NECESARIAS")
        print(f"  Excel: {PLANILLA_PATH}")
        print(f"  Hoja revisada: {exc.sheet_name}")
        print("")
        print(f"  Faltan {len(exc.missing)} columna(s):")
        for column in exc.missing:
            print(f"    - {column}")
        print("")
        print(f"  Columnas requeridas: {', '.join(REQUIRED_COLUMNS)}")
        print(f"  Columnas encontradas: {', '.join(exc.found) or '(ninguna)'}")
        print("")
        print("  Corrige la planilla y vuelve a iniciar el bot.")
        print("=" * 72)
        # Structured markers consumed by Main.qml to build the desktop
        # notification. Keep the format stable.
        print(f"[CLEAN07][COLUMNAS_FALTANTES] {' | '.join(exc.missing)}")
        print(f"[CLEAN07][COLUMNAS_HOJA] {exc.sheet_name}")
        print(f"[CLEAN07][ARCHIVO] {Path(PLANILLA_PATH).name}")
        raise
    except InputError as exc:
        print("=" * 72)
        print("CLEAN07: NO SE PUEDE INICIAR CON LAS ENTRADAS ACTUALES")
        print(f"  {exc}")
        if exc.detail:
            print(f"  Detalle: {exc.detail}")
        print("=" * 72)
        print(f"[CLEAN07][ENTRADA_INVALIDA] {exc}")
        print(f"[CLEAN07][ENTRADA_MOTIVO] {exc.reason}")
        if exc.detail:
            print(f"[CLEAN07][ENTRADA_DETALLE] {exc.detail}")
        raise

    run_dir = _new_run_dir()
    summary = state.summary()
    workbook = summary["workbook"]
    demandas = summary["demandas"]
    mandatos = summary["mandatos"]
    contratos = summary["contratos"]
    carpeta_ruts = summary["carpeta_ruts"]

    print("=" * 72)
    print("CLEAN07_INGRESAR_DEMANDAS_BBRR")
    print(f"  Planilla: {PLANILLA_PATH}")
    print(f"  Hoja de datos: {workbook['sheet_name']}")
    print(f"  Columnas requeridas: OK ({len(REQUIRED_COLUMNS)} columnas)")
    print(f"  Filas de datos: {summary['row_total']}")
    print(f"  Carpeta 01_mandatos: {mandatos['path']} ({mandatos['file_count']} archivo(s), OK)")
    print(
        f"  Carpeta 02_contratos: {contratos['path']} "
        f"({contratos['referenced_count']} referenciado(s) de {contratos['file_count']} en disco, OK)"
    )
    print(
        f"  Carpeta 03_demandas: {demandas['path']} "
        f"({demandas['pdf_count']} demanda(s) firmada(s), OK)"
    )
    print(
        f"  Carpeta 04_Carpeta-Ruts: {carpeta_ruts['path']} "
        f"({carpeta_ruts['pdf_count']} PDF(s) en {carpeta_ruts['subfolder_count']} subcarpeta(s))"
    )
    print(f"  Extension Chrome: {Path(PATH_BOT) / 'extension'}")
    print(f"  Bridge: http://{CLEAN07_BRIDGE_HOST}:{CLEAN07_BRIDGE_PORT}")
    print(f"  Evidencia: {run_dir}")
    print("")
    print("Pasos:")
    print("  1. Abre Chrome e inicia sesion manualmente en la Oficina Judicial Virtual.")
    print("  2. Ve a https://oficinajudicialvirtual.pjud.cl/indexN.php")
    print("  3. Presiona Start en el panel Clean07 y deja la pestana visible.")
    print("=" * 72)
    print(f"[CLEAN07][ARCHIVO] {workbook['filename']}")
    print(f"[CLEAN07][CARPETA_DEMANDAS] {demandas['path']}")

    # Write the audit trail BEFORE the browser does anything: every RUT in
    # the planilla, all "No procesada". run_bridge_session refreshes it as
    # the run progresses and it is written once more at the end — so the
    # file exists, and is current, no matter how the run ends.
    result_target = Path(run_dir) / RESULT_EXCEL_FILENAME
    write_result_excel(state.results, result_target)

    final_summary = run_bridge_session(
        state=state,
        host=CLEAN07_BRIDGE_HOST,
        port=CLEAN07_BRIDGE_PORT,
        timeout_seconds=CLEAN07_TIMEOUT_MINUTES * 60,
        output_dir=run_dir,
    )
    receipt_path = write_bridge_receipt(final_summary, run_dir)
    # Written unconditionally, success or failure — a run that stops
    # partway must still tell the operator what was and wasn't attempted.
    result_path = write_result_excel(state.results, result_target)
    print(f"[CLEAN07][RESULTADO] {result_path}")

    print("Clean07: sesion finalizada.")
    for entry in final_summary.get("logs", []):
        print(f"Clean07: {entry}")
    connected = "si" if final_summary.get("started") else "no"
    print(f"[CLEAN07][CONEXION] conectado={connected} url={final_summary.get('portal_url') or '-'}")
    print(
        f"[CLEAN07][RESUMEN] filas={final_summary.get('row_total', 0)} "
        f"pdfs={demandas['pdf_count']} conectado={connected} "
        f"pasos={final_summary.get('steps_done', 0)} "
        f"ultimo_paso={final_summary.get('last_step_done', 0)}"
    )
    completion = str(final_summary.get("completion_message") or "")
    if completion:
        print(f"[CLEAN07][FIN] {completion}")
    print(f"Clean07: evidencia={receipt_path}")

    step_error = str(final_summary.get("error") or "")
    if step_error:
        print(f"[CLEAN07][PASO_ERROR] {step_error}")
        raise RuntimeError(f"Clean07 se detuvo por un error grave. {step_error}")

    print("Done")
