// Clean07 uses its own loopback port so it can run alongside N03 (8765) and
// Clean05 (8766) without either bridge answering the other's extension.
const BRIDGE_BASE_URL = "http://127.0.0.1:8768";
const MESSAGE_TYPE = "CLEAN07_BRIDGE_REQUEST";
// Must list every route Clean07BridgeHandler serves in functions.py. A missing
// entry is silent here but catastrophic on the portal: the step result never
// reaches the bridge, so /next keeps handing out the SAME step and the
// extension repeats it until the PJUD WAF blocks the session.
const ALLOWED_PATHS = new Set(["/health", "/start", "/log", "/next", "/report"]);
// /file?row=N (functions.py's _serve_demanda_file) is the one route with a
// dynamic query string, so it can't live in the exact-match set above.
function isFileRoute(path) {
  return path.startsWith("/file?row=");
}

// Chunked to avoid blowing the call stack on String.fromCharCode(...bytes)
// for a larger PDF.
function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

async function bridgeRequest(path, options = {}) {
  if (!ALLOWED_PATHS.has(path) && !isFileRoute(path)) {
    return { ok: false, error: `Ruta de bridge no permitida: ${path}` };
  }
  const response = await fetch(`${BRIDGE_BASE_URL}${path}`, {
    method: options.method || "GET",
    headers: { "Content-Type": "application/json" },
    body: Object.prototype.hasOwnProperty.call(options, "body")
      ? JSON.stringify(options.body)
      : undefined
  });
  if (isFileRoute(path)) {
    // The page is HTTPS and the bridge is plain HTTP — a content script
    // fetching this directly would be blocked as mixed content, which is
    // exactly why this relay exists. Binary can't go through JSON, so it is
    // base64-encoded here for the message-passing hop back to content.js.
    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      return { ok: false, error: payload.error || `Bridge ${response.status}` };
    }
    const buffer = await response.arrayBuffer();
    return {
      ok: true,
      filename: response.headers.get("X-Filename") || "documento.pdf",
      content_base64: arrayBufferToBase64(buffer)
    };
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    return { ok: false, error: payload.error || `Bridge ${response.status}` };
  }
  return payload;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== MESSAGE_TYPE) {
    return false;
  }
  bridgeRequest(message.path || "/health", message.options || {})
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({
      ok: false,
      error: String(error && error.message ? error.message : error)
    }));
  return true;
});
