import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property color textMuted: Common.Theme.text2

    Common.BotInfoHeader {
        themeSource: Common.Theme
        Layout.fillWidth: true

        Rectangle {
            radius: 6
            color: Common.Theme.accentSoft
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: cleanBadge.implicitWidth + 16
            implicitHeight: cleanBadge.implicitHeight + 8

            Label {
                id: cleanBadge
                anchors.centerIn: parent
                text: "Clean BBRR"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }

        Rectangle {
            radius: 6
            color: "#163d4d"
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: chromeBadge.implicitWidth + 16
            implicitHeight: chromeBadge.implicitHeight + 8

            Label {
                id: chromeBadge
                anchors.centerIn: parent
                text: "Chrome + bridge"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Qué hace este bot"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Clean08 valida la planilla y luego se conecta, mediante una extensión local de Chrome, a la sesión abierta de la Oficina Judicial Virtual. El primer paso implementado abre la opción Ingresar Escrito."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: inputsLayout.implicitHeight + 20

        ColumnLayout {
            id: inputsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Entradas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "1. input/escritos-pdfs — carpeta fija para los escritos en PDF.\n" +
                      "2. input/planilla — carpeta inicial del selector de la planilla Excel.\n\n" +
                      "La planilla debe incluir una hoja Hoja1 y las columnas Tribunal, ROL, Año y Archivo. Los nombres se validan sin distinguir mayúsculas y minúsculas."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.warningSoft
        border.width: 1
        border.color: Common.Theme.warning
        implicitHeight: pendingLayout.implicitHeight + 20

        ColumnLayout {
            id: pendingLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 4

            Label {
                text: "Validación inicial"
                color: Common.Theme.warning
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Antes de abrir el bridge, Clean08 comprueba la hoja Hoja1, las cuatro columnas obligatorias, que exista al menos una fila con información y que ninguna fila tenga celdas obligatorias vacías. Si encuentra un problema, se detiene y muestra el detalle en una notificación."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: extensionLayout.implicitHeight + 20

        ColumnLayout {
            id: extensionLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Extensión atendida · Step 1"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Carga como extensión descomprimida la carpeta extension de Clean08. Después de pulsar Iniciar y superar la validación, abre la página indexN.php del portal y pulsa Start en el panel Clean08. El bridge local usa 127.0.0.1:8769 y la extensión hace clic una sola vez en Ingresar Escrito."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
