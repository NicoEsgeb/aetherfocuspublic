import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2
    property string planillaPath: ""

    signal planillaPathEdited(string value)

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona la planilla de ingreso antes de ejecutar."
        }
        var lower = path.toLowerCase()
        if (!lower.endsWith(".xlsx") && !lower.endsWith(".xlsm")) {
            return "La planilla debe ser un archivo Excel .xlsx o .xlsm."
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim()
        }
    }

    function inputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function subFolderUrl(subFolder) {
        var base = root.inputFolder()
        if (base.length === 0) {
            return "file:///"
        }
        return root.toFileUrl(base + "/" + subFolder)
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: escritosLayout.implicitHeight + 18

        ColumnLayout {
            id: escritosLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Carpeta de entrada"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            Label {
                text: "Guarda en input/escritos-pdfs los escritos en PDF que utilizará el bot. Esta es una carpeta fija: el botón la abre para que puedas agregar o revisar los archivos."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openEscritosButton
                Layout.fillWidth: true
                text: "Abrir carpeta Escritos pdf"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("escritos-pdfs"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.line
                    color: openEscritosButton.down ? Common.Theme.accentSoft : Common.Theme.panel2
                }
                contentItem: Text {
                    text: openEscritosButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaLayout.implicitHeight + 18

        ColumnLayout {
            id: planillaLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Planilla de ingreso"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            Label {
                text: "Guarda la planilla Excel en input/planilla y selecciónala antes de iniciar. Debe contener una hoja Hoja1 con las columnas Tribunal, ROL, Año y Archivo. Las mayúsculas y minúsculas no afectan la validación."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            TextField {
                id: planillaField
                Layout.fillWidth: true
                text: root.planillaPath
                color: Common.Theme.text
                placeholderText: "Ninguna planilla seleccionada"
                placeholderTextColor: Common.Theme.text3
                readOnly: true
                background: Rectangle {
                    radius: 8
                    color: Common.Theme.panel2
                    border.width: planillaField.activeFocus ? 2 : 1
                    border.color: planillaField.activeFocus ? Common.Theme.accent : Common.Theme.line
                }
            }

            Common.InsetAlloyButton {
                id: selectPlanillaButton
                text: "Seleccionar planilla"
                hoverEnabled: true
                onClicked: {
                    planillaDialog.currentFolder = root.subFolderUrl("planilla")
                    planillaDialog.open()
                }
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.accent
                    color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accentSoft
                }
                contentItem: Text {
                    text: selectPlanillaButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.accentSoft
        border.width: 1
        border.color: Common.Theme.accent
        implicitHeight: bridgeLayout.implicitHeight + 18

        ColumnLayout {
            id: bridgeLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 5

            Label {
                text: "Paso atendido en Chrome"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            Label {
                text: "Al pulsar Iniciar, primero se valida toda la planilla. Si es válida, Clean08 espera la conexión de su extensión. En indexN.php pulsa Start en el panel Clean08; por ahora el bot ejecutará únicamente el clic en Ingresar Escrito."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    FileDialog {
        id: planillaDialog
        title: "Seleccionar planilla de ingreso para Clean08"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: {
            root.planillaPath = root.toLocalPath(selectedFile)
            root.planillaPathEdited(root.planillaPath)
        }
    }
}
