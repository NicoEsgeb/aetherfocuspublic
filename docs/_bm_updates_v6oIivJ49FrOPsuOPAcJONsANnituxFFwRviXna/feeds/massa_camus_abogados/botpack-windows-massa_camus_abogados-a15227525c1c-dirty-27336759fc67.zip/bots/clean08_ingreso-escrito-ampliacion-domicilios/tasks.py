"""Clean08 - Ingreso Escrito Ampliacion de Domicilios.

La task conecta las entradas configuradas en la interfaz con ``functions.py``.
Tras validar la planilla, levanta el bridge atendido para la extension Chrome.

tasks.py se mantiene DELGADO: toda la logica vive en functions.py.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Habilita futuros imports desde bots/shared/ sin acoplar este scaffold a un
# modulo compartido antes de conocer el recorrido real del bot.
BOT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BOT_DIR.parent))

from robocorp.tasks import task

from functions import (
    EmptyPlanillaError,
    IncompleteRowsError,
    InputError,
    MissingColumnsError,
    run_ingreso_escrito_ampliacion_domicilios,
)


ESCRITOS_PDFS_FOLDER_PATH = os.getenv(
    "ESCRITOS_PDFS_FOLDER_PATH", ""
).strip() or str(BOT_DIR / "input" / "escritos-pdfs")
PLANILLA_DIR = BOT_DIR / "input" / "planilla"


def _default_planilla_path() -> str:
    """Usar la primera planilla local al ejecutar fuera de BotManager."""
    candidates = sorted(
        path
        for path in PLANILLA_DIR.iterdir()
        if path.is_file()
        and not path.name.startswith("~$")
        and path.suffix.lower() in {".xlsx", ".xlsm"}
    ) if PLANILLA_DIR.exists() else []
    if candidates:
        return str(candidates[0])
    return str(PLANILLA_DIR / "planilla_ingreso.xlsx")


PLANILLA_PATH = os.getenv("PLANILLA_PATH", "").strip() or _default_planilla_path()
BRIDGE_HOST = os.getenv("CLEAN08_BRIDGE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    BRIDGE_PORT = max(1, min(65535, int(os.getenv("CLEAN08_BRIDGE_PORT", "8769"))))
except ValueError:
    BRIDGE_PORT = 8769
try:
    BRIDGE_TIMEOUT_SECONDS = max(
        30,
        int(os.getenv("CLEAN08_BRIDGE_TIMEOUT_SECONDS", "7200")),
    )
except ValueError:
    BRIDGE_TIMEOUT_SECONDS = 7200


@task
def CLEAN08_INGRESO_ESCRITO_AMPLIACION_DOMICILIOS():
    """Preparar las entradas del flujo de ampliacion de domicilios."""
    try:
        run_ingreso_escrito_ampliacion_domicilios(
            escritos_pdfs_folder=ESCRITOS_PDFS_FOLDER_PATH,
            planilla_path=PLANILLA_PATH,
            output_folder=str(BOT_DIR / "output"),
            bridge_host=BRIDGE_HOST,
            bridge_port=BRIDGE_PORT,
            bridge_timeout_seconds=BRIDGE_TIMEOUT_SECONDS,
        )
    except MissingColumnsError as exc:
        print("=" * 72)
        print("CLEAN08: LA PLANILLA NO TIENE LAS COLUMNAS NECESARIAS")
        print(f"  Excel: {PLANILLA_PATH}")
        print(f"  Hoja revisada: {exc.sheet_name}")
        print(f"  Columnas faltantes: {', '.join(exc.missing)}")
        print(f"  Columnas encontradas: {', '.join(exc.found) or '(ninguna)'}")
        print("  Corrige la planilla y vuelve a iniciar el bot.")
        print("=" * 72)
        print(f"[CLEAN08][COLUMNAS_FALTANTES] {' | '.join(exc.missing)}")
        print(f"[CLEAN08][COLUMNAS_HOJA] {exc.sheet_name}")
        print(f"[CLEAN08][COLUMNAS_ENCONTRADAS] {' | '.join(exc.found)}")
        print(f"[CLEAN08][ARCHIVO] {Path(PLANILLA_PATH).name}")
        raise
    except EmptyPlanillaError as exc:
        print("=" * 72)
        print("CLEAN08: LA PLANILLA NO TIENE FILAS PARA PROCESAR")
        print(f"  Excel: {PLANILLA_PATH}")
        print(f"  Hoja revisada: {exc.sheet_name}")
        print("  Agrega al menos una fila completa y vuelve a iniciar el bot.")
        print("=" * 72)
        print(f"[CLEAN08][SIN_FILAS] {exc.sheet_name}")
        print(f"[CLEAN08][ARCHIVO] {Path(PLANILLA_PATH).name}")
        raise
    except IncompleteRowsError as exc:
        print("=" * 72)
        print("CLEAN08: HAY FILAS CON DATOS OBLIGATORIOS VACIOS")
        print(f"  Excel: {PLANILLA_PATH}")
        print(f"  Hoja revisada: {exc.sheet_name}")
        for issue in exc.issues:
            print(
                f"  Fila {issue['row']}: falta(n) "
                f"{', '.join(issue['missing'])}"
            )
        print("  Completa las filas indicadas y vuelve a iniciar el bot.")
        print("=" * 72)
        print(f"[CLEAN08][FILAS_INCOMPLETAS] {len(exc.issues)}")
        for issue in exc.issues:
            print(
                f"[CLEAN08][FILA_INCOMPLETA] Fila {issue['row']}: "
                f"{' | '.join(issue['missing'])}"
            )
        print(f"[CLEAN08][ARCHIVO] {Path(PLANILLA_PATH).name}")
        raise
    except InputError as exc:
        print("=" * 72)
        print("CLEAN08: NO SE PUEDE INICIAR CON LA PLANILLA SELECCIONADA")
        print(f"  {exc}")
        if exc.detail:
            print(f"  Detalle: {exc.detail}")
        print("=" * 72)
        print(f"[CLEAN08][ENTRADA_INVALIDA] {exc}")
        print(f"[CLEAN08][ENTRADA_MOTIVO] {exc.reason}")
        if exc.detail:
            print(f"[CLEAN08][ENTRADA_DETALLE] {exc.detail}")
        print(f"[CLEAN08][ARCHIVO] {Path(PLANILLA_PATH).name}")
        raise
