"""Loopback bridge for Clean08's attended Chrome extension."""
from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


EXTENSION_BUILD = "v0.1.0"
STEP_ACTION = "click_ingresar_escrito"


class BridgeError(RuntimeError):
    """Raised when an attended bridge session cannot complete safely."""


@dataclass
class BridgeState:
    """One guarded instruction shared by BotManager and the extension."""

    summary_data: dict[str, Any]
    started_at: float = 0.0
    extension_seen_at: float = 0.0
    finished: bool = False
    step_issued: bool = False
    step_completed: bool = False
    error: str = ""
    completion_message: str = ""
    portal_url: str = ""
    portal_title: str = ""
    logs: list[str] = field(default_factory=list)
    lock: threading.Lock = field(default_factory=threading.Lock)
    done_event: threading.Event = field(default_factory=threading.Event)

    def touch(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        return {
            **self.summary_data,
            "started": bool(self.started_at),
            "finished": self.finished,
            "step_completed": self.step_completed,
            "error": self.error,
            "message": self.completion_message,
        }

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.extension_seen_at = time.time()
            build = str(payload.get("build") or "").strip()
            if build != EXTENSION_BUILD:
                self.error = (
                    f"La extension Clean08 cargada ({build or 'sin version'}) no "
                    f"coincide con el bot ({EXTENSION_BUILD}). Recargala en "
                    "chrome://extensions y vuelve a cargar la pagina del portal."
                )
                self.completion_message = "Clean08 se detuvo antes de tocar el portal."
                self.finished = True
                self.done_event.set()
                return {
                    "ok": False,
                    "done": True,
                    "error": self.error,
                    "message": self.completion_message,
                    "summary": self._summary_unlocked(),
                }

            if not self.started_at:
                self.started_at = time.time()
                self.portal_url = str(payload.get("url") or "")
                self.portal_title = str(payload.get("title") or "")
                self.logs.append(f"Start recibido desde {self.portal_url or '(sin URL)'}")
            return {
                "ok": True,
                "done": False,
                "message": "Conexion confirmada. Ejecutando Step 1...",
                "summary": self._summary_unlocked(),
            }

    def next_action(self) -> dict[str, Any]:
        with self.lock:
            self.extension_seen_at = time.time()
            if self.finished:
                return {
                    "action": "done",
                    "error": self.error,
                    "message": self.completion_message,
                }
            if not self.started_at:
                return {"action": "wait", "message": "Esperando Start."}
            if self.step_issued:
                # The extension has the instruction and has not reported it yet.
                # Never issue a second click while the first result is unknown.
                return {"action": "wait", "message": "Esperando resultado de Step 1."}

            self.step_issued = True
            return {
                "action": STEP_ACTION,
                "step_number": 1,
                "step_total": 1,
                "label": "Ingresar Escrito",
            }

    def report(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.extension_seen_at = time.time()
            if self.finished:
                return {
                    "ok": True,
                    "done": True,
                    "error": self.error,
                    "message": self.completion_message,
                }
            if not self.step_issued:
                return {
                    "ok": False,
                    "done": False,
                    "error": "La extension informo un resultado sin un paso activo.",
                }

            detail = str(payload.get("detail") or "").strip()
            if bool(payload.get("ok")):
                self.step_completed = True
                self.completion_message = (
                    detail or 'Step 1 completado: se hizo clic en "Ingresar Escrito".'
                )
                self.logs.append(self.completion_message)
            else:
                self.error = detail or "La extension no pudo completar Step 1."
                self.completion_message = "Clean08 se detuvo en Step 1."
                self.logs.append(self.error)

            self.finished = True
            self.done_event.set()
            return {
                # The HTTP exchange succeeded even when the portal action did
                # not. Keep transport success separate from action failure so
                # the panel can render the desktop's final error cleanly.
                "ok": True,
                "done": True,
                "error": self.error,
                "message": self.completion_message,
                "summary": self._summary_unlocked(),
            }

    def add_log(self, message: str) -> None:
        clean = str(message or "").strip()
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean)


class Clean08BridgeServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], state: BridgeState):
        super().__init__(address, Clean08BridgeHandler)
        self.state = state


class Clean08BridgeHandler(BaseHTTPRequestHandler):
    server: Clean08BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self) -> None:
        if self.path == "/health":
            self.server.state.touch()
            self._json({
                "ok": True,
                "name": "Clean08 PJUD bridge",
                "build": EXTENSION_BUILD,
                "summary": self.server.state.summary(),
            })
            return
        self._json({"ok": False, "error": "Ruta no encontrada."}, 404)

    def do_POST(self) -> None:
        if self.path == "/start":
            self._json(self.server.state.register_start(self._read_json()))
            return
        if self.path == "/next":
            self._json({"ok": True, "step": self.server.state.next_action()})
            return
        if self.path == "/report":
            self._json(self.server.state.report(self._read_json()))
            return
        if self.path == "/log":
            message = str(self._read_json().get("message") or "")
            self.server.state.add_log(message)
            print(f"[CLEAN08][EXT] {message}")
            self._json({"ok": True})
            return
        self._json({"ok": False, "error": "Ruta no encontrada."}, 404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return value if isinstance(value, dict) else {}

    def _json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")


def run_bridge_session(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
) -> dict[str, Any]:
    """Run the bridge until Step 1 completes, fails, or times out."""
    try:
        server = Clean08BridgeServer((host, port), state)
    except OSError as exc:
        raise BridgeError(
            f"No se pudo abrir el bridge local en {host}:{port}. "
            "Puede que otra ejecucion de Clean08 siga abierta."
        ) from exc

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"[CLEAN08][BRIDGE_LISTO] http://{host}:{port}")
    print("[CLEAN08][ESPERANDO_START] Abre indexN.php y presiona Start en la extension.")
    try:
        if not state.done_event.wait(timeout_seconds):
            raise BridgeError(
                "Tiempo de espera agotado: no se completo Step 1 desde la extension Clean08."
            )
        result = state.summary()
        if result["error"]:
            raise BridgeError(result["error"])
        return result
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
