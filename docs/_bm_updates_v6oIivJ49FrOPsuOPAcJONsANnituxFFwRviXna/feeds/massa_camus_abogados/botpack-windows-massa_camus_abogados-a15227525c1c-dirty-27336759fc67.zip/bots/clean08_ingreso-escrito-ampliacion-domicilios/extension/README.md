# Clean08 Chrome extension (local)

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select this `extension` folder.
4. Start Clean08 in BotManager after selecting the workbook.
5. In the authenticated PJUD `indexN.php` page, press **Start** in the Clean08 panel.

The extension talks only to the Clean08 loopback bridge at
`http://127.0.0.1:8769`. The current build executes only Step 1: click the
visible menu item **Ingresar Escrito**.
