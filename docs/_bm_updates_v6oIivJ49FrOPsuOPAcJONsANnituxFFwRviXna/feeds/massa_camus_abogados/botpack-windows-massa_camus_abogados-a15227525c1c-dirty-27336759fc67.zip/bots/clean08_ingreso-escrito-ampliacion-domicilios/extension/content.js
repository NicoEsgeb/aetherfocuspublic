(() => {
  const MESSAGE_TYPE = "CLEAN08_BRIDGE_REQUEST";
  const PANEL_ID = "clean08-pjud-panel";
  const BUILD = "v0.1.0";
  const START_PAGE = "indexn.php";
  const SIBLING_PANEL_IDS = [
    "clean07-pjud-panel",
    "rpa01-pjud-panel",
    "n03-pjud-panel"
  ];

  let connected = false;
  let starting = false;
  let verified = false;
  let busy = false;
  let completed = false;
  let workTimer = 0;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) return existing;

    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean08-title">Clean08 · Ampliación Domicilios · ${BUILD}</div>
      <div class="clean08-status" data-role="status">Esperando BotManager...</div>
      <div class="clean08-details" data-role="details">Planilla sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    positionPanel();
    return panel;
  }

  function positionPanel() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;
    let offset = 14;
    for (const id of SIBLING_PANEL_IDS) {
      const sibling = document.getElementById(id);
      if (sibling) offset += sibling.offsetHeight + 10;
    }
    panel.style.bottom = `${offset}px`;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean08-ok", tone === "ok");
    status.classList.toggle("clean08-error", tone === "error");
  }

  function renderSummary(summary) {
    const details = createPanel().querySelector('[data-role="details"]');
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const escritos = summary && summary.escritos ? summary.escritos : {};
    if (!workbook.filename) {
      details.textContent = "Planilla sin confirmar";
      return;
    }
    details.textContent = `${workbook.filename} · ${summary.row_total || 0} fila(s) · `
      + `${escritos.pdf_count || 0} PDF(s)`;
  }

  function foldLabel(value) {
    return String(value == null ? "" : value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function isVisible(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function findIngresarEscrito() {
    const wanted = foldLabel("Ingresar Escrito");
    const labels = Array.from(document.querySelectorAll(
      ".pg_menu_lt span, .list-group-item span"
    ));
    return labels.find((element) => (
      isVisible(element) && foldLabel(element.textContent) === wanted
    )) || null;
  }

  function waitFor(probe, timeoutMs, errorMessage) {
    return new Promise((resolve, reject) => {
      const immediate = probe();
      if (immediate) {
        resolve(immediate);
        return;
      }
      const deadline = Date.now() + timeoutMs;
      const timer = window.setInterval(() => {
        const result = probe();
        if (result) {
          window.clearInterval(timer);
          resolve(result);
        } else if (Date.now() >= deadline) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }

  async function clickIngresarEscrito() {
    const label = await waitFor(
      findIngresarEscrito,
      15000,
      "No se encontró la opción 'Ingresar Escrito' en el menú visible."
    );
    const target = label.closest(".pg_menu_lt, .list-group-item") || label;
    target.click();
    return 'Step 1 completado: se hizo clic en "Ingresar Escrito".';
  }

  function finish(payload, tone = "ok") {
    completed = true;
    window.clearInterval(workTimer);
    const failed = tone === "error" || Boolean(payload && payload.error);
    setStatus(
      (payload && payload.message)
        || (failed ? "Clean08 se detuvo en Step 1." : "Step 1 completado."),
      failed ? "error" : "ok"
    );
    createPanel().querySelector('[data-role="details"]').textContent =
      "Revisa el resultado en BotManager.";
  }

  async function reportStep(body) {
    try {
      return await bridgeRequest("/report", { method: "POST", body });
    } catch (error) {
      completed = true;
      window.clearInterval(workTimer);
      setStatus(
        `No se pudo informar el resultado (${error.message || error}). `
          + "Se detuvo para no repetir el clic.",
        "error"
      );
      return null;
    }
  }

  async function pumpWork() {
    if (!verified || busy || completed) return;
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};
      if (step.action === "wait") return;
      if (step.action === "done") {
        finish(step, step.error ? "error" : "ok");
        return;
      }
      if (step.action !== "click_ingresar_escrito") {
        const detail = `Paso desconocido: ${step.action || "(vacío)"}. Recarga la extensión.`;
        const reply = await reportStep({ ok: false, detail });
        if (reply) finish(reply, "error");
        return;
      }

      setStatus("Step 1/1 · buscando Ingresar Escrito...");
      try {
        const detail = await clickIngresarEscrito();
        logToBridge(detail);
        const reply = await reportStep({ ok: true, detail });
        if (reply) finish(reply, "ok");
      } catch (error) {
        const detail = `${error.message || error} [página: ${window.location.href}]`;
        logToBridge(detail);
        const reply = await reportStep({ ok: false, detail });
        if (reply) finish(reply, "error");
      }
    } catch (_) {
      if (!completed) {
        connected = false;
        setStatus("Se perdió la conexión con BotManager.", "error");
      }
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    positionPanel();
    if (verified || starting || completed) return;
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      setStatus(
        String(window.location.href).toLowerCase().includes(START_PAGE)
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Ve a indexN.php y presiona Start.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean08 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified || completed) return;
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) await bridgeRequest("/health");
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title, build: BUILD }
      });
      verified = true;
      renderSummary(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
