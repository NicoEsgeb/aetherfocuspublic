"""Logica de negocio de Clean08."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bridge import BridgeState, run_bridge_session


SHEET_NAME = "Hoja1"
HEADER_ROW = 1
REQUIRED_COLUMNS = ("Tribunal", "ROL", "Año", "Archivo")
SUPPORTED_EXCEL_EXTENSIONS = {".xlsx", ".xlsm"}


class InputError(ValueError):
    """Raised when the selected workbook cannot be validated."""

    def __init__(self, message: str, *, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(message)


class MissingColumnsError(ValueError):
    """Raised with every required column absent from Hoja1."""

    def __init__(self, missing: list[str], sheet_name: str, found: list[str]):
        self.missing = list(missing)
        self.sheet_name = sheet_name
        self.found = list(found)
        super().__init__(
            "La planilla no tiene todas las columnas necesarias. "
            f"Faltan: {', '.join(self.missing)}."
        )


class EmptyPlanillaError(ValueError):
    """Raised when Hoja1 has headers but no populated data rows."""

    def __init__(self, sheet_name: str):
        self.sheet_name = sheet_name
        super().__init__(f"La hoja {sheet_name} no contiene filas para procesar.")


class IncompleteRowsError(ValueError):
    """Raised with every populated row missing a required value."""

    def __init__(self, sheet_name: str, issues: list[dict[str, Any]]):
        self.sheet_name = sheet_name
        self.issues = list(issues)
        row_numbers = ", ".join(str(issue["row"]) for issue in self.issues)
        super().__init__(
            "Hay filas con datos obligatorios vacios. "
            f"Revisa las filas de Excel: {row_numbers}."
        )


@dataclass(frozen=True)
class ValidatedPlanilla:
    """Validated workbook metadata and the rows ready for future processing."""

    path: str
    filename: str
    sheet_name: str
    rows: tuple[dict[str, Any], ...]

    @property
    def row_count(self) -> int:
        return len(self.rows)


def _normalize_text(value: Any) -> str:
    """Trim, collapse whitespace and compare text without case sensitivity."""
    return " ".join(str(value if value is not None else "").split()).casefold()


def _is_blank(value: Any) -> bool:
    """Treat None and whitespace-only strings as empty; numeric zero is valid."""
    return value is None or (isinstance(value, str) and not value.strip())


def _read_headers(worksheet: Any) -> dict[str, tuple[str, int]]:
    """Map normalized header text to original text and 1-based column index."""
    headers: dict[str, tuple[str, int]] = {}
    for row in worksheet.iter_rows(
        min_row=HEADER_ROW,
        max_row=HEADER_ROW,
        values_only=True,
    ):
        for index, value in enumerate(row, start=1):
            normalized = _normalize_text(value)
            if not normalized:
                continue
            headers.setdefault(normalized, (" ".join(str(value).split()), index))
        break
    return headers


def validate_planilla(path: str) -> ValidatedPlanilla:
    """Validate Hoja1, its four headers, row presence, and required cells."""
    import openpyxl

    target = Path(path).expanduser().resolve()
    if not target.is_file():
        raise InputError(
            f"No se encontro la planilla seleccionada: {target.name}",
            reason="planilla_inexistente",
            detail=str(target),
        )
    if target.suffix.lower() not in SUPPORTED_EXCEL_EXTENSIONS:
        raise InputError(
            "La planilla debe ser un archivo Excel .xlsx o .xlsm.",
            reason="planilla_formato",
            detail=target.name,
        )

    try:
        workbook = openpyxl.load_workbook(
            str(target),
            read_only=True,
            data_only=True,
        )
    except Exception as exc:
        raise InputError(
            "No se pudo abrir la planilla seleccionada.",
            reason="planilla_ilegible",
            detail=f"{target.name}: {exc}",
        ) from exc

    try:
        sheet_by_normalized_name = {
            _normalize_text(name): name for name in workbook.sheetnames
        }
        actual_sheet_name = sheet_by_normalized_name.get(_normalize_text(SHEET_NAME))
        if actual_sheet_name is None:
            found_sheets = ", ".join(workbook.sheetnames) or "(ninguna)"
            raise InputError(
                f"La planilla debe contener una hoja llamada {SHEET_NAME}.",
                reason="hoja_faltante",
                detail=f"Hojas encontradas: {found_sheets}",
            )

        worksheet = workbook[actual_sheet_name]
        headers = _read_headers(worksheet)
        resolved_columns: dict[str, int] = {}
        missing_columns: list[str] = []
        for required in REQUIRED_COLUMNS:
            match = headers.get(_normalize_text(required))
            if match is None:
                missing_columns.append(required)
            else:
                resolved_columns[required] = match[1]

        found_headers = [original for original, _ in headers.values()]
        if missing_columns:
            raise MissingColumnsError(
                missing_columns,
                actual_sheet_name,
                found_headers,
            )

        rows: list[dict[str, Any]] = []
        incomplete_rows: list[dict[str, Any]] = []
        for excel_row, raw_row in enumerate(
            worksheet.iter_rows(min_row=HEADER_ROW + 1, values_only=True),
            start=HEADER_ROW + 1,
        ):
            # Ignore completely blank spacer/trailing rows, including cells
            # that only contain whitespace.
            if not any(not _is_blank(value) for value in raw_row):
                continue

            record: dict[str, Any] = {"excel_row": excel_row}
            missing_values: list[str] = []
            for column_name, column_index in resolved_columns.items():
                value = (
                    raw_row[column_index - 1]
                    if column_index - 1 < len(raw_row)
                    else None
                )
                record[column_name] = value
                if _is_blank(value):
                    missing_values.append(column_name)

            rows.append(record)
            if missing_values:
                incomplete_rows.append(
                    {"row": excel_row, "missing": missing_values}
                )

        if not rows:
            raise EmptyPlanillaError(actual_sheet_name)
        if incomplete_rows:
            raise IncompleteRowsError(actual_sheet_name, incomplete_rows)

        return ValidatedPlanilla(
            path=str(target),
            filename=target.name,
            sheet_name=actual_sheet_name,
            rows=tuple(rows),
        )
    finally:
        workbook.close()


def run_ingreso_escrito_ampliacion_domicilios(
    *,
    escritos_pdfs_folder: str,
    planilla_path: str,
    output_folder: str,
    bridge_host: str = "127.0.0.1",
    bridge_port: int = 8769,
    bridge_timeout_seconds: int = 7200,
) -> dict[str, Any]:
    """Validate all inputs, then run Step 1 through the attended extension."""
    escritos_dir = Path(escritos_pdfs_folder).expanduser().resolve()
    output_dir = Path(output_folder).expanduser().resolve()

    # The workbook preflight is deliberately the first operation. No output
    # folder or external action is started until all rows are structurally safe.
    planilla = validate_planilla(planilla_path)

    if not escritos_dir.is_dir():
        raise FileNotFoundError(
            f"No existe la carpeta de escritos PDF: {escritos_dir}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    pdf_count = sum(
        1
        for path in escritos_dir.iterdir()
        if path.is_file() and path.suffix.lower() == ".pdf"
    )

    print("=" * 72)
    print("CLEAN08_INGRESO_ESCRITO_AMPLIACION_DOMICILIOS")
    print(f"  Carpeta de escritos PDF: {escritos_dir}")
    print(f"  PDFs encontrados: {pdf_count}")
    print(f"  Planilla seleccionada: {planilla.path}")
    print(f"  Hoja validada: {planilla.sheet_name}")
    print(f"  Columnas requeridas: OK ({', '.join(REQUIRED_COLUMNS)})")
    print(f"  Filas listas para procesar: {planilla.row_count}")
    print(f"  Carpeta de salida: {output_dir}")
    print("=" * 72)
    print(f"[CLEAN08][VALIDACION_OK] filas={planilla.row_count}")

    state = BridgeState(
        summary_data={
            "workbook": {"filename": planilla.filename},
            "row_total": planilla.row_count,
            "escritos": {"pdf_count": pdf_count},
        }
    )
    result = run_bridge_session(
        state=state,
        host=bridge_host,
        port=bridge_port,
        timeout_seconds=bridge_timeout_seconds,
    )
    print('[CLEAN08][PASO_OK] Step 1: clic en "Ingresar Escrito".')
    print("[CLEAN08][FIN] Step 1 completado.")
    return result
