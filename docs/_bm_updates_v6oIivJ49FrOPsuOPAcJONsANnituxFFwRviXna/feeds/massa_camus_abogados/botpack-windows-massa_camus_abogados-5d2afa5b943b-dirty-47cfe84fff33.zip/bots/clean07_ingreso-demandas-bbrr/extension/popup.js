const statusEl = document.getElementById("status");

chrome.runtime.sendMessage({
  type: "CLEAN07_BRIDGE_REQUEST",
  path: "/health",
  options: {}
})
  .then((payload) => {
    if (!payload || payload.ok === false) {
      statusEl.textContent = "Bridge no conectado.";
      return;
    }
    const summary = payload.summary || {};
    const workbook = summary.workbook || {};
    const demandas = summary.demandas || {};
    statusEl.textContent = workbook.filename
      ? `Bridge conectado: ${workbook.filename} · ${summary.row_total || 0} fila(s) · `
        + `${demandas.pdf_count || 0} PDF(s)`
      : "Bridge conectado.";
  })
  .catch(() => {
    statusEl.textContent = "Bridge no conectado. Inicia Clean07 en BotManager.";
  });
