"""
CLEAN06 - CREAR PLANILLA DE INGRESO DE DEMANDAS (Clean BBRR)
============================================================
Reads one "Asignación Final" matriz (Clean03's output, already reviewed by a
human) and writes the "Planilla de Ingreso de Demandas" used to upload the
documents to the PJUD.

100% offline: Excel in, Excel out. No browser, no portal, no OCR. The bot
writes file NAMES as text; it never checks that the PDFs exist — a human builds
the folders and renames the files afterwards.

tasks.py stays THIN: it reads env vars, resolves the output path, and delegates
every rule to functions.py. Full spec: ESPECIFICACION.md.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Parity with the bot template (lets `from shared.xxx import ...` work even
# though this local bot does not currently use the shared helpers).
sys.path.insert(0, str(Path(__file__).parent.parent))

import os
from datetime import datetime

from robocorp.tasks import task

from functions import PlanillaInputError, run_planilla

PATH_BOT = str(Path(__file__).parent)

# The output workbook's file name is fixed by the client; the timestamp lives on
# the per-run folder instead.
OUTPUT_FILE_NAME = "Planilla_Ingreso_Demandas.xlsx"


def _default_planilla_path() -> str:
    """First .xlsx/.xlsm in input/. The desktop UI normally sends the file the
    user picked with "Seleccionar Planilla"; this is the fallback (CLI runs)."""
    input_dir = Path(PATH_BOT) / "input"
    found = sorted(input_dir.glob("*.xlsx")) + sorted(input_dir.glob("*.xlsm"))
    return str(found[0]) if found else str(input_dir / "Asignacion_Final.xlsx")


# The Asignación Final selected in the task panel. Reuses the existing
# `matriz_input_path` -> MATRIZ_INPUT_PATH mapping already present in
# app/services/runners.py, so this bot needs NO core change to receive its input.
MATRIZ_INPUT_PATH = os.getenv("MATRIZ_INPUT_PATH", _default_planilla_path())


@task
def CLEAN06_CREAR_PLANILLA_INGRESO_DEMANDAS():
    """Crear la planilla de ingreso de demandas a partir de la Asignación Final."""
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    # Robocorp drops its own run logs (log.html + numbered output_*.robolog) into
    # output/. Clear the previous run's leftovers so the folder stays tidy — they
    # are regenerated for this run and are NOT the bot's result (the planilla
    # lives in the Planilla_<ts> subfolder). The active output.robolog is left
    # untouched.
    for _old in (*output_root.glob("output_*.robolog"), *output_root.glob("log.html")):
        try:
            _old.unlink()
        except OSError:
            pass

    run_stamp = datetime.now().strftime("%d.%m.%Y_%H_%M_%S")
    run_dir = output_root / f"Planilla_{run_stamp}"
    # NOT created here — run_planilla() creates it only once the input workbook
    # has passed validation, so a rejected Excel leaves no empty folder behind.
    output_path = run_dir / OUTPUT_FILE_NAME

    print(f"[CLEAN06] Planilla de entrada : {MATRIZ_INPUT_PATH}")
    print(f"[CLEAN06] Salida              : {output_path}")

    try:
        summary = run_planilla(MATRIZ_INPUT_PATH, str(output_path))
    except PlanillaInputError as exc:
        # Structural problem (file missing, no header row, missing columns).
        # Fail fast and loudly instead of writing a planilla full of pendientes.
        print(f"[CLEAN06][ERROR] {exc}")
        raise RuntimeError(str(exc)) from exc

    print(
        f"\n[CLEAN06] Listo: {summary['total']} fila(s) "
        f"({summary['ruts']} RUT), {summary['ok']} OK y "
        f"{summary['pendientes']} PENDIENTE."
    )
    if summary["pendientes"]:
        print(
            f"[CLEAN06] {summary['pendientes']} fila(s) quedaron en PENDIENTE. "
            "Están marcadas en amarillo, con un comentario en la celda ESTADO "
            "explicando qué falta."
        )

    print(f"[CLEAN06] Planilla generada: {output_path}")
    print("Done")
