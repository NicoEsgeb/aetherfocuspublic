"""
CLEAN06 - CREAR PLANILLA DE INGRESO DE DEMANDAS (Clean BBRR)
============================================================
Business logic for the Clean06 bot.

Reads ONE "Asignación Final" matriz (Clean03's output, already reviewed by a
human) and writes the "Planilla de Ingreso de Demandas" used to upload the
documents to the PJUD.

100% offline: Excel in, Excel out.

IMPORTANT — the bot never touches the PDFs and never checks whether they exist.
Every path it writes is plain TEXT. A human builds the `<RUT>\\` and
`03_Mandatos\\` folders and renames the files afterwards.

Full specification: ESPECIFICACION.md (same folder).

Reading note
------------
The input workbook is parsed with a small, dedicated xlsx reader instead of
openpyxl. Real Asignación Final files contain numeric cells whose cached value
is the literal `NaN` (left behind by the spreadsheet the client works on), and
openpyxl hard-fails on those with
`ValueError: invalid literal for int() with base 10: 'NaN'` before returning a
single row. Reading the sheet XML directly sidesteps that and also gives the
raw cell text, which is what every column here needs. openpyxl is still used
for WRITING, where it is perfectly safe.
"""
from __future__ import annotations

import json
import re
import unicodedata
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------------------
# Fixed documents (§7 of the spec) — hardcoded, confirmed by the client.
# ---------------------------------------------------------------------------
MANDATOS_FOLDER = "03_Mandatos"

DOC_MANDATO_1 = "1_Mandato_11709-2026.pdf"
DOC_MANDATO_2 = "2_Mandato_37590-2016.pdf"
DOC_RESOLUCION = "3_Resolucion_409.pdf"
DOC_CERTIFICADO = "4_Certificado_2215.pdf"
DOC_MANDATO_5 = "5_Mandato_9342-2016.pdf"

# ---------------------------------------------------------------------------
# Output layout — 25 columns, A..Y. ESTADO is column A (added by the bot).
#
# There is no `Contrato` column: `Contrato.pdf` never existed as a file. The
# only real contract document is the CPSB one, so both contract cases now write
# into `6_Contrato_CPSB` (see `_fill_row`).
# ---------------------------------------------------------------------------
COLUMNS: list[str] = [
    "ESTADO",                              # A
    "RUT",                                 # B
    "DV",                                  # C
    "CARTERA",                             # D
    "ARCH_DEMANDA",                        # E
    "ARCH_PAGARES",                        # F
    DOC_MANDATO_1,                         # G
    DOC_MANDATO_2,                         # H
    DOC_RESOLUCION,                        # I
    DOC_CERTIFICADO,                       # J
    DOC_MANDATO_5,                         # K
    "6_Contrato_CPSB",                     # L
    "7_HOJA_DE_FIRMA.pdf",                 # M
    "DEMANDA",                             # N
    "PAGARES",                             # O
    "MANDATO-1",                           # P
    "MANDATO-2",                           # Q
    "RESOLUCION",                          # R
    "CERTIFICADO",                         # S
    "Pagare firmado cliente",              # T
    "CONTRATO_MANDATO_FIRMADO_CLIENTE",    # U
    "HOJA_DE_FIRMA",                       # V
    "MANDATO-5",                           # W
    "CONTRATO",                            # X
    "HOJA DE FIRMA",                       # Y
]

IDX: dict[str, int] = {name: i for i, name in enumerate(COLUMNS)}

# Column widths, in the same order as COLUMNS.
_WIDTHS = [12, 12, 6, 10, 30, 32, 26, 26, 24, 24, 26, 32, 32,
           12, 20, 12, 12, 13, 13, 20, 32, 15, 12, 12, 16]

# ---------------------------------------------------------------------------
# Colours
# ---------------------------------------------------------------------------
GREEN = "FFC6EFCE"    # fila OK
YELLOW = "FFFFEB9C"   # celda con problema / ESTADO pendiente
HEADER = "FFDDEBF7"

_FILL_GREEN = PatternFill("solid", fgColor=GREEN)
_FILL_YELLOW = PatternFill("solid", fgColor=YELLOW)
_FILL_HEADER = PatternFill("solid", fgColor=HEADER)

ESTADO_OK = "OK"
ESTADO_PENDIENTE = "PENDIENTE"

# ---------------------------------------------------------------------------
# Input columns (located by header NAME, never by position — Clean03's schema
# has changed five times).
# ---------------------------------------------------------------------------
IN_RUT = "RUT"
IN_DV = "DV"
IN_CARTERA_ORIGINAL = "CARTERA_ORIGINAL"
IN_CARTERA_A_PROCESAR = "CARTERA_A_PROCESAR"
IN_COD_CONTRATO = "COD_CONTRATO"
IN_PAGARE_FIRMADO = "PAGARE_FIRMADO_CLIENTE"
IN_CONTRATO_MANDATO = "CONTRATO_MANDATO_FIRMADO_CLIENTE"
IN_HOJA_DE_FIRMA = "HOJA_DE_FIRMA"

# Accepted header spellings, normalised. `CARTERA` is Clean03's older name for
# `CARTERA_ORIGINAL` (renamed 2026-07-03).
_HEADER_ALIASES: dict[str, tuple[str, ...]] = {
    IN_RUT: ("RUT",),
    IN_DV: ("DV",),
    IN_CARTERA_ORIGINAL: ("CARTERA_ORIGINAL", "CARTERA"),
    IN_CARTERA_A_PROCESAR: ("CARTERA_A_PROCESAR",),
    IN_COD_CONTRATO: ("COD_CONTRATO",),
    IN_PAGARE_FIRMADO: ("PAGARE_FIRMADO_CLIENTE",),
    IN_CONTRATO_MANDATO: ("CONTRATO_MANDATO_FIRMADO_CLIENTE", "CONTRATO_FIRMADO_CLIENTE"),
    IN_HOJA_DE_FIRMA: ("HOJA_DE_FIRMA",),
}

REQUIRED_INPUT_COLUMNS = tuple(_HEADER_ALIASES)

# Pagaré file type per cartera. There is no PAGARE_RE and no PAGARE_VI — a
# renegociación and an "a la vista" cartera both use the PAGARE_MP that Clean02
# produced (§8 of the spec).
_PAGARE_TIPO: dict[str, str] = {
    "MP": "MP",
    "RE": "MP",
    "VI": "MP",
    "LP": "LP",
    "TC": "TC",
}

CARTERAS_A_PROCESAR_VALIDAS = ("MP", "LP", "TC", "VI")


# ===========================================================================
# xlsx reading
# ===========================================================================

_NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_NS_REL_DOC = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_NS_REL_PKG = "{http://schemas.openxmlformats.org/package/2006/relationships}"

_CELL_REF_RE = re.compile(r"([A-Z]+)")


def _shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        raw = zf.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    root = ET.fromstring(raw)
    out: list[str] = []
    for si in root.findall(f"{_NS_MAIN}si"):
        out.append("".join(t.text or "" for t in si.iter(f"{_NS_MAIN}t")))
    return out


def _first_sheet_path(zf: zipfile.ZipFile) -> str:
    """Path of the workbook's FIRST sheet, resolved through the rels file."""
    try:
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
    except KeyError:
        return "xl/worksheets/sheet1.xml"

    sheets = wb.find(f"{_NS_MAIN}sheets")
    if sheets is None or len(sheets) == 0:
        return "xl/worksheets/sheet1.xml"
    rel_id = sheets[0].get(f"{_NS_REL_DOC}id")
    if not rel_id:
        return "xl/worksheets/sheet1.xml"

    try:
        rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    except KeyError:
        return "xl/worksheets/sheet1.xml"

    for rel in rels.findall(f"{_NS_REL_PKG}Relationship"):
        if rel.get("Id") != rel_id:
            continue
        target = (rel.get("Target") or "").lstrip("/")
        if target.startswith("xl/"):
            return target
        return f"xl/{target}"
    return "xl/worksheets/sheet1.xml"


def _read_first_sheet(path: str | Path) -> dict[int, dict[str, str]]:
    """
    Return {row_number: {column_letter: text}} for the workbook's first sheet.

    Values come back as raw strings. Formula cells yield their cached value.
    Empty cells are omitted. Immune to the `NaN` cached values that make
    openpyxl refuse the file outright.
    """
    with zipfile.ZipFile(path) as zf:
        shared = _shared_strings(zf)
        sheet_xml = zf.read(_first_sheet_path(zf))

    sheet = ET.fromstring(sheet_xml)
    rows: dict[int, dict[str, str]] = {}

    for row_el in sheet.iter(f"{_NS_MAIN}row"):
        try:
            row_number = int(row_el.get("r") or 0)
        except ValueError:
            continue
        if row_number <= 0:
            continue

        cells: dict[str, str] = {}
        for cell in row_el:
            ref = cell.get("r") or ""
            match = _CELL_REF_RE.match(ref)
            if not match:
                continue
            letter = match.group(1)
            ctype = cell.get("t")

            value: str | None = None
            if ctype == "inlineStr":
                inline = cell.find(f"{_NS_MAIN}is")
                if inline is not None:
                    value = "".join(t.text or "" for t in inline.iter(f"{_NS_MAIN}t"))
            else:
                v = cell.find(f"{_NS_MAIN}v")
                if v is not None and v.text is not None:
                    if ctype == "s":
                        try:
                            value = shared[int(v.text)]
                        except (ValueError, IndexError):
                            value = ""
                    elif ctype == "b":
                        value = "TRUE" if v.text.strip() == "1" else "FALSE"
                    else:
                        value = v.text

            if value is None:
                continue
            value = value.strip()
            if value:
                cells[letter] = value

        if cells:
            rows[row_number] = cells

    return rows


# ===========================================================================
# Small helpers
# ===========================================================================

def _norm_header(text: object) -> str:
    """Uppercase, accent-free, punctuation collapsed to `_`."""
    raw = str(text or "")
    decomposed = unicodedata.normalize("NFKD", raw)
    ascii_only = "".join(c for c in decomposed if not unicodedata.combining(c))
    collapsed = re.sub(r"[^A-Za-z0-9]+", "_", ascii_only).strip("_")
    return collapsed.upper()


def _clean(value: object) -> str:
    return str(value if value is not None else "").strip()


def is_si(value: object) -> bool:
    """A flag counts as set only when it literally says SI."""
    return _clean(value).upper() in {"SI", "SÍ"}


def _digits_only(value: object) -> str:
    return re.sub(r"\D", "", _clean(value))


def format_rut(rut: object, dv: object) -> str:
    """`5228857` + `6` -> `5.228.857-6`. Returns "" when either part is missing."""
    body = _digits_only(rut)
    check = _clean(dv).upper().replace(".", "").replace("-", "")
    if not body or not check:
        return ""

    grouped: list[str] = []
    while len(body) > 3:
        grouped.insert(0, body[-3:])
        body = body[:-3]
    grouped.insert(0, body)
    return f"{'.'.join(grouped)}-{check}"


def _cod_contrato_text(value: object) -> str:
    """`14172`, `14172.0` and `'14172'` all become `14172`."""
    raw = _clean(value)
    if not raw:
        return ""
    if re.fullmatch(r"-?\d+\.0+", raw):
        return raw.split(".")[0]
    return raw


def pagare_tipo(cartera_original: object) -> str:
    """Pagaré file type for a cartera. Empty string when unknown."""
    return _PAGARE_TIPO.get(_clean(cartera_original).upper(), "")


# ===========================================================================
# Row model
# ===========================================================================

@dataclass
class BuiltRow:
    """One output row plus everything the caller needs to paint and report it."""

    values: list[str] = field(default_factory=lambda: [""] * len(COLUMNS))
    issues: list[tuple[int, str]] = field(default_factory=list)
    source_row: int = 0
    rut_display: str = ""
    cartera: str = ""
    is_first_of_rut: bool = False
    # True when the row was rejected outright at the CARTERA_A_PROCESAR gate, so
    # it wrote nothing and cannot carry its RUT's document block.
    rejected: bool = False

    @property
    def estado(self) -> str:
        return ESTADO_PENDIENTE if self.issues else ESTADO_OK

    @property
    def causas(self) -> list[str]:
        seen: list[str] = []
        for _, reason in self.issues:
            if reason not in seen:
                seen.append(reason)
        return seen

    def flag(self, column: str, reason: str) -> None:
        self.issues.append((IDX[column], reason))

    def set(self, column: str, value: str) -> None:
        self.values[IDX[column]] = value


# ===========================================================================
# Reading the Asignación Final
# ===========================================================================

class PlanillaInputError(RuntimeError):
    """The workbook cannot be used at all (missing sheet / missing columns)."""


def _print_columnas_markers(*, missing: list[str], found: str) -> None:
    """
    Emit the structured markers the desktop pop-up parses.

    Clean06 has no Python plugin, so the completion notification is built in QML
    (`clean06FallbackCompletionNotification()` in Main.qml) from these lines. Keep
    the marker names in sync with that function — they are the whole contract.
    """
    print(f"[CLEAN06][COLUMNAS_FALTANTES] {', '.join(missing)}")
    print(f"[CLEAN06][COLUMNAS_ENCONTRADAS] {found}")


def read_asignacion(path: str | Path) -> list[dict[str, str]]:
    """
    Parse the Asignación Final into a list of records keyed by canonical column
    name, in the workbook's own row order.

    Raises PlanillaInputError when the header row or a required column is
    missing — that is a structural problem, so the run fails fast instead of
    producing a planilla full of pendientes.
    """
    try:
        sheet = _read_first_sheet(path)
    except zipfile.BadZipFile as exc:
        # A legacy .xls, a .csv renamed to .xlsx, or a truncated download. Without
        # this the raw BadZipFile escapes tasks.py's PlanillaInputError handler and
        # the user gets a Python traceback instead of a readable cause.
        raise PlanillaInputError(
            f"El archivo '{Path(path).name}' no es un Excel .xlsx válido. "
            "Ábrelo en Excel y guárdalo como 'Libro de Excel (.xlsx)': los "
            "formatos antiguos .xls y los .csv no se pueden leer."
        ) from exc
    except (KeyError, ET.ParseError) as exc:
        raise PlanillaInputError(
            f"El Excel '{Path(path).name}' está dañado o incompleto: no se pudo "
            "leer su primera hoja."
        ) from exc

    if not sheet:
        raise PlanillaInputError(
            "La planilla está vacía: no se encontró ninguna fila con datos."
        )

    header_row = 0
    header_map: dict[str, str] = {}
    for row_number in sorted(sheet)[:15]:
        normalised = {_norm_header(v): letter for letter, v in sheet[row_number].items()}
        if "RUT" in normalised and "DV" in normalised:
            header_row = row_number
            header_map = normalised
            break

    if not header_row:
        # Nothing recognisable as a header. Report the first non-empty row as
        # "lo que se encontró" so the user can see what the bot actually read.
        first_row = sheet[sorted(sheet)[0]]
        seen = ", ".join(sorted(_norm_header(v) for v in first_row.values())) or "(nada)"
        _print_columnas_markers(missing=list(REQUIRED_INPUT_COLUMNS), found=seen)
        raise PlanillaInputError(
            "No se encontró la fila de encabezados (se buscaron las columnas "
            "RUT y DV en las primeras 15 filas)."
        )

    columns: dict[str, str] = {}
    missing: list[str] = []
    for canonical, aliases in _HEADER_ALIASES.items():
        for alias in aliases:
            if alias in header_map:
                columns[canonical] = header_map[alias]
                break
        else:
            missing.append(canonical)

    if missing:
        found = ", ".join(sorted(header_map)) or "(ninguna)"
        _print_columnas_markers(missing=missing, found=found)
        raise PlanillaInputError(
            "Faltan columnas obligatorias en la planilla de entrada: "
            f"{', '.join(missing)}. Columnas encontradas: {found}."
        )

    records: list[dict[str, str]] = []
    for row_number in sorted(sheet):
        if row_number <= header_row:
            continue
        cells = sheet[row_number]
        record = {name: _clean(cells.get(letter)) for name, letter in columns.items()}
        # Skip fully blank rows (trailing formatting, separators, etc.).
        if not any(record.values()):
            continue
        record["_row"] = str(row_number)
        records.append(record)

    return records


# ===========================================================================
# Building the planilla
# ===========================================================================

def build_rows(records: list[dict[str, str]]) -> list[BuiltRow]:
    """
    Turn Asignación Final records into output rows.

    One output row per input row, in input order. The first row of each RUT
    carries the whole document block; the following rows of the same RUT carry
    only RUT / DV / CARTERA / ARCH_PAGARES / PAGARES (§4).
    """
    seen_ruts: set[tuple[str, str]] = set()
    pagare_counter: dict[tuple[str, str, str], int] = {}
    # Ordinal of the pagaré WITHIN its RUT, for the PAGARES label. Keyed by RUT
    # only — unlike `pagare_counter` it does not split by pagaré type.
    rut_pagare_counter: dict[tuple[str, str], int] = {}
    rows: list[BuiltRow] = []

    for record in records:
        rut_raw = record.get(IN_RUT, "")
        dv_raw = record.get(IN_DV, "")
        rut_key = (_digits_only(rut_raw), _clean(dv_raw).upper())

        row = BuiltRow(source_row=int(record.get("_row") or 0))
        row.is_first_of_rut = rut_key not in seen_ruts

        _fill_row(row, record, pagare_counter, rut_pagare_counter)

        # A rejected row writes nothing, so it must NOT consume its RUT's
        # document block — otherwise one bad CARTERA_A_PROCESAR in the first row
        # would silently leave the whole RUT without demanda, mandatos or
        # contrato while its remaining rows still reported OK. The next usable
        # row of the same RUT carries the block instead.
        if row.is_first_of_rut and not row.rejected and (rut_key[0] or rut_key[1]):
            seen_ruts.add(rut_key)

        rows.append(row)

    return rows


def _fill_row(
    row: BuiltRow,
    record: dict[str, str],
    pagare_counter: dict[tuple[str, str, str], int],
    rut_pagare_counter: dict[tuple[str, str], int],
) -> None:
    rut_raw = record.get(IN_RUT, "")
    dv_raw = record.get(IN_DV, "")
    rut_fmt = format_rut(rut_raw, dv_raw)
    rut_counter_key = (_digits_only(rut_raw), _clean(dv_raw).upper())
    row.rut_display = rut_fmt or _clean(rut_raw)

    row.set("RUT", _digits_only(rut_raw) or _clean(rut_raw))
    row.set("DV", _clean(dv_raw).upper())

    # --- cartera a procesar -> columna CARTERA -----------------------------
    # CARTERA_A_PROCESAR is the column a HUMAN resolved. If it is not one of the
    # valid values the row is NOT processed at all: the bot writes nothing but
    # RUT / DV / the offending value, marks it PENDIENTE and lets the yellow
    # cell speak. `RE` (the unresolved purple cell from Clean03) is just one
    # case of this — any unexpected value is treated identically.
    cartera_proc = _clean(record.get(IN_CARTERA_A_PROCESAR)).upper()
    row.set("CARTERA", cartera_proc)
    row.cartera = cartera_proc
    if not cartera_proc:
        row.flag(
            "CARTERA",
            "Falta CARTERA_A_PROCESAR en la planilla de entrada. La fila no se "
            "procesó: completa esa celda y vuelve a correr el bot.",
        )
    elif cartera_proc == "RE":
        row.flag(
            "CARTERA",
            "CARTERA_A_PROCESAR quedó en RE: nadie resolvió la celda morada de "
            "Clean03. Una persona debe cambiarla a MP o VI. La fila no se procesó.",
        )
    elif cartera_proc not in CARTERAS_A_PROCESAR_VALIDAS:
        row.flag(
            "CARTERA",
            f"CARTERA_A_PROCESAR tiene un valor desconocido: '{cartera_proc}'. "
            f"Se esperaba {', '.join(CARTERAS_A_PROCESAR_VALIDAS)}. La fila no se procesó.",
        )

    if row.issues:
        # Row rejected. Still advance BOTH pagaré counters: the physical pagaré
        # exists regardless, so the NEXT pagaré of this RUT must keep its number
        # (_2, _3, ... for the file; PAGARE-2, PAGARE-3, ... for the label).
        # Skipping it would renumber the rest and make them collide once this
        # row is corrected.
        row.rejected = True
        tipo_rechazado = pagare_tipo(record.get(IN_CARTERA_ORIGINAL))
        if tipo_rechazado:
            counter_key = (_digits_only(rut_raw), _clean(dv_raw).upper(), tipo_rechazado)
            pagare_counter[counter_key] = pagare_counter.get(counter_key, 0) + 1
        rut_pagare_counter[rut_counter_key] = \
            rut_pagare_counter.get(rut_counter_key, 0) + 1
        return

    # --- RUT missing: everything path-based is impossible -------------------
    if not rut_fmt:
        faltante = "RUT" if not _digits_only(rut_raw) else "DV"
        reason = f"Falta {faltante} en la planilla de entrada: no se puede armar la ruta <RUT>\\."
        for column in ("ARCH_DEMANDA", "ARCH_PAGARES",
                       "6_Contrato_CPSB", "7_HOJA_DE_FIRMA.pdf", "PAGARES"):
            row.flag(column, reason)

    # --- pagaré file (every row) -------------------------------------------
    cartera_orig = _clean(record.get(IN_CARTERA_ORIGINAL)).upper()
    tipo = pagare_tipo(cartera_orig)
    if not tipo:
        detalle = f"'{cartera_orig}'" if cartera_orig else "vacía"
        row.flag(
            "ARCH_PAGARES",
            f"CARTERA_ORIGINAL {detalle}: no se puede determinar el archivo de "
            f"pagaré. Se esperaba MP, RE, LP, TC o VI.",
        )
    elif rut_fmt:
        counter_key = (*(_digits_only(rut_raw), _clean(dv_raw).upper()), tipo)
        nth = pagare_counter.get(counter_key, 0) + 1
        pagare_counter[counter_key] = nth
        suffix = "" if nth == 1 else f"_{nth}"
        row.set("ARCH_PAGARES", f"{rut_fmt}\\Pagare_{tipo}{suffix}.pdf")

    # --- pagaré label (every row) -------------------------------------------
    # PAGARES is NOT a file name — it is the label the next bot reads: the
    # pagaré's ordinal WITHIN its RUT, restarting at 1 on every new RUT
    # (PAGARE-1, PAGARE-2, ...). It counts ROWS of the RUT, so unlike
    # ARCH_PAGARES it does not split by pagaré type and does not depend on
    # CARTERA_ORIGINAL — a row whose type cannot be resolved still has an
    # ordinal. It does need the RUT, which is what groups the rows.
    nth_rut = rut_pagare_counter.get(rut_counter_key, 0) + 1
    rut_pagare_counter[rut_counter_key] = nth_rut
    if rut_fmt:
        row.set("PAGARES", f"PAGARE-{nth_rut}")

    # --- repeat rows stop here (§4) ----------------------------------------
    if not row.is_first_of_rut:
        return

    # --- firma flags --------------------------------------------------------
    hoja = is_si(record.get(IN_HOJA_DE_FIRMA))
    mandato = is_si(record.get(IN_CONTRATO_MANDATO))
    pagare_firmado = is_si(record.get(IN_PAGARE_FIRMADO))
    activas = sum((hoja, mandato, pagare_firmado))

    row.set("Pagare firmado cliente", _clean(record.get(IN_PAGARE_FIRMADO)))
    row.set("CONTRATO_MANDATO_FIRMADO_CLIENTE", _clean(record.get(IN_CONTRATO_MANDATO)))
    row.set("HOJA_DE_FIRMA", _clean(record.get(IN_HOJA_DE_FIRMA)))

    if activas != 1:
        presentes = [
            nombre for nombre, activo in (
                ("HOJA_DE_FIRMA", hoja),
                ("CONTRATO_MANDATO_FIRMADO_CLIENTE", mandato),
                ("PAGARE_FIRMADO_CLIENTE", pagare_firmado),
            ) if activo
        ]
        detalle = ", ".join(presentes) if presentes else "ninguna"
        reason = (
            "Combinación de banderas de firma no prevista: se esperaba exactamente "
            f"una en SI y hay {activas} ({detalle}). El bot no adivina qué contrato "
            "ni qué mandatos corresponden."
        )
        for column in ("6_Contrato_CPSB", DOC_MANDATO_5, "MANDATO-5", "CONTRATO"):
            row.flag(column, reason)

    # --- always-on documents ------------------------------------------------
    row.set("ARCH_DEMANDA", f"{rut_fmt}\\Demanda.pdf" if rut_fmt else "")
    row.set(DOC_MANDATO_1, f"{MANDATOS_FOLDER}\\{DOC_MANDATO_1}")
    row.set(DOC_MANDATO_2, f"{MANDATOS_FOLDER}\\{DOC_MANDATO_2}")
    row.set(DOC_RESOLUCION, f"{MANDATOS_FOLDER}\\{DOC_RESOLUCION}")
    row.set(DOC_CERTIFICADO, f"{MANDATOS_FOLDER}\\{DOC_CERTIFICADO}")
    row.set("DEMANDA", "DEMANDA")
    row.set("MANDATO-1", "MANDATO-1")
    row.set("MANDATO-2", "MANDATO-2")
    row.set("RESOLUCION", "RESOLUCION")
    row.set("CERTIFICADO", "CERTIFICADO")

    if activas != 1:
        # The three conditional blocks below all depend on knowing which single
        # flag is set. Leave them empty and let the yellow cells speak.
        return

    # --- contrato (§6) ------------------------------------------------------
    # `Contrato.pdf` was never a real file, so the `hoja` case contributes no
    # contract path at all — its contract is the CPSB one written by the hoja
    # block below. `Contrato_Mandato.pdf` IS real and now goes into
    # `6_Contrato_CPSB`, which stays empty in this case (hoja and mandato are
    # mutually exclusive here: activas == 1).
    if mandato and rut_fmt:
        row.set("6_Contrato_CPSB", f"{rut_fmt}\\Contrato_Mandato.pdf")
    if (hoja or mandato) and rut_fmt:
        row.set("CONTRATO", "CONTRATO")

    # --- mandato 9342: hoja OR contrato mandato -----------------------------
    # Independent OR on purpose: 9342 is the personería de los mandatarios del
    # Banco and backs BOTH documents. Nesting it inside the hoja block is the
    # exact bug that hit Clean04 twice.
    if hoja or mandato:
        row.set(DOC_MANDATO_5, f"{MANDATOS_FOLDER}\\{DOC_MANDATO_5}")
        row.set("MANDATO-5", "MANDATO-5")

    # --- hoja de firma block ------------------------------------------------
    if hoja:
        cod_contrato = _cod_contrato_text(record.get(IN_COD_CONTRATO))
        if cod_contrato:
            if rut_fmt:
                row.set("6_Contrato_CPSB", f"{rut_fmt}\\6_CPSB_Rept_{cod_contrato}.pdf")
        else:
            row.flag(
                "6_Contrato_CPSB",
                "HOJA_DE_FIRMA es SI pero falta COD_CONTRATO: no se puede armar el "
                "nombre 6_CPSB_Rept_<cod>.pdf.",
            )
        if rut_fmt:
            row.set("7_HOJA_DE_FIRMA.pdf", f"{rut_fmt}\\7_HOJA_DE_FIRMA.pdf")
        row.set("HOJA DE FIRMA", "HOJA DE FIRMA")


# ===========================================================================
# Writing the planilla
# ===========================================================================

def write_planilla(rows: list[BuiltRow], output_path: str | Path) -> None:
    """Write the 25-column planilla, painted and commented per §9."""
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Ingreso Demandas"

    for column_index, header in enumerate(COLUMNS, start=1):
        cell = sheet.cell(row=1, column=column_index, value=header)
        cell.font = Font(bold=True)
        cell.fill = _FILL_HEADER
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        sheet.column_dimensions[get_column_letter(column_index)].width = \
            _WIDTHS[column_index - 1]

    sheet.freeze_panes = "A2"
    sheet.row_dimensions[1].height = 30

    for offset, row in enumerate(rows):
        excel_row = offset + 2
        row.values[IDX["ESTADO"]] = row.estado
        flagged = {index for index, _ in row.issues}

        for column_index, value in enumerate(row.values, start=1):
            cell = sheet.cell(row=excel_row, column=column_index, value=value or None)
            if not row.issues:
                cell.fill = _FILL_GREEN
            elif (column_index - 1) in flagged:
                cell.fill = _FILL_YELLOW

        if row.issues:
            estado_cell = sheet.cell(row=excel_row, column=IDX["ESTADO"] + 1)
            estado_cell.fill = _FILL_YELLOW
            estado_cell.font = Font(bold=True)
            _comment(estado_cell, _estado_comment(row))

            for index, reason in _first_reason_per_column(row.issues):
                _comment(sheet.cell(row=excel_row, column=index + 1), reason)

    workbook.save(str(output_path))


def _first_reason_per_column(issues: list[tuple[int, str]]) -> list[tuple[int, str]]:
    """One comment per cell, keeping the first reason recorded for it."""
    collected: dict[int, list[str]] = {}
    for index, reason in issues:
        reasons = collected.setdefault(index, [])
        if reason not in reasons:
            reasons.append(reason)
    return [(index, "\n\n".join(reasons)) for index, reasons in sorted(collected.items())]


def _estado_comment(row: BuiltRow) -> str:
    causas = row.causas
    if len(causas) == 1:
        return f"Fila PENDIENTE.\n\n{causas[0]}"
    lines = "\n".join(f"{n}. {c}" for n, c in enumerate(causas, start=1))
    return f"Fila PENDIENTE — {len(causas)} problema(s):\n\n{lines}"


def _comment(cell, text: str) -> None:
    comment = Comment(text, "Clean06")
    comment.width = 380
    comment.height = max(90, 26 * (text.count("\n") + 2))
    cell.comment = comment


# ===========================================================================
# Orchestration
# ===========================================================================

def run_planilla(input_path: str | Path, output_path: str | Path) -> dict:
    """
    Read the Asignación Final, build the planilla, write it, and report.

    Prints the structured markers the desktop run-detail panel parses
    (`Clean06Summary.qml`). Returns a summary dict.
    """
    input_path = Path(input_path)
    # Printed before any validation so the pop-up can always name the offending
    # file, even when the run dies on the very first check.
    print(f"[CLEAN06][ARCHIVO] {input_path.name}")
    if not input_path.is_file():
        raise PlanillaInputError(
            f"No se encontró la planilla de entrada: {input_path}"
        )

    records = read_asignacion(input_path)
    total = len(records)
    print(f"[CLEAN06][INICIO] archivo={input_path.name} filas={total}")

    if total == 0:
        raise PlanillaInputError(
            "La planilla de entrada no tiene filas de datos bajo el encabezado."
        )

    rows = build_rows(records)

    ok = 0
    pendientes = 0
    for position, row in enumerate(rows, start=1):
        if row.issues:
            pendientes += 1
        else:
            ok += 1
        print(
            "[CLEAN06][FILA] "
            + json.dumps(
                {
                    "fila": position,
                    "filaExcel": row.source_row,
                    "rut": row.rut_display,
                    "cartera": row.cartera,
                    "estado": row.estado,
                    "causa": "; ".join(row.causas),
                },
                ensure_ascii=True,
            )
        )
        print(f"[CLEAN06][PROGRESS] {position}/{total}")

    # Created here, not by the caller: a run that dies on validation must not
    # leave an empty Planilla_<timestamp>/ folder behind.
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    write_planilla(rows, output_path)

    print(f"[CLEAN06][RESUMEN] total={total} ok={ok} pendiente={pendientes}")
    print(f"[CLEAN06][SALIDA] {Path(output_path).parent}")

    return {
        "total": total,
        "ok": ok,
        "pendientes": pendientes,
        "ruts": len({r.rut_display for r in rows if r.is_first_of_rut}),
        "output_path": str(output_path),
    }
