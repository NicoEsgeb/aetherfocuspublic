"""
RPA06 NEW - Ingreso / Descargar Informe / GET CARATULAS
=======================================================
This bot is the Clean BBRR version of rpa06_ingreso_caratulas_informe.

Architecture (Path A):
  - shared/ojv_portal    -> OJV login, URL resolution, modal handling
  - shared/artifacts     -> Artifact snapshot and move
  - shared/output_dirs   -> Timestamped output directory creation
  - functions.py         -> Business logic (Excel parsing, PDF, caratulas)

tasks.py stays THIN: it reads env vars, sets up context, and orchestrates
calls to shared/ and functions.py. No business logic lives here.
"""
from __future__ import annotations

import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Enable imports from bots/shared/
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Shared infrastructure
# ---------------------------------------------------------------------------
from shared.ojv_portal import (
    goto_ojv_login_with_browser,
    ojv_url,
)
from shared.pjud_credentials import get_pjud_credentials
from shared.artifacts import (
    snapshot_output_artifacts,
    move_updated_artifacts_to_run_dir,
    register_pending_artifact_move,
)
from shared.output_dirs import (
    create_ingreso_output_dir,
    create_descargar_caratulas_output_dir,
    resolve_descargar_caratulas_output_dir,
    create_descargar_informe_output_dir,
)

# ---------------------------------------------------------------------------
# Standard library / third-party
# ---------------------------------------------------------------------------
from robocorp import browser
from robocorp.tasks import task
import os
import glob
import time
import re
import traceback
from datetime import datetime
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Bot-specific business logic
# ---------------------------------------------------------------------------
from functions import read_excel_ingreso, read_excel_caratulas, ensure_excel_writable_or_raise

# ---------------------------------------------------------------------------
# Path and environment configuration
# ---------------------------------------------------------------------------
PATH_BOT = str(Path(__file__).parent)

DEFAULT_DEMANDAS_FOLDER_PATH = str(Path(PATH_BOT) / "input")
DEMANDAS_FOLDER_PATH = os.getenv("DEMANDAS_FOLDER_PATH", DEFAULT_DEMANDAS_FOLDER_PATH)

DEFAULT_EXCEL_FILE_NAME = str(Path("Matriz_Demandas") / "BOT_MATRIZ_DEMANDAS_ingreso.xlsx")
MATRIZ_DEMANDAS_PATH = os.getenv("MATRIZ_DEMANDAS_PATH", "").strip()
if MATRIZ_DEMANDAS_PATH:
    selected_matrix = Path(MATRIZ_DEMANDAS_PATH).expanduser()
    default_matrix_filename = Path(DEFAULT_EXCEL_FILE_NAME).name
    EXCEL_FILE_CARATULAS = selected_matrix.name or default_matrix_filename
    EXCEL_FILE_NAME = str(selected_matrix)
    if not EXCEL_FILE_NAME:
        EXCEL_FILE_NAME = DEFAULT_EXCEL_FILE_NAME
    if selected_matrix.is_absolute() and "DEMANDAS_FOLDER_PATH" not in os.environ:
        DEMANDAS_FOLDER_PATH = str(selected_matrix.parent)
else:
    EXCEL_FILE_NAME = DEFAULT_EXCEL_FILE_NAME
    EXCEL_FILE_CARATULAS = Path(DEFAULT_EXCEL_FILE_NAME).name

DEFAULT_INFORME_FOLDER_NAME = "Matriz_Caratulas_Informe"
DEFAULT_CARATULAS_FOLDER_PATH = str(Path(DEMANDAS_FOLDER_PATH) / DEFAULT_INFORME_FOLDER_NAME)
CARATULAS_FOLDER_PATH = os.getenv("CARATULAS_FOLDER_PATH", DEFAULT_CARATULAS_FOLDER_PATH)

FECHA_DESDE_CARATULAS = os.getenv("FECHA_DESDE_CARATULAS", "").strip()
FECHA_HASTA_CARATULAS = os.getenv("FECHA_HASTA_CARATULAS", "").strip()
DEFAULT_GET_CARATULAS_MATRIX_FILE = "BOT_MATRIZ_DEMANDAS_ingreso.xlsx"
GET_CARATULAS_SIN_COMPARAR = os.getenv("GET_CARATULAS_SIN_COMPARAR", "").strip() == "1"
# The signed demandas carry a "_firmado" suffix the matriz does not list, so the
# bot has to append it when building each ARCH_DEMANDA path.
DOCUMENTOS_FIRMADOS = os.getenv("DOCUMENTOS_FIRMADOS", "").strip() == "1"
PJUD_USERNAME, PJUD_PASSWORD, PJUD_PROFILE_LABEL = get_pjud_credentials()


# ---------------------------------------------------------------------------
# Path resolvers (bot-specific: depend on this bot's env vars)
# ---------------------------------------------------------------------------

def _resolve_excel_ingreso_demandas() -> str:
    matrix_path = Path(EXCEL_FILE_NAME)
    if matrix_path.is_absolute():
        return str(matrix_path)
    return str((Path(DEMANDAS_FOLDER_PATH) / matrix_path).resolve())


def _resolve_excel_get_caratulas_matrix() -> str:
    explicit_path = os.getenv("MATRIZ_DEMANDAS_GET_CARATULAS_PATH", "").strip()
    if explicit_path:
        path = Path(explicit_path).expanduser()
        if path.is_absolute():
            return str(path)
        return str((Path(DEMANDAS_FOLDER_PATH) / path).resolve())

    demandas_root = Path(DEMANDAS_FOLDER_PATH)
    candidates = (
        demandas_root / "Matriz_Demandas" / DEFAULT_GET_CARATULAS_MATRIX_FILE,
        demandas_root / DEFAULT_GET_CARATULAS_MATRIX_FILE,
    )
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate.resolve())

    searched = ", ".join(str(p) for p in candidates)
    raise FileNotFoundError(
        "No existe la matriz para GET_CARATULAS. "
        f"Buscado en: {searched}. "
        "Puedes definir MATRIZ_DEMANDAS_GET_CARATULAS_PATH."
    )


def _resolve_required_fecha_rango_caratulas() -> tuple[str, str]:
    fecha_desde = FECHA_DESDE_CARATULAS
    fecha_hasta = FECHA_HASTA_CARATULAS
    if not fecha_desde or not fecha_hasta:
        raise ValueError(
            "FECHA_DESDE_CARATULAS y FECHA_HASTA_CARATULAS son obligatorias para GET_CARATULAS "
            "(formato esperado: dd/mm/yyyy)."
        )
    try:
        desde_dt = datetime.strptime(fecha_desde, "%d/%m/%Y")
        hasta_dt = datetime.strptime(fecha_hasta, "%d/%m/%Y")
    except ValueError as error:
        raise ValueError("Rango de fechas invalido. Usa formato dd/mm/yyyy.") from error
    if desde_dt > hasta_dt:
        raise ValueError("Fecha desde no puede ser mayor que fecha hasta.")
    return desde_dt.strftime("%d/%m/%Y"), hasta_dt.strftime("%d/%m/%Y")


def _resolve_fecha_rango_descargar_informe() -> tuple[str, str]:
    if not FECHA_DESDE_CARATULAS or not FECHA_HASTA_CARATULAS:
        raise ValueError(
            "FECHA_DESDE_CARATULAS y FECHA_HASTA_CARATULAS son obligatorias para "
            "DESCARGAR_INFORME (formato esperado: dd/mm/yyyy)."
        )
    return _resolve_required_fecha_rango_caratulas()


def _resolve_excel_informe_pjud(*, require_explicit: bool = False) -> str:
    explicit_path = os.getenv("EXCEL_INFORME_PJUD", "").strip()
    if explicit_path:
        return explicit_path
    if require_explicit:
        raise ValueError(
            "EXCEL_INFORME_PJUD es obligatorio para GET_CARATULAS. "
            "Selecciona un Informe Excel antes de ejecutar."
        )
    pattern = str(Path(CARATULAS_FOLDER_PATH) / "Informe_Causas*.xlsx")
    candidates = sorted(
        glob.glob(pattern),
        key=lambda file_path: os.path.getmtime(file_path),
        reverse=True,
    )
    if candidates:
        return candidates[0]
    return str(Path(CARATULAS_FOLDER_PATH) / EXCEL_FILE_CARATULAS)


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

@task
def RPA_06_Ingreso():
    """RPA 06 NEW - Ingreso de demandas estatal en poder judicial."""
    browser.configure(
        browser_engine="chrome",
        screenshot="only-on-failure",
        headless=False,
    )
    ingreso_matrix_path = _resolve_excel_ingreso_demandas()
    ensure_excel_writable_or_raise(ingreso_matrix_path)

    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    artifact_snapshot = snapshot_output_artifacts(output_root)
    task_started_at = datetime.now()
    ingreso_output_dir = create_ingreso_output_dir(PATH_BOT, task_started_at)

    try:
        page = goto_ojv_login_with_browser()
        page.get_by_role("heading", name="Ingreso de demandas y escritos").wait_for()
        page.get_by_role("button", name="Clave Poder Judicial").first.click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").fill(PJUD_USERNAME)
        page.locator("#inputPassword2C").click()
        page.locator("#inputPassword2C").fill(PJUD_PASSWORD)
        page.get_by_role("button", name="Ingresar").click()
        page.locator("#roles-modal").get_by_text("Seleccione Perfil").wait_for()
        page.get_by_text(PJUD_PROFILE_LABEL).first.click()

        print(f"Ingreso evidencias: {ingreso_output_dir}")

        try:
            read_excel_ingreso(
                EXCEL_FILE_NAME,
                PATH_BOT,
                DEMANDAS_FOLDER_PATH,
                ingreso_output_dir,
                documentos_firmados=DOCUMENTOS_FIRMADOS,
            )
        except Exception:
            traceback.print_exc()
            raise

    finally:
        run_output = Path(ingreso_output_dir)
        move_updated_artifacts_to_run_dir(output_root, run_output, artifact_snapshot)
        register_pending_artifact_move(output_root, run_output, artifact_snapshot)
        print("Done")


@task
def RPA_06_DescargarInformePjud():
    """RPA 06 NEW - Descarga del Excel del poder judicial."""
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    artifact_snapshot = snapshot_output_artifacts(output_root)
    task_started_at = datetime.now()
    descargar_informe_output_dir = ""

    try:
        fecha_desde, fecha_hasta = _resolve_fecha_rango_descargar_informe()
        descargar_informe_output_dir = create_descargar_informe_output_dir(
            PATH_BOT, task_started_at,
        )
        print(f"Descargar Informe output: {descargar_informe_output_dir}")
        Path(descargar_informe_output_dir).mkdir(parents=True, exist_ok=True)

        browser.configure(
            browser_engine="chrome",
            screenshot="only-on-failure",
            headless=False,
        )
        try:
            browser.configure_context(
                accept_downloads=True,
                viewport={"width": 1920, "height": 1080},
                ignore_https_errors=True,
            )
        except Exception:
            try:
                browser.configure_context(
                    accept_downloads=True,
                    viewport={"width": 1920, "height": 1080},
                )
            except Exception:
                pass

        page = goto_ojv_login_with_browser()
        try:
            page.set_viewport_size({"width": 1920, "height": 1080})
        except Exception:
            pass

        page.locator("#link2C").first.wait_for(timeout=60000)
        page.locator("#link2C").first.click()
        page.locator("#inputRut2C").first.fill(PJUD_USERNAME)
        page.locator("#inputPassword2C").first.fill(PJUD_PASSWORD)
        page.locator(".btn-ingreso-pjud").first.click()

        page.locator(".card-text").first.wait_for(timeout=60000)
        page.locator(".card-text").first.click()
        time.sleep(2)

        page.goto(ojv_url("/kpitec-ojv-web/index#bandeja/causas"))
        fecha_desde_input = page.locator("xpath=//label[contains(.,'Fecha Desde')]/../div/input").first
        fecha_hasta_input = page.locator("xpath=//label[contains(.,'Fecha Hasta')]/../div/input").first
        fecha_desde_input.wait_for(timeout=30000)
        fecha_hasta_input.wait_for(timeout=30000)
        fecha_desde_input.fill(fecha_desde)
        fecha_hasta_input.fill(fecha_hasta)
        time.sleep(1)

        try:
            page.evaluate("document.body.style.zoom='70%'")
        except Exception:
            pass

        competencia = page.locator("xpath=//label[contains(.,'Competencia:')]/../select").first
        competencia.wait_for(timeout=30000)
        try:
            competencia.select_option(label="Civil")
        except Exception:
            competencia.click()
            page.keyboard.type("Civil")
            page.keyboard.press("Enter")

        page.locator("xpath=//a[contains(.,'Demandas Enviadas')]").first.wait_for(timeout=30000)
        page.locator("xpath=//a[contains(.,'Demandas Enviadas')]").first.click()
        time.sleep(2)

        export_button = page.locator("xpath=//input[@value='Exportar a Excel']").first
        export_button.wait_for(timeout=30000)
        with page.expect_download(timeout=120000) as download_info:
            export_button.click()
        download = download_info.value

        suggested_name = (
            download.suggested_filename
            or f"Informe_Causas_{datetime.now().strftime('%d.%m.%Y_%H_%M_%S')}.xlsx"
        )
        target_path = Path(descargar_informe_output_dir) / suggested_name
        suffix = 2
        while target_path.exists():
            target_path = (
                Path(descargar_informe_output_dir)
                / f"{target_path.stem}_{suffix}{target_path.suffix}"
            )
            suffix += 1
        download.save_as(str(target_path))
        print(f"[DESCARGAR_INFORME] Excel descargado: {target_path}")

    finally:
        if descargar_informe_output_dir:
            run_output = Path(descargar_informe_output_dir)
            move_updated_artifacts_to_run_dir(output_root, run_output, artifact_snapshot)
            register_pending_artifact_move(output_root, run_output, artifact_snapshot)
        print("Done Descarga Informe Pjud")


@task
def RPA_06_GET_CARATULAS():
    """RPA 06 NEW - Descargar las caratulas de las demandas en poder judicial."""
    sin_comparar = GET_CARATULAS_SIN_COMPARAR
    if sin_comparar:
        try:
            excel_matriz_caratulas = _resolve_excel_get_caratulas_matrix()
        except FileNotFoundError:
            excel_matriz_caratulas = ""
    else:
        excel_matriz_caratulas = _resolve_excel_get_caratulas_matrix()
    excel_informe_pjud = _resolve_excel_informe_pjud(require_explicit=True)
    fecha_desde, fecha_hasta = _resolve_required_fecha_rango_caratulas()

    if not sin_comparar and not os.path.isfile(excel_matriz_caratulas):
        raise FileNotFoundError(
            f"No existe la matriz de caratulas para cruce de RUT: {excel_matriz_caratulas}"
        )
    if not os.path.isfile(excel_informe_pjud):
        raise FileNotFoundError(
            f"No existe el Excel Informe PJUD para descargar caratulas: {excel_informe_pjud}"
        )
    ensure_excel_writable_or_raise(excel_informe_pjud)

    caratulas_output_dir = resolve_descargar_caratulas_output_dir(PATH_BOT)
    print(f"Descargar Caratulas output: {caratulas_output_dir}")
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    artifact_snapshot = snapshot_output_artifacts(output_root)

    try:
        browser.configure(
            browser_engine="chrome",
            screenshot="only-on-failure",
            headless=False,
        )
        try:
            browser.configure_context(
                accept_downloads=True,
                viewport={"width": 1920, "height": 1080},
            )
        except Exception:
            pass

        page = goto_ojv_login_with_browser()
        try:
            page.set_viewport_size({"width": 1920, "height": 1080})
        except Exception:
            pass

        page.locator("#link2C").first.wait_for(timeout=60000)
        page.locator("#link2C").first.click()
        page.locator("#inputRut2C").first.fill(PJUD_USERNAME)
        page.locator("#inputPassword2C").first.fill(PJUD_PASSWORD)
        page.locator(".btn-ingreso-pjud").first.click()

        page.locator(".card-text").first.wait_for(timeout=60000)
        page.locator(".card-text").first.click()
        time.sleep(2)

        read_excel_caratulas(
            excel_informe_pjud,
            caratulas_output_dir,
            page,
            excel_matriz_caratulas,
            fecha_desde,
            fecha_hasta,
            sin_comparar=sin_comparar,
        )

    finally:
        run_output = Path(caratulas_output_dir)
        move_updated_artifacts_to_run_dir(output_root, run_output, artifact_snapshot)
        register_pending_artifact_move(output_root, run_output, artifact_snapshot)
        print("Done")
