"""
RPA01 NEW - Ingreso de Escritos
================================
This bot is the Clean BBRR version of rpa01_ingreso-escritos.

Architecture (Path A):
  - shared/ojv_portal    -> OJV login URL navigation
  - shared/artifacts     -> Artifact snapshot and move
  - shared/output_dirs   -> Timestamped output directory creation
  - functions.py         -> Business logic (Excel parsing, form filling)

tasks.py stays THIN: it sets up context and orchestrates
calls to shared/ and functions.py. No business logic lives here.
"""
from __future__ import annotations

import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Enable imports from bots/shared/
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).parent.parent))

# ---------------------------------------------------------------------------
# Shared infrastructure
# ---------------------------------------------------------------------------
from shared.ojv_portal import goto_ojv_login_with_browser, goto_ojv_login_with_driver
from shared.pjud_credentials import get_pjud_credentials
from shared.artifacts import (
    snapshot_output_artifacts,
    move_updated_artifacts_to_run_dir,
    register_pending_artifact_move,
)
from shared.output_dirs import create_ingreso_output_dir

# ---------------------------------------------------------------------------
# Standard library / third-party
# ---------------------------------------------------------------------------
from robocorp import browser
from robocorp.tasks import task
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import os
import openpyxl
from openpyxl.styles import PatternFill
import time
from datetime import datetime

# ---------------------------------------------------------------------------
# Bot-specific business logic
# ---------------------------------------------------------------------------
from functions import read_excel_preingreso, read_excel_envio, compare_results

# ---------------------------------------------------------------------------
# Path and environment configuration
# ---------------------------------------------------------------------------
BOT_DIR = Path(__file__).resolve().parent
INPUT_DIR = BOT_DIR / "input"
PROCESSING_DIR = BOT_DIR / "processing"
OUTPUT_DIR = BOT_DIR / "output"

PATH_BOT = str(BOT_DIR)
EXCEL_FILE_NAME = os.getenv("MATRIZ_ESCRITOS_PATH", str(INPUT_DIR / "planillas" / "planilla_escritos.xlsx"))
ESCRITOS_DCP_PATH = os.getenv("ESCRITOS_FOLDER_PATH", str(INPUT_DIR / "escritos"))
ROLES_DONE = []
PJUD_USERNAME, PJUD_PASSWORD, PJUD_PROFILE_LABEL = get_pjud_credentials()


def _require_existing_path(path_value: str, description: str, *, expect_directory: bool = False) -> Path:
    candidate = Path(path_value).expanduser()
    exists = candidate.is_dir() if expect_directory else candidate.is_file()
    if exists:
        return candidate

    expected_kind = "carpeta" if expect_directory else "archivo"
    env_var = "ESCRITOS_FOLDER_PATH" if expect_directory else "MATRIZ_ESCRITOS_PATH"
    raise FileNotFoundError(
        f"{description} no existe ({expected_kind}): '{candidate}'. "
        f"Selecciona la ruta correcta en la UI o define {env_var}."
    )


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

@task
def Prueba():
    print("Prueba de que funciona robocorp")


@task
def RPA_01_Ingreso():
    """
    RPA 01 NEW - Ingreso de escritos de pago garantia estatal en poder judicial.
    """
    excel_file = _require_existing_path(EXCEL_FILE_NAME, "La planilla de escritos")
    escritos_folder = _require_existing_path(
        ESCRITOS_DCP_PATH,
        "La carpeta de escritos",
        expect_directory=True,
    )

    browser.configure(
        browser_engine="chrome",
        screenshot="only-on-failure",
        headless=False,
    )

    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    artifact_snapshot = snapshot_output_artifacts(output_root)
    task_started_at = datetime.now()
    ingreso_output_dir = create_ingreso_output_dir(PATH_BOT, task_started_at)

    try:
        page = goto_ojv_login_with_browser()
        page.get_by_role("heading", name="Ingreso de demandas y escritos").wait_for()
        page.get_by_role("button", name="Clave Poder Judicial").first.click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").fill(PJUD_USERNAME)
        page.locator("#inputPassword2C").click()
        page.locator("#inputPassword2C").fill(PJUD_PASSWORD)
        page.get_by_role("button", name="Ingresar").click()
        page.locator("#roles-modal").get_by_text("Seleccione Perfil").wait_for()
        page.get_by_text(PJUD_PROFILE_LABEL).first.click()

        documentos_firmados = os.getenv("DOCUMENTOS_FIRMADOS", "") == "1"
        read_excel_preingreso(
            str(excel_file),
            str(escritos_folder),
            ingreso_output_dir,
            documentos_firmados=documentos_firmados,
        )

    finally:
        move_updated_artifacts_to_run_dir(output_root, Path(ingreso_output_dir), artifact_snapshot)
        register_pending_artifact_move(output_root, Path(ingreso_output_dir), artifact_snapshot)
        print('Done')


@task
def RPA_01_Envio():
    """
    RPA 01 NEW - Envio de escritos de pago garantia estatal en poder judicial.
    """
    excel_file = _require_existing_path(EXCEL_FILE_NAME, "La planilla de escritos")

    browser.configure(
        browser_engine="chromium",
        screenshot="only-on-failure",
        headless=False,
    )

    # Envio needs its own run directory so the debug log has somewhere to land.
    envio_output_dir = create_ingreso_output_dir(PATH_BOT, datetime.now())

    try:
        page = goto_ojv_login_with_browser()
        page.get_by_role("heading", name="Ingreso de demandas y escritos").wait_for()
        page.get_by_role("button", name="Clave Poder Judicial").first.click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").fill(PJUD_USERNAME)
        page.locator("#inputPassword2C").click()
        page.locator("#inputPassword2C").fill(PJUD_PASSWORD)
        page.get_by_role("button", name="Ingresar").click()
        page.locator("#roles-modal").get_by_text("Seleccione Perfil").wait_for()
        page.get_by_text(PJUD_PROFILE_LABEL).first.click()

        read_excel_envio(str(excel_file), envio_output_dir)

    finally:
        print('Done')


@task
def RPA_01_Compare_results():
    """
    RPA 01 NEW - Descarga del Excel del poder judicial y comparacion con el Excel de ingreso del bot.
    """
    _require_existing_path(EXCEL_FILE_NAME, "La planilla de escritos")

    try:
        chrome_options = Options()
        download_path = str(PROCESSING_DIR)
        prefs = {'download.default_directory': download_path}
        chrome_options.add_argument('--start-maximized')
        chrome_options.add_experimental_option('prefs', prefs)
        driver = webdriver.Chrome(options=chrome_options)

        goto_ojv_login_with_driver(driver)
        driver.find_element(By.ID, value='link2C').click()
        driver.find_element(By.ID, value='inputRut2C').send_keys(PJUD_USERNAME)
        driver.find_element(By.ID, value='inputPassword2C').send_keys(PJUD_PASSWORD)
        driver.find_element(By.CLASS_NAME, value='btn-ingreso-pjud').click()
        time.sleep(2)
        driver.find_element(By.CLASS_NAME, value='card-text').click()
        time.sleep(2)
        driver.get("https://ojv.pjud.cl/kpitec-ojv-web/index#bandeja/escritos")
        time.sleep(5)
        driver.find_element(By.XPATH, "//select[contains(.,'Seleccione Competencia')]/option[text()='Civil']").click()
        time.sleep(5)
        driver.find_element(By.XPATH, "//a[contains(.,'Escritos Enviados')]").click()
        time.sleep(5)

        actions = ActionChains(driver)
        actions.send_keys(Keys.ARROW_DOWN).perform()

        driver.find_element(By.XPATH, "//button[contains(.,'Exportar Excel')]").click()
        time.sleep(15)
        time.sleep(15)

        path = str(PROCESSING_DIR)
        outputPath = str(OUTPUT_DIR)
        dir_list = os.listdir(path)
        print("Files and directories in '", path, "' :")
        print(dir_list)
        file = dir_list[0]
        path = os.path.join(path, file)
        informePJUD = openpyxl.load_workbook(path)
        escritos_enviados_sheet = informePJUD["Escritos Enviados"]
        get_roles_done_by_excel()
        for column in escritos_enviados_sheet.iter_cols():
            column_name = column[3].value
            if column_name == "RIT":
                for i, cell in enumerate(column):
                    if i < 4:
                        continue
                    trib_cell = "B" + str(i+1)
                    trib = escritos_enviados_sheet[trib_cell].value.upper().replace("º JUZGADO CIVIL DE SANTIAGO", "")
                    valor = cell.value + "-" + trib
                    print(cell.value, 'pjud')
                    if valor in ROLES_DONE:
                        print(cell.value, 'into roles_done')
                        escritos_enviados_sheet.cell(cell.row, cell.column, cell.value).fill = PatternFill(start_color='92D050', end_color='92D050', fill_type="solid")

        outputPath = os.path.join(outputPath, 'RESULTADO.xlsx')
        informePJUD.save(outputPath)

    finally:
        print('Done')


def get_roles_done_by_excel():
    """
    RPA 01 - Review column ENVIO into an Excel file and set the value of ROLES_DONE variable
    """
    try:
        informe_bot = openpyxl.load_workbook(EXCEL_FILE_NAME)
        informe_bot_sheet = informe_bot["Hoja1"]

        rit_list = []

        lista = list(informe_bot_sheet.iter_cols())
        envio_index = None
        rol_index = None
        tribunal_index = None

        for index in range(len(lista)):
            if (lista[index][0].value == 'ENVIO'):
                envio_index = index
            elif (lista[index][0].value == 'ROL'):
                rol_index = index
            elif (lista[index][0].value == 'TRIBUNAL'):
                tribunal_index = index

        for index in range(informe_bot_sheet.max_row):
            if (lista[envio_index][index].value == 'OK'):
                combinacion = lista[rol_index][index].value + '-' + str(lista[tribunal_index][index].value)[0:len(lista[tribunal_index][index].value)-1]
                rit_list.append(combinacion)
            elif (lista[envio_index][index].value == None and lista[rol_index][index].value == None):
                break

        global ROLES_DONE
        ROLES_DONE = list(map(lambda item: "C-" + str(item), rit_list))
        return ROLES_DONE

    finally:
        informe_bot.close
