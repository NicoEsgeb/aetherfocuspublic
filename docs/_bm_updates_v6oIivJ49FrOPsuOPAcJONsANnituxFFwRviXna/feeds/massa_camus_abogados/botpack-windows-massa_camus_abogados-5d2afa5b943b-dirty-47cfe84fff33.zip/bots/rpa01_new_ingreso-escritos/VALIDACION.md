# RPA 01 — Ingreso de Escritos · corrida de validación

Guía para la primera corrida con archivos reales después de la corrección de
escritos duplicados / faltantes.

---

## Qué se corrigió

El bot subía el mismo escrito dos o tres veces y dejaba otros sin subir. La
causa es que **los ROL se repiten entre juzgados**: en la planilla revisada, 31
ROL existían en 2 a 5 tribunales distintos (por ejemplo el ROL `1149-2026`
existe en el 1°, 10°, 20°, 25° y 28°). Cuando el bot elegía mal el tribunal, la
"Consulta Rol" igual encontraba una causa válida — pero **la equivocada**. Esa
sola falla produce los dos síntomas a la vez: una causa recibe un escrito de
más y la que correspondía se queda sin el suyo.

Ahora el bot **comprueba en pantalla** en qué causa está antes de grabar:

| Control | Qué revisa | Si no coincide |
|---|---|---|
| Tribunal | Lee del portal el juzgado que quedó seleccionado y lo compara con la planilla | No graba. Marca `REVISAR` |
| Caratulado | Compara la carátula que muestra el Poder Judicial con la columna `CARATULA` | No graba. Marca `REVISAR` |
| Escritos seleccionados (Envío) | Cuenta cuántos escritos quedaron marcados con "Seleccionar Todo" | No envía. Marca `REVISAR` |

Ambos controles ocurren **antes** de "Grabar Escrito", así que cuando el bot
detecta un problema **no se crea ningún escrito** y la fila se puede reintentar.

### Estados nuevos en la columna PREINGRESO

| Estado | Significa | ¿Se reintenta solo? |
|---|---|---|
| `OK` | Ingresado correctamente | No |
| `ERROR` | Falló **antes** de grabar. No se creó nada | Sí |
| `REVISAR` | Falta el PDF, o el portal abrió otra causa. No se creó nada | Sí |
| `REVISAR_MANUAL` | **Nuevo.** Falló *después* de grabar el escrito | **No — requiere revisión humana** |

`REVISAR_MANUAL` (celda naranja) es la corrección directa de los duplicados: si
el bot ya apretó "Grabar Escrito" y falló al adjuntar el PDF, el escrito **ya
quedó en la Bandeja**. Antes el bot lo reintentaba y lo subía de nuevo. Ahora
se detiene y espera a que una persona revise la Bandeja:

- si el escrito **está completo** → escriba `OK` en la celda
- si el escrito **no existe** → **borre** el contenido de la celda para que se reintente

Cada celda marcada trae un comentario flotante explicando qué pasó.

---

## Cómo hacer la corrida de prueba

> **Importante:** `Ingreso` y `Envío` son tareas separadas. Ejecutar solo
> `Ingreso` deja los escritos en la Bandeja **sin enviarlos** al tribunal, así
> que se puede revisar todo antes de que salga nada.

### Paso 1 — Prueba corta (5 a 10 filas)

1. Prepare una planilla con **solo 5 a 10 filas**, mezclando tribunales de un
   dígito (1° a 9°) y de dos dígitos (10° en adelante). Los de dos dígitos son
   los que más fallaban.
2. Ejecute **únicamente la tarea `Ingreso`**. No ejecute `Envío` todavía.
3. Si el portal cambió y el bot no logra verificar nada, **se detiene solo a
   las 5 filas** con el mensaje `Ninguna de las primeras N filas pudo
   verificarse`. Eso es esperado y no ingresa nada: mándenos el log y lo
   ajustamos.

### Paso 2 — Revisar en el Poder Judicial

Entre a la Bandeja de Escritos y confirme, para cada fila procesada:

- el escrito quedó en la causa correcta (tribunal + carátula)
- **no hay escritos repetidos**
- no falta ninguno de los que quedaron en `OK`

### Paso 3 — Mandarnos los archivos

En la carpeta de salida de la corrida
(`output/output_ingreso/Ingreso_<fecha>/`) van a quedar:

| Archivo | Para qué sirve |
|---|---|
| `rpa01_debug_ingreso.log` | **El importante.** Fila por fila: qué tribunal pidió, cuál mostró el portal, qué carátula leyó, y por qué aceptó o rechazó |
| `rpa01_debug_ingreso.jsonl` | Lo mismo en formato de análisis |
| `ingreso_escritos_summary.json` | Resumen con los totales |
| `output_<planilla>.xlsx` | La planilla con el resultado de esta corrida |

**Mande esos cuatro archivos** más un comentario de lo que vio en la Bandeja.

### Paso 4 — Corrida completa

Con la prueba corta validada, corra la planilla completa (`Ingreso`), revise, y
recién entonces ejecute `Envío`. El Envío genera su propio
`rpa01_debug_envio.log` en la misma carpeta.

---

## Qué se ve en el log

```
--- fila 12 · ROL 1149-2026 · Tribunal 10° · RUT 18977965-8
      pdf: ...\Trib_10°_ROL_1149-2026_18.977.965-8.pdf
      fijar_datos: ya estaba OFF
      tribunal: OK '10º JUZGADO CIVIL DE SANTIAGO' (metodo=native-select, sonda=native-select, intento=1)
      caratula: OK planilla='BANCO ITAU CHILE S.A./GARCÍA' portal='BANCO ITAU CHILE S.A./GARCIA SOTO'
   => OK

--- fila 13 · ROL 1149-2026 · Tribunal 28° · RUT 18596571-6
      [WARN] Tribunal incorrecto tras seleccionar — reintentando | esperado='28º juzgado civil de santiago' portal='8º JUZGADO CIVIL DE SANTIAGO'
   => REVISAR · Tribunal no coincide — planilla esperaba '28º...' y el portal muestra '8º...'
```

La línea que interesa es cualquiera que diga `[WARN]` o `[ERROR]`. Si aparece
`sin verificar`, significa que el bot no pudo **leer** ese dato del portal — no
que esté mal — y hay que ajustar el selector.

---

## Requisitos de la planilla

La columna **`CARATULA`** debe venir llena: es la que permite distinguir dos
causas con el mismo ROL en juzgados distintos. Si falta, el bot avisa al
empezar y esa verificación queda desactivada (el control de tribunal sigue
funcionando).

---

## Interruptores (solo si hace falta ajustar)

Variables de entorno, todas opcionales:

| Variable | Por defecto | Para qué |
|---|---|---|
| `RPA01_VERIFY_TRIBUNAL` | `1` | Verificar el tribunal en pantalla |
| `RPA01_VERIFY_CARATULA` | `1` | Verificar la carátula contra la planilla |
| `RPA01_ENVIO_ENFORCE_COUNT` | `1` | No enviar si "Seleccionar Todo" marcó más escritos de los que corresponden |
| `RPA01_VERIFY_PROBE_ROWS` | `5` | Filas de sondeo antes de abortar si nada se puede verificar (`0` desactiva) |
| `RPA01_FIJAR_DATOS` | `off` | `off` \| `on` \| `legacy` (el toggle ciego anterior) \| `skip` |
| `RPA01_DEBUG_DIR` | — | Carpeta alternativa para los logs de depuración |
