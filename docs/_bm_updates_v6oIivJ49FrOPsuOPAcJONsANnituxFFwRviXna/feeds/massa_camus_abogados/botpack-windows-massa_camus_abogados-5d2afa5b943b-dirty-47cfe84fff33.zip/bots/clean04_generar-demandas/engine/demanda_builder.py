"""
clean04 — demanda paragraph assembly
====================================
Turns the matriz rows of ONE RUT into the ordered list of paragraphs of a
demanda ejecutiva, following `arbol_decision.svg` + the EXACT wording of
`Formato_macro_2026-06-24_v02.docx`, with the resolved overrides:

  * template per row: CARTERA_A_PROCESAR == MP → A (en cuotas); else
    PAGARE_FIRMADO_CLIENTE == SI → C (plazo fijo, needs FECHA_VCTO_PAGARE),
    otherwise B (a la Vista). CARTERA_A_PROCESAR == RE → the human hasn't
    resolved it yet (ERROR).
  * the mandato paragraphs (A/B) say just "en el Contrato ..." (v03 client
    fix — dropped the trailing "Mandato"; never the old "Contrato de
    Productos y Servicios Bancarios") (#10). The SEGUNDO OTROSÍ document
    name keeps its own wording "Contrato Mandato suscrito ...".
  * the "tasa mensual" paragraph is omitted (#9).
  * the literal "el (los) siguiente (s) pagaré(s)" — no singular/plural
    logic (#11).
  * no page-header code (#12).
  * RUEGO total = Σ MONTO_ADEUDADO of every row (never blank, #8).
  * SEGUNDO OTROSÍ (order per Formato_macro): 4 fixed docs + doc 9342 iff
    HOJA=SI **or** MANDATO=SI + [the «NOTARIO» value · "Hoja de firma suscrita
    por del demandado."] iff HOJA=SI (#6/#7) + "Contrato Mandato suscrito…" iff
    MANDATO=SI (#1). Doc 9342 (personería de los mandatarios del Banco) backs
    both the hoja de firma and the contrato mandato, hence the OR — client
    correction 2026-08-03 (2026-07-09 had already loosened HOJA∧MANDATO to
    HOJA-only; that still dropped 9342 on HOJA=NO ∧ MANDATO=SI RUTs).

The builder does NOT render — it returns structured blocks that engine/render.py
lays out with PyMuPDF. It assumes the RUT has already been validated (see
`validate_rut`); `build_demanda` only reads fields it knows are present.
"""
from __future__ import annotations

import re
from typing import Any

from .matriz_io import Row, is_missing, rut_digits

# ---- fixed party data (source of truth: Formato_macro header) --------------
DEMANDANTE = "BANCO ITAU CHILE"
DEMANDANTE_RUT = "97.023.000-9"
ABOGADO = "JOAQUÍN CARRILLO MORENO"
ABOGADO_RUT = "11.346.197-7"

SI = "SI"

# ---- template selection ----------------------------------------------------
# Per-pagaré (checked on every row): identity + the pagaré's own operación/fecha.
ROW_REQUIRED = ["rut", "dv", "operacion", "fecha_suscripcion_pagare"]
# Deudor-level (checked once per RUT — used a single time in the intro/RUEGO).
# A later pagaré row of the same RUT may leave these blank; that's fine as long
# as at least one row of the RUT carries them.
DEUDOR_REQUIRED = ["nombre", "domicilio_deudor", "comuna_deudor", "region_deudor"]
REQUIRED_BY_TEMPLATE = {
    "A": ["tasa_interes", "num_cuotas", "monto_cuota", "dia_del_mes_vcto_cuota",
          "fecha_vcto_1ra_cuota", "nro_1ra_cuota_imp", "fecha_1ra_cuota_imp",
          "monto_adeudado"],
    "B": ["monto_pagare", "monto_adeudado"],
    "C": ["monto_pagare", "fecha_vcto_pagare"],
}


def _yes(value: Any) -> bool:
    return str(value or "").strip().upper() == SI


def select_template(row: Row) -> str:
    """A / B / C, or 'RE' when CARTERA_A_PROCESAR is still unresolved."""
    cartera = row.get_str("cartera_a_procesar").upper()
    if cartera == "RE":
        return "RE"
    if cartera == "MP":
        return "A"
    if _yes(row.get("pagare_firmado_cliente")):
        return "C"
    return "B"


def required_fields(row: Row, template: str) -> list[str]:
    """Per-row required fields (deudor-level fields are checked per-RUT)."""
    return ROW_REQUIRED + REQUIRED_BY_TEMPLATE.get(template, [])


def total_amount(row: Row) -> int:
    """Amount this row contributes to the RUEGO total. Σ MONTO_ADEUDADO (#8);
    for a-la-Vista rows ADEUDADO == PAGARE, so fall back to MONTO_PAGARE when
    ADEUDADO is absent — a validated row always has at least one of them."""
    for field in ("monto_adeudado", "monto_pagare"):
        v = row.get(field)
        if not is_missing(v):
            return _to_int(v)
    return 0


def validate_rut(rows: list[Row]) -> dict:
    """Decide the fate of a whole RUT (1 PDF = all its rows).

    Returns {status: 'OK'|'REVISAR'|'ERROR', missing_by_row: {excel_row:[field]},
             error_reason: str, error_cells: {excel_row:[field]}, templates:{...}}.
    """
    templates: dict[int, str] = {}
    missing_by_row: dict[int, list[str]] = {}
    error_cells: dict[int, list[str]] = {}
    error_reason = ""
    has_re = False

    for row in rows:
        tpl = select_template(row)
        templates[row.excel_row] = tpl
        if tpl == "RE":
            has_re = True
            error_cells[row.excel_row] = ["cartera_a_procesar"]
            continue
        missing = [f for f in required_fields(row, tpl) if is_missing(row.get(f))]
        # C needs FECHA_VCTO_PAGARE to print "el día X" — already in its required
        # list, so a firmado pagaré without the date lands in REVISAR here.
        if missing:
            missing_by_row[row.excel_row] = missing

    # Deudor-level fields: required once per RUT (used a single time in the
    # intro/RUEGO). Flag them on the first row when NO row of the RUT has them.
    for field in DEUDOR_REQUIRED:
        if not any(row.has(field) for row in rows):
            missing_by_row.setdefault(rows[0].excel_row, []).append(field)

    if has_re:
        return {
            "status": "ERROR",
            "missing_by_row": missing_by_row,
            "error_reason": (
                "CARTERA_A_PROCESAR sigue en RE: el humano debe cambiarla a MP o "
                "VI (clean04 elige la plantilla con esa columna)."),
            "error_cells": error_cells,
            "templates": templates,
        }
    if missing_by_row:
        return {
            "status": "REVISAR",
            "missing_by_row": missing_by_row,
            "error_reason": "",
            "error_cells": {},
            "templates": templates,
        }
    return {
        "status": "OK",
        "missing_by_row": {},
        "error_reason": "",
        "error_cells": {},
        "templates": templates,
    }


# ---- number / value formatting --------------------------------------------
def _to_int(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        return int(round(value))
    digits = re.sub(r"[^\d]", "", str(value).split(",")[0])
    return int(digits) if digits else 0


def fmt_money(value: Any) -> str:
    return f"{_to_int(value):,}".replace(",", ".")


def fmt_tasa(value: Any) -> str:
    """1.31 / '1,63' / '2,35%' -> '1,31' / '1,63' / '2,35' (2 decimals, comma)."""
    if value is None:
        return ""
    try:
        f = float(str(value).strip().replace("%", "").replace(",", "."))
    except ValueError:
        return str(value).strip()
    return f"{f:.2f}".replace(".", ",")


def fmt_rut(rut: Any, dv: Any) -> str:
    # dv may legitimately be 0 (falsy) or 'K' — don't drop it with `dv or ""`.
    dv_s = "" if dv is None else str(dv).strip().upper()
    return f"{_to_int(rut):,}".replace(",", ".") + "-" + dv_s


def _s(row: Row, field: str) -> str:
    return row.get_str(field)


# ---- run / block helpers ---------------------------------------------------
def T(text: str):
    return (text, False)


def Bd(text: str):
    return (text, True)


def _p(runs, align="justify"):
    return {"kind": "p", "align": align, "runs": list(runs)}


def _item(num: str, runs):
    return {"kind": "item", "num": num, "runs": list(runs)}


# ---- fixed text blocks -----------------------------------------------------
_EN_LO_PRINCIPAL_BOLD = ["EN LO PRINCIPAL", "PRIMER OTROSI", "SEGUNDO OTROSI",
                         "TERCER OTROSI", "CUARTO OTROSI", "QUINTO OTROSI",
                         "SEXTO OTROSI"]
EN_LO_PRINCIPAL = (
    "EN LO PRINCIPAL: Demanda Ejecutiva y solicita se despache mandamiento de "
    "ejecución y embargo. PRIMER OTROSI: Acompaña documentos y solicita su "
    "custodia. SEGUNDO OTROSI: Acompaña documentos, con citación. TERCER OTROSI: "
    "Señala bienes para la traba de embargo. CUARTO OTROSI: Forma de "
    "notificación. QUINTO OTROSI: Se tenga presente. SEXTO OTROSI: Patrocinio y "
    "poder."
)

INTRO_FIJO = (
    "JOAQUIN CARRILLO MORENO, abogado, mandatario judicial y actuando en "
    "representación convencional, según se acreditará, de ITAÚ CORPBANCA, hoy "
    "BANCO ITAU CHILE, sociedad anónima bancaria, cuyo representante legal es "
    "su Gerente General don André Carvalho Whyte Gailey, Abogado, C.I. N° "
    "48.225.574-4, todos con domicilio para "
    "estos efectos en calle Málaga 89, Piso 9, Las Condes, ciudad de Santiago, "
    "Región Metropolitana, y con correo electrónico dj@mcoabogados.com para "
    "efectos de notificación, a US. respetuosamente digo:"
)
_INTRO_FIJO_BOLD = ["JOAQUIN CARRILLO MORENO", "ITAÚ CORPBANCA", "BANCO ITAU CHILE"]

CIERRE_VENCIDAS = ("Las obligaciones que por esta demanda se cobran se "
                   "encuentran vencidas y son actualmente exigibles.")
CIERRE_ACELERACION = (
    " En subsidio, para el caso de existir obligaciones pactadas en cuotas o con "
    "vencimientos sucesivos, mi representada hace efectiva la cláusula de "
    "aceleración contenida en los respectivos pagarés y/o contratos que les "
    "sirven de antecedente, declarando vencido y exigible el total del saldo "
    "insoluto adeudado.")
CIERRE_PROTESTO = ("En el o los pagaré(s) se liberó al acreedor de la "
                   "obligación de protesto.")
CIERRE_NOTARIO = (
    "Las firmas de los suscriptores del o los pagaré(s) se encuentran "
    "autorizadas ante Notario, por lo que el o los título(s) goza(n) de mérito "
    "ejecutivo, de acuerdo con lo establecido en el artículo 434 N° 4 del "
    "Código de Procedimiento Civil.")
CIERRE_LIQUIDA = ("La deuda es líquida, actualmente exigible y su acción no se "
                  "encuentra prescrita.")

POR_TANTO = (
    "POR TANTO y de acuerdo con lo expuesto, documentos acompañados y a lo "
    "dispuesto en los artículos 254, 434 N° 4 y siguientes del Código de "
    "Procedimiento Civil, Ley N° 18.092, Ley N° 18.010 y demás normas legales "
    "aplicables:")

PRIMER_OTROSI = (
    "PRIMER OTROSI: Ruego a US. tener por acompañados, bajo el apercibimiento "
    "contemplado en el Artículo 346 N° 3 del Código de Procedimiento Civil, los "
    "siguientes documentos y ordenar su custodia en la Secretaría del Tribunal:")
PRIMER_OTROSI_DOC = ("El o los pagaré(s) singularizado(s) en lo principal de "
                     "esta demanda.")

SEGUNDO_OTROSI = ("SEGUNDO OTROSI: Ruego a US. tener por acompañados con "
                  "citación, los siguientes documentos:")

DOC_9342 = (
    "Copia de la escritura pública de fecha 28 de marzo de 2016, Repertorio N° "
    "9342, otorgada en la Notaría de Santiago de don René Benavente Cash, con "
    "firma electrónica avanzada, donde consta la personería y facultades de los "
    "mandatarios del Banco, para suscribir pagarés. Código de verificación: "
    "6FUXSH-W290169.")
DOC_11706 = (
    "Copia de escritura pública de fecha 4 de marzo del año 2026, Repertorio Nº "
    "11706, otorgada en la Notaría de Santiago de doña María Soledad Lascar "
    "Merino, en donde consta nuestra personería para actuar en nombre y "
    "representación de Banco Itaú Chile. Dicho documento fue emitido con firma "
    "Electrónica avanzada, (Ley N° 19.799, conforme al procedimiento establecido "
    "por auto acordado de 13/10/2016 de la Excma. Corte Suprema), el cual se "
    "acompaña con citación y puede ser verificado a través de la página "
    "www.notariosyconservadores.cl, mediante el código de verificación N° "
    "316-436373.")
DOC_37590 = (
    "Copia de escritura pública de fecha 26 de octubre de 2016, Repertorio N° "
    "37.590/2016, otorgada en la notaría de la ciudad de Santiago de don René "
    "Benavente Cash, en la cual consta la personería de don Danilo Torres "
    "Villarroel para representar a Itaú Corpbanca hoy Banco Itaú Chile. Dicho "
    "documento fue emitido con firma Electrónica avanzada, (Ley N° 19.799, "
    "conforme al procedimiento establecido por auto acordado de 13/10/2016 de la "
    "Excma. Corte Suprema), el cual se acompaña y puede ser verificado a través "
    "de la página www.fojas.cl mediante el código de verificación N° "
    "123456803160.")
DOC_RES409 = (
    "Copia de la Resolución N° 409, dictada por la Superintendencia de Bancos e "
    "Instituciones Financieras, en la que consta la fusión de Banco Itaú Chile y "
    "Corpbanca, y el cambio de nombre de razón social de este último, por Itaú "
    "Corpbanca.")
DOC_CMF = (
    "Certificado emitido por la Comisión para el Mercado Financiero, que "
    "acredita que en virtud de la Resolución N° 2215 dictada por dicha entidad, "
    "se aprobó y autorizó el cambio de razón social de Itaú Corpbanca a Banco "
    "Itaú Chile.")
DOC_CONTRATO_MANDATO = "Contrato Mandato suscrito por el demandado."
# HOJA_DE_FIRMA=SI block closer. Text is reproduced verbatim from Formato_macro
# (the "por del demandado" wording is the client's own — do not "correct" it).
DOC_HOJA_FIRMA = "Hoja de firma suscrita por del demandado."

TERCER_OTROSI = (
    "TERCER OTROSI: Ruego a US. tener presente que señalo para la traba del "
    "embargo todos aquellos bienes muebles o inmuebles que, actualmente, sean o "
    "aparezcan posteriormente de dominio del demandado, designándolo depositario "
    "provisional, bajo su custodia y responsabilidad legal.")
CUARTO_OTROSI = (
    "CUARTO OTROSI: Sírvase US. tener presente que atendido lo dispuesto en los "
    "artículos 48 y 49 del Código de Procedimiento Civil, las sentencias "
    "definitivas, las resoluciones en que se reciba a prueba la causa, o se "
    "ordene la comparecencia personal de las partes, se notifiquen a esta parte "
    "al correo electrónico dj@mcoabogados.com.")
QUINTO_OTROSI = (
    "QUINTO OTROSI: Conforme lo dispuesto por el Artículo 3 Bis del Código de "
    "Procedimiento Civil, y con el fin de ofrecer a la parte demandada salidas "
    "alternativas a este juicio, distintas del remate de los bienes que se "
    "puedan embargar en autos; o bien del pago íntegro e inmediato del (los) "
    "crédito(s) demandado(s) en esta ejecución, vengo en solicitar a S.S. tener "
    "presente que para efectos de evaluar alternativas de normalización de su "
    "situación crediticia, el demandado puede comunicarse al siguiente correo "
    "electrónico, adjuntando copia de su cédula de identidad para efectos de "
    "asegurar y proteger la información entregada, contactojudicial@itau.cl.")
SEXTO_OTROSI = (
    "SEXTO OTROSI: Sírvase US. tener presente que, en mi calidad de abogado "
    "habilitado para el ejercicio de la profesión, asumo el patrocinio y poder "
    "en esta causa, señalando como domicilio el ubicado en calle Málaga 89, Piso "
    "9, Las Condes, ciudad de Santiago, Región Metropolitana.")


def _bold_terms(text: str, terms):
    """Split `text` into runs, bolding every occurrence of the given terms."""
    if not terms:
        return [T(text)]
    pat = re.compile("|".join(re.escape(t) for t in sorted(terms, key=len, reverse=True)))
    runs = []
    i = 0
    for mo in pat.finditer(text):
        if mo.start() > i:
            runs.append(T(text[i:mo.start()]))
        runs.append(Bd(mo.group(0)))
        i = mo.end()
    if i < len(text):
        runs.append(T(text[i:]))
    return runs


# ---- per-pagaré paragraph builders ----------------------------------------
def _num_prefix(index: int, total: int) -> str:
    """'1.- ' when the RUT has several pagarés (matches the golden B), '' for a
    single pagaré (matches the golden A/C)."""
    return f"{index}.- " if total > 1 else ""


def _pagare_A(row: Row, index: int, total: int) -> list[dict]:
    blocks: list[dict] = []
    prefix = _num_prefix(index, total)
    op = _s(row, "operacion")
    monto_pagare = fmt_money(row.get("monto_pagare"))
    # 1) base (+ salvo la última)
    base = [
        T(f"{prefix}Pagaré Nº "), Bd(op),
        T(", suscrito en representación del demandado a la Orden de "),
        Bd(DEMANDANTE), T(", con fecha "), Bd(_s(row, "fecha_suscripcion_pagare")),
        T(" por la suma de $ "), Bd(monto_pagare),
        T(".-, correspondiente a capital, que devenga un interés mensual de "),
        Bd(fmt_tasa(row.get("tasa_interes"))), T("%. El demandado se obligó a "),
        T("pagar al Banco la suma de $ "), Bd(monto_pagare),
        T(".-, conjuntamente, con los intereses, mediante "),
        Bd(_s(row, "num_cuotas")),
        T(" cuotas mensuales, iguales y sucesivas, cada una por la suma de $ "),
        Bd(fmt_money(row.get("monto_cuota"))), T(".-"),
    ]
    if not is_missing(row.get("monto_ultima_cuota")):
        base += [T(", salvo la última por $ "),
                 Bd(fmt_money(row.get("monto_ultima_cuota"))), T(" .-")]
    elif _yes(row.get("pagare_ultima_cuota_inferior")):
        base += [T(", salvo la última que será inferior.")]
    blocks.append(_p(base))

    # 2) vencimiento (+ última cuota date, closes the sentence)
    venc = [
        T("Las cuotas tienen vencimiento los días "),
        Bd(_s(row, "dia_del_mes_vcto_cuota")),
        T(" de cada mes, venciendo la primera el "),
        Bd(_s(row, "fecha_vcto_1ra_cuota")),
    ]
    if not is_missing(row.get("fecha_vcto_ultima_cuota")):
        venc += [T(" y la última el "), Bd(_s(row, "fecha_vcto_ultima_cuota")),
                 T(".")]
    else:
        venc += [T(".")]
    blocks.append(_p(venc))

    # (the "tasa mensual" paragraph is intentionally omitted — #9)

    # 3) cuota impaga
    blocks.append(_p([
        T("Llegada la fecha de vencimiento de la cuota Nº "),
        Bd(_s(row, "nro_1ra_cuota_imp")), T(" del día "),
        Bd(_s(row, "fecha_1ra_cuota_imp")),
        T(", esta no fue pagada, ni tampoco las posteriores, adeudando el "),
        T("demandado un capital insoluto de $ "),
        Bd(fmt_money(row.get("monto_adeudado"))),
        T(".- más todos los intereses pactados en el pagaré, razón por la cual "),
        T("Banco Itaú Chile viene en hacer exigible por medio de la presente "),
        T("demanda el total de lo adeudado."),
    ]))

    # 4) HOJA_DE_FIRMA = SI → mandato + mora + constancia (per pagaré, #A block)
    if _yes(row.get("hoja_de_firma")):
        blocks.append(_p([T(
            "Este pagaré fue suscrito por Banco Itaú Chile en representación del "
            "demandado, en virtud de mandato especial otorgado por éste en el "
            "Contrato y que se acompaña en un otrosí de la presente "
            "demanda.")]))
        blocks.append(_p([T(
            "En el pagaré se estableció que en caso de mora o simple retardo en "
            "el pago de todo o parte de una o más de las cuotas de capital e "
            "intereses que se establecen, el Banco tendrá la facultad de hacer "
            "exigible el total de lo adeudado, el que en ese evento se "
            "considerará de plazo vencido para todos los efectos legales. Esta "
            "mora o simple retardo, devengará desde el día de la mora o simple "
            "retardo y hasta el de su completo y efectivo pago, el interés "
            "máximo convencional permitido estipular para operaciones de crédito "
            "de dinero no reajustables, correspondiendo aplicar la tasa más alta "
            "entre la vigente a la fecha de la suscripción del pagaré y la "
            "vigente al día de la mora o simple retardo.")]))
        blocks.append(_p([T(_CONSTANCIA)]))
    return blocks


def _pagare_B(row: Row, index: int, total: int) -> list[dict]:
    prefix = _num_prefix(index, total)
    op = _s(row, "operacion")
    return [
        _p([
            T(f"{prefix}Pagaré N° "), Bd(op),
            T(" suscrito en representación del demandado, a la Vista y a la Orden "),
            T("de BANCO ITAÚ CHILE con fecha "),
            Bd(_s(row, "fecha_suscripcion_pagare")), T(" por la suma de $ "),
            Bd(fmt_money(row.get("monto_pagare"))),
            T(".-, correspondiente a capital, que devenga, durante toda la "),
            T("vigencia de la obligación, intereses a la tasa máxima "),
            T("convencional para operaciones de crédito de dinero no "),
            T("reajustable."),
        ]),
        _p([
            T("El demandado no pagó el Pagaré a la Vista, razón por la cual el "),
            T("Banco viene por esta demanda en hacer exigible el total adeudado, "),
            T("ascendente a la suma de $ "),
            Bd(fmt_money(row.get("monto_adeudado"))),
            T(".-, más todos los intereses pactados en el pagaré."),
        ]),
        _p([T(
            "Este pagaré fue suscrito por Banco Itaú Chile en representación del "
            "deudor, en virtud de mandato especial otorgado por el demandado en "
            "el Contrato y que se acompaña en un otrosí de la presente "
            "demanda.")]),
    ]


def _pagare_C(row: Row, index: int, total: int) -> list[dict]:
    prefix = _num_prefix(index, total)
    op = _s(row, "operacion")
    monto_pagare = fmt_money(row.get("monto_pagare"))
    return [
        _p([
            T(f"{prefix}Pagaré Nº "), Bd(op),
            T(", suscrito por el demandado a la orden de "), Bd(DEMANDANTE),
            T(", con fecha "), Bd(_s(row, "fecha_suscripcion_pagare")),
            T(", por la suma de $ "), Bd(monto_pagare),
            T(".-, correspondiente a capital. El demandado se obligó a pagar al "),
            T("Banco la referida suma el día "),
            Bd(_s(row, "fecha_vcto_pagare")), T("."),
        ]),
        _p([
            T("El demandado no pagó el Pagaré en la fecha señalada, razón por la "),
            T("cual el Banco viene por la esta demanda en hacer exigible el "),
            T("total adeudado, tanto ascendente a la suma de $ "), Bd(monto_pagare),
            T(".-, más todos los intereses pactados en el pagaré."),
        ]),
        _p([T(
            "En el pagaré se estableció que en caso de mora o simple retardo en "
            "el pago del pagaré se devengará un interés penal igual al máximo que "
            "la ley permita para operaciones no reajustables de esta naturaleza "
            "que resulte ser la más alta de la que se encuentre vigente a la "
            "fecha de la suscripción del pagaré o de la vigente al día de la mora "
            "o simple retardo, el que se aplicará desde la mora o simple retardo "
            "hasta la fecha del efectivo pago.")]),
        _p([T(_CONSTANCIA)]),
    ]


_CONSTANCIA = (
    "Se deja expresa constancia que, tratándose de pagarés asociados a préstamos "
    "bancarios, la suma demandada corresponde al saldo insoluto efectivamente "
    "adeudado, atendidos los pagos que el deudor hubiere realizado con "
    "anterioridad a la mora, y no necesariamente al capital originalmente "
    "otorgado.")

_PAGARE_BUILDERS = {"A": _pagare_A, "B": _pagare_B, "C": _pagare_C}


# ---- whole-demanda assembly ------------------------------------------------
def build_demanda(rows: list[Row], templates: dict[int, str]) -> dict:
    """Return {'basename': str, 'blocks': [block,...]} for a validated RUT.
    Renderers append their own extension ('.pdf' / '.docx')."""
    first = rows[0]
    # Deudor-level fields come from whichever row of the RUT carries them (a
    # later pagaré row may leave them blank — see DEUDOR_REQUIRED).
    nombre = _first_present(rows, "nombre")
    domicilio = _first_present(rows, "domicilio_deudor")
    comuna = _first_present(rows, "comuna_deudor")
    region = _first_present(rows, "region_deudor")
    rut_dv = fmt_rut(first.get("rut"), first.get("dv"))
    total = len(rows)

    blocks: list[dict] = []

    # header table (label : value) — values bold
    blocks.append({"kind": "header_table", "pairs": [
        ("Procedimiento", "EJECUTIVO"),
        ("Materia", "COBRO DE PAGARÉ"),
        ("Demandante", DEMANDANTE),
        ("Rut N°", DEMANDANTE_RUT),
        ("Abogado patrocinante y Apoderado", ABOGADO),
        ("Rut. N°", ABOGADO_RUT),
        ("Demandado", nombre),
        ("Rut N°", rut_dv),
    ]})

    blocks.append(_p(_bold_terms(EN_LO_PRINCIPAL, _EN_LO_PRINCIPAL_BOLD)))
    blocks.append(_p([Bd("S.J.L. en lo Civil de Santiago.")], align="center"))
    blocks.append(_p(_bold_terms(INTRO_FIJO, _INTRO_FIJO_BOLD)))

    # "Que, en la representación indicada, vengo en interponer ... :"
    blocks.append(_p([
        T("Que, en la representación indicada, vengo en interponer demanda "),
        T("ejecutiva en contra de "), Bd(nombre), T(", Rut "), Bd(rut_dv),
        T(", ignoro profesión u oficio, domiciliado en "),
        Bd(domicilio), T(", "), Bd(comuna), T(", "), Bd(region),
        T(", en virtud de ser deudor vencido de las obligaciones que constan en "),
        T("el (los) siguiente (s) pagaré(s):"),
    ]))

    # one block group per pagaré, in matriz order
    for i, row in enumerate(rows, start=1):
        builder = _PAGARE_BUILDERS[templates[row.excel_row]]
        blocks.extend(builder(row, i, total))

    # ---- shared closing (once) ----
    has_cuotas = any(templates[r.excel_row] == "A" for r in rows)
    vencidas = CIERRE_VENCIDAS + (CIERRE_ACELERACION if has_cuotas else "")
    blocks.append(_p([T(vencidas)]))
    blocks.append(_p([T(CIERRE_PROTESTO)]))
    blocks.append(_p([T(CIERRE_NOTARIO)]))
    blocks.append(_p([T(CIERRE_LIQUIDA)]))

    # ---- POR TANTO + RUEGO ----
    blocks.append(_p(_bold_terms(POR_TANTO, ["POR TANTO"])))
    suma = fmt_money(sum(total_amount(r) for r in rows))
    blocks.append(_p([
        Bd("RUEGO A US.:"),
        T(" tener por interpuesta demanda ejecutiva y disponer se despache "),
        T("mandamiento de ejecución y embargo en contra de "), Bd(nombre),
        T(" ya individualizado(a), por la suma de $ "), Bd(suma),
        T(".-, ordenando se siga adelante la ejecución hasta hacer a mi parte, "),
        T("entero y cumplido pago de lo adeudado, más intereses pactados, "),
        T("reajustes y costas."),
    ]))

    # ---- PRIMER OTROSI ----
    blocks.append(_p(_bold_terms(PRIMER_OTROSI, ["PRIMER OTROSI"])))
    blocks.append(_item("•", [T(PRIMER_OTROSI_DOC)]))

    # ---- SEGUNDO OTROSI (conditional documents) ----
    # Order per Formato_macro: the 4 fixed corporate docs, then doc 9342, then
    # the rest of the HOJA_DE_FIRMA=SI block (the «NOTARIO» column value and the
    # "Hoja de firma…" line), then the CONTRATO_MANDATO=SI doc.
    #
    # Doc 9342 is the *mandatarios del Banco* power of attorney: it backs BOTH
    # the hoja de firma AND the contrato mandato, so it is gated on HOJA **or**
    # MANDATO (client correction 2026-08-03 — the previous HOJA-only rule
    # dropped it on HOJA=NO ∧ MANDATO=SI RUTs, which the client then had to add
    # by hand; see training/client_output_1). Neither flag → no 9342.
    blocks.append(_p(_bold_terms(SEGUNDO_OTROSI, ["SEGUNDO OTROSI"])))
    hoja = any(_yes(r.get("hoja_de_firma")) for r in rows)
    mandato = any(_yes(r.get("contrato_mandato_firmado_cliente")) for r in rows)
    docs: list[list] = [
        [T(DOC_11706)],
        [T(DOC_37590)],
        [T(DOC_RES409)],
        [T(DOC_CMF)],
    ]
    if hoja or mandato:
        docs.append([T(DOC_9342)])
    if hoja:
        notario_txt = _first_present(rows, "notario")
        if notario_txt:
            docs.append([T(notario_txt)])
        docs.append([T(DOC_HOJA_FIRMA)])
    if mandato:
        docs.append([T(DOC_CONTRATO_MANDATO)])
    for i, doc_runs in enumerate(docs, start=1):
        blocks.append(_item(f"{i}.", doc_runs))

    # ---- fixed closing otrosíes ----
    blocks.append(_p(_bold_terms(TERCER_OTROSI, ["TERCER OTROSI"])))
    blocks.append(_p(_bold_terms(CUARTO_OTROSI, ["CUARTO OTROSI"])))
    blocks.append(_p(_bold_terms(QUINTO_OTROSI, ["QUINTO OTROSI"])))
    blocks.append(_p(_bold_terms(SEXTO_OTROSI, ["SEXTO OTROSI"])))

    return {"basename": f"{rut_dv}_DEMANDA", "blocks": blocks}


def _first_present(rows: list[Row], field: str) -> str:
    for row in rows:
        v = row.get_str(field)
        if v and v.upper() not in ("NO_ENCONTRADO", "#N/A"):
            return v
    return ""
