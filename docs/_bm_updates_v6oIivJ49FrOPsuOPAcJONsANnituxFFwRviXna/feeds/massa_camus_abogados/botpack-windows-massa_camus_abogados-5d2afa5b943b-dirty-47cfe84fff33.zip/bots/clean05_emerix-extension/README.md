# Clean05 - Emerix (Edge extension)

This bot runs the attended Clean05 Excel-to-Emerix workflow:

1. BotManager receives one `.xlsx` or `.xlsm` input.
2. The user opens normal Microsoft Edge. The panel appears from the Emerix login
   page onward, then the user logs in manually.
3. BotManager starts a local bridge on `http://127.0.0.1:8766`.
4. On `https://itau.emerix.net/emerix.ui/app/dashboard`, the user presses
   **Start** in the Clean05 panel.
5. For `Tipo de Gasto`, the bot first applies the established mapping from
   `Resultado Gestión`. If no rule matches, it uses the same row's
   `NOMBRE EMERIX` value as the literal dropdown label.
6. Valid rows are processed in order. Incomplete rows are skipped as
   `Pendiente`, with the exact Excel cell commented, while the rest continue.
7. The task writes a result workbook and `bridge_connection.json` receipt under
   `output/`.

`NOMBRE EMERIX` is a required header and a required row value. A missing header
blocks startup with the standard missing-columns notification; a blank cell
marks only that row `Pendiente`.

## Load the extension in Edge

Open `edge://extensions`, enable **Developer mode**, choose **Load unpacked**,
and select:

```text
bots/clean05_emerix-extension/extension
```

After installing or updating the unpacked extension, reload the Emerix tab once.
