import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    property string matrixPath: ""
    property string fechaDesde: ""
    property string fechaHasta: ""
    property string informePath: ""
    property string caratulasFolderPath: ""
    property string demandasPath: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal matrixPathEdited(string value)
    signal fechaDesdeEdited(string value)
    signal fechaHastaEdited(string value)
    signal informePathEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            var fallbackValue = taskValueAt(workspaceTaskCombo.currentIndex)
            if (fallbackValue.length > 0) {
                workspaceTaskNameEdited(fallbackValue)
            }
        }
    }

    function normalizedTask(taskName) {
        return String(taskName || "").replace(/[^A-Za-z0-9]/g, "").toLowerCase()
    }

    function taskLabel(taskName) {
        var labels = {
            rpa06ingreso: "Ingresar demandas",
            rpa06descargarinformepjud: "Descargar Informe",
            rpa06getcaratulas: "Descargar Caratulas"
        }
        var key = normalizedTask(taskName)
        if (labels[key] !== undefined) {
            return labels[key]
        }
        return String(taskName || "")
    }

    function taskDisplayOptions() {
        var options = workspaceConfig && workspaceConfig.taskOptions ? workspaceConfig.taskOptions : []
        var display = []
        for (var i = 0; i < options.length; i++) {
            var value = String(options[i] || "").trim()
            if (value.length === 0) {
                continue
            }
            display.push({
                value: value,
                label: taskLabel(value)
            })
        }
        return display
    }

    function taskValueAt(index) {
        var options = taskDisplayOptions()
        if (index < 0 || index >= options.length) {
            return ""
        }
        return String(options[index].value || "")
    }

    function taskModuleSource() {
        var task = normalizedTask(workspaceTaskName)
        if (task.length === 0) {
            task = normalizedTask(taskValueAt(workspaceTaskCombo.currentIndex))
        }
        if (task === "rpa06ingreso" || task === "ingresardemandas") {
            return String(Qt.resolvedUrl("rpa06_task_ingresoUI.qml"))
        }
        if (task === "rpa06descargarinformepjud" || task === "descargarinforme") {
            return String(Qt.resolvedUrl("rpa06_task_descargarInformeUI.qml"))
        }
        if (task === "rpa06getcaratulas" || task === "descargarcaratulas") {
            return String(Qt.resolvedUrl("rpa06_task_getCaratulasUI.qml"))
        }
        return ""
    }

    function validate() {
        var source = taskModuleSource()
        if (source.length === 0) {
            return ""
        }
        if (!taskInputLoader.item) {
            return "No se pudo cargar el formulario de la task."
        }
        if (taskInputLoader.item["validate"]) {
            var message = taskInputLoader.item["validate"]()
            if (message && message.length > 0) {
                return message
            }
        }
        return ""
    }

    function buildPayload() {
        var payload = {}
        if (taskInputLoader.item && taskInputLoader.item["buildPayload"]) {
            var taskPayload = taskInputLoader.item["buildPayload"]()
            for (var key in taskPayload) {
                payload[key] = taskPayload[key]
            }
        }
        return payload
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 10

        Label {
            text: "Task"
            color: root.textMuted
            Layout.preferredWidth: 38
        }

        Common.StyledComboBox {
            id: workspaceTaskCombo
            Layout.fillWidth: true
            textRole: "label"
            model: root.taskDisplayOptions()
            currentIndex: {
                var options = root.taskDisplayOptions()
                if (options.length === 0) {
                    return -1
                }
                for (var i = 0; i < options.length; i++) {
                    if (String(options[i].value || "") === root.workspaceTaskName) {
                        return i
                    }
                }
                return 0
            }
            onActivated: {
                var value = root.taskValueAt(currentIndex)
                if (value.length > 0) {
                    root.workspaceTaskNameEdited(value)
                }
            }
            onCurrentIndexChanged: {
                if (!visible) {
                    return
                }
                var value = root.taskValueAt(currentIndex)
                if (value.length > 0) {
                    root.workspaceTaskNameEdited(value)
                }
            }
        }
    }

    Loader {
        id: taskInputLoader
        Layout.fillWidth: true
        Layout.preferredHeight: item ? Math.max(item.implicitHeight, item.childrenRect.height) : 0
        source: root.taskModuleSource()
        onLoaded: {
            if (item) {
                item.width = width
                if (item["enableMatrixSelection"] !== undefined) {
                    item["enableMatrixSelection"] = true
                }
            }
        }
        onWidthChanged: {
            if (item) {
                item.width = width
            }
        }
    }

    Binding {
        target: taskInputLoader.item
        property: "workspaceConfig"
        value: root.workspaceConfig
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "helpers"
        value: root.helpers
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "matrixPath"
        value: root.matrixPath
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "fechaDesde"
        value: root.fechaDesde
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "fechaHasta"
        value: root.fechaHasta
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "informePath"
        value: root.informePath
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "caratulasFolderPath"
        value: root.caratulasFolderPath
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "demandasPath"
        value: root.demandasPath
        when: taskInputLoader.item !== null
    }

    Connections {
        target: taskInputLoader.item
        ignoreUnknownSignals: true

        function onMatrixPathEdited(value) {
            root.matrixPathEdited(value)
        }

        function onFechaDesdeEdited(value) {
            root.fechaDesdeEdited(value)
        }

        function onFechaHastaEdited(value) {
            root.fechaHastaEdited(value)
        }

        function onInformePathEdited(value) {
            root.informePathEdited(value)
        }
    }

    Label {
        Layout.fillWidth: true
        visible: root.taskModuleSource().length === 0
        color: root.textMuted
        text: "Esta task no requiere entradas adicionales."
        wrapMode: Text.Wrap
        font.pixelSize: Common.Theme.fontSize(12)
    }
}
