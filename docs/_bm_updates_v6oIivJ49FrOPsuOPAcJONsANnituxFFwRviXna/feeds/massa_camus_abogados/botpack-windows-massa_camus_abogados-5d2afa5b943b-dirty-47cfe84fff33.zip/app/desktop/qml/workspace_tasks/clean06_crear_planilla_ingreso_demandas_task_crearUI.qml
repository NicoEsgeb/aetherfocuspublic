import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

// Inputs for CLEAN06_CREAR_PLANILLA_INGRESO_DEMANDAS.
//
// One single input: the Asignación Final (.xlsx). It travels in the payload as
// `matriz_input_path`, which app/services/runners.py already maps to the
// MATRIZ_INPUT_PATH env var — so this bot needs no core change to receive it.
ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2
    property string matrizInputPath: ""

    signal matrizInputPathEdited(string value)

    function validate() {
        if (!String(matrizInputPath || "").trim()) {
            errorNotification.titleText = "Falta la planilla de entrada"
            errorNotification.messageText = "Selecciona la Asignación Final (.xlsx) desde la carpeta input del bot."
            errorNotification.open()
            return "Selecciona la Asignación Final (.xlsx) antes de ejecutar."
        }
        return ""
    }

    function buildPayload() {
        return {
            matriz_input_path: String(matrizInputPath || "").trim()
        }
    }

    function inputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function inputFolderUrl() {
        var base = root.inputFolder()
        if (base.length === 0)
            return "file:///"
        return root.toFileUrl(base)
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function")
            return helpers.localPathToFileUrl(pathText)
        return "file:///"
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function")
            return helpers.fileUrlToLocalPath(fileUrl)
        return String(fileUrl || "")
    }

    // -----------------------------------------------------------------------
    // Asignación Final (.xlsx) — seleccionable, abre en input/
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaCardLayout.implicitHeight + 18

        ColumnLayout {
            id: planillaCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Planilla de Asignación Final (.xlsx)"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Es la matriz que genera Clean03, ya revisada por una persona (con CARTERA_A_PROCESAR resuelta y las columnas de firma completas). Guárdala en la carpeta input del bot. No se modifica: el bot escribe una planilla nueva en output/."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            TextField {
                id: planillaField
                Layout.fillWidth: true
                text: root.matrizInputPath
                color: Common.Theme.text
                placeholderText: "Ninguna planilla seleccionada"
                placeholderTextColor: Common.Theme.text3
                readOnly: true
                background: Rectangle {
                    radius: 8
                    color: Common.Theme.panel2
                    border.width: planillaField.activeFocus ? 2 : 1
                    border.color: planillaField.activeFocus ? Common.Theme.accent : Common.Theme.line
                }
            }

            Common.InsetAlloyButton {
                id: selectPlanillaButton
                text: "Seleccionar Planilla"
                hoverEnabled: true
                onClicked: {
                    planillaDialog.currentFolder = root.inputFolderUrl()
                    planillaDialog.open()
                }
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: selectPlanillaButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    FileDialog {
        id: planillaDialog
        title: "Seleccionar la Asignación Final (.xlsx)"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: {
            root.matrizInputPath = root.toLocalPath(selectedFile)
            root.matrizInputPathEdited(root.matrizInputPath)
        }
    }

    Common.NotificationToast {
        id: errorNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
    }
}
