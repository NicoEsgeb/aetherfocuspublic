import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color accentStrong: Common.Theme.accent
    property color success: Common.Theme.success
    property int infoTabIndex: 0

    Common.BotInfoHeader {
        themeSource: Common.Theme
        width: root.width
    }

    Common.ExternalDependencyWarning {
        width: root.width
        dependencies: root.botInfo && root.botInfo.missingExternalDependencies
            ? root.botInfo.missingExternalDependencies : []
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: processLabel.implicitWidth + 20
        color: Common.Theme.successSoft
        border.width: 1
        border.color: Common.Theme.success

        Label {
            id: processLabel
            anchors.centerIn: parent
            text: "Proceso CLEAN_BBRR"
            color: Common.Theme.success
            font.pixelSize: Common.Theme.fontSize(12)
            font.bold: true
        }
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: localLabel.implicitWidth + 20
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.accent

        Label {
            id: localLabel
            anchors.centerIn: parent
            text: "100% local - sin nube"
            color: Common.Theme.accent
            font.pixelSize: Common.Theme.fontSize(12)
            font.bold: true
        }
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Crear Planilla Ingreso Demandas"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: crearInfoComponent
    }

    Component {
        id: crearInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: CLEAN06_CREAR_PLANILLA_INGRESO_DEMANDAS"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Lee la Asignación Final (la matriz de Clean03 ya revisada por una persona) y arma la Planilla de Ingreso de Demandas que se usa para subir los documentos al PJUD. Todo el procesamiento es local: Excel de entrada, Excel de salida."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Un único Excel: la Asignación Final. Se elige con 'Seleccionar Planilla' (la carpeta input del bot se abre por defecto).",
                    "Debe traer las columnas RUT, DV, CARTERA_ORIGINAL, CARTERA_A_PROCESAR, COD_CONTRATO, PAGARE_FIRMADO_CLIENTE, CONTRATO_MANDATO_FIRMADO_CLIENTE y HOJA_DE_FIRMA. Se buscan por nombre, no por posición.",
                    "CARTERA_A_PROCESAR ya debe estar resuelta: si quedó en RE (la celda morada de Clean03), esa fila sale marcada como PENDIENTE.",
                    "La planilla de entrada NO se modifica: el bot escribe un archivo nuevo en output/."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Un único Excel Planilla_Ingreso_Demandas.xlsx dentro de output/Planilla_[fecha-hora]/.",
                    "25 columnas (A–Y): ESTADO más las 24 de la planilla de ingreso. Una fila por fila de entrada, en el mismo orden.",
                    "Cuando un RUT tiene varios pagarés, sólo su primera fila lleva demanda, mandatos, contrato y hoja de firma; las siguientes llevan sólo RUT, DV, CARTERA y el pagaré.",
                    "Filas OK pintadas de verde. Filas PENDIENTE en blanco, con la celda ESTADO y la celda problemática en amarillo.",
                    "Cada celda amarilla lleva un comentario explicando qué falta; la celda ESTADO resume todas las causas de esa fila."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }

            Label {
                text: "Importante"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "El bot escribe NOMBRES de archivo, no archivos. No copia, no renombra y no revisa que los PDF existan.",
                    "El armado de las carpetas por RUT y de la carpeta 03_Mandatos lo hace una persona después, a mano."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, noteText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: Common.Theme.warning
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: noteText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }
        }
    }
}
