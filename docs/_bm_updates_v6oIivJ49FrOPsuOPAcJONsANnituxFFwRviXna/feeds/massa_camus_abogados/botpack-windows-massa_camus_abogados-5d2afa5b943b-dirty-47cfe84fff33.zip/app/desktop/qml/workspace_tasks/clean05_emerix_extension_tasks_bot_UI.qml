import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    property string planillaPath: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal planillaPathEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            workspaceTaskNameEdited("CLEAN05_EMERIX_EXTENSION")
        }
    }

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona el archivo Excel que utilizará Clean05."
        }
        var lower = path.toLowerCase()
        if (!lower.endsWith(".xlsx") && !lower.endsWith(".xlsm")) {
            return "El archivo debe estar en formato .xlsx o .xlsm."
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim(),
            task_name: testModeCheck.checked
                ? "CLEAN05_EMERIX_EXTENSION_TEST"
                : "CLEAN05_EMERIX_EXTENSION",
            clean05_test_mode: testModeCheck.checked
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: mainLayout.implicitHeight + 20

        ColumnLayout {
            id: mainLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Label {
                text: "Excel de entrada"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    Layout.fillWidth: true
                    text: root.planillaPath
                    color: Common.Theme.text
                    placeholderText: "Selecciona un archivo .xlsx o .xlsm"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Common.InsetAlloyButton {
                    id: selectExcelButton
                    text: "Seleccionar Excel"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            excelFileDialog.currentFolder = root.toFileUrl(folder)
                        }
                        excelFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: Common.Theme.accent
                        color: selectExcelButton.down ? Common.Theme.accent : Common.Theme.accentSoft
                    }
                    contentItem: Text {
                        text: selectExcelButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                radius: 8
                color: testModeCheck.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                border.width: 1
                border.color: testModeCheck.checked ? Common.Theme.accent : Common.Theme.line
                implicitHeight: testModeLayout.implicitHeight + 16

                ColumnLayout {
                    id: testModeLayout
                    anchors.fill: parent
                    anchors.margins: 8
                    spacing: 4

                    CheckBox {
                        id: testModeCheck
                        checked: false
                        spacing: 8
                        Layout.fillWidth: true

                        indicator: Rectangle {
                            implicitWidth: 20
                            implicitHeight: 20
                            x: testModeCheck.leftPadding
                            y: testModeCheck.height / 2 - height / 2
                            radius: 5
                            color: testModeCheck.checked ? Common.Theme.line : Common.Theme.panel2
                            border.width: testModeCheck.checked ? 2 : 1
                            border.color: testModeCheck.checked ? Common.Theme.accent : Common.Theme.line

                            Text {
                                anchors.centerIn: parent
                                text: "✓"
                                color: Common.Theme.text
                                font.pixelSize: Common.Theme.fontSize(14)
                                font.bold: true
                                visible: testModeCheck.checked
                            }
                        }

                        contentItem: Text {
                            text: "Modo prueba — no guardar en Emerix"
                            color: Common.Theme.text
                            font.pixelSize: Common.Theme.fontSize(13)
                            font.bold: true
                            verticalAlignment: Text.AlignVCenter
                            leftPadding: testModeCheck.indicator.width + testModeCheck.spacing
                        }
                    }

                    Label {
                        text: testModeCheck.checked
                            ? "ACTIVO: completa el formulario y lo cierra con la X. Nunca presiona Grabar."
                            : "Desactivado: el bot presiona Grabar y crea la boleta real."
                        color: testModeCheck.checked ? Common.Theme.accent : root.textMuted
                        font.pixelSize: Common.Theme.fontSize(12)
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                    }
                }
            }

            Label {
                text: "Ejecuta Clean05, inicia sesión manualmente en itau.emerix.net y, ya en el dashboard, presiona Start en el panel Clean05. La extensión usa el bridge local 127.0.0.1:8766."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Extensión Edge: bots/clean05_emerix-extension/extension"
                color: Common.Theme.accent
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.WrapAnywhere
            }
        }
    }

    FileDialog {
        id: excelFileDialog
        title: "Seleccionar Excel para Clean05"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: root.planillaPathEdited(root.toLocalPath(selectedFile))
    }
}
