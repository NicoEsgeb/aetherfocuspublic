import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    // Entrada 1 (input/demandas) es FIJA: sólo se abre con un botón.
    // Entrada 2 (la planilla) es seleccionable y viaja en el payload.
    property string planillaPath: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal planillaPathEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            workspaceTaskNameEdited("CLEAN07_INGRESAR_DEMANDAS_BBRR")
        }
    }

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona la planilla de ingreso que utilizará Clean07."
        }
        var lower = path.toLowerCase()
        if (!lower.endsWith(".xlsx") && !lower.endsWith(".xlsm")) {
            return "La planilla debe estar en formato .xlsx o .xlsm."
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim(),
            task_name: "CLEAN07_INGRESAR_DEMANDAS_BBRR"
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function subFolderUrl(sub) {
        var base = root.defaultInputFolder()
        if (base.length === 0)
            return "file:///"
        return root.toFileUrl(base + "/" + sub)
    }

    // -----------------------------------------------------------------------
    // Entrada 1 — carpeta de demandas (fija: input/demandas)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: demandasLayout.implicitHeight + 20

        ColumnLayout {
            id: demandasLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "1. Carpeta de demandas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            Label {
                text: "El bot siempre procesa la carpeta input/demandas. Pega ahí los PDF (una subcarpeta por RUT más 03_Mandatos). Usa el botón para abrirla y revisarla."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openDemandasButton
                text: "Abrir carpeta de demandas"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("demandas"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.line
                    color: openDemandasButton.down ? Common.Theme.accentSoft : Common.Theme.panel2
                }
                contentItem: Text {
                    text: openDemandasButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Entrada 2 — planilla de ingreso (seleccionable, abre input/planilla_ingreso)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaLayout.implicitHeight + 20

        ColumnLayout {
            id: planillaLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Label {
                text: "2. Planilla de ingreso"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    Layout.fillWidth: true
                    text: root.planillaPath
                    color: Common.Theme.text
                    placeholderText: "Selecciona la planilla (.xlsx o .xlsm)"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Common.InsetAlloyButton {
                    id: selectPlanillaButton
                    text: "Seleccionar planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            planillaFileDialog.currentFolder = root.subFolderUrl("planilla_ingreso")
                        }
                        planillaFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: Common.Theme.accent
                        color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accentSoft
                    }
                    contentItem: Text {
                        text: selectPlanillaButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }

            Label {
                text: "Antes de abrir el navegador, Clean07 revisa que la planilla tenga todas las columnas requeridas y que input/demandas tenga PDFs. Si algo falta, el bot no inicia y verás una notificación con el detalle."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // -----------------------------------------------------------------------
    // Cómo se ejecuta (atendido, con extensión de Chrome)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: bridgeLayout.implicitHeight + 20

        ColumnLayout {
            id: bridgeLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Ejecuta Clean07, inicia sesión manualmente en la Oficina Judicial Virtual y, ya en indexN.php, presiona Start en el panel Clean07. La extensión usa el bridge local 127.0.0.1:8768."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Extensión Chrome: bots/clean07_ingreso-demandas-bbrr/extension"
                color: Common.Theme.accent
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.WrapAnywhere
            }
        }
    }

    FileDialog {
        id: planillaFileDialog
        title: "Seleccionar planilla de ingreso para Clean07"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: root.planillaPathEdited(root.toLocalPath(selectedFile))
    }
}
