import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property string planillaPath: ""
    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2

    signal planillaPathEdited(string value)

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona la planilla Excel a utilizar."
        }
        if (typeof controller !== "undefined" && controller !== null) {
            var errorMsg = controller.validatePlanilla(path)
            if (errorMsg && errorMsg.length > 0) {
                var lines = errorMsg.split("\n")
                validationNotification.titleText = lines[0]
                validationNotification.messageText = lines.length > 1 ? lines.slice(1).join("\n") : ""
                validationNotification.open()
                return errorMsg
            }
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim()
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaCardLayout.implicitHeight + 18

        ColumnLayout {
            id: planillaCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Planilla 'Estado Diario' a utilizar"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: planillaField
                    Layout.fillWidth: true
                    text: root.planillaPath
                    color: Common.Theme.text
                    placeholderText: "estado_diario.xlsx"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Button {
                    id: selectPlanillaButton
                    text: "Seleccionar Planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            planillaFileDialog.currentFolder = root.toFileUrl(folder)
                        }
                        planillaFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: selectPlanillaButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }

            Label {
                text: "Antes de iniciar: abre Edge normal, entra a PJUD e INICIA SESIÓN a mano, deja la ventana abierta en 'Mis Causas'. El bot maneja esa ventana sin conectarse a ella."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    FileDialog {
        id: planillaFileDialog
        title: "Seleccionar Planilla Estado Diario"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.planillaPathEdited(root.toLocalPath(selectedFile))
    }

    Common.NotificationToast {
        id: validationNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
        confirmTone: "primary"
    }
}
