import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    property string planillaPath: ""
    property string estadoDiarioPath: ""
    property string movimientosPath: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal planillaPathEdited(string value)
    signal estadoDiarioPathEdited(string value)
    signal movimientosPathEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            var fallbackValue = taskValueAt(workspaceTaskCombo.currentIndex)
            if (fallbackValue.length > 0) {
                workspaceTaskNameEdited(fallbackValue)
            }
        }
    }

    function normalizedTask(taskName) {
        return String(taskName || "").replace(/[^A-Za-z0-9]/g, "").toLowerCase()
    }

    function taskLabel(taskName) {
        var labels = {
            n01buscartribunal: "Buscar Tribunal",
            n01unificarplanillasrit: "Unificar Planillas RIT"
        }
        var key = normalizedTask(taskName)
        if (labels[key] !== undefined) {
            return labels[key]
        }
        return String(taskName || "")
    }

    function taskDisplayOptions() {
        var options = workspaceConfig && workspaceConfig.taskOptions ? workspaceConfig.taskOptions : []
        var display = []
        for (var i = 0; i < options.length; i++) {
            var value = String(options[i] || "").trim()
            if (value.length === 0) {
                continue
            }
            display.push({
                value: value,
                label: taskLabel(value)
            })
        }
        return display
    }

    function taskValueAt(index) {
        var options = taskDisplayOptions()
        if (index < 0 || index >= options.length) {
            return ""
        }
        return String(options[index].value || "")
    }

    function taskModuleSource() {
        var task = normalizedTask(workspaceTaskName)
        if (task.length === 0) {
            task = normalizedTask(taskValueAt(workspaceTaskCombo.currentIndex))
        }
        if (task === "n01buscartribunal") {
            return String(Qt.resolvedUrl("N01_buscar-tribunal_task_buscarTribunalUI.qml"))
        }
        return ""
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function validate() {
        var selectedTask = String(workspaceTaskName || "").trim()
        if (selectedTask.length === 0) {
            return "Selecciona la task a ejecutar."
        }

        var task = normalizedTask(selectedTask)

        if (task === "n01unificarplanillasrit") {
            if (String(estadoDiarioPath || "").trim().length === 0) {
                return "Selecciona la Planilla Estado Diario."
            }
            if (String(movimientosPath || "").trim().length === 0) {
                return "Selecciona la Planilla Movimientos y Estado Diario."
            }
            if (typeof controller !== "undefined" && controller !== null) {
                var err1 = controller.validatePlanilla(String(estadoDiarioPath).trim())
                if (err1 && err1.length > 0) {
                    var lines1 = err1.split("\n")
                    validationNotification.titleText = "Planilla Estado Diario: " + lines1[0]
                    validationNotification.messageText = lines1.length > 1 ? lines1.slice(1).join("\n") : ""
                    validationNotification.open()
                    return err1
                }
                var err2 = controller.validateMovimientosPlanilla(String(movimientosPath).trim())
                if (err2 && err2.length > 0) {
                    var lines2 = err2.split("\n")
                    validationNotification.titleText = "Planilla Movimientos: " + lines2[0]
                    validationNotification.messageText = lines2.length > 1 ? lines2.slice(1).join("\n") : ""
                    validationNotification.open()
                    return err2
                }
            }
            return ""
        }

        if (taskInputLoader.item && taskInputLoader.item["validate"]) {
            var validationMessage = taskInputLoader.item["validate"]()
            if (validationMessage && validationMessage.length > 0) {
                return validationMessage
            }
        }
        return ""
    }

    function buildPayload() {
        var task = normalizedTask(workspaceTaskName)
        console.log("N01 buildPayload: workspaceTaskName=" + workspaceTaskName + " task=" + task + " edPath=" + estadoDiarioPath + " mvPath=" + movimientosPath)

        if (task === "n01unificarplanillasrit") {
            return {
                estado_diario_path: String(estadoDiarioPath || "").trim(),
                movimientos_path: String(movimientosPath || "").trim()
            }
        }

        var payload = {}
        if (taskInputLoader.item && taskInputLoader.item["buildPayload"]) {
            var taskPayload = taskInputLoader.item["buildPayload"]()
            for (var key in taskPayload) {
                payload[key] = taskPayload[key]
            }
        }
        return payload
    }

    // ── Task selector ────────────────────────────────────────────────────────
    RowLayout {
        Layout.fillWidth: true
        spacing: 10

        Label {
            text: "Task"
            color: root.textMuted
            Layout.preferredWidth: 38
        }

        Common.StyledComboBox {
            id: workspaceTaskCombo
            Layout.fillWidth: true
            textRole: "label"
            model: root.taskDisplayOptions()
            currentIndex: {
                var options = root.taskDisplayOptions()
                if (options.length === 0) {
                    return -1
                }
                for (var i = 0; i < options.length; i++) {
                    if (String(options[i].value || "") === root.workspaceTaskName) {
                        return i
                    }
                }
                return 0
            }
            onActivated: {
                var value = root.taskValueAt(currentIndex)
                if (value.length > 0) {
                    root.workspaceTaskNameEdited(value)
                }
            }
            onCurrentIndexChanged: {
                if (!visible) {
                    return
                }
                var value = root.taskValueAt(currentIndex)
                if (value.length > 0) {
                    root.workspaceTaskNameEdited(value)
                }
            }
        }
    }

    // ── Loader for tasks that use a separate input QML (e.g. Buscar Tribunal) ─
    Loader {
        id: taskInputLoader
        Layout.fillWidth: true
        Layout.preferredHeight: item ? Math.max(item.implicitHeight, item.childrenRect.height) : 0
        visible: normalizedTask(root.workspaceTaskName) !== "n01unificarplanillasrit"
        source: root.taskModuleSource()
        onLoaded: {
            if (item) {
                item.width = width
            }
        }
        onWidthChanged: {
            if (item) {
                item.width = width
            }
        }
    }

    Binding {
        target: taskInputLoader.item
        property: "workspaceConfig"
        value: root.workspaceConfig
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "helpers"
        value: root.helpers
        when: taskInputLoader.item !== null
    }
    Binding {
        target: taskInputLoader.item
        property: "planillaPath"
        value: root.planillaPath
        when: taskInputLoader.item !== null
    }

    Connections {
        target: taskInputLoader.item
        ignoreUnknownSignals: true

        function onPlanillaPathEdited(value) {
            root.planillaPathEdited(value)
        }
    }

    // ── Unificar Planillas RIT — inline inputs ───────────────────────────────
    ColumnLayout {
        id: unificarInputs
        Layout.fillWidth: true
        spacing: 8
        visible: normalizedTask(root.workspaceTaskName) === "n01unificarplanillasrit"
        Layout.preferredHeight: visible ? implicitHeight : 0

        // Planilla: Estado Diario
        Rectangle {
            Layout.fillWidth: true
            radius: 10
            color: Common.Theme.panel2
            border.width: 1
            border.color: Common.Theme.line
            implicitHeight: edCardLayout.implicitHeight + 18

            ColumnLayout {
                id: edCardLayout
                anchors.fill: parent
                anchors.margins: 9
                spacing: 8

                Label {
                    text: "Planilla: Estado Diario"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    TextField {
                        Layout.fillWidth: true
                        text: root.estadoDiarioPath
                        color: Common.Theme.text
                        placeholderText: "estado_diario.xlsx"
                        placeholderTextColor: Common.Theme.text3
                        readOnly: true
                        background: Rectangle {
                            radius: 8
                            color: Common.Theme.panel2
                            border.width: 1
                            border.color: Common.Theme.line
                        }
                    }

                    Button {
                        id: selectEdButton
                        text: "Seleccionar Planilla"
                        hoverEnabled: true
                        onClicked: {
                            var folder = root.defaultInputFolder()
                            if (folder.length > 0) {
                                edFileDialog.currentFolder = root.toFileUrl(folder)
                            }
                            edFileDialog.open()
                        }
                        background: Rectangle {
                            radius: 8
                            border.width: 1
                            border.color: selectEdButton.down ? Common.Theme.accent : Common.Theme.accent
                            gradient: Gradient {
                                GradientStop { position: 0.0; color: selectEdButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                                GradientStop { position: 1.0; color: selectEdButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                            }
                        }
                        contentItem: Text {
                            text: selectEdButton.text
                            color: Common.Theme.text
                            font.pixelSize: Common.Theme.fontSize(12)
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }
            }
        }

        // Planilla: Movimientos y Estado Diario
        Rectangle {
            Layout.fillWidth: true
            radius: 10
            color: Common.Theme.panel2
            border.width: 1
            border.color: Common.Theme.line
            implicitHeight: mvCardLayout.implicitHeight + 18

            ColumnLayout {
                id: mvCardLayout
                anchors.fill: parent
                anchors.margins: 9
                spacing: 8

                Label {
                    text: "Planilla: Movimientos y Estado Diario"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    TextField {
                        Layout.fillWidth: true
                        text: root.movimientosPath
                        color: Common.Theme.text
                        placeholderText: "movimientos_estado_diario.xlsx"
                        placeholderTextColor: Common.Theme.text3
                        readOnly: true
                        background: Rectangle {
                            radius: 8
                            color: Common.Theme.panel2
                            border.width: 1
                            border.color: Common.Theme.line
                        }
                    }

                    Button {
                        id: selectMvButton
                        text: "Seleccionar Planilla"
                        hoverEnabled: true
                        onClicked: {
                            var folder = root.defaultInputFolder()
                            if (folder.length > 0) {
                                mvFileDialog.currentFolder = root.toFileUrl(folder)
                            }
                            mvFileDialog.open()
                        }
                        background: Rectangle {
                            radius: 8
                            border.width: 1
                            border.color: selectMvButton.down ? Common.Theme.accent : Common.Theme.accent
                            gradient: Gradient {
                                GradientStop { position: 0.0; color: selectMvButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                                GradientStop { position: 1.0; color: selectMvButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                            }
                        }
                        contentItem: Text {
                            text: selectMvButton.text
                            color: Common.Theme.text
                            font.pixelSize: Common.Theme.fontSize(12)
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }
            }
        }
    }

    // ── Dialogs & notifications ──────────────────────────────────────────────
    FileDialog {
        id: edFileDialog
        title: "Seleccionar Planilla Estado Diario"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: {
            root.estadoDiarioPath = root.toLocalPath(selectedFile)
            root.estadoDiarioPathEdited(root.estadoDiarioPath)
        }
    }

    FileDialog {
        id: mvFileDialog
        title: "Seleccionar Planilla Movimientos y Estado Diario"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: {
            root.movimientosPath = root.toLocalPath(selectedFile)
            root.movimientosPathEdited(root.movimientosPath)
        }
    }

    Common.NotificationToast {
        id: validationNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
        confirmTone: "primary"
    }
}
