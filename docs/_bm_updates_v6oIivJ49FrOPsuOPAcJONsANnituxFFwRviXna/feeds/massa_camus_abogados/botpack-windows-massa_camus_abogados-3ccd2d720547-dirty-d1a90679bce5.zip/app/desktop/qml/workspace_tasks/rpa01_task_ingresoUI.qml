import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2
    property string matrixPath: ""

    signal matrixPathEdited(string value)

    function validate() {
        if (!String(matrixPath || "").trim()) {
            return "Selecciona la Planilla de Escritos antes de ejecutar."
        }
        return ""
    }

    function buildPayload() {
        return {
            matriz_escritos_path: String(matrixPath || "").trim(),
            documentos_firmados: firmadosCheck.checked
        }
    }

    function escritosFolderPath() {
        var inputFolder = String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
        if (inputFolder.length === 0) {
            return ""
        }
        var separator = inputFolder.indexOf("\\") >= 0 ? "\\" : "/"
        if (inputFolder.endsWith("/") || inputFolder.endsWith("\\")) {
            return inputFolder + "escritos"
        }
        return inputFolder + separator + "escritos"
    }

    function planillasFolderPath() {
        var inputFolder = String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
        if (inputFolder.length === 0) {
            return ""
        }
        var separator = inputFolder.indexOf("\\") >= 0 ? "\\" : "/"
        if (inputFolder.endsWith("/") || inputFolder.endsWith("\\")) {
            return inputFolder + "planillas"
        }
        return inputFolder + separator + "planillas"
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    // -----------------------------------------------------------------------
    // Carpeta de Escritos
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: escritosCardLayout.implicitHeight + 18

        ColumnLayout {
            id: escritosCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Carpeta de Escritos"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Pega aqui los PDFs de los escritos a ingresar."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Button {
                id: openEscritosButton
                text: "Carpeta de Escritos"
                hoverEnabled: true
                Layout.alignment: Qt.AlignLeft
                onClicked: {
                    var targetPath = root.escritosFolderPath()
                    if (targetPath.length <= 0) {
                        return
                    }
                    if (typeof controller !== "undefined" && controller !== null) {
                        controller.openPathInExplorer(targetPath)
                    } else {
                        Qt.openUrlExternally(root.toFileUrl(targetPath))
                    }
                }
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: openEscritosButton.down ? Common.Theme.accent : Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: openEscritosButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: openEscritosButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: openEscritosButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Planilla de Escritos a Utilizar
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaCardLayout.implicitHeight + 18

        ColumnLayout {
            id: planillaCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Planilla de Escritos a Utilizar"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: planillaField
                    Layout.fillWidth: true
                    text: root.matrixPath
                    color: Common.Theme.text
                    placeholderText: "planilla_escritos.xlsx"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: planillaField.activeFocus ? 2 : 1
                        border.color: planillaField.activeFocus ? Common.Theme.accent : Common.Theme.line
                    }
                }

                Button {
                    id: selectPlanillaButton
                    text: "Seleccionar Planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folderPath = root.planillasFolderPath()
                        if (folderPath.length > 0) {
                            planillaFileDialog.currentFolder = root.toFileUrl(folderPath)
                        }
                        planillaFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: selectPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: selectPlanillaButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Documentos Firmados (los PDFs traen el sufijo _firmado)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: firmadosLayout.implicitHeight + 18

        ColumnLayout {
            id: firmadosLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: firmadosCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: firmadosCheck.leftPadding
                    y: firmadosCheck.height / 2 - height / 2
                    radius: 5
                    color: firmadosCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: firmadosCheck.checked ? 2 : 1
                    border.color: firmadosCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(14)
                        font.bold: true
                        visible: firmadosCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Documentos Firmados"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: firmadosCheck.indicator.width + firmadosCheck.spacing
                }
            }

            Label {
                text: "Marca esta casilla si los PDFs de esta carpeta vienen con el sufijo \"_firmado\" al final del nombre (ej: Trib_1°_ROL_1149-2026_18.434.983-3_firmado.pdf). El bot agregará \"_firmado\" al buscar cada archivo."
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    FileDialog {
        id: planillaFileDialog
        title: "Seleccionar Planilla de Escritos"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.matrixPathEdited(root.toLocalPath(selectedFile))
    }
}
