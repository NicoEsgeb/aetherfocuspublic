import QtQuick
import QtQuick.Controls

// Secondary ghost button: transparent bg, 1px line border, text2 label.
Button {
    id: control

    hoverEnabled: true
    opacity: enabled ? 1.0 : 0.45
    implicitHeight: 40

    background: Rectangle {
        radius: 9
        color: control.hovered && control.enabled ? Theme.panel2 : "transparent"
        border.width: 1
        border.color: Theme.line
        Behavior on color { ColorAnimation { duration: 120 } }
    }

    contentItem: Label {
        text: control.text
        color: Theme.text2
        font.pixelSize: Theme.fontSize(14)
        font.weight: Font.DemiBold
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        leftPadding: 18
        rightPadding: 18
    }
}
