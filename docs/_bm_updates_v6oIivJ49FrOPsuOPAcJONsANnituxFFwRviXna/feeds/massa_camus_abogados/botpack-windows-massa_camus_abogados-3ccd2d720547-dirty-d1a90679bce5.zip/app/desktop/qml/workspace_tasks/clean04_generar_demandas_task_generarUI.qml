import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2
    // The matriz (Clean03 output) is selectable; it is annotated in place.
    property string matrizInputPath: ""

    signal matrizInputPathEdited(string value)

    function validate() {
        if (!String(matrizInputPath || "").trim()) {
            errorNotification.titleText = "Falta la matriz"
            errorNotification.messageText = "Selecciona la matriz de Clean03 (.xlsx) desde la carpeta input/matriz."
            errorNotification.open()
            return "Selecciona la matriz (.xlsx) antes de ejecutar."
        }
        return ""
    }

    function buildPayload() {
        // The matriz travels as matriz_input_path (mapped to MATRIZ_INPUT_PATH by
        // the runner); the toggle regenerates every RUT, ignoring ESTADO == OK.
        return {
            matriz_input_path: String(matrizInputPath || "").trim(),
            clean04_force_all: forceAllCheck.checked
        }
    }

    function inputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function subFolderUrl(sub) {
        var base = root.inputFolder()
        if (base.length === 0)
            return "file:///"
        return root.toFileUrl(base + "/" + sub)
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function")
            return helpers.localPathToFileUrl(pathText)
        return "file:///"
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function")
            return helpers.fileUrlToLocalPath(fileUrl)
        return String(fileUrl || "")
    }

    // -----------------------------------------------------------------------
    // Matriz (.xlsx) — seleccionable, abre en input/matriz
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: matrizCardLayout.implicitHeight + 18

        ColumnLayout {
            id: matrizCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Matriz de Clean03 (.xlsx)"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Excel con una fila por pagaré (la salida de Clean03). El bot NO modifica este archivo: crea una copia anotada ([nombre]_ESTADO.xlsx) con la columna ESTADO en la carpeta de salida. Guárdala en input/matriz y elígela aquí."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            TextField {
                id: matrizField
                Layout.fillWidth: true
                text: root.matrizInputPath
                color: Common.Theme.text
                placeholderText: "Ninguna matriz seleccionada"
                placeholderTextColor: Common.Theme.text3
                readOnly: true
                background: Rectangle {
                    radius: 8
                    color: Common.Theme.panel2
                    border.width: matrizField.activeFocus ? 2 : 1
                    border.color: matrizField.activeFocus ? Common.Theme.accent : Common.Theme.line
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    id: selectMatrizButton
                    text: "Seleccionar Matriz"
                    hoverEnabled: true
                    onClicked: {
                        matrizDialog.currentFolder = root.subFolderUrl("matriz")
                        matrizDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: selectMatrizButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: selectMatrizButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: selectMatrizButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: selectMatrizButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Button {
                    id: openMatrizButton
                    text: "Abrir carpeta"
                    hoverEnabled: true
                    onClicked: Qt.openUrlExternally(root.subFolderUrl("matriz"))
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: openMatrizButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: openMatrizButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: openMatrizButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: openMatrizButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Regenerar todo (ignorar ESTADO OK)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: forceAllLayout.implicitHeight + 18

        ColumnLayout {
            id: forceAllLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: forceAllCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: forceAllCheck.leftPadding
                    y: forceAllCheck.height / 2 - height / 2
                    radius: 5
                    color: forceAllCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: forceAllCheck.checked ? 2 : 1
                    border.color: forceAllCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(14)
                        font.bold: true
                        visible: forceAllCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Regenerar todo (ignorar ESTADO OK)"
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(13)
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: forceAllCheck.indicator.width + forceAllCheck.spacing
                }
            }

            Label {
                text: "Normalmente el bot omite los RUT que ya están OK (su PDF ya se generó) y solo reprocesa los REVISAR/ERROR. Marca esta casilla para volver a generar TODAS las demandas desde cero, aunque ya estén OK."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    FileDialog {
        id: matrizDialog
        title: "Seleccionar la matriz (.xlsx)"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: {
            root.matrizInputPath = root.toLocalPath(selectedFile)
            root.matrizInputPathEdited(root.matrizInputPath)
        }
    }

    Common.NotificationToast {
        id: errorNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
    }
}
