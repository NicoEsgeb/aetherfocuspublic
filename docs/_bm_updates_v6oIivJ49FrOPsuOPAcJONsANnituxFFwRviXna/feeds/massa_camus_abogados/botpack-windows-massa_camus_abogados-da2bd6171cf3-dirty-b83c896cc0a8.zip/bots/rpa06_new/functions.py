from RPA.Excel.Files import Files as Excel
from robocorp import browser
import time
import os
import shutil
import json
import re
from urllib.parse import urljoin, urlparse
from pypdf import PdfWriter
import glob
from pathlib import Path
from datetime import datetime

INGRESO_CODE_VERSION = "2026-03-09-ingreso-rollback-b2b4783-partial-v1"
FIRMADO_SUFFIX = "_firmado"
GET_CARATULAS_MAX_DOWNLOAD_ATTEMPTS = 3
OJV_FALLBACK_BASE_URLS = (
    "https://ojv.pjud.cl",
    "https://ojv.poderjudicial.cl",
)
DEFAULT_OJV_RISK_WARNING_CONTINUE_TEXT = "Entiendo los riesgos y deseo continuar"
OJV_RISK_WARNING_CONTINUE_TEXT = (
    os.getenv("OJV_RISK_WARNING_CONTINUE_TEXT", DEFAULT_OJV_RISK_WARNING_CONTINUE_TEXT).strip()
    or DEFAULT_OJV_RISK_WARNING_CONTINUE_TEXT
)
_OJV_RISK_WARNING_SPACED_TEXT = r"\s+".join(
    re.escape(part) for part in OJV_RISK_WARNING_CONTINUE_TEXT.split()
)
OJV_AUTO_ACCEPT_RISK_WARNING = os.getenv(
    "OJV_AUTO_ACCEPT_RISK_WARNING",
    "1",
).strip().lower() not in {"0", "false", "no", "off"}
try:
    OJV_RISK_WARNING_TIMEOUT_MS = max(0, int(os.getenv("OJV_RISK_WARNING_TIMEOUT_MS", "6000")))
except ValueError:
    OJV_RISK_WARNING_TIMEOUT_MS = 6000
try:
    OJV_LOGIN_AVISO_TIMEOUT_MS = max(0, int(os.getenv("OJV_LOGIN_AVISO_TIMEOUT_MS", "3000")))
except ValueError:
    OJV_LOGIN_AVISO_TIMEOUT_MS = 3000
OJV_RISK_WARNING_TEXT_PATTERN = re.compile(
    _OJV_RISK_WARNING_SPACED_TEXT + r"\.?",
    re.IGNORECASE,
)


def _ordered_unique(values: list[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return tuple(ordered)


def _resolve_ojv_base_url(current_url: str = "") -> str:
    candidates: list[str] = []
    env_base = os.getenv("OJV_ACTIVE_BASE_URL", "").strip().rstrip("/")
    if env_base:
        candidates.append(env_base)
    if current_url:
        parsed = urlparse(current_url)
        if parsed.scheme and parsed.netloc:
            candidates.append(f"{parsed.scheme}://{parsed.netloc}")
    candidates.extend(OJV_FALLBACK_BASE_URLS)
    unique_candidates = _ordered_unique(candidates)
    if not unique_candidates:
        raise RuntimeError("No se pudo resolver base URL de OJV.")
    return unique_candidates[0]


def _ojv_url(path: str, current_url: str = "") -> str:
    normalized_path = path if path.startswith("/") else f"/{path}"
    return f"{_resolve_ojv_base_url(current_url)}{normalized_path}"

def _resolve_ingreso_output_dir(PATH_BOT: str, INGRESO_OUTPUT_DIR: str | None) -> str:
    output_dir = INGRESO_OUTPUT_DIR or os.path.join(PATH_BOT, "output", "output_ingreso")
    os.makedirs(output_dir, exist_ok=True)
    return output_dir


def _with_firmado_suffix(arch_demanda: str) -> str:
    """Append "_firmado" to the demanda filename listed in ARCH_DEMANDA.

    The matriz lists the unsigned name (01_Demandas_firmadas\\11.824.477-k_2011.pdf)
    while the folder holds the signed file (11.824.477-k_2011_firmado.pdf). Only the
    filename is touched: the original folder prefix and separator are preserved so
    the value keeps working on Windows. Rows that already carry the suffix are left
    alone, so a mixed matriz never ends up with "_firmado_firmado".
    """
    raw = str(arch_demanda or "").strip()
    if not raw:
        return raw

    cut = max(raw.rfind("/"), raw.rfind("\\"))
    parent = raw[: cut + 1]
    filename = raw[cut + 1 :]
    stem, extension = os.path.splitext(filename)
    if not stem or stem.casefold().endswith(FIRMADO_SUFFIX):
        return raw
    return f"{parent}{stem}{FIRMADO_SUFFIX}{extension}"


def _upload_with_file_chooser(page, trigger_locator, file_path: str) -> None:
    resolved_path = os.path.abspath(file_path)
    if not os.path.exists(resolved_path):
        raise FileNotFoundError(f"No existe el archivo a adjuntar: {resolved_path}")

    with page.expect_file_chooser(timeout=30000) as chooser_info:
        trigger_locator.click()
    chooser_info.value.set_files(resolved_path)


def _wait_select2_drop_mask(page, timeout_seconds: int = 6) -> None:
    mask = page.locator("xpath=//*[@id='select2-drop-mask']")
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            if mask.count() == 0:
                return
            if not mask.first.is_visible():
                return
        except Exception:
            # If the element is detached/replaced while polling, continue flow.
            return
        time.sleep(0.5)


def _iter_browser_contexts(page) -> list:
    contexts = [page]
    try:
        for frame in page.frames:
            contexts.append(frame)
    except Exception:
        pass
    return contexts


def _dismiss_vm_risk_warning_if_present(page, timeout_ms: int | None = None) -> bool:
    if not OJV_AUTO_ACCEPT_RISK_WARNING:
        return False

    timeout = OJV_RISK_WARNING_TIMEOUT_MS if timeout_ms is None else max(0, timeout_ms)
    deadline = time.time() + (timeout / 1000)
    while True:
        saw_candidate = False
        for context in _iter_browser_contexts(page):
            candidates = (
                context.get_by_role("button", name=OJV_RISK_WARNING_TEXT_PATTERN).first,
                context.get_by_role("link", name=OJV_RISK_WARNING_TEXT_PATTERN).first,
                context.get_by_text(OJV_RISK_WARNING_TEXT_PATTERN).first,
            )
            for candidate in candidates:
                try:
                    if candidate.count() == 0:
                        continue
                    saw_candidate = True
                    if not candidate.is_visible():
                        continue
                    candidate.click(timeout=1000)
                    print(
                        "[OJV][WARN] Advertencia de seguridad detectada y confirmada "
                        f"('{OJV_RISK_WARNING_CONTINUE_TEXT}')."
                    )
                    return True
                except Exception:
                    continue

        if not saw_candidate:
            return False
        if time.time() >= deadline:
            return False
        time.sleep(0.25)


def _dismiss_login_modal_aviso_if_present(page, timeout_ms: int | None = None) -> bool:
    timeout = OJV_LOGIN_AVISO_TIMEOUT_MS if timeout_ms is None else max(0, timeout_ms)
    aviso_close = page.locator("xpath=//*[@id='modalAviso']/div/div/div[1]/div/img").first
    try:
        if aviso_close.count() == 0:
            return False
        if not aviso_close.is_visible():
            return False
        aviso_close.click(timeout=max(timeout, 500))
        print("[OJV][WARN] Modal de aviso inicial cerrado automaticamente.")
        return True
    except Exception:
        return False


def _handle_ojv_runtime_blockers(page) -> None:
    # Two passes cover chained blockers: risk warning -> modalAviso.
    for _ in range(2):
        handled_any = False
        if _dismiss_vm_risk_warning_if_present(page):
            handled_any = True
            time.sleep(0.5)
        if _dismiss_login_modal_aviso_if_present(page):
            handled_any = True
            time.sleep(0.2)
        if not handled_any:
            return


def _is_any_visible(locator) -> bool:
    try:
        matches = locator.count()
    except Exception:
        return False

    for idx in range(matches):
        try:
            if locator.nth(idx).is_visible():
                return True
        except Exception:
            continue
    return False


def _wait_for_toast_message(
    page,
    message: str,
    timeout_seconds: int,
    poll_seconds: float = 1.0,
) -> bool:
    toast_messages = page.locator("#toast-container .toast-message", has_text=message)
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if _is_any_visible(toast_messages):
            return True
        time.sleep(poll_seconds)
    return False


def _try_open_tipo_documento_selector(page, timeout_ms: int = 2500) -> bool:
    text_pattern = re.compile(r"tipo\s+de\s+documento", re.IGNORECASE)
    candidates = (
        page.locator("#dDAnexo label", has_text=text_pattern).first,
        page.locator("#dDAnexo *", has_text=text_pattern).first,
    )
    for candidate in candidates:
        try:
            if candidate.count() == 0:
                continue
            candidate.wait_for(state="visible", timeout=timeout_ms)
            candidate.click()
            return True
        except Exception:
            continue
    return False


def _label_pattern(label_text: str) -> re.Pattern[str]:
    spaced = r"\s+".join(re.escape(part) for part in label_text.strip().split())
    return re.compile(spaced, re.IGNORECASE)


def _normalize_select_text(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).lower()


def _normalize_rit(value: str) -> str:
    return re.sub(r"\s+", "", str(value or "").strip()).upper()


def _label_locator(page, label_text: str, *, scope: str | None = None, prefer_last: bool = False):
    root = page.locator(scope) if scope else page
    labels = root.locator("label", has_text=_label_pattern(label_text))
    try:
        total = labels.count()
    except Exception:
        return None
    if total == 0:
        return None

    indices = range(total - 1, -1, -1) if prefer_last else range(total)
    for idx in indices:
        candidate = labels.nth(idx)
        try:
            if candidate.is_visible():
                return candidate
        except Exception:
            continue

    return labels.nth(total - 1 if prefer_last else 0)


def _click_materia_agregar(page) -> bool:
    candidate_groups = (
        page.locator(
            "xpath=//label[contains(.,'Materia')]/ancestor::div[contains(@class,'row')][1]"
            "//button[contains(.,'Agregar')]"
        ),
        page.locator("xpath=//label[contains(.,'Materia')]/ancestor::div[1]//button[contains(.,'Agregar')]"),
        page.locator("xpath=//button[contains(.,'Agregar')]"),
    )
    for candidates in candidate_groups:
        try:
            total = candidates.count()
            if total == 0:
                continue
            for idx in range(total):
                candidate = candidates.nth(idx)
                try:
                    if not candidate.is_visible():
                        continue
                    candidate.click(timeout=4000)
                    return True
                except Exception:
                    continue
        except Exception:
            continue

    # Fallback: in algunos despliegues de OJV el foco queda en Materia y Enter agrega.
    for key_sequence in (("Enter",), ("Tab", "Enter"), ("Tab", "Tab", "Enter")):
        try:
            for key in key_sequence:
                page.keyboard.press(key)
            return True
        except Exception:
            continue

    return False


def _select_value_with_tab_fallback(
    page,
    label_text: str,
    value: str,
    *,
    prefer_last: bool = False,
    timeout_ms: int = 5000,
) -> bool:
    label = _label_locator(page, label_text, prefer_last=prefer_last)
    if label is None:
        return False

    try:
        label.wait_for(state="visible", timeout=timeout_ms)
    except Exception:
        return False

    try:
        label.click()
    except Exception:
        return False

    for commit_key in ("Tab", "Enter"):
        try:
            page.keyboard.press("Tab")
            page.keyboard.type(str(value))
            page.keyboard.press(commit_key)
            _wait_select2_drop_mask(page)
            return True
        except Exception:
            continue
    return False


def _select_value_by_label(
    page,
    label_text: str,
    value: str,
    *,
    scope: str | None = None,
    prefer_last: bool = False,
    timeout_ms: int = 30000,
    exact_only: bool = False,
) -> bool:
    label = _label_locator(page, label_text, scope=scope, prefer_last=prefer_last)
    if label is None:
        return False

    try:
        label.wait_for(state="visible", timeout=timeout_ms)
    except Exception:
        return False

    native_select_candidates = (
        label.locator("xpath=../select[1]").first,
        label.locator("xpath=../div//select[1]").first,
        label.locator("xpath=ancestor::div[1]//select[1]").first,
    )
    target_text = _normalize_select_text(str(value))
    for candidate in native_select_candidates:
        try:
            if candidate.count() == 0:
                continue
            candidate.wait_for(state="visible", timeout=timeout_ms)
            try:
                candidate.select_option(label=value)
                return True
            except Exception:
                pass

            options = candidate.locator("option")
            option_count = options.count()

            exact_index = None
            contains_index = None
            for index in range(option_count):
                option_text = _normalize_select_text(options.nth(index).inner_text() or "")
                if option_text == target_text:
                    exact_index = index
                    break
                if (
                    not exact_only
                    and contains_index is None
                    and target_text
                    and target_text in option_text
                ):
                    contains_index = index

            if exact_index is not None:
                candidate.select_option(index=exact_index)
                return True
            if contains_index is not None:
                candidate.select_option(index=contains_index)
                return True
        except Exception:
            continue

    clicked = False
    click_candidates = (
        label.locator(
            "xpath=../div//*[contains(@class,'select2-choice') or contains(@class,'select2-container')][1]"
        ).first,
        label.locator("xpath=../div//input[not(@type='hidden')][1]").first,
        label.locator(
            "xpath=ancestor::div[1]//*[contains(@class,'select2-choice') or contains(@class,'select2-container')][1]"
        ).first,
    )
    for candidate in click_candidates:
        try:
            if candidate.count() == 0:
                continue
            candidate.wait_for(state="visible", timeout=timeout_ms)
            candidate.click()
            clicked = True
            break
        except Exception:
            continue

    if not clicked:
        try:
            label.click()
            clicked = True
        except Exception:
            return False

    if not clicked:
        return False

    search_query = (
        "input.select2-input:visible, "
        ".select2-drop-active input:visible, "
        "input[type='search']:visible, "
        "input[role='combobox']:visible"
    )
    deadline = time.time() + 2.5
    while time.time() < deadline:
        search_inputs = page.locator(search_query)
        try:
            if search_inputs.count() > 0:
                box = search_inputs.last
                try:
                    box.fill("")
                except Exception:
                    pass
                box.type(str(value))
                if exact_only:
                    time.sleep(0.4)
                    result_options = page.locator(".select2-results li:visible")
                    try:
                        result_count = result_options.count()
                        for index in range(result_count):
                            option = result_options.nth(index)
                            option_text = _normalize_select_text(option.inner_text() or "")
                            if option_text == target_text:
                                option.click()
                                _wait_select2_drop_mask(page)
                                return True
                    except Exception:
                        pass
                    try:
                        box.press("Escape")
                    except Exception:
                        pass
                    return False
                box.press("Enter")
                _wait_select2_drop_mask(page)
                return True
        except Exception:
            pass
        time.sleep(0.2)

    result_options = page.locator(".select2-results li:visible")
    try:
        result_count = result_options.count()
        if result_count > 0:
            exact_option = None
            contains_option = None
            for index in range(result_count):
                option = result_options.nth(index)
                option_text = _normalize_select_text(option.inner_text() or "")
                if option_text == target_text:
                    exact_option = option
                    break
                if (
                    not exact_only
                    and contains_option is None
                    and target_text
                    and target_text in option_text
                ):
                    contains_option = option

            chosen = exact_option or contains_option
            if chosen is not None:
                chosen.click()
                _wait_select2_drop_mask(page)
                return True
    except Exception:
        pass

    try:
        page.keyboard.type(str(value))
        page.keyboard.press("Enter")
        _wait_select2_drop_mask(page)
        return True
    except Exception:
        return False


def _fill_input_by_label(
    page,
    label_text: str,
    value: str,
    *,
    scope: str | None = None,
    prefer_last: bool = False,
    timeout_ms: int = 30000,
) -> bool:
    label = _label_locator(page, label_text, scope=scope, prefer_last=prefer_last)
    if label is None:
        return False

    try:
        label.wait_for(state="visible", timeout=timeout_ms)
    except Exception:
        return False

    input_candidates = (
        label.locator("xpath=../input[not(@type='hidden')][1]").first,
        label.locator("xpath=../div//input[not(@type='hidden')][1]").first,
        label.locator("xpath=ancestor::div[1]//input[not(@type='hidden')][1]").first,
        label.locator("xpath=../textarea[1]").first,
        label.locator("xpath=../div//textarea[1]").first,
        label.locator("xpath=ancestor::div[1]//textarea[1]").first,
    )
    for candidate in input_candidates:
        try:
            if candidate.count() == 0:
                continue
            candidate.wait_for(state="visible", timeout=timeout_ms)
            candidate.click()
            candidate.fill(str(value))
            return True
        except Exception:
            continue
    return False


def _set_anexo_tipo_documento(
    page,
    *,
    tipo_documento: str,
    observacion: str,
) -> bool:
    if _select_value_by_label(
        page,
        "Tipo de Documento",
        tipo_documento,
        scope="#dDAnexo",
        prefer_last=True,
        timeout_ms=3500,
    ):
        if observacion:
            _fill_input_by_label(
                page,
                "Observ",
                observacion,
                scope="#dDAnexo",
                prefer_last=True,
                timeout_ms=2000,
            )
        return True

    if not _select_value_with_tab_fallback(
        page,
        "Tipo de Documento",
        tipo_documento,
        prefer_last=True,
        timeout_ms=3500,
    ):
        if not _select_value_by_label(
            page,
            "Tipo de Documento",
            tipo_documento,
            scope="#dDAnexo",
            prefer_last=True,
            timeout_ms=3500,
        ):
            return False

    if observacion:
        _fill_input_by_label(
            page,
            "Observ",
            observacion,
            scope="#dDAnexo",
            prefer_last=True,
            timeout_ms=2000,
        )
    return True


def _get_original_papel_toggle(page):
    scope = page.locator("#dDAnexo")
    candidates = (
        scope.locator("xpath=.//button[contains(normalize-space(.),'Original Papel')]").first,
        scope.locator("xpath=.//label[contains(normalize-space(.),'Original Papel')]").first,
        scope.get_by_text(re.compile(r"^\s*Original\s+Papel\s*$", re.IGNORECASE), exact=True).first,
    )
    for candidate in candidates:
        try:
            if candidate.count() == 0:
                continue
            if candidate.is_visible():
                return candidate
        except Exception:
            continue
    return None


def _read_original_papel_state(toggle):
    try:
        return toggle.evaluate(
            """el => {
                const checkbox =
                    (el.matches && el.matches("input[type='checkbox']") ? el : null) ||
                    el.querySelector("input[type='checkbox']") ||
                    el.closest("label,button,div")?.querySelector("input[type='checkbox']");
                if (checkbox) return !!checkbox.checked;

                const ariaChecked = (el.getAttribute("aria-checked") || "").toLowerCase();
                if (ariaChecked === "true") return true;
                if (ariaChecked === "false") return false;

                const ariaPressed = (el.getAttribute("aria-pressed") || "").toLowerCase();
                if (ariaPressed === "true") return true;
                if (ariaPressed === "false") return false;

                const icon = el.querySelector("i,span");
                const classText = `${el.className || ""} ${icon ? icon.className || "" : ""}`.toLowerCase();
                if (classText.includes("check-square") || classText.includes("checked")) return true;
                if (classText.includes("square-o") || classText.includes("unchecked")) return false;
                if (classText.includes("active")) return true;

                return null;
            }"""
        )
    except Exception:
        return None


def _set_original_papel_state(page, checked: bool) -> bool:
    toggle = _get_original_papel_toggle(page)
    if toggle is None:
        return False

    for _ in range(3):
        state = _read_original_papel_state(toggle)
        if state is not None and state == checked:
            return True
        try:
            toggle.click(timeout=2000)
        except Exception:
            return False
        time.sleep(0.2)
        state = _read_original_papel_state(toggle)
        if state is not None and state == checked:
            return True

    return False


def _save_workbook_with_retry(excel: Excel, path: str, retries: int = 6, delay_seconds: float = 1.0) -> None:
    for attempt in range(1, retries + 1):
        try:
            excel.save_workbook(path)
            return
        except PermissionError as error:
            if attempt >= retries:
                raise PermissionError(
                    f"No se pudo guardar el Excel: {path}. "
                    "Verifica que el archivo no este abierto en Excel u otra app."
                ) from error
            time.sleep(delay_seconds)
        except OSError as error:
            if getattr(error, "errno", None) != 13 or attempt >= retries:
                raise
            time.sleep(delay_seconds)


def ensure_excel_writable_or_raise(path: str) -> None:
    target = Path(path).expanduser()
    if not target.exists() or not target.is_file():
        raise FileNotFoundError(f"No existe el Excel: {target}")
    try:
        with open(target, "rb+"):
            pass
    except PermissionError as error:
        raise PermissionError(
            f"No se pudo guardar el Excel: {target}. "
            "Verifica que el archivo no este abierto en Excel u otra app."
        ) from error
    except OSError as error:
        if getattr(error, "errno", None) == 13:
            raise PermissionError(
                f"No se pudo guardar el Excel: {target}. "
                "Verifica que el archivo no este abierto en Excel u otra app."
            ) from error
        raise


def _ensure_ingreso_column(excel: Excel, workbook_path: str):
    rows = excel.read_worksheet_as_table("BOT", header=True, start=3)
    ingreso_index = 1
    if not rows.columns.__contains__("INGRESO"):
        excel.insert_columns_before(1, 1)
        excel.set_cell_value(3, 1, "INGRESO")
        _save_workbook_with_retry(excel, workbook_path)
        rows = excel.read_worksheet_as_table("BOT", header=True, start=3)
    else:
        ingreso_index = rows.columns.index("INGRESO") + 1
    return rows, ingreso_index


def _is_ingreso_ok(value) -> bool:
    return str(value or "").strip().upper() == "OK"


def _build_ingreso_summary_rows(run_rows) -> tuple[list[dict], str]:
    try:
        columns = list(run_rows.columns)
    except Exception:
        columns = []

    demanda_column_key = columns[1] if len(columns) >= 2 else ""
    summary_rows: list[dict] = []
    for row_offset, row in enumerate(run_rows):
        row_number = row_offset + 4
        ingreso_text = str(row.get("INGRESO", "")).strip()
        if not ingreso_text:
            continue

        demanda_raw = row.get(demanda_column_key, "") if demanda_column_key else ""
        demanda_text = str(demanda_raw).strip()
        summary_rows.append(
            {
                "rowNumber": row_number,
                "ingreso": ingreso_text,
                "ok": ingreso_text.upper() == "OK",
                "demanda": demanda_text,
            }
        )
    return summary_rows, demanda_column_key


def _write_ingreso_summary_json(
    *,
    summary_path: Path,
    matrix_output_path: str,
    total_rows: int,
    ok_rows: int,
    pending_rows: int,
    rows: list[dict],
    demanda_column_key: str,
) -> None:
    payload = {
        "summaryKind": "ingreso",
        "schemaVersion": 1,
        "matrixOutputPath": matrix_output_path,
        "totals": {
            "total": total_rows,
            "ok": ok_rows,
            "pending": pending_rows,
        },
        "demandaColumnKey": demanda_column_key,
        "rowCount": len(rows),
        "rows": rows,
    }
    summary_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _build_get_caratulas_summary_rows(
    run_rows,
    *,
    target_row_numbers: set[int] | None = None,
) -> tuple[list[dict], str]:
    try:
        columns = list(run_rows.columns)
    except Exception:
        columns = []

    rit_column_key = ""
    for column_name in columns:
        if str(column_name or "").strip().upper() == "RIT":
            rit_column_key = column_name
            break
    if not rit_column_key and columns:
        rit_column_key = columns[0]

    summary_rows: list[dict] = []
    for row_offset, row in enumerate(run_rows):
        row_number = row_offset + 5
        if target_row_numbers is not None and row_number not in target_row_numbers:
            continue

        rit_raw = row.get(rit_column_key, "") if rit_column_key else ""
        rit_text = str(rit_raw or "").strip()
        if not rit_text:
            rit_text = "-"

        descarga_raw = row.get("DESCARGA_CARATULA", "")
        descarga_text = str(descarga_raw or "").strip()
        is_ok = descarga_text.upper() == "OK"
        summary_rows.append(
            {
                "rowNumber": row_number,
                "rit": rit_text,
                "descarga_caratula": "Ok" if is_ok else "Pendiente",
                "ok": is_ok,
            }
        )
    return summary_rows, rit_column_key


def _write_get_caratulas_summary_json(
    *,
    summary_path: Path,
    informe_path: str,
    output_dir: str,
    total_rows: int,
    ok_rows: int,
    pending_rows: int,
    run_target: int,
    run_ok: int,
    run_pending: int,
    failed_downloads: int,
    rows: list[dict],
    rit_column_key: str,
) -> None:
    payload = {
        "summaryKind": "get_caratulas",
        "schemaVersion": 1,
        "informePath": informe_path,
        "outputDir": output_dir,
        "totals": {
            "total": total_rows,
            "ok": ok_rows,
            "pending": pending_rows,
            "failed_downloads": failed_downloads,
        },
        "runTotals": {
            "target": run_target,
            "ok": run_ok,
            "pending": run_pending,
        },
        "ritColumnKey": rit_column_key,
        "rowCount": len(rows),
        "rows": rows,
    }
    summary_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def read_excel_ingreso(
    EXCEL_FILE_NAME: str,
    PATH_BOT: str,
    DEMANDAS_FOLDER_PATH: str,
    INGRESO_OUTPUT_DIR: str | None = None,
    documentos_firmados: bool = False,
):
    """
    open and read an excel file for ingreso

    """
    print(f"[INGRESO][CODE_VERSION] {INGRESO_CODE_VERSION}")
    print(f"[INGRESO][DOCUMENTOS_FIRMADOS] {'SI' if documentos_firmados else 'NO'}")
    print('Ingreso')
    run_excel = Excel()
    source_excel = Excel()

    input_path = os.path.join(DEMANDAS_FOLDER_PATH, EXCEL_FILE_NAME)
    source_matrix = Path(input_path)
    if not source_matrix.exists():
        raise FileNotFoundError(f"No existe la matriz de ingreso: {source_matrix}")
    source_matrix_path = str(source_matrix)

    output_dir = Path(_resolve_ingreso_output_dir(PATH_BOT, INGRESO_OUTPUT_DIR))
    finished_matrix_name = f"{source_matrix.stem}_terminado{source_matrix.suffix or '.xlsx'}"
    path = str(output_dir / finished_matrix_name)
    shutil.copy2(source_matrix, path)
    print(f"[INGRESO] Matriz origen: {source_matrix}")
    print(f"[INGRESO] Matriz salida: {path}")
    ingreso_errors = []
    processed_rows = 0
    ok_rows = 0
    failed_rows = 0
    summary_rows: list[dict] = []
    summary_demanda_key = ""
    summary_total_rows = 0
    summary_ok_rows = 0
    summary_pending_rows = 0

    try:
        source_excel.open_workbook(source_matrix_path)
        source_rows, source_ingreso_index = _ensure_ingreso_column(source_excel, source_matrix_path)

        run_excel.open_workbook(path)
        run_rows, run_ingreso_index = _ensure_ingreso_column(run_excel, path)

        # Keep run output as a per-run log: clear previous INGRESO values copied from source.
        for row_number, _ in enumerate(run_rows, start=4):
            run_excel.set_cell_value(row_number, run_ingreso_index, "")
        _save_workbook_with_retry(run_excel, path)

        source_rows = source_excel.read_worksheet_as_table("BOT", header=True, start=3)
        for row_offset, row in enumerate(source_rows):
            numero = row_offset + 4
            if _is_ingreso_ok(row.get("INGRESO")):
                continue

            processed_rows += 1
            row_file = str(row["ARCH_DEMANDA"])
            if documentos_firmados:
                row_file = _with_firmado_suffix(row_file)
            print(f"[INGRESO][ROW {numero}] {row_file}")
            try:
                fill_form_ingreso_demandas(
                    row,
                    PATH_BOT,
                    DEMANDAS_FOLDER_PATH,
                    INGRESO_OUTPUT_DIR,
                    documentos_firmados,
                )
                run_excel.set_cell_value(numero, run_ingreso_index, "OK")
                source_excel.set_cell_value(numero, source_ingreso_index, "OK")
                ok_rows += 1
            except Exception as e:
                error_text = str(e).strip() or e.__class__.__name__
                print(f"[INGRESO][ERROR][ROW {numero}] {error_text}")
                run_excel.set_cell_value(numero, run_ingreso_index, error_text)
                # Keep original matrix retryable: errors remain empty.
                source_excel.set_cell_value(numero, source_ingreso_index, "")
                failed_rows += 1
                ingreso_errors.append(f"Fila {numero} ({row_file}): {error_text}")

                try:
                    current_url = ""
                    try:
                        current_url = browser.page().url
                    except Exception:
                        pass
                    page = browser.goto(_ojv_url("/kpitec-ojv-web/index#mantenedor/usuarios", current_url))
                    _handle_ojv_runtime_blockers(page)
                    page.reload()
                    _handle_ojv_runtime_blockers(page)
                except Exception as recovery_error:
                    recovery_text = str(recovery_error).strip() or recovery_error.__class__.__name__
                    print(f"[INGRESO][RECOVERY][ROW {numero}] {recovery_text}")
                    ingreso_errors.append(f"Recuperacion fallida fila {numero}: {recovery_text}")

            _save_workbook_with_retry(run_excel, path)
            _save_workbook_with_retry(source_excel, source_matrix_path)

        _save_workbook_with_retry(run_excel, path)
        _save_workbook_with_retry(source_excel, source_matrix_path)

        final_rows = source_excel.read_worksheet_as_table("BOT", header=True, start=3)
        total_rows = 0
        ok_total = 0
        for final_row in final_rows:
            total_rows += 1
            if _is_ingreso_ok(final_row.get("INGRESO")):
                ok_total += 1
        pending_rows = max(total_rows - ok_total, 0)
        all_ok = total_rows > 0 and pending_rows == 0
        summary_total_rows = total_rows
        summary_ok_rows = ok_total
        summary_pending_rows = pending_rows

        run_rows_for_summary = run_excel.read_worksheet_as_table("BOT", header=True, start=3)
        summary_rows, summary_demanda_key = _build_ingreso_summary_rows(run_rows_for_summary)
        summary_path = output_dir / "ingreso_summary.json"
        _write_ingreso_summary_json(
            summary_path=summary_path,
            matrix_output_path=path,
            total_rows=summary_total_rows,
            ok_rows=summary_ok_rows,
            pending_rows=summary_pending_rows,
            rows=summary_rows,
            demanda_column_key=summary_demanda_key,
        )
        print(f"[INGRESO][SUMMARY_JSON] {summary_path}")
        print(f"[INGRESO][SUMMARY_ROWS] rows={len(summary_rows)}")
        print(
            f"[INGRESO][MATRIZ] total={total_rows} ok={ok_total} "
            f"pendientes={pending_rows} all_ok={'YES' if all_ok else 'NO'}"
        )
    finally:
        try:
            run_excel.close_workbook()
        except Exception:
            pass
        try:
            source_excel.close_workbook()
        except Exception:
            pass

    print(f"Done Ingreso | procesadas={processed_rows} ok={ok_rows} error={failed_rows}")

    if ingreso_errors:
        resumen = "; ".join(ingreso_errors[:3])
        raise RuntimeError(
            f"RPA_06_Ingreso finalizo con {failed_rows} fila(s) con error. "
            f"Primeros errores: {resumen}"
        )

def fill_form_ingreso_demandas(
    row,
    PATH_BOT: str,
    DEMANDAS_FOLDER_PATH: str,
    INGRESO_OUTPUT_DIR: str | None = None,
    documentos_firmados: bool = False,
):
    
    page = browser.page()
    _handle_ojv_runtime_blockers(page)
    output_dir = _resolve_ingreso_output_dir(PATH_BOT, INGRESO_OUTPUT_DIR)
    rut = str(row["ARCH_DEMANDA"]).replace('01_Demandas_firmadas\\','').split('_')[0]

    page.get_by_text("Ingresar Demanda/Recurso").click()

    time.sleep(1)
    _handle_ojv_runtime_blockers(page)

    page.get_by_text("Competencia", exact=True).wait_for()

    page.get_by_text("Competencia", exact=True).click()
    page.press("body", "Tab")
    page.keyboard.type("Civil")
    page.press("body", "Tab")
    time.sleep(1)
    page.keyboard.type("C.A. de Santiago")
    page.press("body", "Tab")
    time.sleep(2)
    page.keyboard.type("Dist. Corte Santiago")
    page.press("body", "Tab")
    time.sleep(1)
    page.keyboard.type("JOAQ")
    page.press("body", "Tab")
    time.sleep(1)
    page.locator("xpath=//label[contains(.,'Procedimiento')]").wait_for(timeout=50000)
    page.locator("xpath=//label[contains(.,'Procedimiento')]").click()
    page.press("body", "Tab")
    page.keyboard.type("Ejecutivo")
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.keyboard.type("pagare, cobro de")
    page.press("body", "Tab")
    page.press("body", "Enter")
    time.sleep(1)
    page.press("body", "Tab")
    page.press("body", "Tab")
    page.press("body", "Tab")
    page.keyboard.type("dte.")
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")

    datos = getDatosHomologacion(str(row["PRESTAMO"]).upper())

    page.keyboard.type(datos[0])
    page.press("body", "Tab")

    _wait_select2_drop_mask(page)

    page.locator("xpath=//label[contains(.,'Tipo Persona:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("juridica")
    page.press("body", "Tab")
    page.keyboard.type(datos[1])
    page.press("body", "Tab")

    page.locator("xpath=//button[contains(.,'Agregar Litigante')]").click()

    page.locator("xpath=//label[contains(.,'Tipo Sujeto:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("AB.DTE.")
    page.press("body", "Tab")
    time.sleep(1)
    page.keyboard.type("113461977")
    page.press("body", "Tab")

    _wait_select2_drop_mask(page)

    page.locator("xpath=//label[contains(.,'Tipo Persona:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("natural")
    page.press("body", "Tab")

    page.locator("xpath=//button[contains(.,'Agregar Litigante')]").click()

    ### AGREGAR AL DEMANDADO ###

    page.locator("xpath=//label[contains(.,'Tipo Sujeto:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("DDO.")
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")

    page.keyboard.type(rut)
    page.press("body", "Tab")

    _wait_select2_drop_mask(page)

    page.locator("xpath=//label[contains(.,'Tipo Persona:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("natural")
    page.press("body", "Tab")

    page.locator("xpath=//button[contains(.,'Datos Litigante')]").click()
    page.locator("xpath=//*[@id='datos_multiples_litigante']/div/div/div[contains(.,'Editar Datos Litigante')]").wait_for(state="visible")
    time.sleep(1)

    if page.locator("xpath=//*[@id='cardListaDirec']/div[2]/div/div/div[contains(.,'El litigante no posee direcciones ingresadas.')]").is_visible() :
        page.locator("xpath=//*[@id='formularioDireccion']/div/div[1]/div/label[contains(.,'Tipo de Direccion')]").click()
        page.press("body", "Tab")
        page.keyboard.type("particular")
        page.press("body", "Tab")
        time.sleep(1)
        page.keyboard.type("I Región de Tarapacá")
        page.press("body", "Tab")
        time.sleep(2)
        page.keyboard.type("Alto Hospicio")
        page.press("body", "Tab")
        time.sleep(1)
        page.keyboard.type("Avenida")
        page.press("body", "Tab")
        time.sleep(1)
        page.keyboard.type("1")
        page.press("body", "Tab")
        time.sleep(1)
        page.keyboard.type("1")
        page.press("body", "Tab")
        time.sleep(1)

        page.locator("xpath=//*[@id='botonesDireccion']/div/div/div/div[2]/button[contains(.,'Ingresar')]").click()
        time.sleep(1)

    page.locator("xpath=//*[@id='datos_multiples_litigante']/div/div/div[3]/div/div/div[2]/button[contains(.,'Guardar')]").click()
    time.sleep(1)

    page.locator("xpath=//button[contains(.,'Agregar Litigante')]").click()
    time.sleep(1)

    demandado = str(row['NOMBRE_DEUDOR']).strip().upper().replace("Á", "A").replace("É", "E").replace("Í", "I").replace("Ó", "O").replace("Ú", "U")
    demandadoPjud = page.locator("xpath=//*[@id='idTrCardLitCau-2']/div/div/div[2]/div[1]/div[1]/p").inner_text().strip().upper().replace("Á", "A").replace("É", "E").replace("Í", "I").replace("Ó", "O").replace("Ú", "U")

    ruta = os.path.join(output_dir, f"{rut}-ingreso.png")
    page.screenshot(path=ruta, full_page=True)

    if (demandado != demandadoPjud):
        raise Exception("NOMBRES NO COINCIDEN EN EL PJUD")
                            
    page.locator("xpath=//*[@id='page']/div/div[6]/div/div/div[2]/div[5]/div/div/div/div[4]/button[contains(.,'Ingresar')]").click()
    time.sleep(1)

    page.get_by_text("Adjuntar Archivo").wait_for();
    page.get_by_text("Adjuntar Archivo").click()

    ### ruta al archivo de demanda
    arch_demanda = str(row['ARCH_DEMANDA'])
    if documentos_firmados:
        arch_demanda = _with_firmado_suffix(arch_demanda)
    ruta_demanda = os.path.join(DEMANDAS_FOLDER_PATH, arch_demanda)
    _upload_with_file_chooser(
        page,
        page.locator("#dDPrincipal").get_by_role("button", name="Adjuntar"),
        ruta_demanda,
    )

    upload = _wait_for_toast_message(
        page,
        "Documento guardado correctamente. Para realizar envío al tribunal debe dirigirse a bandeja demandas/recursos",
        timeout_seconds=61,
    )
    
    if not upload :
        ruta = os.path.join(output_dir, f"{rut}-ERROR-ADJUNTANDO-DEMANDA.png")
        page.screenshot(path=ruta, full_page=True)

        raise Exception('ERROR ADJUNTANDO DEMANDA')
    
    datos = [{'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['ARCH_PAGARES'])),
              'referencia': str(int(row["CANTIDAD_PAGARES"])) + ' PAGARES',
              'documento': 'pagare',
              'observacion' : str(int(row["CANTIDAD_PAGARES"])) + ' PAGARES'
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['ARCH_CONTRATO'])),
              'referencia': 'CONTRATO',
              'documento': 'contrato',
              'observacion' : 'CONTRATO'
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['1_MANDATO_1'])),
              'referencia': 'MANDATO-1',
              'documento': '',
              'observacion' : ''
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['2_MANDATO_2'])),
              'referencia': 'MANDATO-2',
              'documento': '',
              'observacion' : ''
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['3_MANDATO_3'])),
              'referencia': 'MANDATO-3',
              'documento': '',
              'observacion' : ''
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['4_MANDATO_4'])),
              'referencia': 'MANDATO-4',
              'documento': '',
              'observacion' : ''
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['RESOLUCION'])),
              'referencia': 'RESOLUCION',
              'documento': '',
              'observacion' : ''
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['CERTIFICADO'])),
              'referencia': 'CERTIFICADO',
              'documento': '',
              'observacion' : ''
            },
            {'ruta': os.path.join(DEMANDAS_FOLDER_PATH, str(row['7_MANDATO_7'])),
              'referencia': 'MANDATO-7',
              'documento': '',
              'observacion' : ''
            }]

    documentos = [str(row['PJUD_PAGARES']), str(row['PJUD_CONTRATO']), str(row['PJUD_MANDATO_1']), str(row['PJUD_MANDATO_2']), str(row['PJUD_MANDATO_3']), str(row['PJUD_MANDATO_4']), str(row['PJUD_RESOLUCION']), str(row['PJUD_CERTIFICADO'])]

    if (str(row['PRESTAMO']) == 'CEDIDA') :
         documentos.append("MANDATO_7")

    for index, x in enumerate(documentos):
               
        ### ruta del archivo 
        ruta_documento = datos[index]['ruta']
        referencia = datos[index]['referencia']
        tipo_documento = datos[index]['documento']
        observacion = datos[index]['observacion']

        referencia_input = page.locator("xpath=//*[@id='dDAnexo']/div[3]/div[1]/div/input")
        referencia_input.wait_for(state="visible", timeout=30000)
        referencia_input.fill(referencia)
        page.press("body", "Tab")
        if (tipo_documento != ''):
            page.press("body", "Space")
            time.sleep(1)
        
        if (tipo_documento != ''):
            tipo_doc_visible = _set_anexo_tipo_documento(
                page,
                tipo_documento=tipo_documento,
                observacion=observacion,
            )
            if not tipo_doc_visible:
                error_shot = os.path.join(output_dir, f"{rut}-ERROR-TIPO-DOCUMENTO-{x}.png")
                page.screenshot(path=error_shot, full_page=True)
                print(
                    f"[INGRESO][ERROR] Campo Tipo de Documento no visible para {x}. "
                    "Abortando adjuntos para esta demanda."
                )
                page.get_by_role("button", name="Cerrar y Continuar").click()
                time.sleep(2)
                accionSobreDemanda(page, demandado, "Eliminar")
                raise Exception(f"ERROR TIPO DOCUMENTO NO VISIBLE: {x}")

        _upload_with_file_chooser(
            page,
            page.locator("xpath=//*[@id='dDAnexo']/div[3]/div[3]/div/button[contains(.,'Adjuntar')]"),
            ruta_documento,
        )

        time.sleep(2)

        upload = _wait_for_toast_message(
            page,
            "Documento guardado correctamente. Para realizar envío al tribunal debe dirigirse a bandeja demandas/recursos",
            timeout_seconds=91,
        )
        
        if not upload :
            ruta = os.path.join(output_dir, f"{rut}-ERROR-ADJUNTANDO-{x}.png")

            page.screenshot(path=ruta, full_page=True)
            page.get_by_role("button", name="Cerrar y Continuar").click()
            
            time.sleep(2)
            accionSobreDemanda(page, demandado, "Eliminar")                

            raise Exception(f"ERROR ADJUNTANDO {x}")
        
        time.sleep(2)

    page.press("body", "PageDown") 
    ruta = os.path.join(output_dir, f"{rut}-adjuntos.png")
    page.screenshot(path=ruta, full_page=True)

    page.get_by_role("button", name="Cerrar y Continuar").click()

    time.sleep(2)
#    accionSobreDemanda(page, demandado, "Enviar")

def accionSobreDemanda(page, demandado, accion):
    try:
        page.get_by_text("Bandeja Demandas/Recursos").click()
        
        page.locator("xpath=//*[@id='page']/div/div[4]/div/div/div/div/div[3]/div[1]/div/input").wait_for(timeout=30000)

        if not _select_value_by_label(page, "Competencia", "Civil"):
            competencia_label = page.locator(
                "xpath=//*[@id='page']/div/div[4]/div/div/div/div/div[2]/div[3]/div/label[contains(.,'Competencia:')]"
            )
            competencia_label.click()
            page.keyboard.type("Civil")
            page.keyboard.press("Enter")

        page.locator("xpath=//*[@id='page']/div/div[4]/div/div/div/div/div[3]/div[1]/div/input").click()

        ## Demandas no enviadas
        demandas_no_enviadas = page.locator("xpath=//a[contains(.,'Demandas No Enviadas')]/span").text_content().strip()

        demanda_match = False
        if demandas_no_enviadas != 'None' and demandas_no_enviadas.isnumeric() :       

            for x in range(int(demandas_no_enviadas)) :
                if 'Pagaré, Cobro De' == page.locator(f"xpath=//*[@id='idTrCardBandCau-{x}']/div/div/div[2]/div[2]/div[2]/span").text_content():  
                    
                    ## Click en el menu
                    page.locator(f"xpath=//*[@id='idTrCardBandCau-{x}']/div/div/div[3]/a").click()
                    ## Click en editar causa
                    page.locator(f"xpath=//*[@id='element-popover-idTrCardBandCau-{x}']/div/div/div[2]/div/button").click()

                    for y in range(int(page.locator("xpath=//*[@id='edit_bandeja_causa_civil']/div/div/div[2]/div/div/div/div[3]/div/div/div[1]/span").text_content())) :
                        if page.locator(f"xpath=//*[@id='idTrCardEditCauCivil-{y}']/div/div/div[2]/div[1]/div/p").text_content().strip().upper().replace("Á", "A").replace("É", "E").replace("Í", "I").replace("Ó", "O").replace("Ú", "U") == demandado :
                            demanda_match = True
                            break
                            
                    page.locator("xpath=//*[@id='edit_bandeja_causa_civil']/div/div/div[3]/div/div/div[1]/button").click()

                if demanda_match :
                    page.locator(f"xpath=//*[@id='idTrCardBandCau-{x}']/div/div/div[1]/div").click()                       

                    if accion == "Eliminar" :
                        page.locator("xpath=//*[@id='page']/div/div[7]/div/div/div[1]/div/div/div[2]/input").click()
                        time.sleep(1)
                        page.locator("#modalConfirmarEliminar").wait_for()
                        page.locator("xpath=//*[@id='modalConfirmarEliminar']/div/div/div[2]/div/div/div[2]/button").click()
                        time.sleep(2)
                        break
                    elif accion == 'Enviar':
                        page.locator("xpath=//*[@id='page']/div/div[7]/div/div/div[1]/div/div/div[5]/input").click()
                        time.sleep(1)
                        page.locator("#modalConfirmarEnvioSinFirma").wait_for()                        
                        page.locator("xpath=//*[@id='modalConfirmarEnvioSinFirma']/div/div/div[3]/div/div/div[2]/button").click()
                        time.sleep(2)
                        _wait_for_toast_message(
                            page,
                            "Demanda enviada con éxito. El certificado correspondiente está disponible en la pestaña de Demandas Enviadas",
                            timeout_seconds=61,
                        )
                        break

        page.get_by_text("Mantenedor").click()
        time.sleep(1)
    except Exception as e:
        raise Exception(f"ERROR EN LA ACCION {accion}")

def getDatosHomologacion(tipoSujeto) :

    if tipoSujeto == 'CEDIDA' :
        return ['60.805.000-0', 'TESORERIA GENERAL DE LA REPUBLICA']
    elif tipoSujeto == 'PROPIA' :
        return ['97.023.000-9', 'BANCO ITAU CHILE S.A.']


def _press_key(page, key: str, times: int = 1) -> None:
    for _ in range(max(times, 1)):
        page.keyboard.press(key)


def _select_competencia_civil(page) -> None:
    if _select_value_by_label(page, "Competencia", "Civil"):
        return

    competencia = page.locator("xpath=//label[contains(.,'Competencia:')]/../select").first
    competencia.wait_for(timeout=30000)
    try:
        competencia.select_option(label="Civil")
    except Exception:
        try:
            competencia.click()
            page.keyboard.type("Civil")
        except Exception:
            pass


def _select_tribunal_en_bandeja(page, tribunal: str) -> bool:
    tribunal_pantalla = ""
    for intento in range(10):
        _select_competencia_civil(page)
        time.sleep(2)

        tribunal_ok = _select_value_by_label(page, "Tribunal", tribunal, exact_only=True)
        if not tribunal_ok:
            tribunal_ok = _select_value_by_label(
                page,
                "Tribunal",
                tribunal,
                prefer_last=True,
                exact_only=True,
                timeout_ms=6000,
            )
        if not tribunal_ok:
            try:
                tribunal_select = page.locator("xpath=//label[contains(.,'Tribunal')]/../select").first
                tribunal_select.wait_for(timeout=6000)
                tribunal_select.select_option(label=tribunal)
                tribunal_ok = True
            except Exception:
                tribunal_ok = False
        if not tribunal_ok:
            print(
                f"[GET_CARATULAS] No se pudo seleccionar exactamente el tribunal "
                f"'{tribunal}' (intento {intento + 1}/10)."
            )
            continue

        demandas_enviadas = page.locator("xpath=//a[contains(.,'Demandas Enviadas')]").first
        demandas_enviadas.wait_for(timeout=30000)
        demandas_enviadas.click()
        time.sleep(2)

        tribunal_locator = page.locator(
            "xpath=//*[@id='idTrCardBandCau-0']/div/div/div[2]/div[2]/div[1]/span"
        ).first
        if tribunal_locator.count() > 0:
            tribunal_pantalla = tribunal_locator.inner_text().strip()
            if _normalize_select_text(tribunal_pantalla) == _normalize_select_text(tribunal):
                return True
            print(
                f"[GET_CARATULAS] Tribunal solicitado '{tribunal}' pero PJUD muestra "
                f"'{tribunal_pantalla}' (intento {intento + 1}/10)."
            )

    return _normalize_select_text(tribunal_pantalla) == _normalize_select_text(tribunal)


def _close_context_tabs_except(page) -> None:
    for tab in page.context.pages:
        if tab == page:
            continue
        try:
            if not tab.is_closed():
                tab.close()
        except Exception:
            continue


def _is_real_pdf(body: bytes | None) -> bool:
    """Only %PDF bytes count. The URL is NOT evidence.

    Run 103 saved 536 bytes of '<!doc...' because _looks_like_pdf_bytes accepts
    anything whose URL contains 'getdoc', so the URL rule short-circuited the
    content rule. Chrome's PDF viewer navigates to the getDoc URL but the
    response body Playwright can read for that navigation is the viewer shell,
    not the document. Check the magic bytes and re-fetch when they are missing.
    """
    return bool(body) and b"%PDF-" in body[:1024]


def _looks_like_pdf_bytes(content_type: str, body: bytes, source_url: str) -> bool:
    """The bytes decide. content_type and source_url are hints, never proof.

    This used to return True whenever the URL contained 'getdoc', so every
    caratula URL passed regardless of what came back -- which is how run 103
    saved 536 bytes of '<!doc' as a PDF and marked the row OK. If we are
    holding a body, the magic bytes settle it.
    """
    return _is_real_pdf(body)


def _download_caratula_via_click(page, link, output_path: str, timeout_ms: int = 25000) -> bool:
    """Click once and grab the caratula bytes off the network, however it arrives.

    Everything URL-based failed because popup.url stays empty even when the
    address bar plainly shows .../fileCertificado/getDoc?certificado=... , and
    the download-event path failed because in the bot's Chrome the PDF renders
    INLINE (no download is ever created). Both are guesses about HOW the
    document is delivered.

    So stop guessing: listen on the whole BrowserContext -- which covers the
    popup as well as `page` -- for either a download event or any response that
    looks like the PDF, click once, and keep whatever turns up first. The body
    is read while the popup is still open, because Playwright discards response
    bodies once the page that fetched them closes.
    """
    ctx = page.context
    downloads: list = []
    responses: list = []
    seen: list = []

    def _on_download(d):
        downloads.append(d)

    def _wire_page(target_page):
        try:
            target_page.on("download", _on_download)
        except Exception:
            pass

    def _on_response(response):
        try:
            url = response.url or ""
            content_type = response.headers.get("content-type", "") or ""
        except Exception:
            return
        seen.append(f"{content_type}|{url[:120]}")
        if (
            "getdoc" in url.lower()
            or "application/pdf" in content_type.lower()
            or url.lower().endswith(".pdf")
        ):
            responses.append(response)

    for existing in list(ctx.pages):
        _wire_page(existing)
    ctx.on("page", _wire_page)
    ctx.on("response", _on_response)

    try:
        try:
            link.click()
        except Exception as error:
            summary = str(error).splitlines()[0][:200] if str(error) else type(error).__name__
            print(f"[GET_CARATULAS][DL:2-click] no se pudo hacer click: {summary}")
            return False

        deadline = time.time() + (max(timeout_ms, 0) / 1000)
        while not downloads and not responses and time.time() < deadline:
            try:
                page.wait_for_timeout(200)
            except Exception:
                time.sleep(0.2)

        # Prefer a real download event when Chrome made one.
        for download in downloads:
            try:
                download.save_as(output_path)
            except Exception:
                continue
            size = os.path.getsize(output_path) if os.path.exists(output_path) else 0
            if size > 0:
                with open(output_path, "rb") as check:
                    head = check.read(5)
                if head == b"%PDF-":
                    print(f"[GET_CARATULAS][DL:2-click] OK (download) {size} bytes")
                    return True
                print(
                    f"[GET_CARATULAS][DL:2-click] descarga no es PDF "
                    f"(bytes={size} head={head!r})."
                )

        # Otherwise take the bytes straight off the response, popup still open.
        candidate_urls: list[str] = []
        for response in responses:
            try:
                url = response.url or ""
            except Exception:
                url = ""
            if url and url not in candidate_urls:
                candidate_urls.append(url)
            try:
                body = response.body()
            except Exception:
                body = None
            if _is_real_pdf(body):
                with open(output_path, "wb") as pdf_file:
                    pdf_file.write(body)
                print(
                    f"[GET_CARATULAS][DL:2-click] OK (response) {len(body)} bytes "
                    f"desde {url[:120]}"
                )
                return True
            print(
                f"[GET_CARATULAS][DL:2-click] respuesta no es PDF "
                f"(bytes={len(body) if body else 0} head={(body[:16] if body else b'')!r}); "
                "se reintentara pidiendo la URL."
            )

        # The viewer shell is not the document: ask for the same URL over the
        # session's own cookies and check the magic bytes again.
        for url in candidate_urls:
            try:
                fetched = ctx.request.get(url, timeout=15000)
                body = fetched.body() if fetched.ok else None
            except Exception as error:
                summary = str(error).splitlines()[0][:160] if str(error) else type(error).__name__
                print(f"[GET_CARATULAS][DL:2-click] refetch fallo: {summary}")
                continue
            if _is_real_pdf(body):
                with open(output_path, "wb") as pdf_file:
                    pdf_file.write(body)
                print(
                    f"[GET_CARATULAS][DL:2-click] OK (refetch) {len(body)} bytes "
                    f"desde {url[:120]}"
                )
                return True
            print(
                f"[GET_CARATULAS][DL:2-click] refetch no es PDF "
                f"(bytes={len(body) if body else 0} head={(body[:16] if body else b'')!r}) "
                f"url={url[:120]}"
            )

        print(
            f"[GET_CARATULAS][DL:2-click] ni descarga ni respuesta PDF. "
            f"respuestas_vistas={len(seen)}"
        )
        for line in seen[-8:]:
            print(f"[GET_CARATULAS][DL:2-click]   visto: {line}")
        return False
    finally:
        for remover, event, handler in (
            (ctx.remove_listener, "response", _on_response),
            (ctx.remove_listener, "page", _wire_page),
        ):
            try:
                remover(event, handler)
            except Exception:
                pass
        # Always shut the viewer tab. Bodies are read above, so this is safe --
        # and without it every SUCCESS leaked a getDoc tab (the old strategies
        # only closed on failure), which at 150 causas means 150 open tabs and
        # a bandeja the operator can never see.
        _close_context_tabs_except(page)


def _wait_for_popup_url(popup, timeout_ms: int = 15000) -> str:
    """Wait until the popup has really navigated, then return its URL.

    expect_popup() hands back the Page the moment it is created, while it is
    still about:blank -- reading .url right then yields "" and the caller
    concludes there is nothing to download, even though the PDF is about to
    render. PJUD serves the caratula from .../fileCertificado/getDoc?...
    """
    deadline = time.time() + (max(timeout_ms, 0) / 1000)
    while True:
        try:
            url = (popup.url or "").strip()
        except Exception:
            url = ""
        if url and not url.lower().startswith("about:"):
            return url
        if time.time() >= deadline:
            return ""
        time.sleep(0.25)


def _save_pdf_from_url(page, candidate_url: str, output_path: str, stage: str = "") -> bool:
    """Re-fetch candidate_url over HTTP and keep it only if it really is a PDF.

    The fetch is a SEPARATE request from the tab that may already be showing the
    document, so a one-shot/session-bound URL can come back as HTML here even
    though the PDF renders fine on screen. Say so out loud instead of failing
    silently: that discard is invisible in the log and looks like "the bot opened
    the PDF and just didn't download it".
    """
    tag = f"[GET_CARATULAS][DL:{stage}]" if stage else "[GET_CARATULAS][DL]"
    if not candidate_url:
        print(f"{tag} sin URL candidata.")
        return False
    url = candidate_url if candidate_url.lower().startswith("http") else urljoin(page.url, candidate_url)
    try:
        response = page.context.request.get(url, timeout=12000)
        if not response.ok:
            print(f"{tag} HTTP {response.status} al pedir {url[:160]}")
            return False
        body = response.body()
        if not body:
            print(f"{tag} respuesta vacia (0 bytes) desde {url[:160]}")
            return False
        content_type = response.headers.get("content-type", "") or ""
        if not _looks_like_pdf_bytes(content_type, body, url):
            print(
                f"{tag} descartado: no parece PDF. "
                f"content_type={content_type!r} bytes={len(body)} "
                f"head={body[:16]!r} url={url[:160]}"
            )
            return False
        with open(output_path, "wb") as pdf_file:
            pdf_file.write(body)
        print(f"{tag} OK {len(body)} bytes desde {url[:160]}")
        return True
    except Exception as error:
        summary = str(error).splitlines()[0][:200] if str(error) else type(error).__name__
        print(f"{tag} excepcion al descargar: {summary} url={url[:160]}")
        return False


def _extract_pdf_candidate_url(page, link) -> str:
    try:
        href = (link.get_attribute("href") or "").strip()
    except Exception:
        href = ""
    if href and href != "#" and not href.lower().startswith("javascript:"):
        return href if href.lower().startswith("http") else urljoin(page.url, href)

    js_sources = []
    for attr in ("onclick", "ng-click", "data-href", "data-url"):
        try:
            raw = (link.get_attribute(attr) or "").strip()
        except Exception:
            raw = ""
        if raw:
            js_sources.append(raw)

    # Capture quoted URLs, especially getDoc endpoints opened via window.open().
    for raw in js_sources:
        matches = re.findall(r"""['"]([^'"]+)['"]""", raw)
        for match in matches:
            candidate = match.strip()
            if not candidate:
                continue
            if "getdoc" in candidate.lower() or candidate.lower().endswith(".pdf"):
                return candidate if candidate.lower().startswith("http") else urljoin(page.url, candidate)
    return ""


def _download_caratula_pdf(page, card_index: int, output_path: str) -> tuple[bool, str]:
    link_selector = f"xpath=//*[@id='idTrCardBandCau-{card_index}']/div/div/div[1]/a"
    rit_selector = f"xpath=//*[@id='idTrCardBandCau-{card_index}']/div/div/div[2]/div[2]/div[4]/span"

    link = page.locator(link_selector).first
    link.wait_for(timeout=60000)

    rit = ""
    try:
        rit = page.locator(rit_selector).first.inner_text().strip()
    except Exception:
        rit = ""

    if os.path.exists(output_path):
        os.remove(output_path)

    try:
        link.scroll_into_view_if_needed()
    except Exception:
        pass

    print(f"[GET_CARATULAS][DL] causa {rit or f'card{card_index}'}: intentando descarga.")

    # 1/4 - URL directa del href/onclick, sin abrir nada.
    pdf_url = _extract_pdf_candidate_url(page, link)
    if _save_pdf_from_url(page, pdf_url, output_path, stage="1-href"):
        return True, rit

    # 2/5 - click -> PJUD responde con attachment -> capturamos la descarga.
    if _download_caratula_via_click(page, link, output_path):
        return True, rit

    # 3/5 - click -> se abre el PDF en un popup -> re-pedimos esa URL.
    popup = None
    try:
        with page.expect_popup(timeout=12000) as popup_info:
            link.click()
        popup = popup_info.value
        try:
            popup.wait_for_load_state("domcontentloaded", timeout=12000)
        except Exception:
            pass

        popup_url = _wait_for_popup_url(popup)
        print(f"[GET_CARATULAS][DL:2-popup] popup abierto en {popup_url[:160] or '(sin URL)'}")
        if _save_pdf_from_url(page, popup_url, output_path, stage="2-popup"):
            return True, rit
    except Exception as error:
        summary = str(error).splitlines()[0][:200] if str(error) else type(error).__name__
        print(f"[GET_CARATULAS][DL:2-popup] no se abrio popup: {summary}")
    finally:
        try:
            if popup and not popup.is_closed():
                popup.close()
        except Exception:
            pass
        _close_context_tabs_except(page)

    # 3/4 - click -> evento de descarga del navegador.
    try:
        with page.expect_download(timeout=12000) as download_info:
            link.click()
        download = download_info.value
        download.save_as(output_path)
        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            print(f"[GET_CARATULAS][DL:3-download] OK {os.path.getsize(output_path)} bytes")
            return True, rit
        print("[GET_CARATULAS][DL:3-download] descarga guardada pero vacia.")
    except Exception as error:
        summary = str(error).splitlines()[0][:200] if str(error) else type(error).__name__
        print(f"[GET_CARATULAS][DL:3-download] sin evento de descarga: {summary}")
    finally:
        _close_context_tabs_except(page)

    try:
        with page.expect_response(
            lambda response: (
                "application/pdf" in (response.headers.get("content-type", "") or "").lower()
                or "getdoc" in (response.url or "").lower()
            ),
            timeout=12000,
        ) as response_info:
            link.click()
        pdf_response = response_info.value
        pdf_body = pdf_response.body()
        content_type = pdf_response.headers.get("content-type", "") or ""
        if pdf_body and _looks_like_pdf_bytes(content_type, pdf_body, pdf_response.url):
            with open(output_path, "wb") as pdf_file:
                pdf_file.write(pdf_body)
            print(f"[GET_CARATULAS][DL:4-response] OK {len(pdf_body)} bytes")
            return True, rit
        print(
            f"[GET_CARATULAS][DL:4-response] descartado: content_type={content_type!r} "
            f"bytes={len(pdf_body) if pdf_body else 0} "
            f"head={(pdf_body[:16] if pdf_body else b'')!r} url={(pdf_response.url or '')[:160]}"
        )
    except Exception as error:
        summary = str(error).splitlines()[0][:200] if str(error) else type(error).__name__
        print(f"[GET_CARATULAS][DL:4-response] sin respuesta PDF: {summary}")
    finally:
        _close_context_tabs_except(page)

    print(f"[GET_CARATULAS][DL] causa {rit or f'card{card_index}'}: las 4 estrategias fallaron.")
    return False, rit


def _download_caratula_pdf_with_retries(
    page,
    card_index: int,
    output_path: str,
    max_attempts: int = GET_CARATULAS_MAX_DOWNLOAD_ATTEMPTS,
) -> tuple[bool, str, int]:
    attempts = max(1, int(max_attempts or 1))
    last_rit = ""

    for attempt in range(1, attempts + 1):
        ok, rit = _download_caratula_pdf(page, card_index, output_path)
        if rit:
            last_rit = rit
        if ok:
            if attempt > 1:
                print(
                    f"[GET_CARATULAS] Descarga recuperada para causa {last_rit or 'SIN_RIT'} "
                    f"en intento {attempt}/{attempts}."
                )
            return True, (rit or last_rit), attempt

        if attempt < attempts:
            print(
                f"[GET_CARATULAS] Reintentando descarga de causa {last_rit or 'SIN_RIT'} "
                f"({attempt + 1}/{attempts})."
            )
            time.sleep(1)
            _close_context_tabs_except(page)

    return False, last_rit, attempts


def _rit_tribunal_key_from_pdf_basename(base_name: str) -> str:
    base = str(base_name or "").strip()
    if not base or base == "CaratulasUnidas":
        return ""

    # Already-renamed format: <RUT>-C-<RIT>-<Tribunal>
    if "-C-" in base:
        _, rit_tail = base.split("-C-", 1)
        return f"C-{rit_tail}"

    # Raw downloaded format: <RIT>-<Tribunal>
    if base.startswith("C-"):
        return base

    return ""


def read_excel_caratulas(
    EXCEL_INFORME_PJUD: str,
    CARATULAS_FOLDER_PATH: str,
    page,
    EXCEL_INGRESO_DEMANDAS: str,
    fecha_desde: str,
    fecha_hasta: str,
    sin_comparar: bool = False,
):
    """
    open and read an excel file for get caratulas

    When ``sin_comparar`` is True, every caratula downloaded from the Informe is
    kept (no RUT cross-reference against the matrix, no deletes); otherwise only
    caratulas whose demandado RUT is an INGRESO=OK row in the matrix survive.
    """
    lista_ordenada = sorted(glob.glob(os.path.join(CARATULAS_FOLDER_PATH, "*.pdf")))
    for file in lista_ordenada:
        print(file)

    print('Caratulas')
    excel = Excel()

    if os.path.isabs(EXCEL_INFORME_PJUD):
        path = EXCEL_INFORME_PJUD
    else:
        path = os.path.join(CARATULAS_FOLDER_PATH, EXCEL_INFORME_PJUD)

    if not os.path.isfile(path):
        raise FileNotFoundError(f"No existe el Excel Informe PJUD: {path}")

    excel.open_workbook(path)
    rows = excel.read_worksheet_as_table("Demandas Enviadas", header=True, start=4)

    initial_total_rows = 0
    initial_ok_rows = 0
    for row in rows:
        initial_total_rows += 1
        if str(row.get("DESCARGA_CARATULA", "") or "").strip().upper() == "OK":
            initial_ok_rows += 1
    initial_pending_rows = max(initial_total_rows - initial_ok_rows, 0)

    caratulaIndex = 1

    if not rows.columns.__contains__("DESCARGA_CARATULA"):
        excel.insert_columns_before(1, 1)
        excel.set_cell_value(4, 1, "DESCARGA_CARATULA")
        _save_workbook_with_retry(excel, path)
    else:
        caratulaIndex = rows.columns.index("DESCARGA_CARATULA") + 1

    rows = excel.read_worksheet_as_table("Demandas Enviadas", header=True, start=4)

    tribunalesList = []
    rits_pendientes_por_tribunal: dict[str, set[str]] = {}

    for row in rows:
        tribunal_row = str(row.get("Tribunal", "") or "").strip()
        descarga_actual = str(row.get("DESCARGA_CARATULA", "") or "").strip().upper()
        if not tribunal_row:
            continue
        if not tribunalesList.__contains__(tribunal_row) and descarga_actual != "OK":
            tribunalesList.append(tribunal_row)
        if descarga_actual == "OK":
            continue
        rit_pendiente = _normalize_rit(row.get("Rit", ""))
        if rit_pendiente:
            rits_pendientes_por_tribunal.setdefault(tribunal_row, set()).add(rit_pendiente)

    fecha_desde_objetivo = str(fecha_desde or "").strip()
    fecha_hasta_objetivo = str(fecha_hasta or "").strip()
    if not fecha_desde_objetivo or not fecha_hasta_objetivo:
        raise ValueError(
            "Rango de fechas obligatorio para GET_CARATULAS. "
            "Define FECHA_DESDE_CARATULAS y FECHA_HASTA_CARATULAS."
        )

    total_descargas = 0
    failed_downloads: list[str] = []
    fatal_download_error: Exception | None = None
    for tribunal in tribunalesList:
        try:
            rits_objetivo = rits_pendientes_por_tribunal.get(tribunal, set())
            if rits_objetivo:
                print(
                    f"[GET_CARATULAS] Tribunal {tribunal}: buscando {len(rits_objetivo)} RIT objetivo."
                )
            else:
                print(
                    f"[GET_CARATULAS] Tribunal {tribunal}: no hay RIT objetivo en Informe, "
                    "se intentara descarga general."
                )

            page.goto(_ojv_url("/kpitec-ojv-web/index#bandeja/causas", page.url))
            time.sleep(5)

            fecha_desde_input = page.locator("xpath=//label[contains(.,'Fecha Desde')]/../div/input").first
            fecha_hasta_input = page.locator("xpath=//label[contains(.,'Fecha Hasta')]/../div/input").first
            fecha_desde_input.wait_for(timeout=30000)
            fecha_hasta_input.wait_for(timeout=30000)
            fecha_desde_input.fill(fecha_desde_objetivo)
            fecha_hasta_input.fill(fecha_hasta_objetivo)
            time.sleep(2)

            try:
                page.evaluate("document.body.style.zoom='70%'")
            except Exception:
                pass

            if not _select_tribunal_en_bandeja(page, tribunal):
                print(f"No se pudo seleccionar el tribunal {tribunal}.")
                continue

            demandas = page.locator("xpath=//*[@id='idBandejaCausa']/div/div").count()
            if demandas == 0:
                print(f"No se encontraron causas para el tribunal {tribunal} con el filtro aplicado.")
                continue

            descargas_exitosas = 0
            rits_descargados: set[str] = set()
            for x in range(demandas):
                if x % 5 == 0 and x > 0:
                    _press_key(page, "ArrowDown", 6)

                card_rit = ""
                try:
                    card_rit = page.locator(
                        f"xpath=//*[@id='idTrCardBandCau-{x}']/div/div/div[2]/div[2]/div[4]/span"
                    ).first.inner_text().strip()
                except Exception:
                    card_rit = ""

                card_rit_norm = _normalize_rit(card_rit)
                if rits_objetivo and card_rit_norm and card_rit_norm not in rits_objetivo:
                    continue

                ruta_temporal = os.path.join(CARATULAS_FOLDER_PATH, f"tmp_getcar_{x}.pdf")
                ok_descarga, rit, attempts_used = _download_caratula_pdf_with_retries(
                    page,
                    x,
                    ruta_temporal,
                )
                if not ok_descarga:
                    rit_error = rit or card_rit or f"SINRIT-{x}"
                    print(
                        f"error descarga documento de la causa {rit_error} del tribunal {tribunal} "
                        f"(intentos={attempts_used})"
                    )
                    failed_downloads.append(f"{rit_error}|{tribunal}")
                    if os.path.exists(ruta_temporal):
                        os.remove(ruta_temporal)
                    continue

                rit_archivo = str(rit or card_rit or "").strip()
                rit_archivo_norm = _normalize_rit(rit_archivo)
                if rits_objetivo and rit_archivo_norm and rit_archivo_norm not in rits_objetivo:
                    if os.path.exists(ruta_temporal):
                        os.remove(ruta_temporal)
                    continue

                # Last gate before the row is called done: whatever strategy
                # claimed success, the file itself has to be a PDF. Otherwise a
                # junk body gets renamed, counted, and written OK into the Excel
                # -- and re-running then SKIPS the row, hiding the failure.
                try:
                    with open(ruta_temporal, "rb") as check:
                        head = check.read(1024)
                except Exception:
                    head = b""
                if not _is_real_pdf(head):
                    rit_error = rit or card_rit or f"SINRIT-{x}"
                    size = os.path.getsize(ruta_temporal) if os.path.exists(ruta_temporal) else 0
                    print(
                        f"[GET_CARATULAS][WARN] descarga descartada para {rit_error}: "
                        f"el archivo no es un PDF (bytes={size} head={head[:16]!r})."
                    )
                    failed_downloads.append(f"{rit_error}|{tribunal}")
                    if os.path.exists(ruta_temporal):
                        os.remove(ruta_temporal)
                    continue

                if not rit_archivo:
                    rit_archivo = f"SINRIT-{x}"

                ruta_caratula = os.path.join(CARATULAS_FOLDER_PATH, f"{rit_archivo}-{tribunal}.pdf")
                if os.path.exists(ruta_caratula):
                    os.remove(ruta_caratula)
                os.rename(ruta_temporal, ruta_caratula)
                descargas_exitosas += 1
                if rit_archivo_norm:
                    rits_descargados.add(rit_archivo_norm)
                    # Mark this row immediately so partial progress is preserved if browser closes.
                    for idx, row in enumerate(rows):
                        if str(row.get("Tribunal", "") or "").strip() != tribunal:
                            continue
                        if _normalize_rit(row.get("Rit", "")) == rit_archivo_norm:
                            excel.set_cell_value(idx + 5, caratulaIndex, "OK")

                if rits_objetivo and rits_objetivo.issubset(rits_descargados):
                    print(
                        f"[GET_CARATULAS] Tribunal {tribunal}: RIT objetivo completados, "
                        "se detiene iteracion de tarjetas."
                    )
                    break

            if descargas_exitosas == 0:
                print(f"No se descargaron PDFs para el tribunal {tribunal}.")
                continue

            total_descargas += descargas_exitosas

            for idx, row in enumerate(rows):
                if str(row.get("Tribunal", "") or "").strip() != tribunal:
                    continue
                if not rits_objetivo:
                    excel.set_cell_value(idx + 5, caratulaIndex, "OK")
                    continue
                if _normalize_rit(row.get("Rit", "")) in rits_descargados:
                    excel.set_cell_value(idx + 5, caratulaIndex, "OK")

            print("Descargado el tribunal " + tribunal)
            _save_workbook_with_retry(excel, path)
        except Exception as error:
            fatal_download_error = error
            print(
                f"[GET_CARATULAS][WARN] Descarga interrumpida en tribunal '{tribunal}': {error}"
            )
            break

    _save_workbook_with_retry(excel, path)
    excel.close_workbook()

    excel.open_workbook(path) 
    rows = excel.read_worksheet_as_table("Demandas Enviadas", header=True, start=4)

    # Recovery path: if browser closed after downloading PDFs, align DESCARGA_CARATULA from files.
    existing_pdf_rit_keys: set[str] = set()
    for file in glob.glob(os.path.join(CARATULAS_FOLDER_PATH, "*.pdf")):
        base = os.path.splitext(os.path.basename(file))[0]
        rit_key = _rit_tribunal_key_from_pdf_basename(base)
        if not rit_key:
            continue
        # A .pdf extension is not proof either: junk left by an earlier run
        # would otherwise be recovered as OK and never retried.
        try:
            with open(file, "rb") as check:
                if not _is_real_pdf(check.read(1024)):
                    print(
                        f"[GET_CARATULAS][RECOVERY][WARN] se ignora "
                        f"{os.path.basename(file)}: no es un PDF valido."
                    )
                    continue
        except Exception:
            continue
        existing_pdf_rit_keys.add(rit_key)

    aligned_from_files = 0
    for idx, row in enumerate(rows):
        rit = str(row.get("Rit", "") or "").strip()
        tribunal = str(row.get("Tribunal", "") or "").strip()
        if not rit or not tribunal:
            continue

        rit_tribunal = f"{rit}-{tribunal}"
        descarga = str(row.get("DESCARGA_CARATULA", "") or "").strip().upper()
        if descarga != "OK" and rit_tribunal in existing_pdf_rit_keys:
            excel.set_cell_value(idx + 5, caratulaIndex, "OK")
            aligned_from_files += 1

    if aligned_from_files > 0:
        print(
            f"[GET_CARATULAS][RECOVERY] Se marcaron {aligned_from_files} fila(s) como OK "
            "segun PDFs ya descargados."
        )
        _save_workbook_with_retry(excel, path)
        rows = excel.read_worksheet_as_table("Demandas Enviadas", header=True, start=4)

    total_rows = 0
    ok_rows = 0
    for row in rows:
        total_rows += 1
        if str(row.get("DESCARGA_CARATULA", "") or "").strip().upper() == "OK":
            ok_rows += 1
    pending_rows = max(total_rows - ok_rows, 0)
    failed_downloads_count = len(failed_downloads)
    run_ok_rows = max(ok_rows - initial_ok_rows, 0)
    if run_ok_rows > initial_pending_rows:
        run_ok_rows = initial_pending_rows
    run_pending_rows = max(initial_pending_rows - run_ok_rows, 0)
    print(
        f"[GET_CARATULAS][MATRIZ] total={total_rows} ok={ok_rows} "
        f"pending={pending_rows} failed_downloads={failed_downloads_count}"
    )
    print(
        f"[GET_CARATULAS][RUN] target={initial_pending_rows} ok={run_ok_rows} "
        f"pending={run_pending_rows}"
    )

    # Snapshot per-run for UI detail: immutable view even when later retries finish all rows.
    summary_rows, summary_rit_key = _build_get_caratulas_summary_rows(
        rows,
        target_row_numbers=None,
    )
    run_summary_stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    run_summary_path = Path(CARATULAS_FOLDER_PATH) / f"get_caratulas_run_summary_{run_summary_stamp}.json"
    _write_get_caratulas_summary_json(
        summary_path=run_summary_path,
        informe_path=path,
        output_dir=CARATULAS_FOLDER_PATH,
        total_rows=total_rows,
        ok_rows=ok_rows,
        pending_rows=pending_rows,
        run_target=initial_pending_rows,
        run_ok=run_ok_rows,
        run_pending=run_pending_rows,
        failed_downloads=failed_downloads_count,
        rows=summary_rows,
        rit_column_key=summary_rit_key,
    )
    print(f"[GET_CARATULAS][RUN_SUMMARY_JSON] {run_summary_path}")
    print(f"[GET_CARATULAS][RUN_SUMMARY_ROWS] rows={len(summary_rows)}")

    if pending_rows > 0:
        print(
            "[GET_CARATULAS] Se detectaron pendientes. "
            "CaratulasUnidas se generara con las descargas disponibles; "
            "el summary final queda pendiente hasta completar el proceso."
        )
    else:
        summary_path = Path(CARATULAS_FOLDER_PATH) / "get_caratulas_summary.json"
        _write_get_caratulas_summary_json(
            summary_path=summary_path,
            informe_path=path,
            output_dir=CARATULAS_FOLDER_PATH,
            total_rows=total_rows,
            ok_rows=ok_rows,
            pending_rows=pending_rows,
            run_target=initial_pending_rows,
            run_ok=run_ok_rows,
            run_pending=run_pending_rows,
            failed_downloads=failed_downloads_count,
            rows=summary_rows,
            rit_column_key=summary_rit_key,
        )
        print(f"[GET_CARATULAS][SUMMARY_JSON] {summary_path}")
        print(f"[GET_CARATULAS][SUMMARY_ROWS] rows={len(summary_rows)}")

    RIT_RUT = {}
    for row in rows:
        if row["DESCARGA_CARATULA"] == "OK":
            if rows.columns.__contains__("4-Rut") and str(row["4-Rut"]) != "None":
                RIT_RUT[str(row["Rit"]) + "-" + str(row["Tribunal"])] = str(row["4-Rut"])
            else:
                RIT_RUT[str(row["Rit"]) + "-" + str(row["Tribunal"])] = str(row["3-Rut"])

    _save_workbook_with_retry(excel, path)
    excel.close_workbook()

    if sin_comparar:
        print(
            "[GET_CARATULAS] Modo 'sin comparar': se conservan todas las "
            "caratulas del informe (sin cruce de RUT contra la matriz)."
        )
        caratulas_validas = dict(RIT_RUT)
    else:
        matriz_path = EXCEL_INGRESO_DEMANDAS
        if not os.path.isabs(matriz_path):
            matriz_path = os.path.abspath(matriz_path)
        if not os.path.isfile(matriz_path):
            raise FileNotFoundError(f"No existe la matriz para cruce de RUT: {matriz_path}")

        excel.open_workbook(matriz_path)
        rows = excel.read_worksheet_as_table("BOT", header=True, start=3)
        if not rows.columns.__contains__("ARCH_DEMANDA"):
            excel.close_workbook()
            raise KeyError(
                "La matriz para cruce de RUT no tiene la columna 'ARCH_DEMANDA'. "
                f"Archivo: {matriz_path}"
            )

        has_ingreso_column = rows.columns.__contains__("INGRESO")
        if has_ingreso_column:
            print("[GET_CARATULAS] Cruce de RUT usando solo filas con INGRESO=OK.")
        else:
            print("[GET_CARATULAS] Columna INGRESO no encontrada; usando todas las filas con ARCH_DEMANDA.")

        RUT_MATRIZ = []
        for row in rows:
            if has_ingreso_column and str(row.get("INGRESO", "")).strip().upper() != "OK":
                continue

            arch_demanda = str(row.get("ARCH_DEMANDA", "") or "").strip()
            if not arch_demanda or arch_demanda.upper() == "NONE":
                continue

            nombre_archivo = arch_demanda.replace("\\", "/").split("/")[-1]
            rut = nombre_archivo.split("_")[0].replace(".", "").upper()
            if rut:
                RUT_MATRIZ.append(rut)

        excel.close_workbook()

        rut_ingreso_set = set(RUT_MATRIZ)
        caratulas_validas = {
            rit_tribunal: rut
            for rit_tribunal, rut in RIT_RUT.items()
            if rut in rut_ingreso_set
        }

    salida_unida = os.path.join(CARATULAS_FOLDER_PATH, "CaratulasUnidas.pdf")
    if os.path.isfile(salida_unida):
        os.remove(salida_unida)

    archivos_para_unir = []

    for file in glob.glob(os.path.join(CARATULAS_FOLDER_PATH, "*.pdf")):
        base = os.path.splitext(os.path.basename(file))[0]

        if base == "CaratulasUnidas":
            os.remove(file)
            continue

        if base in caratulas_validas:
            nuevo = f"{caratulas_validas[base]}-{base}"
            destino = os.path.join(CARATULAS_FOLDER_PATH, nuevo + ".pdf")
            if os.path.abspath(file) != os.path.abspath(destino):
                if os.path.isfile(destino):
                    os.remove(destino)
                os.rename(file, destino)
            archivos_para_unir.append(destino)
            continue

        # Handle already-renamed files from this/previous runs: <RUT>-C-<RIT>-<Tribunal>
        if "-C-" in base:
            rut_prefix, rit_tail = base.split("-C-", 1)
            rit_tribunal = f"C-{rit_tail}"
            if (
                rit_tribunal in caratulas_validas
                and rut_prefix.upper() == caratulas_validas[rit_tribunal].upper()
            ):
                archivos_para_unir.append(file)
            else:
                os.remove(file)
            continue

        if base.startswith("C-"):
            os.remove(file)

    lista_ordenada = sorted(set(archivos_para_unir))
    merger = PdfWriter()
    merged_files = []
    for file in lista_ordenada:
        # One unreadable PDF used to abort the entire task at the very last
        # step, losing every good download with it (run 103).
        try:
            merger.append(fileobj=file, pages=(0, 1))
            merged_files.append(file)
        except Exception as error:
            summary = str(error).splitlines()[0][:160] if str(error) else type(error).__name__
            print(
                f"[GET_CARATULAS][MERGE][WARN] se omite {os.path.basename(file)}: {summary}"
            )
    lista_ordenada = merged_files

    if lista_ordenada:
        with open(salida_unida, "wb") as output:
            merger.write(output)

    merger.close()
    if lista_ordenada:
        merge_status = "PARCIAL" if pending_rows > 0 else "COMPLETO"
        print(
            f"[GET_CARATULAS][MERGED] status={merge_status} "
            f"pdfs={len(lista_ordenada)} pending={pending_rows} path={salida_unida}"
        )
    else:
        print(
            "[GET_CARATULAS][WARN] No hay caratulas validas disponibles para generar "
            "CaratulasUnidas.pdf."
        )
    print(
        f"Done Descarga Caratulas | total={total_rows} ok={ok_rows} "
        f"pending={pending_rows} failed_downloads={failed_downloads_count} "
        f"run_target={initial_pending_rows} run_ok={run_ok_rows} run_pending={run_pending_rows}"
    )

    if fatal_download_error and ok_rows > 0:
        print(
            "[GET_CARATULAS][WARN] Ejecucion interrumpida, pero se conservaron "
            "descargas parciales en la carpeta de salida."
        )
        return

    if total_rows <= 0:
        raise RuntimeError("GET_CARATULAS no contiene filas en el informe para procesar.")

    if ok_rows <= 0 and pending_rows > 0:
        raise RuntimeError(
            "GET_CARATULAS no descargo ninguna caratula (ok=0). "
            "Revisar seleccion de tribunal/filtros en PJUD."
        )

    if fatal_download_error:
        raise RuntimeError(
            f"GET_CARATULAS interrumpido antes de completar la descarga: {fatal_download_error}"
        )
