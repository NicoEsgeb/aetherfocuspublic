import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2

    function botFolderPath() {
        var inputFolder = String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
        if (inputFolder.length === 0)
            return ""
        var normalized = inputFolder.replace(/\\/g, "/")
        while (normalized.length > 1 && normalized.endsWith("/"))
            normalized = normalized.substring(0, normalized.length - 1)
        var separator = normalized.lastIndexOf("/")
        return separator > 0 ? normalized.substring(0, separator) : ""
    }

    function botFolderUrl() {
        var folder = root.botFolderPath()
        if (folder.length === 0)
            return ""
        if (helpers && typeof helpers.localPathToFileUrl === "function")
            return helpers.localPathToFileUrl(folder)
        return "file:///" + folder
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
            text: "Clean06 · Emerix (Extensión)"
            color: Common.Theme.text
            font.pixelSize: Common.Theme.fontSize(16)
            font.bold: true
            Layout.fillWidth: true
            wrapMode: Text.Wrap
        }

        Rectangle {
            radius: 6
            color: Common.Theme.accentSoft
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: cleanBadge.implicitWidth + 16
            implicitHeight: cleanBadge.implicitHeight + 8
            Label {
                id: cleanBadge
                anchors.centerIn: parent
                text: "Clean BBRR"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }

        Rectangle {
            radius: 6
            color: Common.Theme.successSoft
            border.width: 1
            border.color: Common.Theme.success
            implicitWidth: edgeBadge.implicitWidth + 16
            implicitHeight: edgeBadge.implicitHeight + 8
            Label {
                id: edgeBadge
                anchors.centerIn: parent
                text: "Edge real"
                color: Common.Theme.success
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: locationLayout.implicitHeight + 20

        ColumnLayout {
            id: locationLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Ubicación del bot"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }

            Label {
                text: "Abre la carpeta de Clean06 para acceder directamente a su extensión, archivos de entrada y resultados."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openBotFolderButton
                text: "Abrir Ubicación del bot"
                hoverEnabled: true
                enabled: root.botFolderPath().length > 0
                onClicked: {
                    var target = root.botFolderUrl()
                    if (target.length > 0)
                        Qt.openUrlExternally(target)
                }
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: openBotFolderButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: openBotFolderButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Primera etapa disponible"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "Clean06 ya recibe un único Excel, abre un bridge local independiente y se enlaza con su propia extensión dentro de la sesión real de Emerix. El usuario conserva el control del login."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: stepsLayout.implicitHeight + 20

        ColumnLayout {
            id: stepsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Cómo probar la conexión"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "1. En Edge, abre edge://extensions, activa el modo desarrollador y carga bots/clean06_emerix-extension/extension.\n" +
                      "2. Selecciona el Excel y pulsa Iniciar bot en BotManager.\n" +
                      "3. Abre https://itau.emerix.net/emerix.ui/login e inicia sesión manualmente.\n" +
                      "4. En /emerix.ui/app/dashboard, presiona Start en el panel Clean06.\n\n" +
                      "La prueba genera bridge_connection.json en la carpeta output del bot."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.warningSoft
        border.width: 1
        border.color: Common.Theme.warning
        implicitHeight: pendingLayout.implicitHeight + 20

        ColumnLayout {
            id: pendingLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 4

            Label {
                text: "Pendiente de definición"
                color: Common.Theme.warning
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "La navegación posterior a Start, las columnas del Excel y el resultado final se agregarán cuando Massa-Camus defina el recorrido de Clean06."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
