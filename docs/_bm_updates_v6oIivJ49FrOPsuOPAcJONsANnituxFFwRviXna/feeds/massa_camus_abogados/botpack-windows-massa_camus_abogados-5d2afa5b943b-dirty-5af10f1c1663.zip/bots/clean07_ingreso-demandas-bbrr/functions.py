"""Business logic for the Clean07 "Ingresar Demandas BBRR" bridge.

Clean07 is the PJUD twin of Clean05: the human opens their own Chrome, logs into
the Oficina Judicial Virtual by hand, and the bot works the page from a Chrome
extension that talks to this loopback bridge.

The run is:

  1. validate the selected planilla against the required column set,
  2. validate input/01_mandatos holds the 5 fixed shared documents,
  3. validate input/02_contratos holds every contrato the planilla references,
  4. validate input/03_demandas holds at least one RUT the planilla needs,
  5. open the bridge and confirm the extension connected (Start pressed),
  6. drive the portal one step at a time through ``ROW_STEPS``.

The portal route is being built one step at a time: ``ROW_STEPS`` currently
covers the one-time page setup (tribunal, materia, both litigantes); the
per-row loop that repeats for every RUT comes next. Validation is
deliberately fail-fast — a planilla or folder that cannot be processed must
never reach the browser, so the operator finds out in BotManager instead of
halfway through a real ingreso.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import json
import threading
import time

ALLOWED_EXCEL_SUFFIXES = {".xlsx", ".xlsm"}
BOT_ID = "clean07_ingreso_demandas_bbrr"
BOT_LABEL = "Clean07"

# The page the operator is expected to run the bot from. Start is accepted from
# any PJUD page (the content script only runs on that origin), but a different
# page is recorded so the log shows where the handoff actually happened.
PORTAL_HOST = "oficinajudicialvirtual.pjud.cl"
PORTAL_START_PAGE = "indexN.php"

# Columns the planilla must expose, taken from the reference workbook
# input/planilla_ingreso/Planilla_Ingreso_Demandas.xlsx (the output of Clean06).
# Matching is case-insensitive and whitespace-tolerant, so "hoja de firma" and
# "  HOJA   DE  FIRMA " both satisfy "HOJA DE FIRMA". Underscores are NOT
# whitespace, so "HOJA_DE_FIRMA" and "HOJA DE FIRMA" stay two distinct columns —
# they are two different columns in the real planilla.
#
# `Contrato` is deliberately ABSENT: Clean06 dropped that column on 2026-08-17
# (Contrato.pdf never existed as a file; the mandato case now writes
# <RUT>\Contrato_Mandato.pdf into 6_Contrato_CPSB). An older reference workbook
# on disk may still carry it — do NOT re-add it from there. Requiring it would
# reject every current Clean06 planilla; leaving it out accepts both layouts,
# since an extra column in the input is simply ignored.
REQUIRED_COLUMNS: tuple[str, ...] = (
    "ESTADO",
    "RUT",
    "DV",
    "CARTERA",
    "ARCH_DEMANDA",
    "ARCH_PAGARES",
    "1_Mandato_11709-2026.pdf",
    "2_Mandato_37590-2016.pdf",
    "3_Resolucion_409.pdf",
    "4_Certificado_2215.pdf",
    "5_Mandato_9342-2016.pdf",
    "6_Contrato_CPSB",
    "7_HOJA_DE_FIRMA.pdf",
    "DEMANDA",
    "PAGARES",
    "MANDATO-1",
    "MANDATO-2",
    "RESOLUCION",
    "CERTIFICADO",
    "Pagare firmado cliente",
    "CONTRATO_MANDATO_FIRMADO_CLIENTE",
    "HOJA_DE_FIRMA",
    "MANDATO-5",
    "CONTRATO",
    "HOJA DE FIRMA",
)

# The 5 shared documents every filing needs, regardless of RUT — same names as
# the first 5 REQUIRED_COLUMNS above (those are the planilla's column headers;
# these are the actual files input/01_mandatos must physically contain).
REQUIRED_MANDATO_FILENAMES: tuple[str, ...] = (
    "1_Mandato_11709-2026.pdf",
    "2_Mandato_37590-2016.pdf",
    "3_Resolucion_409.pdf",
    "4_Certificado_2215.pdf",
    "5_Mandato_9342-2016.pdf",
)

HEADER_ROW = 1

# The steps the extension performs on the portal for one planilla row, in order.
# The names are the contract with extension/content.js: every entry must have a
# handler in its STEP_HANDLERS map. The list grows as the client defines the
# route; the session finishes cleanly after the last one.
ROW_STEPS: tuple[str, ...] = (
    # Left menu of indexN.php: "Ingresar Demanda/Recurso".
    "click_ingresar_demanda",
    # Competencia / tribunal block, filled in cascade order.
    "select_competencia",
    "select_corte",
    "select_tribunal",
    # "Dirigido a" comes pre-selected with the patrocinating abogado, so this
    # only confirms it and corrects it if the portal ever defaults elsewhere.
    "ensure_dirigido_a",
    # Checks "Fijar Datos" so the tribunal block stays filled for the next
    # ingreso instead of resetting on every row.
    "click_fijar_datos",
    # "Ingreso de Demanda" card: Procedimiento = Ejecutivo, then its Materia.
    "select_procedimiento",
    "select_materia",
    # Second "Fijar Datos" — the one in the Ingreso de Demanda card footer.
    # It is a DIFFERENT checkbox from the tribunal one above; both render the
    # same "Fijar Datos" text, so they are only distinguishable by id.
    "click_fijar_datos_materia",
    # Agregar is LAST in this section: it adds the materia to the causa and
    # opens the next section below, so it must fire after Fijar Datos, not
    # before — reversed from the order this was first built in.
    "click_agregar_materia",
    # Litigantes section, opened by Agregar Materia above. "Tipo Sujeto" is a
    # select2 bound to tipoLitiganteSel inside a `foreach: litigantesCausa`
    # list; this targets the FIRST litigante block only, same as this bot
    # started with the first Fijar Datos before the second appeared.
    "select_tipo_sujeto",
    # Rut of that same litigante (plain <input name="rut">, Knockout-bound to
    # rutSel). Gated by `disable: bloqueoRutComp`, which Tipo Sujeto above is
    # expected to clear.
    "fill_rut",
    # Once the verification digit lands, the portal runs its own RUT lookup
    # and reveals "Tipo Persona" and "Razón Social" — both auto-filled by the
    # system itself, nothing to click or type. The animation can take 10+
    # seconds, so this step just waits for both to land on the expected
    # values instead of driving anything.
    "await_litigante_lookup",
    # The SII lookup fills Razón Social with the full legal name including the
    # merger note "(O ITAÚ CORPBANCA)"; the client wants the shorter "BANCO
    # ITAÚ CHILE" filed instead, so this overwrites what the lookup wrote.
    "edit_razon_social",
    # Third "Fijar Datos" — the litigante card's own footer checkbox
    # (id_check_fijar_mod_lit), so the DTE's data stays filled for the next
    # ingreso the same way the tribunal and materia ones do. Reuses
    # click_fijar_datos; only the checkbox id differs.
    "click_fijar_datos_litigante",
    # Same shape as Agregar Materia: no stable id, reached by its Knockout
    # click binding (validarIngresoLitigante). Confirms the litigante was
    # added by counting litigantesCausa's own rendered children before/after.
    "click_agregar_litigante",
    # Confirming the first litigante (DTE.) opens a SECOND blank litigante
    # block for the abogado patrocinante. Reuses select_tipo_sujeto's handler
    # with a different option — same select2, same tipoLitiganteSel binding,
    # just now rendered for this second entry.
    "select_tipo_sujeto_abogado",
    # Rut of the abogado patrocinante — same JOAQUÍN MAURICIO CARRILLO MORENO
    # as Dirigido a. Reuses fill_rut's handler; only the STEP_VALUES entry
    # differs.
    "fill_rut_abogado",
    # The abogado's RUT is a natural person, so the lookup reveals Tipo
    # Persona + three name fields (Nombres, Primer apellido, Segundo
    # apellido) instead of Razón Social — all auto-filled and disabled,
    # nothing to click or type.
    "await_abogado_lookup",
    # Same button, same binding, as click_agregar_litigante above — confirms
    # this SECOND litigante (the abogado) the same way the first one was.
    "click_agregar_litigante",
)

# Values for the tribunal block. They live here, not in the extension, so the
# day a Corte has to come from the planilla (clean03 carries REGION_DEUDOR) only
# this side changes and the extension stays generic.
#
# Civil is right because what gets filed is a juicio ejecutivo on a pagaré:
# clean04 writes «Procedimiento EJECUTIVO / Materia COBRO DE PAGARÉ» addressed
# to «S.J.L. en lo Civil de Santiago». PJUD's "Cobranza" is the Juzgado de
# Cobranza Laboral y Previsional — a different jurisdiction entirely.
#
# "Dist. Corte Santiago" is the distribución office, not a named court: the
# Corte assigns the causa to one of its juzgados civiles. That is why the
# demanda is addressed to «S.J.L. en lo Civil de Santiago» with no number.
#
# The abogado matches clean04's ABOGADO / ABOGADO_RUT (11.346.197-7), the same
# person rpa06 files under.
STEP_VALUES: dict[str, str] = {
    "select_competencia": "Civil",
    "select_corte": "C.A. de Santiago",
    "select_tribunal": "Dist. Corte Santiago",
    "ensure_dirigido_a": "JOAQUÍN MAURICIO CARRILLO MORENO",
    # Same reasoning as Competencia=Civil: clean04 emits «Procedimiento
    # EJECUTIVO / Materia COBRO DE PAGARÉ». "Procedimiento Concursal" is a
    # different option in the same list, so the extension matches EXACTLY.
    "select_procedimiento": "Ejecutivo",
    # The extension folds case and accents before comparing, so the portal
    # writing "Pagaré" changes nothing — only the WORDING and punctuation have
    # to match, because the comparison is otherwise exact. If the real option
    # reads differently, the step fails and reports the list the portal offered.
    "select_materia": "Pagaré, cobro de",
    # The "Fijar Datos" checkboxes are carried as VALUES, not hardcoded in the
    # extension, because they are indistinguishable by label — all three read
    # "Fijar Datos" — and only the id separates tribunal / materia / litigante.
    "click_fijar_datos": "id_check_fijar_mod_tribunal",
    "click_fijar_datos_materia": "id_check_fijar_mod_materia",
    "click_fijar_datos_litigante": "id_check_fijar_mod_lit",
    # The option renders as "DTE." (with the trailing period) in the portal's
    # select2 list, and matching stays exact, so the period is kept here too.
    "select_tipo_sujeto": "DTE.",
    # Second litigante: the abogado patrocinante, distinct from plain "DTE."
    # (the demandante itself) and "DDO."/"AP.DTE" — matching stays exact so
    # the wrong one can never be picked.
    "select_tipo_sujeto_abogado": "AB.DTE.",
    # Banco Itaú Chile's RUT — the fixed demandante on every filing (same
    # constant as clean04's DEMANDANTE_RUT "97.023.000-9"). Typed as bare
    # digits INCLUDING the verification digit ("970230009"); the portal's own
    # mask inserts the dots and dash as it types, and finishes formatting once
    # the "9" lands — which is also what reveals the next two fields.
    "fill_rut": "970230009",
    # Abogado patrocinante's RUT — clean04's ABOGADO_RUT "11.346.197-7",
    # same person as Dirigido a. Bare digits including the verification
    # digit, same masked-input reasoning as fill_rut above.
    "fill_rut_abogado": "113461977",
    # What the portal's own RUT lookup is expected to fill in, packed as
    # "tipo_persona::razon_social" since STEP_VALUES only carries one string
    # per step. Both come from the SII record behind Itaú's RUT, not from
    # anything the extension chooses.
    "await_litigante_lookup": "JURIDICA::BANCO ITAÚ CHILE (O ITAÚ CORPBANCA)",
    # The client wants the shorter legal name filed, without the merger note
    # the SII lookup appends.
    "edit_razon_social": "BANCO ITAÚ CHILE",
    # What the abogado's RUT lookup is expected to fill in, packed as
    # "tipo_persona::nombres::primer_apellido::segundo_apellido" — a natural
    # person this time, so four fields instead of Razón Social's one. Same
    # JOAQUÍN MAURICIO CARRILLO MORENO as Dirigido a, split into its parts.
    "await_abogado_lookup": "NATURAL::JOAQUÍN MAURICIO::CARRILLO::MORENO",
}

# Milestone guard: while the route is incomplete, stop after the first row so
# the operator watches one clean pass instead of repeating a partial flow on
# every row. Flip to False once ROW_STEPS files a demanda end to end.
HALT_AFTER_FIRST_ROW = True

DEFAULT_DONE_MESSAGE = "Conexión verificada con BotManager."

# How many times the same step may be handed to the extension before the bridge
# declares the loop stuck. One retry is tolerated (a reloaded tab re-asks for
# the step it was performing); beyond that the run stops.
MAX_STEP_ISSUES = 2

# The extension polls /next about every 1.2 s once Start is pressed. If it goes
# quiet for this long (tab closed, extension reloaded, operator walked away),
# close the session instead of hanging until the global timeout.
EXTENSION_IDLE_SECONDS = 90


class MissingColumnsError(ValueError):
    """Raised when the planilla is missing one or more required columns."""

    def __init__(self, missing: list[str], sheet_name: str, found: list[str]):
        self.missing = list(missing)
        self.sheet_name = sheet_name
        self.found = list(found)
        super().__init__(
            "La planilla no tiene todas las columnas necesarias. "
            f"Faltan: {', '.join(self.missing)}."
        )


class InputError(ValueError):
    """Raised when an input other than the columns makes the run impossible.

    Carries a short machine-readable ``reason`` so the desktop notification can
    explain the exact problem instead of a generic failure.
    """

    def __init__(self, message: str, *, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(message)


def _normalize_header(value: Any) -> str:
    """Fold a header to its comparable form: trimmed, collapsed and caseless."""
    return " ".join(str(value if value is not None else "").split()).casefold()


def _read_header_row(worksheet: Any) -> dict[str, tuple[str, int]]:
    """Map normalized header -> (original text, 1-based column index)."""
    headers: dict[str, tuple[str, int]] = {}
    for row in worksheet.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW, values_only=True):
        for index, cell in enumerate(row, start=1):
            normalized = _normalize_header(cell)
            if not normalized:
                continue
            # First occurrence wins, so a duplicated header cannot shadow it.
            headers.setdefault(normalized, (" ".join(str(cell).split()), index))
        break
    return headers


def _match_required_columns(
    headers: dict[str, tuple[str, int]],
) -> tuple[dict[str, Any], list[str]]:
    """Resolve every required column, collecting ALL misses instead of the first."""
    resolved: dict[str, Any] = {}
    missing: list[str] = []
    for required in REQUIRED_COLUMNS:
        match = headers.get(_normalize_header(required))
        if match is None:
            missing.append(required)
            continue
        original, index = match
        resolved[required] = {"header": original, "index": index}
    return resolved, missing


def inspect_excel(path: str) -> dict[str, Any]:
    """Validate the selected planilla and return non-sensitive workbook metadata.

    Every required column is checked before failing, so the operator sees the
    complete list of what is missing instead of only the first offender.
    """
    import openpyxl

    target = Path(path).expanduser()
    if not target.exists() or not target.is_file():
        raise InputError(
            f"No se encontró la planilla seleccionada: {target.name}",
            reason="planilla_inexistente",
            detail=str(target),
        )
    if target.suffix.lower() not in ALLOWED_EXCEL_SUFFIXES:
        raise InputError(
            "La planilla debe ser un archivo Excel .xlsx o .xlsm.",
            reason="planilla_formato",
            detail=target.name,
        )

    try:
        workbook = openpyxl.load_workbook(str(target), read_only=True, data_only=True)
    except Exception as exc:
        raise InputError(
            f"No se pudo abrir la planilla: {exc}",
            reason="planilla_ilegible",
            detail=target.name,
        ) from exc

    try:
        sheet_names = list(workbook.sheetnames)
        if not sheet_names:
            raise InputError(
                "La planilla no contiene hojas.",
                reason="planilla_sin_hojas",
                detail=target.name,
            )

        # The planilla may carry helper sheets, so keep the first sheet that
        # exposes every required column and fall back to the closest match.
        best: dict[str, Any] | None = None
        for name in sheet_names:
            worksheet = workbook[name]
            headers = _read_header_row(worksheet)
            resolved, missing = _match_required_columns(headers)
            candidate = {
                "sheet_name": name,
                "columns": resolved,
                "missing": missing,
                "found_headers": [original for original, _ in headers.values()],
                "data_rows": max(0, int(worksheet.max_row or 0) - HEADER_ROW),
            }
            if not missing:
                best = candidate
                break
            if best is None or len(missing) < len(best["missing"]):
                best = candidate

        assert best is not None  # sheet_names is non-empty
        if best["missing"]:
            raise MissingColumnsError(best["missing"], best["sheet_name"], best["found_headers"])
    finally:
        workbook.close()

    return {
        "filename": target.name,
        "path": str(target),
        "sheet_names": sheet_names,
        "sheet_count": len(sheet_names),
        "sheet_name": best["sheet_name"],
        "columns": best["columns"],
        "data_rows": best["data_rows"],
    }


def read_rows(path: str, sheet_name: str, columns: dict[str, Any]) -> list[dict[str, Any]]:
    """Read the planilla rows, keeping the Excel row number for every record.

    Fully blank rows are dropped so trailing formatting does not inflate the
    count the operator sees in the panel.
    """
    import openpyxl

    workbook = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    try:
        worksheet = workbook[sheet_name]
        indexes = {name: int(meta["index"]) for name, meta in columns.items()}
        rows: list[dict[str, Any]] = []
        for excel_row, raw in enumerate(
            worksheet.iter_rows(min_row=HEADER_ROW + 1, values_only=True),
            start=HEADER_ROW + 1,
        ):
            if not any(cell not in (None, "") for cell in raw):
                continue
            record: dict[str, Any] = {"excel_row": excel_row}
            for name, index in indexes.items():
                value = raw[index - 1] if index - 1 < len(raw) else None
                record[name] = value
            rows.append(record)
        return rows
    finally:
        workbook.close()


def format_rut(rut: object, dv: object) -> str:
    """`5228857` + `6` -> `5.228.857-6`. Returns "" when either part is missing.

    Copy of Clean06's formatter (bots/clean06_crear-planilla-ingreso-demandas/
    functions.py) — Clean06 is the planilla's source, so its RUT format is the
    one the folder names on disk must match. Not imported across bots per the
    project convention; this is small enough to duplicate.
    """
    body = "".join(ch for ch in str(rut or "") if ch.isdigit())
    check = str(dv or "").strip().upper().replace(".", "").replace("-", "")
    if not body or not check:
        return ""

    grouped: list[str] = []
    while len(body) > 3:
        grouped.insert(0, body[-3:])
        body = body[:-3]
    grouped.insert(0, body)
    return f"{'.'.join(grouped)}-{check}"


def inspect_mandatos_folder(path: str) -> dict[str, Any]:
    """Validate input/01_mandatos holds the fixed shared document set.

    These 5 files are the same on every filing session (mandato, resolución,
    certificado — not per-RUT), so the check is a hard, exact-filename match
    against REQUIRED_MANDATO_FILENAMES rather than anything read from the
    planilla.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de mandatos (input/01_mandatos).",
            reason="carpeta_mandatos_inexistente",
            detail=str(target),
        )

    present = {p.name for p in target.iterdir() if p.is_file()}
    missing = [name for name in REQUIRED_MANDATO_FILENAMES if name not in present]
    if missing:
        raise InputError(
            f"Faltan {len(missing)} documento(s) en input/01_mandatos.",
            reason="mandatos_incompletos",
            detail=" | ".join(missing),
        )

    return {
        "path": str(target),
        "file_count": len(present),
    }


def inspect_contratos_folder(path: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate input/02_contratos holds every contrato the planilla references.

    The 6_Contrato_CPSB column carries a value like `5.228.857-6\\6_CPSB_Rept_
    14172.pdf` per row (empty when a row needs none). Only the FILENAME after
    the last backslash matters here — the RUT-DV prefix identifies which row
    needs it, not a real subfolder; every contrato sits flat in this folder.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de contratos (input/02_contratos).",
            reason="carpeta_contratos_inexistente",
            detail=str(target),
        )

    present = {p.name for p in target.iterdir() if p.is_file()}
    referenced: set[str] = set()
    for row in rows:
        text = str(row.get("6_Contrato_CPSB") or "").strip()
        if not text:
            continue
        filename = Path(text.replace("\\", "/")).name
        if filename:
            referenced.add(filename)

    missing = sorted(name for name in referenced if name not in present)
    if missing:
        raise InputError(
            f"Faltan {len(missing)} contrato(s) en input/02_contratos.",
            reason="contratos_faltantes",
            detail=" | ".join(missing),
        )

    return {
        "path": str(target),
        "file_count": len(present),
        "referenced_count": len(referenced),
    }


def inspect_demandas_folder(path: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate input/03_demandas holds at least the RUTs this planilla needs.

    Each row's own PDFs (ARCH_DEMANDA, ARCH_PAGARES, ...) are resolved lazily
    when the loop actually files that row, so this is deliberately a cheap
    up-front sanity check — the right BATCH was dropped in — not a guarantee
    every single row's folder exists.
    """
    target = Path(path).expanduser()
    if not target.exists() or not target.is_dir():
        raise InputError(
            "No se encontró la carpeta de demandas (input/03_demandas).",
            reason="carpeta_inexistente",
            detail=str(target),
        )

    pdfs = sorted(p for p in target.rglob("*") if p.is_file() and p.suffix.lower() == ".pdf")
    subfolders = sorted(p.name for p in target.iterdir() if p.is_dir())
    if not pdfs:
        raise InputError(
            "La carpeta input/03_demandas no contiene ningún PDF.",
            reason="carpeta_vacia",
            detail=str(target),
        )

    expected_ruts = sorted({format_rut(row.get("RUT"), row.get("DV")) for row in rows} - {""})
    if expected_ruts and not (set(subfolders) & set(expected_ruts)):
        raise InputError(
            "Ninguno de los RUT de la planilla tiene carpeta en input/03_demandas.",
            reason="demandas_sin_rut_coincidente",
            detail=" | ".join(expected_ruts[:10]),
        )

    return {
        "path": str(target),
        "pdf_count": len(pdfs),
        "subfolder_count": len(subfolders),
        "subfolders": subfolders[:20],
    }


def _normalize_build(value: Any) -> str:
    """Compare builds without tripping over the "v" prefix.

    content.js carries "v0.7.2" for the panel title while manifest.json carries
    "0.7.2"; they are the same build.
    """
    text = str(value or "").strip()
    return text[1:] if text[:1].lower() == "v" else text


def extension_manifest_version() -> str:
    """Version of the extension AS INSTALLED ON DISK, next to this file.

    Deliberately read from the manifest rather than duplicated in a constant:
    the packaged bot and its extension always ship together, so the manifest is
    the one value that cannot silently disagree with what was deployed.
    """
    manifest = Path(__file__).parent / "extension" / "manifest.json"
    try:
        with manifest.open("r", encoding="utf-8") as handle:
            return str(json.load(handle).get("version") or "")
    except (OSError, json.JSONDecodeError):
        return ""


@dataclass
class BridgeState:
    """Shared state between the desktop task and the Chrome extension.

    The extension polls /health, the operator presses Start (/start), and from
    then on every /next hands out the current ``ROW_STEPS`` entry, which the
    extension performs and answers on /report. Mirrors Clean05's machine.
    """

    input_path: str
    workbook: dict[str, Any]
    demandas: dict[str, Any]
    mandatos: dict[str, Any]
    contratos: dict[str, Any]
    rows: list[dict[str, Any]] = field(default_factory=list)
    extension_seen_at: float = 0.0
    started_at: float = 0.0
    finished: bool = False
    error: str = ""
    portal_url: str = ""
    portal_title: str = ""
    logs: list[str] = field(default_factory=list)
    # Position in the run: which planilla row, and which step inside that row.
    cursor: int = 0
    step_index: int = 0
    rows_done: int = 0
    steps_done: int = 0
    last_step_done: int = 0
    completion_message: str = ""
    # Repeat guard: which step was last handed out, and how many times in a row.
    issued_key: tuple[int, int] | None = None
    issued_count: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock)

    def next_action(self) -> dict[str, Any]:
        """Tell the extension what to do next on the PJUD page."""
        with self.lock:
            self.extension_seen_at = time.time()
            if not self.started_at:
                return {"action": "wait", "message": "Esperando Start."}
            if self.finished or self.cursor >= len(self.rows):
                self.finished = True
                return self._done_step_unlocked()

            row = self.rows[self.cursor]
            step_name = ROW_STEPS[self.step_index]

            # The extension is busy while it performs a step, so it only asks
            # again after reporting. Handing out the same step repeatedly means
            # the reports are not arriving — and repeating an action on the
            # portal is what gets the session blocked by the WAF. Stop instead.
            key = (self.cursor, self.step_index)
            self.issued_count = self.issued_count + 1 if key == self.issued_key else 1
            self.issued_key = key
            if self.issued_count > MAX_STEP_ISSUES:
                self.error = (
                    f"Fila {self.cursor + 1}, paso {self.step_index + 1} "
                    f"({step_name}): la extensión pidió el mismo paso "
                    f"{self.issued_count} veces sin informar el resultado. "
                    "Se detuvo la corrida para no repetirlo en el portal."
                )
                self.completion_message = (
                    f"El bot se detuvo en Step {self.step_index + 1}. Revisa BotManager."
                )
                self.logs.append(self.error)
                self.finished = True
                return self._done_step_unlocked()

            step: dict[str, Any] = {
                "action": step_name,
                "row_number": self.cursor + 1,
                "excel_row": row.get("excel_row"),
                "total": len(self.rows),
                "step_number": self.step_index + 1,
                "step_total": len(ROW_STEPS),
            }
            if step_name in STEP_VALUES:
                step["value"] = STEP_VALUES[step_name]
            return step

    def report_action(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Record how the step the extension just performed went.

        A failed step stops the run. There is no recovery route on PJUD yet, and
        a step that failed means the page is not where the bot believed it was —
        continuing blindly there risks filing into the wrong causa.
        """
        with self.lock:
            self.extension_seen_at = time.time()
            ok = bool(payload.get("ok"))
            detail = " ".join(str(payload.get("detail") or "").split())[:300]
            position = self.cursor + 1
            step_number = self.step_index + 1
            step_name = ROW_STEPS[self.step_index]

            if not ok:
                self.logs.append(f"Fila {position} [{step_name}]: ERROR {detail}")
                self.error = (
                    f"Fila {position}, paso {step_number} ({step_name}): "
                    f"{detail or 'el paso falló sin detalle.'}"
                )
                self.completion_message = (
                    f"El bot se detuvo en Step {step_number}. Revisa BotManager."
                )
                self.finished = True
                return self._report_reply_unlocked()

            self.logs.append(f"Fila {position} [{step_name}]: OK. {detail}".strip())
            self.steps_done += 1
            self.last_step_done = step_number
            self.step_index += 1
            if self.step_index >= len(ROW_STEPS):
                self.step_index = 0
                self.cursor += 1
                self.rows_done += 1
                # The route is still partial, so the last defined step IS the
                # end of the run for now. The message names it so the operator
                # can see how far the bot got without opening the log.
                self.completion_message = (
                    f"Bot ha finalizado correctamente en Step {step_number}"
                )
                if HALT_AFTER_FIRST_ROW or self.cursor >= len(self.rows):
                    self.finished = True
            return self._report_reply_unlocked()

    def _report_reply_unlocked(self) -> dict[str, Any]:
        return {
            "ok": True,
            "done": self.finished,
            "message": self.completion_message or DEFAULT_DONE_MESSAGE,
            "error": self.error,
            "rowsDone": self.rows_done,
            "rowTotal": len(self.rows),
            "stepsDone": self.steps_done,
        }

    def _done_step_unlocked(self) -> dict[str, Any]:
        return {
            "action": "done",
            "message": self.completion_message or DEFAULT_DONE_MESSAGE,
            "error": self.error,
            "rowTotal": len(self.rows),
            "rowsDone": self.rows_done,
            "stepsDone": self.steps_done,
            "pdfCount": int(self.demandas.get("pdf_count", 0)),
        }

    def touch_extension(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            self.extension_seen_at = now
            self.started_at = now
            self.portal_url = str(payload.get("url") or "")[:1000]
            self.portal_title = str(payload.get("title") or "")[:300]
            self.logs.append(f"Start recibido desde {self.portal_url or 'el portal PJUD'}.")
            if PORTAL_START_PAGE.lower() not in self.portal_url.lower():
                self.logs.append(
                    "Aviso: el Start no se presionó desde "
                    f"{PORTAL_START_PAGE}. Se registró igualmente."
                )

            # Reloading the bot files does NOT reload the extension Chrome has
            # already loaded, so the two can drift: the desktop hands out a step
            # the loaded content script never heard of. Catch that HERE, before
            # anything is touched on the portal, instead of halfway through a
            # form. The expected value is read from the extension's own
            # manifest, so there is no second constant to keep in sync.
            # A MISSING build is itself proof of staleness: every extension from
            # 0.7.2 on reports it, so silence means the loaded copy predates the
            # check. That is what makes this gate work on the very first run
            # after updating, which is exactly when the drift happens.
            loaded = _normalize_build(payload.get("build"))
            on_disk = _normalize_build(extension_manifest_version())
            if on_disk and loaded != on_disk:
                came_as = loaded or "una versión anterior a 0.7.2 (no informó su versión)"
                self.error = (
                    f"La extensión cargada en Chrome es {came_as}, pero el bot "
                    f"instalado es la {on_disk}. Recarga la extensión en "
                    "chrome://extensions y luego recarga la pestaña del portal. "
                    "No se tocó el portal."
                )
                self.completion_message = (
                    f"La extensión cargada ({loaded}) es más antigua que el bot "
                    f"({on_disk}). Recárgala en chrome://extensions y luego "
                    "recarga la pestaña del portal."
                )
                self.logs.append(self.error)
                self.finished = True
                # ok=True on purpose: the request WAS handled. The extension
                # treats ok=False as a transport failure and would let the
                # /health poller overwrite this message a second later, hiding
                # the real cause behind "Bridge no conectado".
                return {"ok": True, "done": True, "error": self.error,
                        "message": self.completion_message}
            if loaded:
                self.logs.append(f"Extensión build {loaded} (bot {on_disk or '?'}).")
            return {
                "ok": True,
                "message": (
                    f"Conexión confirmada. Planilla con {len(self.rows)} fila(s) y "
                    f"{int(self.demandas.get('pdf_count', 0))} PDF(s) listos."
                ),
                "summary": self._summary_unlocked(),
            }

    def add_log(self, message: str) -> None:
        clean = " ".join(str(message or "").split())
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean[:500])
            self.logs = self.logs[-100:]

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        return {
            "bot_id": BOT_ID,
            "bot_label": BOT_LABEL,
            "extension_seen": self.extension_seen_at > 0,
            "extension_seen_at": self.extension_seen_at,
            "started": self.started_at > 0,
            "started_at": self.started_at,
            "portal_url": self.portal_url,
            "portal_title": self.portal_title,
            "input_path": self.input_path,
            "workbook": dict(self.workbook),
            "demandas": dict(self.demandas),
            "mandatos": dict(self.mandatos),
            "contratos": dict(self.contratos),
            "workflow_configured": True,
            "step_total": len(ROW_STEPS),
            "steps_done": self.steps_done,
            "last_step_done": self.last_step_done,
            "rows_done": self.rows_done,
            "row_total": len(self.rows),
            "completion_message": self.completion_message,
            "finished": self.finished,
            "error": self.error,
            "logs": list(self.logs),
        }


class Clean07BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], state: BridgeState):
        super().__init__(server_address, Clean07BridgeHandler)
        self.state = state


class Clean07BridgeHandler(BaseHTTPRequestHandler):
    server: Clean07BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self._send_empty(204)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "name": "Clean07 PJUD bridge",
                "summary": self.server.state.summary(),
            })
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self) -> None:
        if self.path.startswith("/start"):
            self._send_json(self.server.state.register_start(self._read_json()))
            return
        if self.path.startswith("/next"):
            self._send_json({"ok": True, "step": self.server.state.next_action()})
            return
        if self.path.startswith("/report"):
            self._send_json(self.server.state.report_action(self._read_json()))
            return
        if self.path.startswith("/log"):
            payload = self._read_json()
            message = str(payload.get("message") or "")
            self.server.state.add_log(message)
            print(f"CLEAN07[EXT]: {message}")
            self._send_json({"ok": True})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _send_empty(self, status: int) -> None:
        self.send_response(status)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


def build_bridge_state(
    planilla_path: str,
    mandatos_folder: str,
    contratos_folder: str,
    demandas_folder: str,
) -> BridgeState:
    """Validate every input and create the in-memory bridge session.

    Raises before the bridge exists, so a rejected planilla or a missing
    document never reaches the browser and the operator gets the exact cause
    in BotManager instead of a failure halfway through a real ingreso.
    """
    target = str(Path(planilla_path).expanduser().resolve())
    workbook = inspect_excel(target)
    rows = read_rows(target, workbook["sheet_name"], workbook["columns"])
    if not rows:
        raise InputError(
            "La planilla no tiene filas de datos bajo el encabezado.",
            reason="planilla_sin_filas",
            detail=workbook["filename"],
        )

    mandatos = inspect_mandatos_folder(mandatos_folder)
    contratos = inspect_contratos_folder(contratos_folder, rows)
    demandas = inspect_demandas_folder(demandas_folder, rows)

    return BridgeState(
        input_path=target,
        workbook=workbook,
        demandas=demandas,
        mandatos=mandatos,
        contratos=contratos,
        rows=rows,
    )


def run_bridge_session(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
    output_dir: str,
    log_every_seconds: int = 15,
) -> dict[str, Any]:
    """Serve the loopback bridge until the extension finishes the steps.

    The server must stay up after Start, because that is when the extension
    begins asking /next and working the portal. It returns as soon as the
    session reports itself finished, or once the extension has been silent for
    EXTENSION_IDLE_SECONDS (tab closed mid-run).
    """
    try:
        server = Clean07BridgeServer((host, port), state)
    except OSError as exc:
        raise InputError(
            f"No se pudo abrir el bridge local en {host}:{port}. "
            "Puede que otra ejecución de Clean07 siga abierta.",
            reason="bridge_ocupado",
            detail=str(exc),
        ) from exc

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"Clean07: bridge escuchando en http://{host}:{port}")
    # Output folder marker for the desktop run detail.
    print(f"[CLEAN07][SALIDA] {output_dir}")

    deadline = time.time() + timeout_seconds
    last_log = 0.0
    try:
        while time.time() < deadline:
            summary = state.summary()
            now = time.time()
            if summary["finished"]:
                return summary
            if summary["started"] and now - summary["extension_seen_at"] > EXTENSION_IDLE_SECONDS:
                # Start was registered but the extension went silent mid-run.
                # The handshake happened, so report what was completed instead
                # of hanging until the global timeout.
                state.add_log(
                    "La extensión dejó de responder tras Start; se cierra la "
                    f"sesión con {state.steps_done} paso(s) completado(s)."
                )
                return state.summary()
            if now - last_log >= log_every_seconds:
                seen = "si" if summary["extension_seen"] else "no"
                if summary["started"]:
                    print(
                        f"Clean07: en curso | fila={summary['rows_done'] + 1}"
                        f"/{summary['row_total']} pasos_ok={summary['steps_done']}"
                    )
                else:
                    print(f"Clean07: esperando Start | extension_conectada={seen}")
                last_log = now
            time.sleep(0.5)
        raise TimeoutError(
            "Clean07: timeout esperando la conexión de la extensión de Chrome."
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3.0)


def write_bridge_receipt(summary: dict[str, Any], output_dir: str) -> str:
    """Persist a small receipt proving that the desktop/extension bridge worked."""
    target = Path(output_dir) / "bridge_connection.json"
    payload = dict(summary)
    payload["receipt_created_at"] = time.time()
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(target)
