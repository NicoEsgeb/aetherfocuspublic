import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 10
    implicitHeight: childrenRect.height

    property color textMuted: Common.Theme.text2

    Common.BotInfoHeader {
        themeSource: Common.Theme
        Layout.fillWidth: true

        Rectangle {
            radius: 6
            color: Common.Theme.accentSoft
            border.width: 1
            border.color: "#36d7ff"
            implicitWidth: cleanBadge.implicitWidth + 16
            implicitHeight: cleanBadge.implicitHeight + 8
            Label {
                id: cleanBadge
                anchors.centerIn: parent
                text: "Clean BBRR"
                color: "#36d7ff"
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }

        Rectangle {
            radius: 6
            color: Common.Theme.successSoft
            border.width: 1
            border.color: Common.Theme.success
            implicitWidth: chromeBadge.implicitWidth + 16
            implicitHeight: chromeBadge.implicitHeight + 8
            Label {
                id: chromeBadge
                anchors.centerIn: parent
                text: "Chrome real"
                color: Common.Theme.success
                font.pixelSize: Common.Theme.fontSize(12)
                font.bold: true
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: aboutLayout.implicitHeight + 20

        ColumnLayout {
            id: aboutLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Qué hace este bot"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "Clean07 ingresa demandas en la Oficina Judicial Virtual desde tu propia sesión de Chrome. El usuario conserva el control del login: el bot valida las entradas, abre un bridge local y se enlaza con su extensión dentro del portal."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: inputsLayout.implicitHeight + 20

        ColumnLayout {
            id: inputsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Entradas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "1. input/demandas — carpeta fija con los PDF a ingresar (una subcarpeta por RUT más 03_Mandatos).\n" +
                      "2. Planilla de ingreso — se elige con «Seleccionar planilla»; el diálogo abre en input/planilla_ingreso. Es la salida de Clean06.\n\n" +
                      "Antes de abrir el navegador, Clean07 verifica que la planilla tenga todas las columnas requeridas, que tenga filas y que la carpeta de demandas contenga PDF. Si algo falla, el bridge no se abre y aparece una notificación con el detalle exacto."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: stepsLayout.implicitHeight + 20

        ColumnLayout {
            id: stepsLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Cómo probar la conexión"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "1. En Chrome, abre chrome://extensions, activa el modo desarrollador y carga bots/clean07_ingreso-demandas-bbrr/extension.\n" +
                      "2. Selecciona la planilla y pulsa Iniciar bot en BotManager.\n" +
                      "3. Abre https://oficinajudicialvirtual.pjud.cl e inicia sesión manualmente.\n" +
                      "4. En indexN.php, presiona Start en el panel Clean07.\n\n" +
                      "La prueba genera bridge_connection.json en la carpeta output del bot."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.warningSoft
        border.width: 1
        border.color: Common.Theme.warning
        implicitHeight: pendingLayout.implicitHeight + 20

        ColumnLayout {
            id: pendingLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 4

            Label {
                text: "Pendiente de definición"
                color: Common.Theme.warning
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
            }
            Label {
                text: "Esta primera etapa llega hasta confirmar la conexión con la extensión. La navegación dentro del portal y el ingreso de cada demanda se agregarán cuando esté definido el recorrido."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }
}
