# Clean 06 — Creación Planilla de Ingreso de Demandas

Especificación funcional. Escrita antes de codificar, a partir del par de archivos de
entrenamiento (`training/Asignaction_Final.xlsx` → `training/BOT.xlsx`) y de las
confirmaciones del cliente del 2026-08-06.

---

## 1. Qué hace el bot

Lee **una** planilla de Asignación Final (la matriz de salida de Clean 03, ya revisada por
un humano) y escribe **una** planilla nueva: la Planilla de Ingreso de Demandas que se usa
para subir los documentos al PJUD.

Es un bot **100% offline**: sólo Excel → Excel. No navega portales, no toca el disco fuera
de su carpeta de salida y **no verifica que los PDF existan**.

> **Importante:** las rutas y nombres de archivo que el bot escribe son *texto*, no
> referencias a archivos reales. El armado de las carpetas (`<RUT>\`, `03_Mandatos\`) y el
> copiado/renombrado de los PDF lo hace **el humano después**, a mano. El bot nunca revisa
> el disco.

---

## 2. Entrada

- Un archivo `.xlsx` seleccionado por el usuario mediante el botón **"Seleccionar Planilla"**,
  que abre la carpeta `input/` del bot.
- Encabezados en la fila 1, datos desde la fila 2.
- **Las columnas se ubican por nombre de encabezado, no por posición.** El esquema de Clean 03
  ha cambiado varias veces (28 → 29 → 30 → 31 → 32 columnas) y el archivo de entrenamiento
  tiene 30 columnas (`A–AD`), distinto del Clean 03 actual.

Columnas de entrada que el bot realmente usa:

| Encabezado | Uso |
|---|---|
| `RUT` | columna `B` de salida, y carpeta `<RUT>` de las rutas |
| `DV` | columna `C` de salida, y dígito verificador de la carpeta |
| `CARTERA_ORIGINAL` | determina el **nombre del archivo de pagaré** (con `RE → MP`) |
| `CARTERA_A_PROCESAR` | columna `D` de salida |
| `COD_CONTRATO` | número del archivo `6_CPSB_Rept_<cod>.pdf` |
| `PAGARE_FIRMADO_CLIENTE` | bandera de firma |
| `CONTRATO_MANDATO_FIRMADO_CLIENTE` | bandera de firma |
| `HOJA_DE_FIRMA` | bandera de firma |

El resto de las columnas de la matriz (`NOMBRE`, `OPERACIÓN`, montos, fechas, domicilio,
`NOTARIO`, `FECHA_PROTOCOLI`, …) **no se usan**.

---

## 3. Salida

- Nombre: **`Planilla_Ingreso_Demandas.xlsx`**, dentro de una carpeta por corrida:
  `output/Planilla_<dd.mm.aaaa_HH_MM_SS>/Planilla_Ingreso_Demandas.xlsx`.
  El nombre del archivo queda exactamente como lo pidió el cliente; la marca de tiempo
  vive en la carpeta.
- **Encabezados en la fila 1. Datos desde la fila 2.**
  Las filas 1 y 2 del archivo de entrenamiento (los rótulos `NOMBRES DE ARCHIVOS FISICOS` /
  `NOMBRES DE ARCHIVO EN PJUD` y la leyenda `1_Mandato-1` … `De columna C`) son anotaciones
  que el cliente agregó como guía. **No van en la salida.**
- **26 columnas, `A–Z`** — la columna `A` es `ESTADO`, agregada por el bot (§9); las 25
  restantes son las del archivo de entrenamiento, corridas una posición a la derecha.
- **El orden de las filas se conserva tal como viene de la entrada.** No se ordena ni se agrupa.

### Encabezados (texto literal, fila 1)

```
A  ESTADO                              N  7_HOJA_DE_FIRMA.pdf
B  RUT                                 O  DEMANDA
C  DV                                  P  PAGARES
D  CARTERA                             Q  MANDATO-1
E  ARCH_DEMANDA                        R  MANDATO-2
F  ARCH_PAGARES                        S  RESOLUCION
G  Contrato                            T  CERTIFICADO
H  1_Mandato_11709-2026.pdf            U  Pagare firmado cliente
I  2_Mandato_37590-2016.pdf            V  CONTRATO_MANDATO_FIRMADO_CLIENTE
J  3_Resolucion_409.pdf                W  HOJA_DE_FIRMA
K  4_Certificado_2215.pdf              X  MANDATO-5
L  5_Mandato_9342-2016.pdf             Y  CONTRATO
M  6_Contrato_CPSB                     Z  HOJA DE FIRMA
```

Nótese que los encabezados de `H–L` son el *nombre del archivo*, mientras que las celdas
debajo llevan la ruta completa `03_Mandatos\<nombre>`.

---

## 4. Modelo de filas

**Una fila de salida por cada fila de entrada.** En el entrenamiento: 49 filas → 49 filas.

Las filas se agrupan por RUT. Un RUT con varios pagarés ocupa varias filas consecutivas:

- **Primera fila del RUT ("fila completa")** — lleva todo: demanda, mandatos, contrato,
  hoja de firma y sus nombres PJUD.
- **Filas siguientes del mismo RUT ("filas de repetición")** — llevan **sólo** cuatro columnas
  de datos: `B RUT`, `C DV`, `D CARTERA`, `F ARCH_PAGARES`, `P PAGARES`. Todas las demás quedan
  vacías (salvo `A ESTADO`, que toda fila lleva).

Razón: la demanda, los mandatos, el contrato y la hoja de firma se suben **una vez por RUT**;
los pagarés son **uno por operación**.

Entrenamiento: 39 filas completas + 10 filas de repetición.

**Quién lleva el bloque cuando la primera fila es rechazada (§9).** Una fila rechazada no
escribe nada, así que **no puede quedarse con el bloque de documentos de su RUT**: lo lleva la
primera fila *utilizable* de ese RUT. Sin esta regla, un solo `CARTERA_A_PROCESAR` malo en la
primera fila dejaría al RUT completo sin demanda, sin mandatos y sin contrato, mientras sus
demás filas seguirían diciendo `OK` — un hueco invisible en la planilla. Si **todas** las filas
de un RUT son rechazadas, nadie lleva el bloque y todas quedan `PENDIENTE`, que es lo correcto.

---

## 5. Formato del RUT en las rutas

`RUT` + `DV` → `5.228.857-6` (puntos de miles, guion, DV).
El DV puede ser un dígito o la letra `K` (`7.127.196-K`).

En la **columna B** el RUT va sin puntos, tal cual viene de la entrada (`5228857`).

---

## 6. Las tres banderas de firma

Toda la lógica condicional depende de tres columnas de la entrada:

```
hoja            = (HOJA_DE_FIRMA                    == "SI")
mandato         = (CONTRATO_MANDATO_FIRMADO_CLIENTE == "SI")
pagare_firmado  = (PAGARE_FIRMADO_CLIENTE           == "SI")
```

**Confirmado por el cliente: en cada fila hay exactamente UNA de las tres en `SI`.**
Nunca dos, nunca ninguna.

Reglas derivadas (confirmadas por el cliente):

| Bloque | Condición | Columnas afectadas |
|---|---|---|
| Contrato | `hoja` → `Contrato.pdf` · `mandato` → `Contrato_Mandato.pdf` · ninguna → vacío | `G`, `Y` |
| Mandato-5 (9342) | `hoja` **o** `mandato` | `L`, `X` |
| Hoja de firma | `hoja` | `M`, `N`, `Z` |

El mandato **9342** se incluye cuando hay hoja de firma **o** contrato mandato, porque es la
*personería de los mandatarios del Banco* y respalda a **ambos**. Se omite cuando el pagaré
viene firmado por el cliente.

> Éste es exactamente el punto que falló dos veces en Clean 04. La condición es un **OR**
> independiente — no debe codificarse dentro del bloque de la hoja de firma.

---

## 7. Especificación columna por columna

`RUT_FMT` = RUT formateado (`5.228.857-6`). "Fila completa" = primera fila de cada RUT.

| Col | Encabezado | Valor | Cuándo se escribe |
|---|---|---|---|
| A | `ESTADO` | `OK` o `PENDIENTE` — ver §9 | toda fila |
| B | `RUT` | copia de `RUT` (sin puntos) | toda fila |
| C | `DV` | copia de `DV` | toda fila |
| D | `CARTERA` | copia de **`CARTERA_A_PROCESAR`** | toda fila |
| E | `ARCH_DEMANDA` | `<RUT_FMT>\Demanda.pdf` | fila completa |
| F | `ARCH_PAGARES` | `<RUT_FMT>\Pagare_<TIPO>[_N].pdf` — ver §8 | toda fila |
| G | `Contrato` | `<RUT_FMT>\Contrato.pdf` si `hoja`; `<RUT_FMT>\Contrato_Mandato.pdf` si `mandato` | fila completa, si `hoja` o `mandato` |
| H | `1_Mandato_11709-2026.pdf` | `03_Mandatos\1_Mandato_11709-2026.pdf` | fila completa, siempre |
| I | `2_Mandato_37590-2016.pdf` | `03_Mandatos\2_Mandato_37590-2016.pdf` | fila completa, siempre |
| J | `3_Resolucion_409.pdf` | `03_Mandatos\3_Resolucion_409.pdf` | fila completa, siempre |
| K | `4_Certificado_2215.pdf` | `03_Mandatos\4_Certificado_2215.pdf` | fila completa, siempre |
| L | `5_Mandato_9342-2016.pdf` | `03_Mandatos\5_Mandato_9342-2016.pdf` | fila completa, si `hoja` **o** `mandato` |
| M | `6_Contrato_CPSB` | `<RUT_FMT>\6_CPSB_Rept_<COD_CONTRATO>.pdf` | fila completa, si `hoja` |
| N | `7_HOJA_DE_FIRMA.pdf` | `<RUT_FMT>\7_HOJA_DE_FIRMA.pdf` | fila completa, si `hoja` |
| O | `DEMANDA` | literal `DEMANDA` | fila completa, siempre |
| P | `PAGARES` | nombre de archivo de `F`, sin la carpeta | toda fila |
| Q | `MANDATO-1` | literal `MANDATO-1` | fila completa, siempre |
| R | `MANDATO-2` | literal `MANDATO-2` | fila completa, siempre |
| S | `RESOLUCION` | literal `RESOLUCION` | fila completa, siempre |
| T | `CERTIFICADO` | literal `CERTIFICADO` | fila completa, siempre |
| U | `Pagare firmado cliente` | copia textual de `PAGARE_FIRMADO_CLIENTE` | fila completa |
| V | `CONTRATO_MANDATO_FIRMADO_CLIENTE` | copia textual de la columna homónima | fila completa |
| W | `HOJA_DE_FIRMA` | copia textual de `HOJA_DE_FIRMA` | fila completa |
| X | `MANDATO-5` | literal `MANDATO-5` | fila completa, si `hoja` **o** `mandato` |
| Y | `CONTRATO` | literal `CONTRATO` | fila completa, si `G` tiene valor |
| Z | `HOJA DE FIRMA` | literal `HOJA DE FIRMA` | fila completa, si `hoja` |

`U`, `V`, `W` se copian **tal cual**: vacío queda vacío, `NO` queda `NO`. No se normaliza.

---

## 8. Nombre del archivo de pagaré (columna F)

```
<RUT_FMT>\Pagare_<TIPO>.pdf          primer pagaré de ese tipo en ese RUT
<RUT_FMT>\Pagare_<TIPO>_2.pdf        segundo
<RUT_FMT>\Pagare_<TIPO>_3.pdf        tercero … sin límite
```

**`TIPO` sale de `CARTERA_ORIGINAL`, no de `CARTERA_A_PROCESAR`**, con una sola conversión:

```
MP → MP        LP → LP        TC → TC        RE → MP
```

Motivo: el nombre debe corresponder al **documento físico**. No existe un `PAGARE_RE` ni un
`PAGARE_VI` — una renegociación (`RE`) y una cartera *a la vista* (`VI`) usan igualmente el
archivo `PAGARE_MP` que produce Clean 02.

Consecuencia visible: en el caso `VI` la columna `D` dice `VI` mientras el archivo dice
`Pagare_MP.pdf`. **Es correcto que no coincidan.**

El contador es **por RUT y por tipo**, asignado en el orden en que las filas vienen en la
entrada. Confirmado por el cliente: **no hay máximo** — se han visto 6 o 7 pagarés del mismo
tipo en casos extremos.

Verificación sobre las 49 filas de entrenamiento: 0 discrepancias contra
`CARTERA_ORIGINAL (RE→MP)`, 1 discrepancia contra `CARTERA_A_PROCESAR`.

---

## 9. Columna ESTADO y colores

### Estado por fila

| Estado | Significado |
|---|---|
| `OK` | el bot pudo construir todas las celdas que correspondían a esa fila |
| `PENDIENTE` | faltó al menos un dato de entrada, o la fila cayó en un caso no previsto |

### Colores

| Caso | Pintado |
|---|---|
| Fila `OK` | **toda la fila en verde** — las 26 celdas, incluidas las que quedan vacías por ser fila de repetición |
| Fila `PENDIENTE` | **fila en blanco** (sin relleno), con dos excepciones: |
| ↳ celda `A ESTADO` | **amarilla** |
| ↳ celda o celdas que causan el problema | **amarillas** |

### Comentarios (obligatorios)

**Toda celda amarilla lleva un comentario de Excel explicando qué pasa.** No se pinta una
celda sin decir por qué.

- En la celda problemática: la causa concreta (`"Falta COD_CONTRATO en la matriz de entrada.
  No se puede construir el nombre 6_CPSB_Rept_<cod>.pdf."`).
- En la celda `ESTADO`: un resumen de todas las causas de esa fila, para que el usuario sepa
  qué revisar sin ir celda por celda.

La celda amarilla queda **vacía** — el bot no escribe `REVISAR` ni ningún marcador dentro.
El color y el comentario son la señal.

El bot **nunca inventa un valor**: la celda problemática queda marcada y la fila sigue en la
planilla. El resto de las filas se procesa normalmente — un problema en una fila no detiene
la corrida.

**El estado es por fila, independiente.** Si la primera fila de un RUT queda `PENDIENTE`, sus
filas de repetición pueden quedar `OK` — cada fila se evalúa sola.

### Casos que producen `PENDIENTE`

| Situación | Celdas amarillas | La fila se procesa |
|---|---|---|
| **`CARTERA_A_PROCESAR` no es `MP`, `LP`, `TC` ni `VI`** — vacía, `RE` sin resolver, o cualquier otro valor | `A`, `D` | **NO** — ver abajo |
| Falta `RUT` o `DV` | `A` + las que dependen del RUT: `E`, `F`, `G`, `M`, `N`, `P` | sí, parcialmente |
| `CARTERA_ORIGINAL` vacía o desconocida (no se puede nombrar el pagaré) | `A`, `F`, `P` | sí, parcialmente |
| `hoja = SI` pero `COD_CONTRATO` vacío | `A`, `M` | sí, parcialmente |
| Combinación de banderas distinta de "exactamente una en `SI`" | `A`, `G`, `L`, `X`, `Y` | sí, parcialmente |

### Fila rechazada por `CARTERA_A_PROCESAR`

`CARTERA_A_PROCESAR` es la columna que **resolvió una persona**. Si no trae uno de los cuatro
valores válidos, la fila **no se procesa**: el bot escribe únicamente `RUT`, `DV` y el valor
que encontró, marca `ESTADO = PENDIENTE` y pinta la celda `CARTERA` de amarillo. Todo el
resto de la fila queda vacío. `RE` sin resolver es sólo un caso más de esto — cualquier valor
inesperado recibe el mismo trato.

Dos consecuencias que el bot maneja explícitamente:

1. **El contador de pagarés igual avanza.** El pagaré físico existe aunque la fila se
   rechace, así que el siguiente pagaré del mismo RUT y tipo conserva su número
   (`_2`, `_3`, …). Si no avanzara, al corregir la matriz los archivos se renumerarían y
   chocarían entre sí.
2. **La fila rechazada no se queda con el bloque de documentos del RUT** — pasa a la primera
   fila utilizable (§4).

`CARTERA_A_PROCESAR` y `CARTERA_ORIGINAL` se validan por separado a propósito: la primera
alimenta la columna `CARTERA`, la segunda el nombre del archivo de pagaré (§8). Una puede
fallar sin la otra.

Un problema **estructural** (archivo inexistente, sin fila de encabezados, o falta una
columna obligatoria) NO produce pendientes: la corrida falla de inmediato con un mensaje
que nombra las columnas faltantes, igual que Clean 05.

La combinación de banderas es la salvaguarda importante: el cliente confirmó que siempre hay exactamente una
bandera en `SI`, pero si alguna vez llega un lote distinto, el bot **no adivina** — lo pone a
la vista.

---

## 10. Detalle del run (panel del escritorio)

El panel *Detalle del run* debe mostrar el resultado igual que los otros bots: totales y una
tabla de filas.

**Contenido:**

- Totales: filas procesadas, `OK`, `PENDIENTE`.
- Tabla de filas: N° de fila · RUT · CARTERA · ESTADO · causa (para las pendientes).
- Botón **`Abrir carpeta de salida`**, que abre la carpeta con timestamp donde quedó la
  planilla (mismo comportamiento que Clean 05).

**Restricción de implementación — importante:**

> El panel **debe** implementarse como un componente **QML que parsea el log**, igual que
> `Clean05Summary.qml` y `BotN03Summary.qml`, seleccionado como *fallback* en `Main.qml`.
>
> **NO** debe hacerse como un plugin Python en `app/desktop/bot_plugins/`. Ese código va
> congelado dentro del `.exe`, así que agregarlo obliga a una **reinstalación completa** del
> cliente en vez de una actualización de bot-pack.

Para eso el bot imprime marcadores estructurados en el log:

```
[CLEAN06][INICIO] archivo=<nombre> filas=<n>
[CLEAN06][PROGRESS] <i>/<n>
[CLEAN06][FILA] fila=<n> rut=<rut> cartera=<c> estado=OK|PENDIENTE causa=<texto>
[CLEAN06][RESUMEN] total=<n> ok=<n> pendiente=<n>
[CLEAN06][SALIDA] <ruta absoluta de la carpeta de salida>
```

La notificación de término se resuelve por el mismo camino QML (sin plugin congelado).

---

## 11. Confirmaciones del cliente (2026-08-06)

| # | Pregunta | Respuesta |
|---|---|---|
| 1 | ¿Puede haber más de una bandera de firma en `SI`? ¿O ninguna? | Siempre exactamente una |
| 2 | ¿El mandato 9342 va con hoja de firma **o** contrato mandato, y se omite con pagaré firmado? | Sí |
| 3 | ¿Hay un máximo de pagarés repetidos del mismo tipo? | No lo saben; han visto 6 o 7. Lo define el banco |
| 4 | Cuando `CARTERA_A_PROCESAR = VI`, ¿el archivo se llama `Pagare_VI.pdf`? | No — se llama `Pagare_MP.pdf` |
| 5 | ¿Los cinco documentos de `03_Mandatos` son fijos? | Sí, hardcodeados por ahora |
| 6 | ¿Orden de las filas? | El mismo de la entrada |
| 7 | ¿Nombre del archivo de salida? | `Planilla_Ingreso_Demandas` |

---

## 12. Puntos abiertos

- **`CARTERA_A_PROCESAR` inválida rechaza la fila, no la corrida.** Confirmado por Nico el
  2026-08-06: la fila queda sin procesar y en amarillo, y el resto de la planilla se genera
  igual. No se rechaza la corrida completa.
- **Los cinco documentos de `03_Mandatos` están hardcodeados.** El cliente confirmó que hoy
  son fijos, pero `1_Mandato_11709-2026` lleva el año en el nombre. Si el banco emite un
  mandato nuevo en 2027 hay que editar `functions.py` y volver a desplegar. Convertirlos en
  campos editables del panel es una mejora futura, no un pendiente actual.

---

## 13. Notas de verificación del archivo de entrenamiento

`training/BOT.xlsx` fue corregido varias veces durante la especificación. **Sus coordenadas de
columna son las viejas (`A–Y`, sin `ESTADO`)**; la salida del bot lleva todo corrido una
posición a la derecha.

Estado del archivo al cerrar la especificación:

- `M` corregida — ahora 33/39, coincide exactamente con `hoja`.
- **`K12` y `X12` quedaron desactualizadas**: siguen escritas en la fila del RUT
  `12.045.013-1` (`PAGARE_FIRMADO_CLIENTE = SI`), donde según la regla confirmada deben ir
  vacías. Una corrección anterior las había limpiado y un guardado posterior las restauró.
- **`O10` quedó desactualizada**: dice `Pagare_VI.pdf` mientras `E10` ya dice `Pagare_MP.pdf`.
  Como `PAGARES` se deriva de `ARCH_PAGARES`, el bot escribirá `Pagare_MP.pdf`.

**Al validar el bot contra este archivo, esas tres celdas darán diferencia. Es esperado:
la regla confirmada manda sobre el archivo.**

Conteos de referencia (39 filas completas, en coordenadas del archivo de entrenamiento):
`F` 38 · `K` 38 · `L` 33 · `M` 33 · `W` 38 · `X` 38 · `Y` 33 (según la regla confirmada).

---

## 14. Implementación

| Pieza | Archivo |
|---|---|
| Lógica de negocio | `functions.py` |
| Orquestación (delgada) | `tasks.py` |
| Registro del bot | `botmanager.json` (`clean06_crear_planilla_ingreso_demandas`) |
| Panel de información | `app/desktop/qml/workspace_info/clean06_crear_planilla_ingreso_demandas_information_bot_UI.qml` |
| Panel de tasks | `app/desktop/qml/workspace_tasks/clean06_crear_planilla_ingreso_demandas_tasks_bot_UI.qml` |
| Selector de planilla | `app/desktop/qml/workspace_tasks/clean06_crear_planilla_ingreso_demandas_task_crearUI.qml` |
| Detalle del run | `app/desktop/qml/run_summary/Clean06Summary.qml` + una rama en `Main.qml` |

### Decisiones que mantienen el bot en el carril bot-pack (sin reinstalación)

- **Sin `engine/`.** Toda la lógica vive en `functions.py`, así que `deploy-bot.sh` acepta
  este bot (rechaza los que tienen `engine/`, como Clean 03 y Clean 04).
- **Sin cambios en el core.** El panel envía la planilla como `matriz_input_path`, clave que
  `app/services/runners.py` **ya** mapea a la variable de entorno `MATRIZ_INPUT_PATH` (la
  usan Clean 03 y Clean 04). No hubo que tocar `runners.py`, que va congelado en el `.exe`.
- **Sin plugin Python.** El detalle del run es un parser QML del log, elegido como *fallback*
  en `Main.qml`. Un plugin en `app/desktop/bot_plugins/` habría forzado una reinstalación.

### Lectura del Excel de entrada

La planilla de entrada se parsea con `zipfile` + `ElementTree`, **no con openpyxl**. Los
archivos reales de Asignación Final traen celdas numéricas cuyo valor en caché es el literal
`NaN`, y openpyxl aborta el archivo completo con
`ValueError: invalid literal for int() with base 10: 'NaN'` antes de devolver una sola fila —
el propio archivo de entrenamiento lo reproduce. openpyxl sí se usa para **escribir**.

---

## 15. Validación ejecutada

| Prueba | Resultado |
|---|---|
| Salida vs `training/BOT.xlsx` (49 filas × 25 columnas) | **1.222 / 1.225 celdas idénticas** |
| Las 3 diferencias | exactamente las 3 celdas desactualizadas del §13 (`O10`, `K12`, `X12`) |
| Filas y RUTs | 49 filas de entrada → 49 filas de salida, 39 RUT, 10 filas de repetición |
| Casos `PENDIENTE` (planilla sintética de 15 filas) | los 8 casos previstos se marcan; los 7 válidos quedan OK |
| Fila rechazada por `CARTERA_A_PROCESAR` | escribe sólo `RUT`, `DV` y el valor inválido; el resto queda vacío |
| Fila mala **en medio** de un RUT | el contador salta correctamente a `Pagare_MP_3.pdf`; el bloque sigue en la primera fila |
| Fila mala **primera** de un RUT | el bloque de documentos pasa a la primera fila utilizable |
| **Todas** las filas de un RUT rechazadas | nadie lleva el bloque; todas quedan `PENDIENTE` |
| Contador de pagarés repetidos | verificado hasta `Pagare_MP_4.pdf` |
| Colores | fila OK = 26/26 celdas verdes y sin comentario; fila PENDIENTE = `ESTADO` + celdas problemáticas en amarillo |
| Comentarios | cada celda amarilla lleva su causa; `ESTADO` lleva el resumen de la fila |
| Lectura con `NaN` | el archivo de entrenamiento se lee completo (openpyxl falla en el mismo archivo) |
| `qmllint` | mismas clases de advertencia que los paneles existentes; ninguna nueva |
| Descubrimiento del bot | `tasks.py` + `robot.yaml` + `@task` presentes; ambos QML existen en la ruta declarada |
| Corrida punta a punta vía `tasks.py` | 49 filas, 49 OK, marcadores `INICIO`/`FILA`/`PROGRESS`/`RESUMEN`/`SALIDA` emitidos |
| `Clean06Summary.qml` con el log real | parsea 49/49 filas, totales correctos, botón de carpeta con la ruta correcta |
| Suite de tests del proyecto | 73 passed · 1 failed (`test_routes.py::test_home_page_loads_seeded_processes`, **falla igual sin este bot** — preexistente) |
