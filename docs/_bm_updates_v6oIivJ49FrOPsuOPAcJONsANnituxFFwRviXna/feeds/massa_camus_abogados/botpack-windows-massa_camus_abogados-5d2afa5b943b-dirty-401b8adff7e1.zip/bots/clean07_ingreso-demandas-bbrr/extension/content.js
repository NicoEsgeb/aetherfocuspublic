(() => {
  const MESSAGE_TYPE = "CLEAN07_BRIDGE_REQUEST";
  const PANEL_ID = "clean07-pjud-panel";
  // The N03 bot injects its own panel on the same PJUD origin, anchored to the
  // same corner. When both are loaded, Clean07 stacks itself above N03 instead
  // of covering it.
  const N03_PANEL_ID = "n03-pjud-panel";
  // Shown in the panel title. Reloading the extension does NOT re-inject this
  // script into tabs that are already open, so this marker is the way to tell
  // whether the page is running the current build or a stale one.
  const BUILD = "v0.1.0";
  // The page the operator is meant to press Start from. Start is accepted
  // anywhere on the portal; this only drives the hint text.
  const START_PAGE = "indexn.php";

  let connected = false;
  let starting = false;
  let verified = false;
  let workTimer = 0;
  let busy = false;
  // Set once the desktop confirms the session is done, so the panel shows a
  // friendly message instead of a scary "connection lost" when the bridge
  // server shuts down right after the handshake.
  let completed = false;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean07-title">Clean07 · Demandas BBRR · ${BUILD}</div>
      <div class="clean07-status" data-role="status">Esperando BotManager...</div>
      <div class="clean07-details" data-role="details">Planilla sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    positionPanel();
    return panel;
  }

  // Keep clear of the N03 panel when both extensions are enabled. Re-checked on
  // every poll because N03 injects asynchronously.
  function positionPanel() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) {
      return;
    }
    const other = document.getElementById(N03_PANEL_ID);
    const offset = other ? other.offsetHeight + 24 : 14;
    panel.style.bottom = `${offset}px`;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean07-ok", tone === "ok");
    status.classList.toggle("clean07-error", tone === "error");
  }

  function renderSummary(summary) {
    const details = createPanel().querySelector('[data-role="details"]');
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const demandas = summary && summary.demandas ? summary.demandas : {};
    if (!workbook.filename) {
      details.textContent = "Planilla sin confirmar";
      return;
    }
    const rows = summary && summary.row_total ? summary.row_total : 0;
    details.textContent = `${workbook.filename} · ${rows} fila(s) · `
      + `${demandas.pdf_count || 0} PDF(s) en demandas`;
  }

  function onStartPage() {
    return String(window.location.href || "").toLowerCase().includes(START_PAGE);
  }

  async function pumpWork() {
    if (!verified || busy || completed) {
      return;
    }
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};

      if (step.action === "wait") {
        return;
      }
      if (step.action === "done") {
        // Stage 1 ends here: the handshake is the whole job for now.
        completed = true;
        const message = step.message || "Conexión verificada con BotManager.";
        setStatus(`${message} Revisa el resultado en BotManager.`, "ok");
        logToBridge("La extension confirmo la conexion desde el portal PJUD.");
        window.clearInterval(workTimer);
        return;
      }
      // No step handlers yet: the PJUD navigation lands here in the next stage.
    } catch (_) {
      if (completed) {
        return; // finished cleanly; the server just shut down.
      }
      connected = false;
      setStatus("Se perdió la conexión con BotManager.", "error");
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    positionPanel();
    if (verified || starting || completed) {
      return;
    }
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      setStatus(
        onStartPage()
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Ve a indexN.php y presiona Start.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean07 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified) {
      return;
    }
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) {
        await bridgeRequest("/health");
      }
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title }
      });
      verified = true;
      renderSummary(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
