// Clean07 uses its own loopback port so it can run alongside N03 (8765) and
// Clean05 (8766) without either bridge answering the other's extension.
const BRIDGE_BASE_URL = "http://127.0.0.1:8768";
const MESSAGE_TYPE = "CLEAN07_BRIDGE_REQUEST";
const ALLOWED_PATHS = new Set(["/health", "/start", "/log", "/next"]);

async function bridgeRequest(path, options = {}) {
  if (!ALLOWED_PATHS.has(path)) {
    return { ok: false, error: `Ruta de bridge no permitida: ${path}` };
  }
  const response = await fetch(`${BRIDGE_BASE_URL}${path}`, {
    method: options.method || "GET",
    headers: { "Content-Type": "application/json" },
    body: Object.prototype.hasOwnProperty.call(options, "body")
      ? JSON.stringify(options.body)
      : undefined
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    return { ok: false, error: payload.error || `Bridge ${response.status}` };
  }
  return payload;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== MESSAGE_TYPE) {
    return false;
  }
  bridgeRequest(message.path || "/health", message.options || {})
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({
      ok: false,
      error: String(error && error.message ? error.message : error)
    }));
  return true;
});
