# Clean07 - Ingreso Demandas BBRR (extensión de Chrome)

Bot atendido para la Oficina Judicial Virtual (PJUD). El usuario mantiene el
control del login; el bot trabaja la página desde una extensión de Chrome
conectada a un bridge local.

## Entradas

1. **`input/demandas/`** (carpeta fija) — los PDFs a ingresar. La planilla los
   referencia con rutas relativas a esta carpeta (una subcarpeta por RUT más la
   carpeta compartida `03_Mandatos`). El panel de tareas sólo ofrece un botón
   para abrirla.
2. **La planilla de ingreso** (seleccionable) — se elige con **Seleccionar
   planilla**, que abre `input/planilla_ingreso/`. Es la salida de Clean06.

## Validación previa (antes de abrir el navegador)

Al presionar **Iniciar bot** Clean07 valida, en este orden:

1. que la planilla exista y sea `.xlsx` / `.xlsm`,
2. que tenga **todas** las columnas requeridas (se revisan todas y se informan
   todas las que falten, no sólo la primera),
3. que tenga al menos una fila de datos,
4. que `input/demandas/` exista y contenga al menos un PDF.

Si algo falla, el bridge **no** se abre y BotManager muestra una notificación
explicando la causa exacta. Recién cuando todo pasa se abre el bridge.

## Flujo de la primera etapa

1. BotManager valida las entradas y abre el bridge en `http://127.0.0.1:8768`.
2. El usuario abre Chrome e inicia sesión manualmente en la Oficina Judicial
   Virtual.
3. En `https://oficinajudicialvirtual.pjud.cl/indexN.php` el panel Clean07
   muestra `Bridge conectado`.
4. El usuario presiona **Start**: la conexión queda confirmada y el bot escribe
   `bridge_connection.json` en `output/Clean07_Demandas_<fecha>/`.

La navegación e ingreso de cada demanda se agregan en la siguiente etapa.

## Cargar la extensión en Chrome

Abre `chrome://extensions`, activa el **Modo de desarrollador**, elige **Cargar
descomprimida** y selecciona:

```text
bots/clean07_ingreso-demandas-bbrr/extension
```

Después de instalar o actualizar la extensión, recarga una vez la pestaña del
portal.

## Puertos de bridge en uso

| Bot | Puerto |
|-----|--------|
| N03 | 8765 |
| Clean05 (Emerix) | 8766 |
| **Clean07 (PJUD)** | **8768** |

Clean07 y N03 se inyectan en el mismo dominio PJUD; cuando ambos están
activos, el panel de Clean07 se ubica encima del de N03.
