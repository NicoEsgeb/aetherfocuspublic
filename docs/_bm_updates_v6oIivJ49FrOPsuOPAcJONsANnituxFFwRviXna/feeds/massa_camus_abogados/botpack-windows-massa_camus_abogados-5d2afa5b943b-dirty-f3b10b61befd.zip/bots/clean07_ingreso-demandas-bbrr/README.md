# Clean07 - Ingreso Demandas BBRR (extensión de Chrome)

Bot atendido para la Oficina Judicial Virtual (PJUD). El usuario mantiene el
control del login; el bot trabaja la página desde una extensión de Chrome
conectada a un bridge local.

## Entradas

Cuatro carpetas fijas, cada una con su propio botón "Abrir carpeta" en el panel
de tareas:

1. **`input/01_mandatos/`** — los 5 documentos compartidos, iguales en toda
   corrida (mandato, resolución, certificado — no varían por RUT):
   `1_Mandato_11709-2026.pdf`, `2_Mandato_37590-2016.pdf`,
   `3_Resolucion_409.pdf`, `4_Certificado_2215.pdf`,
   `5_Mandato_9342-2016.pdf`.
2. **`input/02_contratos/`** — los contratos que la planilla referencia por
   fila en la columna `6_Contrato_CPSB` (valor tipo `<RUT-DV>\<archivo>.pdf`;
   sólo importa el nombre de archivo, todos los contratos viven sueltos en
   esta carpeta, no en subcarpetas por RUT).
3. **`input/03_demandas/`** — una subcarpeta por RUT con los PDF de cada
   demanda (`ARCH_DEMANDA`, `ARCH_PAGARES`, etc.). Es la antigua
   `input/demandas/`, renombrada.
4. **La planilla de ingreso** (seleccionable) — se elige con **Seleccionar
   planilla**, que abre `input/planilla_ingreso/`. Es la salida de Clean06.

## Validación previa (antes de abrir el navegador)

Al presionar **Iniciar bot** Clean07 valida, en este orden:

1. que la planilla exista y sea `.xlsx` / `.xlsm`,
2. que tenga **todas** las columnas requeridas (se revisan todas y se informan
   todas las que falten, no sólo la primera),
3. que tenga al menos una fila de datos,
4. que `input/01_mandatos/` contenga los 5 documentos fijos exactos — si falta
   uno solo, el bot no inicia,
5. que `input/02_contratos/` contenga todos los contratos que la planilla
   referencia (columna `6_Contrato_CPSB`) — si falta alguno de los que la
   planilla necesita, el bot no inicia,
6. que `input/03_demandas/` contenga al menos una subcarpeta cuyo nombre
   coincida con algún RUT de la planilla (chequeo liviano de que se copió el
   lote correcto; no exige que estén TODOS los RUT).

Si algo falla, el bridge **no** se abre y BotManager muestra una notificación
explicando la causa exacta. Recién cuando todo pasa se abre el bridge.

## Flujo

1. BotManager valida las entradas y abre el bridge en `http://127.0.0.1:8768`.
2. El usuario abre Chrome e inicia sesión manualmente en la Oficina Judicial
   Virtual.
3. En `https://oficinajudicialvirtual.pjud.cl/indexN.php` el panel Clean07
   muestra `Bridge conectado`.
4. El usuario presiona **Start** y la extensión empieza a trabajar el portal
   ejecutando primero `PREP_STEPS` (`functions.py`) una sola vez, y luego
   `LOOP_STEPS` una vez por fila.
5. Al terminar el último paso definido el panel queda en verde con
   `Bot ha finalizado correctamente en Step N` y el bot escribe
   `bridge_connection.json` en `output/Clean07_Demandas_<fecha>/`.

## Pasos implementados

### `PREP_STEPS` — una sola vez por sesión

| # | Nombre | Qué hace en el portal |
|---|--------|------------------------|
| 1 | `click_ingresar_demanda` | Click en el menú izquierdo **Ingresar Demanda/Recurso** |
| 2 | `select_competencia` | Competencia = **Civil** |
| 3 | `select_corte` | Corte = **C.A. de Santiago** |
| 4 | `select_tribunal` | Tribunal = **Dist. Corte Santiago** |
| 5 | `ensure_dirigido_a` | Verifica que Dirigido a sea **JOAQUÍN MAURICIO CARRILLO MORENO** |
| 6 | `click_fijar_datos` | Marca **Fijar Datos** para que el bloque de tribunal quede fijo en el siguiente ingreso |
| 7 | `select_procedimiento` | Procedimiento = **Ejecutivo** (tarjeta «Ingreso de Demanda») |
| 8 | `select_materia` | Materia = **Pagaré, cobro de** |
| 9 | `click_fijar_datos_materia` | Marca el **Fijar Datos** de la tarjeta «Ingreso de Demanda» |
| 10 | `click_agregar_materia` | Click en **Agregar** — suma la materia a `listaMateriasCausa` y abre la sección de litigantes |
| 11 | `select_tipo_sujeto` | Primer litigante: Tipo Sujeto = **DTE.** (el demandante, Banco Itaú) |
| 12 | `fill_rut` | Rut del demandante = **97.023.000-9**, tipeado carácter a carácter para que la máscara del portal lo formatee |
| 13 | `await_litigante_lookup` | Espera la búsqueda automática del RUT: Tipo Persona = **JURIDICA**, Razón Social = **BANCO ITAÚ CHILE (O ITAÚ CORPBANCA)** |
| 14 | `edit_razon_social` | Corrige Razón Social al nombre corto que pide el cliente: **BANCO ITAÚ CHILE** |
| 15 | `click_fijar_datos_litigante` | Marca el **Fijar Datos** de la tarjeta del litigante |
| 16 | `click_agregar_litigante` | Click en **Agregar Litigante** — confirma el primer litigante y abre uno nuevo, vacío |
| 17 | `select_tipo_sujeto_abogado` | Segundo litigante: Tipo Sujeto = **AB.DTE.** (abogado patrocinante) |
| 18 | `fill_rut_abogado` | Rut del abogado = **11.346.197-7** (mismo que Dirigido a) |
| 19 | `await_abogado_lookup` | Espera la búsqueda automática: Tipo Persona = **NATURAL**, Nombres/Primer apellido/Segundo apellido = **JOAQUÍN MAURICIO / CARRILLO / MORENO** |
| 20 | `click_agregar_litigante` | Mismo botón que el paso 16 — confirma el segundo litigante |

### `LOOP_STEPS` — una vez por fila, después de `PREP_STEPS`

| # | Nombre | Qué hace en el portal |
|---|--------|------------------------|
| 1 | `select_tipo_sujeto_ddo` | Tercer litigante (por fila): Tipo Sujeto = **DDO.** (el demandado de esta fila) |

La comparación de opciones es **exacta** (tras plegar mayúsculas y acentos), así que
una opción vecina nunca puede elegirse por error. A cambio, un valor mal escrito
simplemente falla — y cuando falla, el error **lista las opciones que ofreció el
portal**, para corregir el valor de una sola vez en vez de adivinar.

«Agregar» tampoco tiene id estable — se ubica igual que los campos, por su binding
de Knockout (`agregarMateria`). Queda deshabilitado hasta que el formulario marca
`valid` (materia elegida), así que el paso espera eso antes de hacer click; y el
resultado se confirma contando los hijos de `listaMateriasCausa` antes/después
(no basta con que el click se haya disparado — hay que ver que sumó una fila).

**Ojo con los ids de select2.** Corte y Tribunal decoran un `<div>` que SÍ trae id
(`select-asientoCorte`, `select-tribunales`), así que select2 les arma un contenedor
estable `s2id_select-*`. **Procedimiento no tiene id**: su div sólo trae el binding
`value: procedimientoSeleccionado`, y select2 le autogenera `s2id_autogenN` — un
número que cambia entre renders (su contenedor era 171 y su focusser 172). Por eso
ese campo se resuelve por su **binding de Knockout** y no por id
(`findSelect2ContainerByBinding`); el contenedor es el hermano ANTERIOR del div
enlazado. Cualquier campo nuevo sin id se agrega igual.

**Hay dos "Fijar Datos" distintos**: `id_check_fijar_mod_tribunal` (bloque de
tribunal, paso 6) y `id_check_fijar_mod_materia` (tarjeta de Ingreso de Demanda,
paso 8). Los dos muestran exactamente el texto "Fijar Datos", así que **nunca**
los busques por label — el id es lo único que los distingue. Por eso el id viaja
como `value` desde `STEP_VALUES` y un solo handler atiende ambos pasos.

Los valores viven en `STEP_VALUES` (`functions.py`), no en la extensión: el día que
la Corte deba salir de la planilla (clean03 trae `REGION_DEUDOR`) sólo cambia ese lado.

**Competencia no es select2**: es un `<select>` nativo de Knockout cuyas `<option>`
tienen todas `value=""`. Hay que elegir por índice y disparar `change` a mano, o
Knockout nunca se entera. Los otros tres sí son **select2 v3**, que comparte UN
único `#select2-drop` para todos los campos (por eso se abre el control primero y
recién después se lee el drop) y que selecciona con **mouseup**, no con click.
Cada paso relee el valor elegido antes de continuar.

El recorrido se construye paso a paso. Para agregar el siguiente: añade su
nombre a `PREP_STEPS` (si corre una sola vez) o `LOOP_STEPS` (si repite por
fila) en `functions.py`, y su handler con el mismo nombre en `STEP_HANDLERS`
dentro de `extension/content.js` — no hace falta tocar nada más.

Mientras `LOOP_STEPS` esté incompleto, `HALT_AFTER_FIRST_ROW = True` detiene la
corrida después de `PREP_STEPS` + una vuelta completa de `LOOP_STEPS`, para
poder mirar una fila limpia en vez de repetir un flujo parcial en cada fila.
Cámbialo a `False` cuando `LOOP_STEPS` ingrese una demanda de principio a fin.

Un paso que falla **detiene la corrida**: todavía no existe una ruta de
recuperación en PJUD, y si un paso falló la página no está donde el bot cree,
así que seguir a ciegas podría ingresar en una causa equivocada.

## Cargar la extensión en Chrome

Abre `chrome://extensions`, activa el **Modo de desarrollador**, elige **Cargar
descomprimida** y selecciona:

```text
bots/clean07_ingreso-demandas-bbrr/extension
```

Después de instalar o actualizar la extensión, recarga una vez la pestaña del
portal.

## Puertos de bridge en uso

| Bot | Puerto |
|-----|--------|
| N03 | 8765 |
| Clean05 (Emerix) | 8766 |
| **Clean07 (PJUD)** | **8768** |

Clean07 y N03 se inyectan en el mismo dominio PJUD; cuando ambos están
activos, el panel de Clean07 se ubica encima del de N03.
