import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Step-by-step "Cómo instalar Tesseract" card for the bots that shell out to the
// Tesseract OCR binary (clean02, clean03).
//
// WHY this lives in QML and not in app/services/external_dependencies.py: that
// module is frozen inside the core .exe, so its INSTRUCTIONS text can only change
// with a core rebuild + reinstall. Everything under app/desktop/qml/ ships in a
// normal bot pack, so the instructions a client actually reads are kept HERE and
// can be corrected at any time.
//
// The installer ships the Spanish model (tools/tessdata/spa.traineddata, exported
// as TESSDATA_PREFIX by ci/shell_entry.py) but NOT the Tesseract binary itself --
// that stays a machine prerequisite. Hence this card.
Rectangle {
    id: root

    // True when the app's dependency probe could not find tesseract on this
    // machine. Drives the tone and makes the card open itself, so a blocked user
    // lands on the steps instead of on a collapsed header.
    property bool missing: false
    property bool expanded: missing

    readonly property string wingetCommand:
        "winget install -e --id UB-Mannheim.TesseractOCR --accept-package-agreements --accept-source-agreements"
    readonly property string brewCommand: "brew install tesseract tesseract-lang"

    readonly property color toneColor: missing ? Theme.warning : Theme.accent

    width: parent ? parent.width : implicitWidth
    implicitHeight: guideColumn.implicitHeight + 22
    radius: Theme.radiusInner
    color: missing ? Qt.alpha(Theme.warning, 0.10) : Theme.panel2
    border.width: 1
    border.color: missing ? Qt.alpha(Theme.warning, 0.55) : Theme.line
    clip: true

    // Off-screen editor used purely as a clipboard bridge: QML has no direct
    // clipboard API, but TextEdit.copy() writes the current selection to it.
    TextEdit {
        id: clipboardBridge
        visible: false
        width: 0
        height: 0
    }

    function copyToClipboard(value) {
        clipboardBridge.text = String(value)
        clipboardBridge.selectAll()
        clipboardBridge.copy()
        clipboardBridge.deselect()
    }

    ColumnLayout {
        id: guideColumn
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 11
        spacing: root.expanded ? 12 : 0

        InsetAlloyButton {
            id: headerButton
            alloyTone: root.missing ? "warning" : "primary"
            Layout.fillWidth: true
            implicitHeight: 32
            text: "Cómo instalar Tesseract"
            hoverEnabled: true
            onClicked: root.expanded = !root.expanded

            background: Rectangle {
                radius: Theme.radiusInner
                color: headerButton.hovered ? Qt.alpha(root.toneColor, 0.16) : "transparent"
            }

            contentItem: RowLayout {
                spacing: 9

                Label {
                    text: root.missing ? "!" : "?"
                    color: root.toneColor
                    font.pixelSize: Theme.fontSize(16)
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    Layout.preferredWidth: 18
                }

                Label {
                    text: headerButton.text
                    color: root.toneColor
                    font.pixelSize: Theme.fontSize(13)
                    font.weight: Font.DemiBold
                    elide: Text.ElideRight
                    Layout.fillWidth: true
                }

                Label {
                    text: root.missing ? "FALTA EN ESTE EQUIPO" : "INSTALADO"
                    color: root.missing ? Theme.warning : Theme.success
                    font.pixelSize: Theme.fontSize(10)
                    font.weight: Font.DemiBold
                }

                Label {
                    text: root.expanded ? "^" : "v"
                    color: root.toneColor
                    font.pixelSize: Theme.fontSize(15)
                }
            }
        }

        ColumnLayout {
            visible: root.expanded
            Layout.fillWidth: true
            spacing: 10

            Label {
                text: "Este bot lee PDF escaneados con Tesseract, un programa gratuito que "
                    + "debe estar instalado en el computador. Se instala UNA sola vez. "
                    + "El idioma español ya viene incluido en BotManager: no tienes que "
                    + "descargarlo ni marcar ninguna opción de idioma."
                color: Theme.text2
                font.pixelSize: Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }

            // ---------------- Windows ----------------
            Label {
                text: "Windows"
                color: Theme.text
                font.pixelSize: Theme.fontSize(13)
                font.weight: Font.DemiBold
                Layout.fillWidth: true
            }

            Repeater {
                model: [
                    "Cierra BotManager por completo.",
                    "Aprieta la tecla Windows, escribe  cmd  y abre \"Símbolo del sistema\".",
                    "Copia el comando de abajo, pégalo en la ventana negra y aprieta Enter.",
                    "Espera a que termine (1 a 2 minutos) y cierra la ventana negra.",
                    "Vuelve a abrir BotManager y ejecuta el bot de nuevo."
                ]

                delegate: RowLayout {
                    id: winStepRow
                    required property int index
                    required property string modelData
                    Layout.fillWidth: true
                    spacing: 8

                    Label {
                        text: String(winStepRow.index + 1) + "."
                        color: root.toneColor
                        font.pixelSize: Theme.fontSize(12)
                        font.weight: Font.DemiBold
                        Layout.preferredWidth: 18
                        horizontalAlignment: Text.AlignRight
                        verticalAlignment: Text.AlignTop
                    }

                    Label {
                        text: winStepRow.modelData
                        color: Theme.text2
                        font.pixelSize: Theme.fontSize(12)
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                    }
                }
            }

            CommandBox {
                Layout.fillWidth: true
                command: root.wingetCommand
                toneColor: root.toneColor
                onCopyRequested: root.copyToClipboard(root.wingetCommand)
            }

            Label {
                text: "No necesitas permisos de administrador. Si aparece \"winget no se "
                    + "reconoce\", este Windows no tiene el Instalador de aplicaciones: "
                    + "usa el botón de descarga oficial de más abajo e instálalo a mano."
                color: Theme.text3
                font.pixelSize: Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 1
                color: Theme.lineSoft
            }

            // ---------------- macOS ----------------
            Label {
                text: "Mac"
                color: Theme.text
                font.pixelSize: Theme.fontSize(13)
                font.weight: Font.DemiBold
                Layout.fillWidth: true
            }

            Repeater {
                model: [
                    "Cierra BotManager por completo.",
                    "Abre la aplicación \"Terminal\" (Cmd + Espacio, escribe Terminal).",
                    "Copia el comando de abajo, pégalo en la Terminal y aprieta Enter.",
                    "Vuelve a abrir BotManager y ejecuta el bot de nuevo."
                ]

                delegate: RowLayout {
                    id: macStepRow
                    required property int index
                    required property string modelData
                    Layout.fillWidth: true
                    spacing: 8

                    Label {
                        text: String(macStepRow.index + 1) + "."
                        color: root.toneColor
                        font.pixelSize: Theme.fontSize(12)
                        font.weight: Font.DemiBold
                        Layout.preferredWidth: 18
                        horizontalAlignment: Text.AlignRight
                        verticalAlignment: Text.AlignTop
                    }

                    Label {
                        text: macStepRow.modelData
                        color: Theme.text2
                        font.pixelSize: Theme.fontSize(12)
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                    }
                }
            }

            CommandBox {
                Layout.fillWidth: true
                command: root.brewCommand
                toneColor: root.toneColor
                onCopyRequested: root.copyToClipboard(root.brewCommand)
            }

            Label {
                text: "Requiere Homebrew (brew.sh). En Mac conviene instalar también "
                    + "tesseract-lang, que trae el español."
                color: Theme.text3
                font.pixelSize: Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }

            InsetAlloyButton {
                id: downloadButton
                alloyTone: root.missing ? "warning" : "primary"
                text: "Abrir descarga oficial de Tesseract"
                implicitHeight: 30
                onClicked: Qt.openUrlExternally(
                    "https://github.com/UB-Mannheim/tesseract/wiki")

                background: Rectangle {
                    radius: Theme.radiusInner
                    color: downloadButton.hovered ? Qt.alpha(root.toneColor, 0.20) : "transparent"
                    border.width: 1
                    border.color: root.toneColor
                }

                contentItem: Label {
                    text: downloadButton.text
                    color: root.toneColor
                    font.pixelSize: Theme.fontSize(12)
                    font.weight: Font.DemiBold
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: 12
                    rightPadding: 12
                }
            }
        }
    }
}
