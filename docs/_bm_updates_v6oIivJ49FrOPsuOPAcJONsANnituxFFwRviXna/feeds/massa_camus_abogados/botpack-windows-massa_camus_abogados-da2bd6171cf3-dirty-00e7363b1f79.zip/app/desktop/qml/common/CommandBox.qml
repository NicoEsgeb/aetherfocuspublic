import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// A terminal command shown so a non-technical user can copy it exactly: monospace,
// selectable (read-only, so it cannot be edited into something broken) and with a
// one-click "Copiar" button. Used by TesseractInstallGuide.
Rectangle {
    id: root

    property string command: ""
    property color toneColor: Theme.accent

    signal copyRequested()

    // Reset by the caller's next copy; drives the transient "Copiado" label.
    property bool justCopied: false

    implicitHeight: boxRow.implicitHeight + 16
    radius: Theme.radiusInner
    color: Theme.isDark ? Qt.darker(Theme.panel, 1.25) : Theme.panel2
    border.width: 1
    border.color: Theme.line

    Timer {
        id: copiedTimer
        interval: 1800
        onTriggered: root.justCopied = false
    }

    RowLayout {
        id: boxRow
        anchors.fill: parent
        anchors.margins: 8
        spacing: 8

        TextEdit {
            id: commandText
            text: root.command
            Layout.fillWidth: true
            readOnly: true
            selectByMouse: true
            wrapMode: TextEdit.WrapAnywhere
            color: Theme.text
            selectionColor: Qt.alpha(root.toneColor, 0.35)
            selectedTextColor: Theme.text
            font.family: "Courier New"
            font.pixelSize: Theme.fontSize(11)
        }

        InsetAlloyButton {
            id: copyButton
            text: root.justCopied ? "Copiado" : "Copiar"
            implicitHeight: 26
            implicitWidth: 78
            Layout.alignment: Qt.AlignTop
            onClicked: {
                root.copyRequested()
                root.justCopied = true
                copiedTimer.restart()
            }

            background: Rectangle {
                radius: Theme.radiusInner
                color: copyButton.hovered ? Qt.alpha(root.toneColor, 0.20) : "transparent"
                border.width: 1
                border.color: root.justCopied ? Theme.success : root.toneColor
            }

            contentItem: Label {
                text: copyButton.text
                color: root.justCopied ? Theme.success : root.toneColor
                font.pixelSize: Theme.fontSize(11)
                font.weight: Font.DemiBold
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }
    }
}
