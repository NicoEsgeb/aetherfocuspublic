"""
RPA01 NEW - Ingreso de Escritos
================================
This bot is the Clean BBRR version of rpa01_ingreso-escritos.

Architecture (Path A):
  - shared/ojv_portal    -> OJV login URL navigation (Envio / Compare only)
  - shared/artifacts     -> Artifact snapshot and move
  - shared/output_dirs   -> Timestamped output directory creation
  - bridge.py            -> Attended Chrome-extension bridge (Ingreso)
  - functions.py         -> Business logic (Excel parsing, form filling)

RPA_01_Ingreso is ATTENDED
--------------------------
PJUD's WAF blocks the automated browser this task used to drive, so it no
longer drives one. The operator logs into the Oficina Judicial Virtual in their
OWN Chrome and presses Start on the RPA01 extension panel; this task validates
the inputs, opens a loopback bridge on 127.0.0.1:8767 and feeds the extension
one step at a time. No credentials live in this task any more.

RPA_01_Envio and RPA_01_Compare_results still use the old driven browser and
are subject to the same WAF block — they have not been ported yet.

tasks.py stays THIN: it sets up context and orchestrates calls to shared/,
bridge.py and functions.py. No business logic lives here.
"""
from __future__ import annotations

import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Enable imports from bots/shared/ and from this bot's own modules
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).parent.parent))
# The bot's OWN dir, so bridge.py can `from functions import ...` regardless of
# how the interpreter was started.
sys.path.insert(0, str(Path(__file__).parent))

# ---------------------------------------------------------------------------
# Shared infrastructure
# ---------------------------------------------------------------------------
from shared.ojv_portal import goto_ojv_login_with_browser, goto_ojv_login_with_driver
from shared.pjud_credentials import get_pjud_credentials
from shared.artifacts import (
    snapshot_output_artifacts,
    move_updated_artifacts_to_run_dir,
    register_pending_artifact_move,
)
from shared.output_dirs import create_ingreso_output_dir

# ---------------------------------------------------------------------------
# Standard library / third-party
# ---------------------------------------------------------------------------
from robocorp import browser
from robocorp.tasks import task
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import os
import shutil
import openpyxl
from openpyxl.styles import PatternFill
import time
from datetime import datetime

# ---------------------------------------------------------------------------
# Bot-specific business logic
# ---------------------------------------------------------------------------
from functions import (
    FIJAR_DATOS_MODE,
    VERIFY_TRIBUNAL,
    compare_results,
    read_excel_envio,
)
from bridge import (
    DEFAULT_BRIDGE_PORT,
    InputError,
    build_bridge_state,
    build_result_summary_json,
    build_result_tally,
    run_bridge_session,
    write_bridge_receipt,
    write_preingreso_results,
)

# ---------------------------------------------------------------------------
# Path and environment configuration
# ---------------------------------------------------------------------------
BOT_DIR = Path(__file__).resolve().parent
INPUT_DIR = BOT_DIR / "input"
PROCESSING_DIR = BOT_DIR / "processing"
OUTPUT_DIR = BOT_DIR / "output"

PATH_BOT = str(BOT_DIR)
EXCEL_FILE_NAME = os.getenv("MATRIZ_ESCRITOS_PATH", str(INPUT_DIR / "planillas" / "planilla_escritos.xlsx"))
ESCRITOS_DCP_PATH = os.getenv("ESCRITOS_FOLDER_PATH", str(INPUT_DIR / "escritos"))
ROLES_DONE = []
PJUD_USERNAME, PJUD_PASSWORD, PJUD_PROFILE_LABEL = get_pjud_credentials()

# --- Attended bridge (Ingreso only) ---------------------------------------
RPA01_BRIDGE_HOST = os.getenv("RPA01_BRIDGE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    RPA01_BRIDGE_PORT = max(1, min(65535, int(os.getenv("RPA01_BRIDGE_PORT", str(DEFAULT_BRIDGE_PORT)))))
except ValueError:
    RPA01_BRIDGE_PORT = DEFAULT_BRIDGE_PORT
try:
    RPA01_TIMEOUT_MINUTES = max(5, int(os.getenv("RPA01_TIMEOUT_MINUTES", "120")))
except ValueError:
    RPA01_TIMEOUT_MINUTES = 120


def _require_existing_path(path_value: str, description: str, *, expect_directory: bool = False) -> Path:
    candidate = Path(path_value).expanduser()
    exists = candidate.is_dir() if expect_directory else candidate.is_file()
    if exists:
        return candidate

    expected_kind = "carpeta" if expect_directory else "archivo"
    env_var = "ESCRITOS_FOLDER_PATH" if expect_directory else "MATRIZ_ESCRITOS_PATH"
    raise FileNotFoundError(
        f"{description} no existe ({expected_kind}): '{candidate}'. "
        f"Selecciona la ruta correcta en la UI o define {env_var}."
    )


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

@task
def Prueba():
    print("Prueba de que funciona robocorp")


@task
def RPA_01_Ingreso():
    """
    RPA 01 NEW - Ingreso de escritos de pago garantia estatal en poder judicial.

    ATENDIDA. El operador inicia sesion a mano en su PROPIO Chrome y presiona
    Start en el panel de la extension RPA01. Esta task valida las entradas,
    abre el bridge local y le entrega un paso a la vez. No abre ningun
    navegador ni usa credenciales.
    """
    excel_file = _require_existing_path(EXCEL_FILE_NAME, "La planilla de escritos")
    escritos_folder = _require_existing_path(
        ESCRITOS_DCP_PATH,
        "La carpeta de escritos",
        expect_directory=True,
    )
    documentos_firmados = os.getenv("DOCUMENTOS_FIRMADOS", "") == "1"

    # Validate before creating the run folder so a rejected input leaves no
    # empty evidence directory behind.
    try:
        state = build_bridge_state(
            str(excel_file),
            str(escritos_folder),
            documentos_firmados=documentos_firmados,
            verify_tribunal=VERIFY_TRIBUNAL,
            fijar_datos=(FIJAR_DATOS_MODE == "on"),
        )
    except InputError as exc:
        print("=" * 72)
        print("RPA01: NO SE PUEDE INICIAR CON LAS ENTRADAS ACTUALES")
        print(f"  {exc}")
        if exc.detail:
            print(f"  Detalle: {exc.detail}")
        print("=" * 72)
        # Structured markers consumed by the desktop to build the notification.
        # Keep the format stable.
        print(f"[RPA01][ENTRADA_INVALIDA] {exc}")
        print(f"[RPA01][ENTRADA_MOTIVO] {exc.reason}")
        if exc.detail:
            print(f"[RPA01][ENTRADA_DETALLE] {exc.detail}")
        raise

    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    artifact_snapshot = snapshot_output_artifacts(output_root)
    task_started_at = datetime.now()
    ingreso_output_dir = create_ingreso_output_dir(PATH_BOT, task_started_at)

    # This run's own copy of the planilla. The SOURCE keeps the run re-runnable
    # (OK / REVISAR_MANUAL rows are never reprocessed); the copy is evidence of
    # what this particular run did.
    output_copy = Path(ingreso_output_dir) / f"output_{excel_file.name}"
    shutil.copy2(str(excel_file), str(output_copy))

    missing = state.escritos.get("missing", [])
    print("=" * 72)
    print("RPA_01_Ingreso (atendida)")
    print(f"  Planilla: {excel_file}")
    print(f"  Hoja de datos: {state.sheet_name}")
    print(f"  Filas con ROL: {len(state.rows)}")
    print(f"  Carpeta escritos: {escritos_folder}")
    print(f"  PDFs resueltos: {state.escritos['pdf_count']} de {len(state.rows)} fila(s)")
    print(f"  Documentos firmados: {'si' if documentos_firmados else 'no'}")
    print(f"  Extension Chrome: {Path(PATH_BOT) / 'extension'}")
    print(f"  Bridge: http://{RPA01_BRIDGE_HOST}:{RPA01_BRIDGE_PORT}")
    print(f"  Evidencia: {ingreso_output_dir}")
    print("")
    print("Pasos:")
    print("  1. Abre Chrome e inicia sesion manualmente en la Oficina Judicial Virtual.")
    print("  2. Ve a Tramite Facil (ojv.pjud.cl/kpitec-ojv-web).")
    print("  3. Presiona Start en el panel RPA01 y deja la pestana visible.")
    print("=" * 72)
    print(f"[RPA01][ARCHIVO] {excel_file.name}")
    # Printed BEFORE the bridge opens: these rows never reach the portal, so
    # this is the operator's chance to fix the folder first.
    if missing:
        print(f"[RPA01][PDFS_FALTANTES] {len(missing)}")
        for _, filename in missing[:20]:
            print(f"[RPA01][PDF_FALTANTE] {filename}")
        if len(missing) > 20:
            print(f"[RPA01][PDF_FALTANTE] ... y {len(missing) - 20} mas")

    # Write the audit trail BEFORE anything touches the portal: every row of
    # the planilla with the status it starts from. run_bridge_session refreshes
    # it as the run progresses and it is written once more at the end — so the
    # file exists, and is current, no matter how the run ends.
    write_preingreso_results(state, str(excel_file), str(output_copy))

    try:
        final_summary = run_bridge_session(
            state=state,
            host=RPA01_BRIDGE_HOST,
            port=RPA01_BRIDGE_PORT,
            timeout_seconds=RPA01_TIMEOUT_MINUTES * 60,
            output_dir=ingreso_output_dir,
            source_path=str(excel_file),
            output_copy_path=str(output_copy),
        )
    finally:
        move_updated_artifacts_to_run_dir(output_root, Path(ingreso_output_dir), artifact_snapshot)
        register_pending_artifact_move(output_root, Path(ingreso_output_dir), artifact_snapshot)

    receipt_path = write_bridge_receipt(final_summary, ingreso_output_dir)
    # Written unconditionally, success or failure — a run that stops partway
    # must still tell the operator what was and wasn't attempted.
    write_preingreso_results(state, str(excel_file), str(output_copy))
    print(f"[RPA01][RESULTADO] {output_copy}")

    conectado = "si" if final_summary.get("started") else "no"
    print(f"[RPA01][CONEXION] conectado={conectado} url={final_summary.get('portal_url') or '-'}")
    print(
        f"[RPA01][RESUMEN] filas={final_summary.get('row_total', 0)} "
        f"ok={final_summary.get('rows_ok', 0)} "
        f"procesadas={final_summary.get('rows_done', 0)} "
        f"conectado={conectado} pasos={final_summary.get('steps_done', 0)}"
    )
    completion = str(final_summary.get("completion_message") or "")
    if completion:
        print(f"[RPA01][FIN] {completion}")
    print(f"[RPA01][TALLY] {build_result_tally(state)}")
    print(f"RPA01: evidencia={receipt_path}")

    for entry in final_summary.get("logs", []):
        print(f"RPA01: {entry}")

    # LAST on purpose — the desktop truncates the raw log to its final stretch,
    # so these two must survive a long run. Keep them the last two prints.
    print(f"[RPA01][SALIDA] {ingreso_output_dir}")
    print(f"[RPA01][DETALLE] {build_result_summary_json(state)}")

    step_error = str(final_summary.get("error") or "")
    if step_error:
        print(f"[RPA01][PASO_ERROR] {step_error}")
        raise RuntimeError(f"RPA01 se detuvo por un error grave. {step_error}")

    print("Done")


@task
def RPA_01_Envio():
    """
    RPA 01 NEW - Envio de escritos de pago garantia estatal en poder judicial.
    """
    excel_file = _require_existing_path(EXCEL_FILE_NAME, "La planilla de escritos")

    browser.configure(
        browser_engine="chromium",
        screenshot="only-on-failure",
        headless=False,
    )

    # Envio needs its own run directory so the debug log has somewhere to land.
    envio_output_dir = create_ingreso_output_dir(PATH_BOT, datetime.now())

    try:
        page = goto_ojv_login_with_browser()
        page.get_by_role("heading", name="Ingreso de demandas y escritos").wait_for()
        page.get_by_role("button", name="Clave Poder Judicial").first.click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").click()
        page.get_by_role("textbox", name="Ej: 12345678 (Rut sin guión").fill(PJUD_USERNAME)
        page.locator("#inputPassword2C").click()
        page.locator("#inputPassword2C").fill(PJUD_PASSWORD)
        page.get_by_role("button", name="Ingresar").click()
        page.locator("#roles-modal").get_by_text("Seleccione Perfil").wait_for()
        page.get_by_text(PJUD_PROFILE_LABEL).first.click()

        read_excel_envio(str(excel_file), envio_output_dir)

    finally:
        print('Done')


@task
def RPA_01_Compare_results():
    """
    RPA 01 NEW - Descarga del Excel del poder judicial y comparacion con el Excel de ingreso del bot.
    """
    _require_existing_path(EXCEL_FILE_NAME, "La planilla de escritos")

    try:
        chrome_options = Options()
        download_path = str(PROCESSING_DIR)
        prefs = {'download.default_directory': download_path}
        chrome_options.add_argument('--start-maximized')
        chrome_options.add_experimental_option('prefs', prefs)
        driver = webdriver.Chrome(options=chrome_options)

        goto_ojv_login_with_driver(driver)
        driver.find_element(By.ID, value='link2C').click()
        driver.find_element(By.ID, value='inputRut2C').send_keys(PJUD_USERNAME)
        driver.find_element(By.ID, value='inputPassword2C').send_keys(PJUD_PASSWORD)
        driver.find_element(By.CLASS_NAME, value='btn-ingreso-pjud').click()
        time.sleep(2)
        driver.find_element(By.CLASS_NAME, value='card-text').click()
        time.sleep(2)
        driver.get("https://ojv.pjud.cl/kpitec-ojv-web/index#bandeja/escritos")
        time.sleep(5)
        driver.find_element(By.XPATH, "//select[contains(.,'Seleccione Competencia')]/option[text()='Civil']").click()
        time.sleep(5)
        driver.find_element(By.XPATH, "//a[contains(.,'Escritos Enviados')]").click()
        time.sleep(5)

        actions = ActionChains(driver)
        actions.send_keys(Keys.ARROW_DOWN).perform()

        driver.find_element(By.XPATH, "//button[contains(.,'Exportar Excel')]").click()
        time.sleep(15)
        time.sleep(15)

        path = str(PROCESSING_DIR)
        outputPath = str(OUTPUT_DIR)
        dir_list = os.listdir(path)
        print("Files and directories in '", path, "' :")
        print(dir_list)
        file = dir_list[0]
        path = os.path.join(path, file)
        informePJUD = openpyxl.load_workbook(path)
        escritos_enviados_sheet = informePJUD["Escritos Enviados"]
        get_roles_done_by_excel()
        for column in escritos_enviados_sheet.iter_cols():
            column_name = column[3].value
            if column_name == "RIT":
                for i, cell in enumerate(column):
                    if i < 4:
                        continue
                    trib_cell = "B" + str(i+1)
                    trib = escritos_enviados_sheet[trib_cell].value.upper().replace("º JUZGADO CIVIL DE SANTIAGO", "")
                    valor = cell.value + "-" + trib
                    print(cell.value, 'pjud')
                    if valor in ROLES_DONE:
                        print(cell.value, 'into roles_done')
                        escritos_enviados_sheet.cell(cell.row, cell.column, cell.value).fill = PatternFill(start_color='92D050', end_color='92D050', fill_type="solid")

        outputPath = os.path.join(outputPath, 'RESULTADO.xlsx')
        informePJUD.save(outputPath)

    finally:
        print('Done')


def get_roles_done_by_excel():
    """
    RPA 01 - Review column ENVIO into an Excel file and set the value of ROLES_DONE variable
    """
    try:
        informe_bot = openpyxl.load_workbook(EXCEL_FILE_NAME)
        informe_bot_sheet = informe_bot["Hoja1"]

        rit_list = []

        lista = list(informe_bot_sheet.iter_cols())
        envio_index = None
        rol_index = None
        tribunal_index = None

        for index in range(len(lista)):
            if (lista[index][0].value == 'ENVIO'):
                envio_index = index
            elif (lista[index][0].value == 'ROL'):
                rol_index = index
            elif (lista[index][0].value == 'TRIBUNAL'):
                tribunal_index = index

        for index in range(informe_bot_sheet.max_row):
            if (lista[envio_index][index].value == 'OK'):
                combinacion = lista[rol_index][index].value + '-' + str(lista[tribunal_index][index].value)[0:len(lista[tribunal_index][index].value)-1]
                rit_list.append(combinacion)
            elif (lista[envio_index][index].value == None and lista[rol_index][index].value == None):
                break

        global ROLES_DONE
        ROLES_DONE = list(map(lambda item: "C-" + str(item), rit_list))
        return ROLES_DONE

    finally:
        informe_bot.close
