# RPA01 — Ingreso de Escritos (atendido)

## Qué cambió

`RPA_01_Ingreso` ya **no abre ningún navegador**. El WAF del Poder Judicial
bloquea el Chrome automatizado que esta task manejaba, así que pasó al mismo
patrón atendido que usan Clean05, Clean07 y N03:

1. El operador abre **su propio Chrome** e inicia sesión a mano en la Oficina
   Judicial Virtual.
2. La task valida la planilla y la carpeta de escritos, y abre un bridge local
   en `http://127.0.0.1:8767`.
3. La extensión RPA01 (carpeta `extension/`) se conecta a ese bridge, el
   operador presiona **Start** en el panel, y a partir de ahí la extensión pide
   un paso a la vez y lo ejecuta sobre la página real.

**No hay credenciales en el bot.** El login es manual, siempre.

## Cómo se corre

1. Cargar la extensión una sola vez: `chrome://extensions` → *Modo de
   desarrollador* → *Cargar descomprimida* → elegir la carpeta `extension/`.
2. Iniciar sesión a mano en la Oficina Judicial Virtual.
3. Ir a **Trámite Fácil** (`ojv.pjud.cl/kpitec-ojv-web`).
4. Ejecutar `RPA_01_Ingreso` desde BotManager (planilla + carpeta de escritos).
5. Presionar **Start** en el panel RPA01 y dejar la pestaña visible.

> Al cambiar cualquier archivo de `extension/`, hay que subir la versión en
> `manifest.json` **y** en `BUILD` dentro de `content.js`. El bridge rechaza el
> handshake si las dos no coinciden con lo instalado, antes de tocar el portal.

## Las dos garantías siguen intactas

Los ROL se repiten entre juzgados, así que un tribunal mal seleccionado abre una
causa **real pero distinta** y "Consulta Rol" igual tiene éxito. Por eso hay dos
verificaciones independientes antes del punto de no retorno:

| Guardia | Paso | Si falla |
|---|---|---|
| **Tribunal** | `select_tribunal` — se selecciona y se vuelve a **leer** del portal | `REVISAR` (no se creó nada, se puede reintentar) |
| **Carátula** | `verify_caratula` — se compara con la columna `CARATULA` | `REVISAR` |

**Punto de no retorno: `click_grabar_escrito`.** Desde ahí el escrito existe en
la Bandeja. Cualquier falla posterior marca la fila `REVISAR_MANUAL` y **nunca**
se reintenta sola — eso es lo que evitó que el mismo escrito se subiera dos y
tres veces.

Una fila que falla ya no mata la corrida: se ejecuta `RECOVER_STEPS`
(cerrar diálogos + volver a Trámite Fácil) y sigue con la fila siguiente. Tres
fallas seguidas sí detienen todo.

## Estados en la columna PREINGRESO

| Estado | Significa | ¿Se reintenta solo? |
|---|---|---|
| `OK` | Ingresado y adjuntado | No |
| `REVISAR` | Falta el PDF, o el portal abrió otra causa. No se creó nada | Sí |
| `ERROR` | Falló antes de Grabar Escrito | Sí |
| `REVISAR_MANUAL` | Falló **después** de Grabar Escrito | **Nunca** |

Las filas marcadas se pintan y llevan un comentario flotante explicando el
motivo. Se escribe tanto en la planilla original (para poder re-correrla) como
en la copia dentro de la carpeta del run.

Una fila sin su PDF se marca `REVISAR` **antes** de abrir el bridge: nunca llega
al portal.

## Pendiente de validar en el portal real

Tres pasos eran *typeahead* a ciegas en la versión anterior (se tipeaba `joa`,
`gen`, `da cuenta de pag` sobre el control enfocado). Se tradujeron a búsqueda
por prefijo sobre el control real, pero **el texto exacto de las opciones solo
se puede confirmar contra el formulario en vivo**. Si alguno falla, el error
incluye la lista completa de opciones que ofreció el portal — con eso se corrige
en una sola pasada, por variable de entorno y sin tocar código:

| Variable | Default | Paso |
|---|---|---|
| `RPA01_SOLICITANTE` / `_MATCH` / `RPA01_LABEL_SOLICITANTE` | `joa` / `prefix` / `Solicitante` | `select_solicitante` |
| `RPA01_TIPO_ESCRITO` / `_MATCH` / `RPA01_LABEL_TIPO_ESCRITO` | `gen` / `prefix` / `Tipo Escrito` | `select_tipo_escrito` |
| `RPA01_MATERIA_ESCRITO` / `_MATCH` / `RPA01_LABEL_MATERIA` | `da cuenta de pag` / `prefix` / `Materia` | `select_materia_escrito` |
| `RPA01_CUADERNO` / `_MATCH` | *(vacío)* / `first` | `select_cuaderno` |
| `RPA01_COMPETENCIA` | `Civil` | `select_competencia` |
| `RPA01_TIPO_CAUSA` | `C` | `select_tipo_causa` |
| `RPA01_TIPO_DOCUMENTO` | `Escrito` | `select_tipo_documento_escrito` |

`_MATCH` acepta `exact`, `prefix` o `first`.

Otras variables: `RPA01_BRIDGE_HOST`, `RPA01_BRIDGE_PORT` (8767),
`RPA01_TIMEOUT_MINUTES` (120), `RPA01_VERIFY_TRIBUNAL`, `RPA01_FIJAR_DATOS`,
`DOCUMENTOS_FIRMADOS`.

## Lo que NO está portado

`RPA_01_Envio` y `RPA_01_Compare_results` siguen usando el navegador manejado
(Playwright / Selenium) y por lo tanto siguen expuestas al mismo bloqueo del
WAF. Son pantallas distintas (la Bandeja), con su propio recorrido.

El camino Playwright viejo de Ingreso sigue en `functions.py`
(`read_excel_preingreso` / `fill_form_escritos`) marcado como retirado, como
referencia mientras se valida el atendido. No lo llama nadie.

## Archivos

| Archivo | Qué hace |
|---|---|
| `tasks.py` | Valida entradas, abre el bridge, escribe resultados |
| `bridge.py` | Máquina de pasos, servidor HTTP local, resultado en Excel |
| `functions.py` | Helpers compartidos + camino Playwright retirado |
| `extension/content.js` | Un handler por paso, sobre la página real |
| `extension/background.js` | Relay al bridge + `ALLOWED_PATHS` |
