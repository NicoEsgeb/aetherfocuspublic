(() => {
  const MESSAGE_TYPE = "RPA01_BRIDGE_REQUEST";
  const PANEL_ID = "rpa01-pjud-panel";
  // The other attended bots inject their own panel on the same PJUD origin,
  // anchored to the same corner. When several are loaded, RPA01 stacks itself
  // above whichever is already there instead of covering it.
  const SIBLING_PANEL_IDS = ["clean07-pjud-panel", "n03-pjud-panel"];
  // Shown in the panel title. Reloading the extension does NOT re-inject this
  // script into tabs that are already open, so this marker is the way to tell
  // whether the page is running the current build or a stale one. It travels
  // with /start so the desktop can refuse a stale extension before anything is
  // touched on the portal.
  const BUILD = "v0.1.0";
  // The OJV app this bot's route was built against. Start is accepted anywhere
  // on the portal; this only drives the hint text.
  const START_PAGE = "kpitec-ojv-web";

  let connected = false;
  let starting = false;
  let verified = false;
  let workTimer = 0;
  let busy = false;
  // Set once the desktop confirms the session is done, so the panel shows a
  // friendly message instead of a scary "connection lost" when the bridge
  // server shuts down right after the handshake.
  let completed = false;
  // Repeat guard. The bridge only re-issues a step it never got a report for,
  // so seeing the same one twice means the loop is stuck — and repeating a
  // click on the portal is exactly what gets the session blocked by the WAF.
  let lastStepKey = "";
  let sameStepCount = 0;
  const MAX_STEP_ATTEMPTS = 2;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  // ---------------------------------------------------------------------------
  // Panel
  // ---------------------------------------------------------------------------

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="rpa01-title">RPA01 · Ingreso Escritos · ${BUILD}</div>
      <div class="rpa01-status" data-role="status">Esperando BotManager...</div>
      <div class="rpa01-details" data-role="details">Planilla sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    positionPanel();
    return panel;
  }

  // Keep clear of the other bots' panels when several extensions are enabled.
  // Re-checked on every poll because they inject asynchronously.
  function positionPanel() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) {
      return;
    }
    let offset = 14;
    for (const id of SIBLING_PANEL_IDS) {
      const other = document.getElementById(id);
      if (other) {
        offset += other.offsetHeight + 10;
      }
    }
    panel.style.bottom = `${offset}px`;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("rpa01-ok", tone === "ok");
    status.classList.toggle("rpa01-error", tone === "error");
  }

  function renderSummary(summary) {
    const details = createPanel().querySelector('[data-role="details"]');
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const escritos = summary && summary.escritos ? summary.escritos : {};
    if (!workbook.filename) {
      details.textContent = "Planilla sin confirmar";
      return;
    }
    const rows = summary && summary.row_total ? summary.row_total : 0;
    details.textContent = `${workbook.filename} · ${rows} fila(s) · `
      + `${escritos.pdf_count || 0} PDF(s) en escritos`;
  }

  function onStartPage() {
    return String(window.location.href || "").toLowerCase().includes(START_PAGE);
  }

  const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

  // ---------------------------------------------------------------------------
  // Text helpers
  // ---------------------------------------------------------------------------

  // Labels arrive padded and accented, and the planilla writes the tribunal with
  // DEGREE SIGN ("10°") while PJUD renders MASCULINE ORDINAL ("10º JUZGADO
  // CIVIL DE SANTIAGO"). Comparing them raw never matches, so everything is
  // compared on a folded form: accents stripped, non-alphanumerics collapsed.
  // Mirrors _norm() in functions.py — keep the two in step.
  function foldLabel(value) {
    return String(value == null ? "" : value)
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  // Looser fold that keeps the original spacing, for display in error messages.
  function tidy(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  // getComputedStyle(el).display only reflects the ELEMENT'S OWN display — an
  // ancestor's display:none does not change it. getBoundingClientRect's actual
  // rendered size correctly collapses to 0x0 whenever display:none applies
  // anywhere up the ancestor chain, and unlike offsetParent it stays correct
  // for position:fixed elements too (Bootstrap modals commonly are).
  function isVisible(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  // The portal renders its forms from Knockout bindings after the page settles,
  // so poll instead of assuming an element exists the moment we look.
  function waitFor(probe, errorMessage, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const immediate = probe();
      if (immediate) {
        resolve(immediate);
        return;
      }
      const deadline = Date.now() + timeoutMs;
      const timer = window.setInterval(() => {
        const found = probe();
        if (found) {
          window.clearInterval(timer);
          resolve(found);
        } else if (Date.now() > deadline) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }

  function findByText(selector, label, root) {
    const target = foldLabel(label);
    const scope = root || document;
    let candidates = [];
    try {
      candidates = Array.from(scope.querySelectorAll(selector));
    } catch (_) {
      return null;
    }
    // Exact text first, so a longer entry containing the same words cannot win
    // over the real one.
    return candidates.find((el) => foldLabel(el.textContent) === target)
      || candidates.find((el) => foldLabel(el.textContent).includes(target))
      || null;
  }

  // ---------------------------------------------------------------------------
  // Label-anchored control resolution
  // ---------------------------------------------------------------------------
  // The Playwright version this replaces navigated the Trámite Fácil form by
  // LABEL (//label[contains(.,'Tribunal')]), never by id — the form's ids are
  // Knockout-generated and drift between renders. The same approach is kept
  // here: find the visible label, then walk to the control that belongs to it.
  // Mirrors _first_visible_label / _read_control_text in functions.py.

  function findVisibleLabel(labelText) {
    const target = foldLabel(labelText);
    const labels = Array.from(document.querySelectorAll("label"));
    const matching = labels.filter((el) => foldLabel(el.textContent).includes(target));
    if (!matching.length) {
      return null;
    }
    return matching.find(isVisible) || matching[0];
  }

  // Everything that could plausibly hold this label's value, nearest first.
  // `scope` is the label itself and then its immediate container, matching the
  // "../x" then "ancestor::div[1]//x" pairs the Python probes use.
  function controlScopes(label) {
    const scopes = [];
    if (label.parentElement) scopes.push(label.parentElement);
    const container = label.closest("div");
    if (container && container !== label.parentElement) scopes.push(container);
    if (container && container.parentElement) scopes.push(container.parentElement);
    return scopes;
  }

  function findNativeSelectNear(label) {
    for (const scope of controlScopes(label)) {
      const select = scope.querySelector("select");
      if (select) return select;
    }
    return null;
  }

  function findInputNear(label) {
    for (const scope of controlScopes(label)) {
      const input = scope.querySelector('input:not([type="hidden"]):not([type="checkbox"])');
      if (input) return input;
    }
    return null;
  }

  function findSelect2ContainerNear(label) {
    for (const scope of controlScopes(label)) {
      const container = scope.querySelector(".select2-container");
      if (container) return container;
    }
    return null;
  }

  function findCheckboxNear(label) {
    for (const scope of controlScopes(label)) {
      const box = scope.querySelector('input[type="checkbox"]');
      if (box) return box;
    }
    return null;
  }

  // Read the value currently SHOWN by the control next to `labelText`.
  // Returns {text, strategy}; text is null when nothing could be read — that is
  // reported as "unverified", never silently treated as a match.
  function readControlText(labelText) {
    const label = findVisibleLabel(labelText);
    if (!label) {
      return { text: null, strategy: "label-no-encontrado" };
    }

    const select = findNativeSelectNear(label);
    if (select && select.selectedIndex >= 0) {
      const text = tidy(select.options[select.selectedIndex].textContent || select.value);
      if (text) return { text, strategy: "native-select" };
    }

    const container = findSelect2ContainerNear(label);
    if (container) {
      const chosen = container.querySelector(".select2-chosen");
      const text = chosen ? tidy(chosen.textContent) : "";
      if (text) return { text, strategy: "select2-chosen" };
    }

    const input = findInputNear(label);
    if (input) {
      const text = tidy(input.value);
      if (text) return { text, strategy: "input" };
    }

    for (const scope of controlScopes(label)) {
      const node = Array.from(scope.querySelectorAll("span, p, strong, b"))
        .find((el) => tidy(el.textContent));
      if (node) {
        const text = tidy(node.textContent);
        if (text && foldLabel(text) !== foldLabel(label.textContent)) {
          return { text, strategy: "texto" };
        }
      }
    }

    // Last resort: read the whole container and subtract the label itself. Some
    // OJV read-only fields are plain text nodes with no element of their own.
    const container2 = label.closest("div");
    if (container2) {
      const whole = tidy(container2.textContent);
      const labelShown = tidy(label.textContent);
      const remainder = whole.replace(labelShown, " ").replace(/^[\s:]+|[\s:]+$/g, "");
      if (remainder) {
        return { text: remainder, strategy: "contenedor" };
      }
    }

    return { text: null, strategy: "ilegible" };
  }

  // ---------------------------------------------------------------------------
  // select2 v3 driver
  // ---------------------------------------------------------------------------
  // The portal keeps ONE shared drop element (#select2-drop) that select2
  // repositions and refills for whichever control is open, so: open the
  // control, then read whatever the shared drop currently holds. Never the
  // reverse.
  const SELECT2_DROP_ID = "select2-drop";

  function fireMouse(element, type) {
    element.dispatchEvent(new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window,
      button: 0
    }));
  }

  function select2Chosen(container) {
    const chosen = container.querySelector(".select2-chosen");
    return chosen ? foldLabel(chosen.textContent) : "";
  }

  // Find the drop that belongs to THIS control. The container's focusser
  // carries the control's autogen id (s2id_autogenN) and the open drop holds
  // the matching search input (s2id_autogenN_search) — that link is exact,
  // whereas the #select2-drop id is shared and stale copies of other fields
  // linger in the DOM with display:none.
  function findSelect2Drop(container) {
    const focusser = container.querySelector("input.select2-focusser");
    if (focusser && focusser.id) {
      const search = document.getElementById(`${focusser.id}_search`);
      const own = search && search.closest(".select2-drop");
      if (isVisible(own)) {
        return own;
      }
    }
    const shared = document.getElementById(SELECT2_DROP_ID);
    return isVisible(shared) ? shared : null;
  }

  async function openSelect2El(container, fieldLabel) {
    await waitFor(
      () => !container.classList.contains("select2-container-disabled") || null,
      `El campo ${fieldLabel} sigue deshabilitado.`,
      10000
    );
    const choice = container.querySelector("a.select2-choice");
    if (!choice) {
      throw new Error(`El campo ${fieldLabel} no expone el control select2.`);
    }
    // select2 v3 opens on MOUSEDOWN — a bare .click() leaves it closed.
    fireMouse(choice, "mousedown");
    fireMouse(choice, "mouseup");
    fireMouse(choice, "click");
    const drop = await waitFor(
      () => findSelect2Drop(container),
      `No se abrió el desplegable de ${fieldLabel}.`,
      8000
    );
    return { container, drop };
  }

  function select2Options(drop) {
    return Array.from(drop.querySelectorAll("li.select2-result-selectable"));
  }

  // Matching stays as tight as the caller asks for, so a near neighbour can
  // never be picked by accident. The cost is that a value whose wording is
  // slightly off just fails — so when it does, report what the portal actually
  // offered. That turns a guessing loop into a single fix.
  function listOptions(labels, max = 30) {
    const items = labels.map(tidy).filter(Boolean);
    if (!items.length) {
      return "(ninguna)";
    }
    const shown = items.slice(0, max).join(" · ");
    return items.length > max ? `${shown} … (+${items.length - max} más)` : shown;
  }

  // "exact"  — the whole option text must match (default; safest)
  // "prefix" — the option must START with the value. This is the faithful
  //            translation of the old keyboard typeahead ("joa" -> JOAQUÍN...),
  //            which is what the Playwright version actually did.
  // "first"  — take the first selectable option, which is what a bare
  //            ArrowDown off the placeholder used to do (the cuaderno field).
  function pickByMode(entries, wanted, mode) {
    const target = foldLabel(wanted);
    if (mode === "first") {
      return entries.find((entry) => foldLabel(entry.label)) || null;
    }
    const exact = entries.find((entry) => foldLabel(entry.label) === target);
    if (exact || mode === "exact") {
      return exact || null;
    }
    return entries.find((entry) => foldLabel(entry.label).startsWith(target))
      || entries.find((entry) => foldLabel(entry.label).includes(target))
      || null;
  }

  // select2 v3 selects on MOUSEUP, not click, so a bare .click() on the row
  // does nothing. Send the full sequence a real pointer would produce.
  function chooseSelect2Option(item) {
    fireMouse(item, "mousedown");
    fireMouse(item, "mouseup");
    fireMouse(item, "click");
  }

  async function setSelect2El(container, fieldLabel, wanted, mode = "exact") {
    const { drop } = await openSelect2El(container, fieldLabel);
    // The list is filled asynchronously, so a slow load must not look like a
    // missing value.
    await waitFor(() => (select2Options(drop).length ? true : null), "no-options", 8000)
      .catch(() => {});
    const entries = select2Options(drop).map((li) => ({ el: li, label: li.textContent }));
    const chosen = pickByMode(entries, wanted, mode);
    if (!chosen) {
      throw new Error(
        `No apareció la opción "${wanted}" en ${fieldLabel}. `
        + `El portal ofrece: ${listOptions(entries.map((e) => e.label))}`
      );
    }
    const chosenLabel = tidy(chosen.label);
    chooseSelect2Option(chosen.el);
    // Read back: never move on trusting that the click landed.
    await waitFor(
      () => select2Chosen(container) === foldLabel(chosenLabel) || null,
      `${fieldLabel} no quedó en "${chosenLabel}" tras seleccionarlo.`,
      8000
    );
    return chosenLabel;
  }

  async function setNativeSelect(select, fieldLabel, wanted, mode = "exact") {
    await waitFor(
      () => (select.options.length ? true : null),
      `El campo ${fieldLabel} no cargó sus opciones.`,
      10000
    );
    const entries = Array.from(select.options).map((opt) => ({ el: opt, label: opt.textContent }));
    const chosen = pickByMode(entries, wanted, mode);
    if (!chosen) {
      throw new Error(
        `No apareció la opción "${wanted}" en ${fieldLabel}. `
        + `El portal ofrece: ${listOptions(entries.map((e) => e.label))}`
      );
    }
    // Every <option> on the Knockout-bound selects carries value="" (Knockout
    // keeps the real objects itself), so assigning .value does nothing — the
    // option must be chosen by index and the change event dispatched by hand
    // or Knockout never learns about it.
    select.selectedIndex = chosen.el.index;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    const chosenLabel = tidy(chosen.label);
    await waitFor(
      () => foldLabel(select.options[select.selectedIndex].textContent)
        === foldLabel(chosenLabel) || null,
      `${fieldLabel} no quedó en "${chosenLabel}".`,
      8000
    );
    return chosenLabel;
  }

  // One entry point for every "pick a value in the field next to this label"
  // step. Resolves whichever control the portal actually rendered there.
  async function setFieldByLabel(labelText, wanted, mode = "exact") {
    const label = await waitFor(
      () => findVisibleLabel(labelText),
      `No se encontró el campo "${labelText}" en el formulario.`
    );
    const container = findSelect2ContainerNear(label);
    if (container) {
      return setSelect2El(container, labelText, wanted, mode);
    }
    const select = findNativeSelectNear(label);
    if (select) {
      return setNativeSelect(select, labelText, wanted, mode);
    }
    throw new Error(`El campo "${labelText}" no expone ni <select> ni select2.`);
  }

  // ---------------------------------------------------------------------------
  // Typing
  // ---------------------------------------------------------------------------

  function dispatchKey(input, type, key) {
    input.dispatchEvent(new KeyboardEvent(type, { key, bubbles: true, cancelable: true }));
  }

  // Fields on this form carry input masks that reformat live as characters
  // arrive, so setting .value in one shot leaves them unformatted and Knockout
  // never sees the change. Replay a real key sequence per character instead.
  async function typeInto(input, wanted) {
    input.focus();
    input.click();
    input.value = "";
    input.dispatchEvent(new Event("input", { bubbles: true }));
    for (const char of String(wanted)) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      input.value += char;
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(25);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();
  }

  // ---------------------------------------------------------------------------
  // Step handlers — one per name in bridge.py LOOP_STEPS / RECOVER_STEPS
  // ---------------------------------------------------------------------------

  const MENU_ITEM_SELECTOR = ".list-group-item span, .pg_menu_lt span, li span, a span, a, button";
  const MENU_ITEM_WRAPPER = ".list-group-item, .pg_menu_lt, li, a, button";

  function where(step) {
    return `Fila ${step.row_number}/${step.total}`;
  }

  async function clickIngresarEscrito(step) {
    const label = await waitFor(
      () => findByText(MENU_ITEM_SELECTOR, "Ingresar Escrito"),
      "No se encontró la opción 'Ingresar Escrito' en el portal."
    );
    const target = label.closest(MENU_ITEM_WRAPPER) || label.parentElement || label;
    target.click();
    return `${where(step)}: se abrió "Ingresar Escrito".`;
  }

  async function selectCompetencia(step) {
    const wanted = String(step.value || "Civil");
    const chosen = await setFieldByLabel("Competencia", wanted, step.match || "exact");
    return `${where(step)}: Competencia = ${chosen}.`;
  }

  async function selectTipoCausa(step) {
    const wanted = String(step.value || "C");
    // This one has a stable Knockout binding, so prefer it over the label walk
    // (several "Tipo" labels render on this form).
    const select = document.querySelector('select[data-bind*="tiposCausas"]');
    if (select) {
      const chosen = await setNativeSelect(select, "Tipo de causa", wanted, step.match || "exact");
      return `${where(step)}: Tipo de causa = ${chosen}.`;
    }
    const chosen = await setFieldByLabel("Tipo", wanted, step.match || "exact");
    return `${where(step)}: Tipo de causa = ${chosen}.`;
  }

  // Historically this was an UNCONDITIONAL click on the checkbox — i.e. a
  // toggle. It flipped on/off on alternating rows, so every other escrito was
  // filled into a form PJUD had pre-populated with the previous causa's data.
  // Read the state first and only click when it does not already match.
  async function setFijarDatos(step) {
    const desired = Boolean(step.desired);
    const label = findVisibleLabel("Fijar Datos");
    if (!label) {
      return `${where(step)}: no se encontró 'Fijar Datos' (no se tocó).`;
    }
    const box = findCheckboxNear(label);
    if (!box) {
      return `${where(step)}: 'Fijar Datos' sin checkbox legible (no se tocó).`;
    }
    if (box.checked === desired) {
      return `${where(step)}: 'Fijar Datos' ya estaba ${desired ? "ON" : "OFF"}.`;
    }
    box.click();
    await waitFor(
      () => box.checked === desired || null,
      `'Fijar Datos' no quedó en ${desired ? "ON" : "OFF"}.`,
      5000
    );
    return `${where(step)}: 'Fijar Datos' = ${desired ? "ON" : "OFF"}.`;
  }

  // GUARD 1 — the tribunal is selected and then PROVEN. A wrong tribunal still
  // finds a valid causa (ROLs repeat across juzgados), so "Consulta Rol" would
  // succeed on the WRONG expediente. Never assume the selection landed.
  async function selectTribunal(step) {
    const wanted = String(step.value || "");
    const chosen = await setFieldByLabel("Tribunal", wanted, step.match || "exact");
    if (!step.verify) {
      return { message: `${where(step)}: Tribunal = ${chosen} (verificación desactivada).`, confirmed: false };
    }
    const { text, strategy } = readControlText("Tribunal");
    if (text === null) {
      // Could not READ it back. Reported as unverified rather than failed —
      // the carátula guard downstream is the second, independent check.
      return {
        message: `${where(step)}: Tribunal = ${chosen}, pero no se pudo verificar (sonda=${strategy}).`,
        confirmed: false
      };
    }
    if (foldLabel(text) !== foldLabel(wanted) && !foldLabel(text).includes(foldLabel(wanted))) {
      throw new Error(
        `Tribunal no coincide — la planilla esperaba "${wanted}" y el portal `
        + `muestra "${tidy(text)}".`
      );
    }
    return { message: `${where(step)}: Tribunal verificado = ${tidy(text)}.`, confirmed: true };
  }

  async function fillRol(step) {
    const wanted = String(step.value || "").trim();
    const label = await waitFor(
      () => findVisibleLabel("Rol"),
      "No se encontró el campo Rol."
    );
    const input = findInputNear(label);
    if (!input) {
      throw new Error("El campo Rol no expone un input.");
    }
    await waitFor(() => !input.disabled || null, "El campo Rol sigue deshabilitado.", 8000);
    await typeInto(input, wanted);
    await waitFor(
      () => String(input.value || "").replace(/\D/g, "") === wanted.replace(/\D/g, "") || null,
      `Rol no quedó en "${wanted}" (quedó "${input.value}").`,
      5000
    );
    return `${where(step)}: Rol = ${input.value}.`;
  }

  // The year has its own dedicated select2 with stable classes, unlike the rest
  // of the form. Always RE-select it, even when the visible value already
  // matches (e.g. the default 2026): skipping the selection leaves the form's
  // year/Rol state uncommitted, so "Consulta Rol" does nothing and the run
  // stalls until the button is clicked by hand.
  const YEAR_CONTAINER = "div.select2-container.pg-select2-year-control";
  const YEAR_DROPDOWN = "div.select2-drop-active.pg-select2-year-dropdown";

  async function selectAno(step) {
    const wanted = String(step.value || "").trim();
    if (!wanted) {
      throw new Error("Año vacío para la consulta de causa.");
    }
    const container = await waitFor(
      () => document.querySelector(YEAR_CONTAINER),
      "No se encontró el selector de año."
    );
    const choice = container.querySelector("a.select2-choice");
    if (!choice) {
      throw new Error("El selector de año no expone el control select2.");
    }
    fireMouse(choice, "mousedown");
    fireMouse(choice, "mouseup");
    fireMouse(choice, "click");

    const drop = await waitFor(
      () => {
        const el = document.querySelector(YEAR_DROPDOWN);
        return isVisible(el) ? el : null;
      },
      "No se abrió el desplegable de año.",
      8000
    );
    const search = drop.querySelector("input.select2-input");
    if (search) {
      await typeInto(search, wanted);
    }
    const item = await waitFor(
      () => Array.from(drop.querySelectorAll(".select2-result-label"))
        .find((el) => tidy(el.textContent) === wanted) || null,
      `El año "${wanted}" no aparece en el desplegable.`,
      8000
    );
    chooseSelect2Option(item);

    const chosen = container.querySelector(".select2-chosen");
    await waitFor(
      () => (chosen && tidy(chosen.textContent) === wanted) || null,
      `No se pudo seleccionar el año "${wanted}".`,
      6000
    );
    return `${where(step)}: Año = ${wanted}.`;
  }

  async function clickConsultaRol(step) {
    const button = await waitFor(
      () => findByText("button, a.btn, input[type='button']", "Consulta Rol"),
      "No se encontró el botón 'Consulta Rol'."
    );
    button.click();
    return `${where(step)}: se presionó 'Consulta Rol'.`;
  }

  // GUARD 2 — the carátula PJUD just loaded must be the one the planilla
  // expects. This is the check that catches a wrong causa even when the
  // tribunal read-back was unavailable, and it runs BEFORE Grabar Escrito so
  // nothing is created when it fails.
  //
  // Mirrors _caratula_key / _caratula_matches in functions.py: the bank side of
  // the carátula is identical on every row, so only the part after the last "/"
  // discriminates.
  function caratulaKey(value) {
    const text = String(value || "");
    const part = text.includes("/") ? text.slice(text.lastIndexOf("/") + 1) : text;
    return foldLabel(part);
  }

  function caratulaMatches(expected, shown) {
    const key = caratulaKey(expected);
    const shownNorm = foldLabel(shown);
    if (!key || !shownNorm) {
      return false;
    }
    if (shownNorm.includes(key)) {
      return true;
    }
    const tokens = key.split(" ").filter((token) => token.length > 2);
    return tokens.length > 0 && tokens.every((token) => shownNorm.includes(token));
  }

  async function verifyCaratula(step) {
    // "Consulta Rol" fills the carátula asynchronously and the LABEL exists
    // before the value does, so poll instead of reading once.
    await waitFor(
      () => findVisibleLabel("Caratulado"),
      "No apareció el campo 'Caratulado' tras 'Consulta Rol'."
    );
    const expected = String(step.value || "").trim();
    if (!expected) {
      return {
        message: `${where(step)}: la planilla no trae CARATULA, no se pudo verificar la causa.`,
        confirmed: false
      };
    }

    let shown = null;
    let strategy = "ilegible";
    const deadline = Date.now() + 8000;
    while (Date.now() < deadline) {
      const read = readControlText("Caratulado");
      if (read.text) {
        shown = read.text;
        strategy = read.strategy;
        break;
      }
      await sleep(500);
    }

    if (!shown) {
      return {
        message: `${where(step)}: no se pudo LEER el Caratulado del portal (sonda=${strategy}).`,
        confirmed: false
      };
    }
    if (!caratulaMatches(expected, shown)) {
      throw new Error(
        `CAUSA EQUIVOCADA — el portal abrió otra carátula para este ROL. `
        + `La planilla esperaba "${expected}" y el portal muestra "${tidy(shown)}".`
      );
    }
    return { message: `${where(step)}: carátula verificada "${tidy(shown)}".`, confirmed: true };
  }

  // A bare ArrowDown off the placeholder is what the Playwright version did
  // here, so the default value is empty and the mode is "first".
  async function selectCuaderno(step) {
    const chosen = await setFieldByLabel("Cuaderno", String(step.value || ""), step.match || "first");
    return `${where(step)}: Cuaderno = ${chosen}.`;
  }

  async function selectSolicitante(step) {
    const chosen = await setFieldByLabel(
      String(step.label || "Solicitante"),
      String(step.value || ""),
      step.match || "prefix"
    );
    return `${where(step)}: Solicitante = ${chosen}.`;
  }

  async function selectTipoEscrito(step) {
    const chosen = await setFieldByLabel(
      String(step.label || "Tipo Escrito"),
      String(step.value || ""),
      step.match || "prefix"
    );
    return `${where(step)}: Tipo de escrito = ${chosen}.`;
  }

  async function selectMateriaEscrito(step) {
    const chosen = await setFieldByLabel(
      String(step.label || "Materia"),
      String(step.value || ""),
      step.match || "prefix"
    );
    return `${where(step)}: Materia = ${chosen}.`;
  }

  // ---------------------------------------------------------------------------
  // POINT OF NO RETURN. From here the escrito EXISTS in the Bandeja, so every
  // later failure is reported with filed=true and the bridge flags the row
  // REVISAR_MANUAL instead of retrying it into a duplicate.
  // ---------------------------------------------------------------------------

  async function clickGrabarEscrito(step) {
    const button = await waitFor(
      () => findByText("button, a.btn, input[type='button']", "Grabar Escrito"),
      "No se encontró el botón 'Grabar Escrito'."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Grabar Escrito' sigue deshabilitado.",
      8000
    );
    // The click is deliberately the LAST thing this handler does. Anything
    // that threw above happened BEFORE the escrito could exist, which is what
    // lets the bridge treat those failures as safely retryable.
    button.click();
    return { message: `${where(step)}: se presionó 'Grabar Escrito'.`, filed: true };
  }

  async function awaitAdjuntarModal(step) {
    await waitFor(
      () => findByText("h1, h2, h3, h4, h5, .modal-title, label, span, a", "Adjuntar Archivos"),
      "No apareció la sección 'Adjuntar Archivos' tras 'Grabar Escrito'.",
      20000
    );
    return { message: `${where(step)}: se abrió 'Adjuntar Archivos'.`, filed: true };
  }

  // Fetches THIS row's own escrito PDF from the bridge (GET /file?row=N,
  // relayed through background.js as base64 — the page is HTTPS and the bridge
  // is plain HTTP, so a direct fetch here would be blocked as mixed content)
  // and stages it on the hidden file input via DataTransfer.
  //
  // This is what replaces the native Windows "Abrir" dialog the Playwright
  // version drove through robocorp.windows: Chrome only opens that dialog from
  // a trusted user gesture, so a synthetic click can never reach it. It also
  // makes the step work on macOS, which the Windows-only dialog never did.
  const FILE_INPUT_IDS = ["uploadMultiFileDocPrincipal", "dDPrincipal"];

  function findFileInput() {
    for (const id of FILE_INPUT_IDS) {
      const direct = document.getElementById(id);
      if (direct && direct.tagName === "INPUT" && direct.type === "file") {
        return direct;
      }
      if (direct) {
        const nested = direct.querySelector('input[type="file"]');
        if (nested) return nested;
      }
    }
    return document.querySelector('input[type="file"]');
  }

  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  async function attachEscritoFile(step) {
    const result = await bridgeRequest(`/file?row=${step.row_number}`);
    const bytes = base64ToBytes(result.content_base64);
    const file = new File([bytes], result.filename, { type: "application/pdf" });

    const input = await waitFor(
      findFileInput,
      "No se encontró el input de archivo del Documento Principal."
    );
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    input.files = dataTransfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    return {
      message: `${where(step)}: se adjuntó ${result.filename} (${bytes.length} bytes).`,
      filed: true
    };
  }

  async function clickAdjuntar(step) {
    const scope = document.getElementById("dDPrincipal") || document;
    const button = await waitFor(
      () => findByText("button, a.btn, input[type='button']", "Adjuntar", scope),
      "No se encontró el botón 'Adjuntar' del Documento Principal."
    );
    await waitFor(
      () => !button.disabled || null,
      "El botón 'Adjuntar' sigue deshabilitado.",
      10000
    );
    button.click();
    return { message: `${where(step)}: se presionó 'Adjuntar'.`, filed: true };
  }

  async function selectTipoDocumentoEscrito(step) {
    const wanted = String(step.value || "Escrito");
    const target = foldLabel(wanted);
    const node = await waitFor(
      () => Array.from(document.querySelectorAll("li, a, span, option, label, td"))
        .find((el) => foldLabel(el.textContent) === target && isVisible(el)) || null,
      `No apareció la opción de tipo de documento "${wanted}".`,
      15000
    );
    (node.closest("li, a, option, label, td") || node).click();
    return { message: `${where(step)}: tipo de documento = ${wanted}.`, filed: true };
  }

  async function clickCerrarContinuar(step) {
    const button = await waitFor(
      () => findByText("button, a.btn, input[type='button']", "Cerrar y Continuar"),
      "No se encontró el botón 'Cerrar y Continuar'.",
      20000
    );
    button.click();
    return { message: `${where(step)}: se presionó 'Cerrar y Continuar'.`, filed: true };
  }

  async function clickTramiteFacil(step) {
    const link = await waitFor(
      () => findByText(MENU_ITEM_SELECTOR, "Trámite Fácil"),
      "No se encontró el enlace 'Trámite Fácil' para volver.",
      20000
    );
    const target = link.closest(MENU_ITEM_WRAPPER) || link.parentElement || link;
    target.click();
    return { message: `${where(step)}: se volvió a 'Trámite Fácil'.`, filed: true };
  }

  // ---------------------------------------------------------------------------
  // Recovery — put the portal back on a known screen after a row failed, so the
  // run can continue with the NEXT row instead of dying on the whole planilla.
  // ---------------------------------------------------------------------------

  async function closeBlockingDialogs(step) {
    const closed = [];
    const buttons = Array.from(document.querySelectorAll(
      ".modal button, .modal a.btn, .modal .close, .ui-dialog button"
    )).filter(isVisible);
    for (const button of buttons) {
      const text = foldLabel(button.textContent);
      if (text.includes("cerrar") || text.includes("aceptar")
        || text.includes("cancelar") || button.classList.contains("close")) {
        button.click();
        closed.push(tidy(button.textContent) || "×");
        await sleep(400);
      }
    }
    return `${where(step)}: se cerraron ${closed.length} diálogo(s) ${closed.length ? `(${closed.join(", ")})` : ""}.`.trim();
  }

  async function gotoTramiteFacil(step) {
    // Deliberately a hash navigation on the SPA rather than a full reload: a
    // reload drops the operator's session state and is what a WAF notices.
    const link = findByText(MENU_ITEM_SELECTOR, "Trámite Fácil");
    if (link) {
      (link.closest(MENU_ITEM_WRAPPER) || link).click();
    } else {
      window.location.hash = "#facil/tramite";
    }
    await sleep(1500);
    return `${where(step)}: portal devuelto a 'Trámite Fácil'.`;
  }

  const STEP_HANDLERS = {
    click_ingresar_escrito: clickIngresarEscrito,
    select_competencia: selectCompetencia,
    set_fijar_datos: setFijarDatos,
    select_tipo_causa: selectTipoCausa,
    select_tribunal: selectTribunal,
    fill_rol: fillRol,
    select_ano: selectAno,
    click_consulta_rol: clickConsultaRol,
    verify_caratula: verifyCaratula,
    select_cuaderno: selectCuaderno,
    select_solicitante: selectSolicitante,
    select_tipo_escrito: selectTipoEscrito,
    select_materia_escrito: selectMateriaEscrito,
    // --- point of no return ---
    click_grabar_escrito: clickGrabarEscrito,
    await_adjuntar_modal: awaitAdjuntarModal,
    attach_escrito_file: attachEscritoFile,
    click_adjuntar: clickAdjuntar,
    select_tipo_documento_escrito: selectTipoDocumentoEscrito,
    click_cerrar_continuar: clickCerrarContinuar,
    click_tramite_facil: clickTramiteFacil,
    // --- recovery ---
    close_blocking_dialogs: closeBlockingDialogs,
    goto_tramite_facil: gotoTramiteFacil
  };

  // ---------------------------------------------------------------------------
  // Work loop
  // ---------------------------------------------------------------------------

  // End of session. Stops the work loop BEFORE the bridge server shuts down, so
  // the panel keeps the result message instead of flipping to "connection lost".
  function finish(payload, tone) {
    completed = true;
    window.clearInterval(workTimer);
    const failed = tone === "error" || Boolean(payload && payload.error);
    const message = (payload && payload.message)
      || (failed ? "El bot se detuvo por un error." : "Conexión verificada con BotManager.");
    setStatus(message, failed ? "error" : "ok");
    createPanel().querySelector('[data-role="details"]').textContent =
      "Revisa el resultado en BotManager.";
  }

  // Hard stop: no more work is pulled from the bridge. Used whenever continuing
  // could repeat an action on the portal. Recovery is deliberately manual
  // (reload the page and press Start again) so nothing touches PJUD by itself.
  function stopPump(message) {
    completed = true;
    window.clearInterval(workTimer);
    setStatus(message, "error");
    logToBridge(message);
  }

  // Reporting is what lets the bridge advance, so a failed report means the
  // next /next would hand out the SAME step again. Stop instead of looping.
  async function reportStep(body) {
    try {
      return await bridgeRequest("/report", { method: "POST", body });
    } catch (error) {
      const detail = String(error && error.message ? error.message : error);
      stopPump(
        `No se pudo informar el resultado a BotManager (${detail}). `
        + "El bot se detuvo para no repetir el paso en el portal. "
        + "Recarga la página y presiona Start de nuevo."
      );
      return null;
    }
  }

  async function pumpWork() {
    if (!verified || busy || completed) {
      return;
    }
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};

      if (step.action === "wait") {
        return;
      }
      if (step.action === "done") {
        finish(step);
        return;
      }

      const handler = STEP_HANDLERS[step.action];
      if (!handler) {
        // The desktop asked for a step this build does not know, so the loaded
        // extension is older than the bot files on disk. This MUST be reported:
        // returning without reporting leaves the bridge re-issuing the step
        // until its repeat guard trips, which blames "the same step 3 times"
        // instead of naming the real cause.
        const detail = `Paso desconocido "${step.action}": la extensión cargada `
          + `(${BUILD}) es más antigua que el bot. Recárgala en chrome://extensions `
          + "y luego recarga la pestaña del portal.";
        setStatus(detail, "error");
        logToBridge(detail);
        const staleReply = await reportStep({ ok: false, detail });
        if (staleReply && staleReply.done) {
          finish(staleReply, "error");
        }
        return;
      }

      const stepKey = `${step.row_number}:${step.step_number}:${step.action}`;
      if (stepKey === lastStepKey) {
        sameStepCount += 1;
      } else {
        lastStepKey = stepKey;
        sameStepCount = 1;
      }
      if (sameStepCount > MAX_STEP_ATTEMPTS) {
        stopPump(
          `El paso ${step.step_number} se repitió sin avanzar. El bot se detuvo `
          + "para no insistir sobre el portal. Revisa BotManager."
        );
        return;
      }

      setStatus(
        `Fila ${step.row_number}/${step.total} · paso ${step.step_number}/${step.step_total}...`
      );
      try {
        const result = await handler(step);
        // Most handlers return a plain string. The guard steps return
        // {message, confirmed} — "the click landed" and "the portal proved it"
        // are different things the bridge needs to tell apart. Steps past
        // Grabar Escrito return {message, filed:true} so a later failure is
        // never retried into a duplicate escrito.
        const isRich = result && typeof result === "object";
        const detail = isRich ? result.message : result;
        setStatus(detail, "ok");
        logToBridge(detail);
        const reportBody = { ok: true, detail };
        if (isRich && "confirmed" in result) {
          reportBody.confirmed = result.confirmed;
        }
        if (isRich && "filed" in result) {
          reportBody.filed = result.filed;
        }
        const reply = await reportStep(reportBody);
        if (reply && reply.done) {
          finish(reply);
        }
      } catch (error) {
        // Always report WHERE it failed. A step can fail simply because the tab
        // is on a different OJV app than the one the route was built against,
        // and that is invisible from the message alone.
        const detail = `${String(error && error.message ? error.message : error)}`
          + ` [pagina: ${window.location.href}]`;
        setStatus(`Error: ${detail}`, "error");
        logToBridge(detail);
        // The desktop decides what a failure costs: before Grabar Escrito the
        // row is safely retryable, at or after it the row is flagged
        // REVISAR_MANUAL and never auto-retried.
        const reply = await reportStep({ ok: false, detail });
        if (reply && reply.done) {
          finish(reply, "error");
        }
      }
    } catch (_) {
      if (completed) {
        return; // finished cleanly; the server just shut down.
      }
      connected = false;
      setStatus("Se perdió la conexión con BotManager.", "error");
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    positionPanel();
    if (verified || starting || completed) {
      return;
    }
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      setStatus(
        onStartPage()
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Abre Trámite Fácil y presiona Start.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta RPA01 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified) {
      return;
    }
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) {
        await bridgeRequest("/health");
      }
      // BUILD travels with Start so the desktop can refuse a stale extension
      // before anything is touched on the portal.
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title, build: BUILD }
      });
      if (payload.done || payload.ok === false) {
        // Rejected at the handshake (almost always: this extension is older
        // than the installed bot). Do not start the work loop.
        finish(payload, "error");
        button.disabled = false;
        return;
      }
      verified = true;
      renderSummary(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
