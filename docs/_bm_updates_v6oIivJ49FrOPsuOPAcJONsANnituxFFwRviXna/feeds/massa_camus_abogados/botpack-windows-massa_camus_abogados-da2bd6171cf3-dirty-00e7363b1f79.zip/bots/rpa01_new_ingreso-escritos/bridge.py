"""
RPA01 NEW - Ingreso de Escritos — attended bridge (Chrome extension)
====================================================================

Why this module exists
----------------------
The Playwright version of this task drove its own automated Chrome. PJUD's WAF
blocks that browser, so the task could not reach the portal at all. This module
replaces the driven browser with the attended pattern the other PJUD bots use:

  - the human opens their OWN Chrome and logs into the Oficina Judicial Virtual
    by hand (no credentials live in the bot any more),
  - this module opens a loopback HTTP bridge on 127.0.0.1:8767,
  - the RPA01 Chrome extension polls it, and for each planilla row asks for the
    next step, performs it on the real page, and reports back.

Everything the old version guarded against is preserved, because the guards were
never about the browser:

  TRIBUNAL  — selected, then READ BACK and compared. ROLs repeat across
              juzgados, so a wrong tribunal still finds a real causa.
  CARATULA  — after "Consulta Rol", compared against the planilla's CARATULA.
  POINT OF NO RETURN — "Grabar Escrito" creates the escrito in the Bandeja.
              A failure at or after it flags the row REVISAR_MANUAL and it is
              NEVER auto-retried, which is what stopped duplicate uploads.

tasks.py stays THIN: it validates inputs, starts this bridge, and writes the
result planilla.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from functions import (
    STATUS_ERROR,
    STATUS_OK,
    STATUS_REVISAR,
    STATUS_REVISAR_MANUAL,
    _caratula_matches,
    _causa_mismatch_note,
    _mark_missing_file_cells,
    _missing_file_note,
    _norm_status,
    _possibly_created_note,
    _should_process,
    _tribunal_numero,
    _tribunal_portal_label,
)

BOT_ID = "rpa01_new_ingreso_escritos"
BOT_LABEL = "RPA01"

# 8765 = N03, 8766 = Clean05, 8768 = Clean07. 8767 was freed when
# clean06_emerix_extension was retired. Must match BRIDGE_BASE_URL in
# extension/background.js.
DEFAULT_BRIDGE_PORT = 8767

PORTAL_START_PAGE = "kpitec-ojv-web"

# The extension goes quiet while it performs a step, but GET /health keeps the
# session alive. Longer than any single step is expected to take.
EXTENSION_IDLE_SECONDS = 90

# How many times /next may hand out the SAME step before the run is stopped.
# The extension only asks again after reporting, so a repeat means reports are
# not arriving — and repeating an action on the portal is what gets the session
# blocked by the WAF.
MAX_STEP_ISSUES = 2

# Back-to-back row failures that end the run for real. A single bad row is
# recovered from; three in a row means the portal is not where we think it is.
MAX_CONSECUTIVE_ROW_FAILURES = 3

DEFAULT_DONE_MESSAGE = "Conexión verificada con BotManager."

REQUIRED_COLUMNS = ("ROL", "TRIBUNAL", "RUT", "DV")
PREINGRESO_COLUMN = "PREINGRESO"
CARATULA_COLUMN = "CARATULA"
DATA_SHEET = "Hoja1"
HEADER_ROW = 1


# ---------------------------------------------------------------------------
# Steps
# ---------------------------------------------------------------------------
# One pass per planilla row. Unlike Clean07 there is no shared prep phase: the
# Trámite Fácil form is re-opened from the menu for every escrito.
LOOP_STEPS: tuple[str, ...] = (
    # Left menu of the OJV portal.
    "click_ingresar_escrito",
    "select_competencia",
    # Set explicitly, never toggled. The Playwright version clicked this
    # unconditionally, which flipped it on/off on alternating rows and filled
    # every other escrito into a form pre-populated with the previous causa.
    "set_fijar_datos",
    "select_tipo_causa",
    # GUARD 1 — selected and then PROVEN by reading the control back.
    "select_tribunal",
    "fill_rol",
    "select_ano",
    "click_consulta_rol",
    # GUARD 2 — the carátula the portal just loaded must be the planilla's.
    # Runs BEFORE Grabar Escrito, so a mismatch creates nothing.
    "verify_caratula",
    "select_cuaderno",
    "select_solicitante",
    "select_tipo_escrito",
    "select_materia_escrito",
    # ---------------------------------------------------------------------
    # POINT OF NO RETURN — from here the escrito EXISTS in the Bandeja.
    # ---------------------------------------------------------------------
    "click_grabar_escrito",
    "await_adjuntar_modal",
    "attach_escrito_file",
    "click_adjuntar",
    "select_tipo_documento_escrito",
    "click_cerrar_continuar",
    "click_tramite_facil",
)

# Runs after a row fails, to put the portal back on a known screen so the run
# can continue with the NEXT row instead of burning the rest of the planilla.
RECOVER_STEPS: tuple[str, ...] = (
    "close_blocking_dialogs",
    "goto_tramite_facil",
)

POINT_OF_NO_RETURN = LOOP_STEPS.index("click_grabar_escrito")

# Steps whose failure means "the portal is on the wrong causa" rather than "the
# bot broke". Nothing was created, so the row is REVISAR (retryable) instead of
# ERROR.
GUARD_STEPS = frozenset({"select_tribunal", "verify_caratula"})


def _env(name: str, default: str) -> str:
    return (os.getenv(name, "") or "").strip() or default


def _env_flag(name: str, default: bool = False) -> bool:
    raw = (os.getenv(name, "") or "").strip().lower()
    if raw in ("1", "true", "si", "sí", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    return default


# Fixed values the form is filled with, and how each one is matched against the
# options the portal renders.
#
# "prefix" is the faithful translation of the old keyboard typeahead: the
# Playwright version typed "joa" / "gen" / "da cuenta de pag" into the focused
# control and let the browser jump to the first option starting with those
# letters. Every one of these is env-overridable because the exact option
# wording can only be confirmed against the live portal — when a step fails it
# reports the full list of options the portal offered, which is what turns a
# wrong value here into a one-line fix instead of a guessing loop.
STEP_VALUES: dict[str, dict[str, str]] = {
    "select_competencia": {
        "value": _env("RPA01_COMPETENCIA", "Civil"),
        "match": "exact",
    },
    "select_tipo_causa": {
        "value": _env("RPA01_TIPO_CAUSA", "C"),
        "match": "exact",
    },
    "select_cuaderno": {
        # Empty + "first" reproduces the bare ArrowDown off the placeholder that
        # the Playwright version did here.
        "value": _env("RPA01_CUADERNO", ""),
        "match": _env("RPA01_CUADERNO_MATCH", "first"),
    },
    "select_solicitante": {
        "value": _env("RPA01_SOLICITANTE", "joa"),
        "match": _env("RPA01_SOLICITANTE_MATCH", "prefix"),
        "label": _env("RPA01_LABEL_SOLICITANTE", "Solicitante"),
    },
    "select_tipo_escrito": {
        "value": _env("RPA01_TIPO_ESCRITO", "gen"),
        "match": _env("RPA01_TIPO_ESCRITO_MATCH", "prefix"),
        "label": _env("RPA01_LABEL_TIPO_ESCRITO", "Tipo Escrito"),
    },
    "select_materia_escrito": {
        "value": _env("RPA01_MATERIA_ESCRITO", "da cuenta de pag"),
        "match": _env("RPA01_MATERIA_ESCRITO_MATCH", "prefix"),
        "label": _env("RPA01_LABEL_MATERIA", "Materia"),
    },
    "select_tipo_documento_escrito": {
        "value": _env("RPA01_TIPO_DOCUMENTO", "Escrito"),
        "match": "exact",
    },
}


class InputError(ValueError):
    """An input the operator can fix, reported before the bridge opens."""

    def __init__(self, message: str, *, reason: str, detail: str = ""):
        super().__init__(message)
        self.reason = reason
        self.detail = detail


# ---------------------------------------------------------------------------
# Planilla
# ---------------------------------------------------------------------------
def _normalize_header(value: Any) -> str:
    return " ".join(str(value or "").split()).upper()


def read_planilla(path: str) -> tuple[str, list[Any], list[dict[str, Any]], int]:
    """Read the escritos planilla with openpyxl.

    Returns (sheet_name, header_values, rows, preingreso_col_index). Each row
    carries its own 1-based ``excel_row`` so results can be written straight
    back to the cell they came from.
    """
    from openpyxl import load_workbook

    source = Path(path)
    if not source.is_file():
        raise InputError(
            f"La planilla de escritos no existe: '{source}'.",
            reason="planilla_no_existe",
        )

    workbook = load_workbook(str(source), data_only=True)
    sheet_name = DATA_SHEET if DATA_SHEET in workbook.sheetnames else workbook.sheetnames[0]
    sheet = workbook[sheet_name]

    header_cells = list(next(sheet.iter_rows(min_row=HEADER_ROW, max_row=HEADER_ROW), ()))
    header_values = [cell.value for cell in header_cells]
    columns: dict[str, int] = {}
    for index, value in enumerate(header_values, start=1):
        name = _normalize_header(value)
        if name and name not in columns:
            columns[name] = index

    missing = [name for name in REQUIRED_COLUMNS if name not in columns]
    if missing:
        workbook.close()
        raise InputError(
            f"La planilla no tiene las columnas necesarias: {', '.join(missing)}.",
            reason="columnas_faltantes",
            detail=f"Columnas encontradas: {', '.join(columns) or '(ninguna)'}",
        )

    rows: list[dict[str, Any]] = []
    for excel_row in range(HEADER_ROW + 1, sheet.max_row + 1):
        record: dict[str, Any] = {"excel_row": excel_row}
        for name, column_index in columns.items():
            record[name] = sheet.cell(row=excel_row, column=column_index).value
        if not str(record.get("ROL") or "").strip():
            continue
        rows.append(record)

    preingreso_index = columns.get(PREINGRESO_COLUMN, 0)
    workbook.close()

    if not rows:
        raise InputError(
            "La planilla no tiene filas con ROL.",
            reason="planilla_vacia",
        )
    return sheet_name, header_values, rows, preingreso_index


def ensure_preingreso_column(path: str, sheet_name: str) -> int:
    """Insert the PREINGRESO column at position 1 when it is missing.

    Matches the Playwright version's behaviour so a planilla that has already
    been through the bot keeps its column where the operator expects it.
    """
    from openpyxl import load_workbook

    workbook = load_workbook(path)
    sheet = workbook[sheet_name] if sheet_name in workbook.sheetnames else workbook.active
    for index in range(1, sheet.max_column + 1):
        if _normalize_header(sheet.cell(row=HEADER_ROW, column=index).value) == PREINGRESO_COLUMN:
            workbook.close()
            return index
    sheet.insert_cols(1)
    sheet.cell(row=HEADER_ROW, column=1, value=PREINGRESO_COLUMN)
    workbook.save(path)
    workbook.close()
    return 1


def escrito_filename(row: dict[str, Any], documentos_firmados: bool) -> str:
    """The PDF this row expects, named exactly as the Playwright version did.

    e.g. ``Trib_10°_ROL_1149-2026_12.345.678-9.pdf`` (plus ``_firmado``).
    """
    tribunal = str(row.get("TRIBUNAL") or "")
    # The planilla writes "10°"; the trailing ordinal mark is re-added below so
    # a plain "10" and "10°" both produce the same filename.
    numero = _tribunal_numero(tribunal)
    rut_raw = str(row.get("RUT") or "").strip()
    try:
        rut_formatted = f"{int(float(rut_raw)):,}".replace(",", ".")
    except (TypeError, ValueError) as exc:
        raise InputError(
            f"RUT inválido en la planilla: '{rut_raw}'.",
            reason="rut_invalido",
            detail=str(exc),
        ) from exc
    name = (
        f"Trib_{numero}°_ROL_{str(row.get('ROL') or '').strip()}_"
        f"{rut_formatted}-{str(row.get('DV') or '').strip()}"
    )
    if documentos_firmados:
        name += "_firmado"
    return f"{name}.pdf"


def inspect_escritos_folder(
    path: str,
    rows: list[dict[str, Any]],
    documentos_firmados: bool,
) -> dict[str, Any]:
    """Resolve every row's PDF up front.

    The Playwright version checked file existence before touching the portal so
    a missing PDF could not jam the native "Abrir" dialog. That dialog is gone,
    but checking up front is still the right thing: a row with no file is
    flagged REVISAR without costing a single portal interaction.
    """
    folder = Path(path).expanduser()
    if not folder.is_dir():
        raise InputError(
            f"La carpeta de escritos no existe: '{folder}'.",
            reason="carpeta_no_existe",
        )

    resolved: dict[int, Path] = {}
    missing: list[tuple[int, str]] = []
    for row in rows:
        filename = escrito_filename(row, documentos_firmados)
        candidate = folder / filename
        if candidate.is_file():
            resolved[int(row["excel_row"])] = candidate
        else:
            missing.append((int(row["excel_row"]), filename))

    return {
        "path": str(folder),
        "pdf_count": len(resolved),
        "resolved": resolved,
        "missing": missing,
        "file_count": sum(1 for item in folder.glob("*.pdf") if item.is_file()),
    }


# ---------------------------------------------------------------------------
# Bridge state
# ---------------------------------------------------------------------------
@dataclass
class BridgeState:
    """Shared state between the desktop task and the Chrome extension.

    The extension polls /health, the operator presses Start (/start), and from
    then on every /next hands out the current step for the current row, which
    the extension performs on the real page and answers on /report.
    """

    input_path: str
    sheet_name: str
    workbook: dict[str, Any]
    escritos: dict[str, Any]
    documentos_firmados: bool = False
    rows: list[dict[str, Any]] = field(default_factory=list)
    source_header: list[Any] = field(default_factory=list)
    preingreso_index: int = 1
    verify_tribunal: bool = True
    fijar_datos: bool = False
    # excel_row -> {"estado", "note", "rol", "tribunal", "detail"}. Pre-filled
    # for every row in the planilla, so a row the run never reaches still shows
    # up in the output.
    results: dict[int, dict[str, Any]] = field(default_factory=dict)
    # excel_row -> absolute Path of that row's escrito PDF.
    files: dict[int, Path] = field(default_factory=dict)

    extension_seen_at: float = 0.0
    started_at: float = 0.0
    finished: bool = False
    error: str = ""
    portal_url: str = ""
    portal_title: str = ""
    logs: list[str] = field(default_factory=list)

    # "loop" runs LOOP_STEPS for the current row; "recover" runs RECOVER_STEPS
    # after a row failed, then hands back to "loop" for the NEXT row.
    phase: str = "loop"
    cursor: int = 0
    step_index: int = 0
    # Set the moment a step reports filed=true. Everything after that point can
    # only ever be REVISAR_MANUAL — the escrito already exists in the Bandeja.
    row_filed: bool = False
    # Whether either guard positively PROVED the causa for the current row.
    row_verified: bool = False

    rows_done: int = 0
    rows_ok: int = 0
    steps_done: int = 0
    last_step_done: int = 0
    consecutive_failures: int = 0
    completion_message: str = ""

    issued_key: tuple[str, int, int] | None = None
    issued_count: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock)

    # -- steps --------------------------------------------------------------

    def _phase_steps(self) -> tuple[str, ...]:
        return RECOVER_STEPS if self.phase == "recover" else LOOP_STEPS

    def next_action(self) -> dict[str, Any]:
        """Tell the extension what to do next on the PJUD page."""
        with self.lock:
            self.extension_seen_at = time.time()
            if not self.started_at:
                return {"action": "wait", "message": "Esperando Start."}

            self._skip_unprocessable_rows_unlocked()

            if self.finished or self.cursor >= len(self.rows):
                self.finished = True
                if not self.error:
                    self.completion_message = self._outcome_message_unlocked()
                return self._done_step_unlocked()

            row = self.rows[self.cursor]
            phase_steps = self._phase_steps()
            step_name = phase_steps[self.step_index]

            # The extension is busy while it performs a step, so it only asks
            # again after reporting. Handing out the same step repeatedly means
            # the reports are not arriving — and repeating an action on the
            # portal is what gets the session blocked by the WAF. Stop instead.
            key = (self.phase, self.cursor, self.step_index)
            self.issued_count = self.issued_count + 1 if key == self.issued_key else 1
            self.issued_key = key
            if self.issued_count > MAX_STEP_ISSUES:
                self.error = (
                    f"Fila {self.cursor + 1}, paso {self.step_index + 1} "
                    f"({step_name}): la extensión pidió el mismo paso "
                    f"{self.issued_count} veces sin informar el resultado. "
                    "Se detuvo la corrida para no repetirlo en el portal."
                )
                self.completion_message = (
                    f"El bot se detuvo en el paso {self.step_index + 1}. Revisa BotManager."
                )
                self.logs.append(self.error)
                self.finished = True
                return self._done_step_unlocked()

            step: dict[str, Any] = {
                "action": step_name,
                "row_number": self.cursor + 1,
                "excel_row": row.get("excel_row"),
                "total": len(self.rows),
                "step_number": self.step_index + 1,
                "step_total": len(phase_steps),
            }

            if step_name in STEP_VALUES:
                step.update(STEP_VALUES[step_name])
            elif step_name == "select_tribunal":
                step["value"] = _tribunal_portal_label(_tribunal_numero(row.get("TRIBUNAL")))
                step["verify"] = self.verify_tribunal
            elif step_name == "fill_rol":
                step["value"] = str(row.get("ROL") or "").split("-")[0].strip()
            elif step_name == "select_ano":
                rol = str(row.get("ROL") or "")
                step["value"] = rol.split("-")[1].strip() if "-" in rol else ""
            elif step_name == "verify_caratula":
                step["value"] = str(row.get(CARATULA_COLUMN) or "").strip()
            elif step_name == "set_fijar_datos":
                step["desired"] = self.fijar_datos
            return step

    def _skip_unprocessable_rows_unlocked(self) -> None:
        """Advance past rows that must not be sent to the portal at all.

        Three kinds: already OK, already REVISAR_MANUAL (an escrito may exist
        in the Bandeja — never auto-retry), and rows whose PDF is missing.
        """
        while self.cursor < len(self.rows):
            if self.phase == "recover" or self.step_index > 0:
                return
            row = self.rows[self.cursor]
            excel_row = int(row["excel_row"])
            entry = self.results.get(excel_row, {})
            estado = _norm_status(entry.get("estado"))

            if estado in (STATUS_OK, STATUS_REVISAR_MANUAL):
                self.logs.append(
                    f"Fila {self.cursor + 1} (ROL {row.get('ROL')}): omitida, ya marcada {estado}."
                )
                self.cursor += 1
                continue
            if excel_row not in self.files:
                # Recorded at build time; nothing to do on the portal.
                self.cursor += 1
                continue
            return

    # -- files --------------------------------------------------------------

    def resolve_row_file(self, row_number: int) -> Path | None:
        """Absolute path to THIS row's escrito PDF. ``row_number`` is 1-based."""
        index = row_number - 1
        if not (0 <= index < len(self.rows)):
            return None
        return self.files.get(int(self.rows[index]["excel_row"]))

    # -- reporting ----------------------------------------------------------

    def report_action(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Record how the step the extension just performed went."""
        with self.lock:
            self.extension_seen_at = time.time()
            ok = bool(payload.get("ok"))
            detail = " ".join(str(payload.get("detail") or "").split())[:400]
            phase_steps = self._phase_steps()
            step_name = phase_steps[self.step_index]
            position = self.cursor + 1

            if payload.get("filed"):
                # Never unset: once Grabar Escrito has landed, every later
                # failure on this row is REVISAR_MANUAL.
                self.row_filed = True
            if payload.get("confirmed"):
                self.row_verified = True

            if not ok:
                self.logs.append(f"Fila {position} [{step_name}]: ERROR {detail}")
                self._handle_failure_unlocked(step_name, position, detail)
                return self._report_reply_unlocked()

            self.logs.append(f"Fila {position} [{step_name}]: OK. {detail}".strip())
            self.steps_done += 1
            self.last_step_done = self.step_index + 1
            self.step_index += 1

            if self.step_index < len(phase_steps):
                return self._report_reply_unlocked()

            # The phase just finished.
            if self.phase == "recover":
                self.phase = "loop"
                self.step_index = 0
                self._advance_row_unlocked()
                return self._report_reply_unlocked()

            self._finish_row_unlocked(STATUS_OK)
            return self._report_reply_unlocked()

    def _handle_failure_unlocked(self, step_name: str, position: int, detail: str) -> None:
        if self.phase == "recover":
            # Recovery itself failed: the portal is not somewhere this bot can
            # reason about any more. Stop rather than file into the unknown.
            self.error = (
                f"La recuperación falló en '{step_name}' (fila {position}): {detail}. "
                "Se detuvo la corrida."
            )
            self.completion_message = (
                "El bot no pudo devolver el portal a Trámite Fácil. Revisa BotManager."
            )
            self.logs.append(self.error)
            self.finished = True
            return

        if self.row_filed or self.step_index >= POINT_OF_NO_RETURN:
            # The escrito may already be in the Bandeja. Never auto-retry.
            estado = STATUS_REVISAR_MANUAL
            note = _possibly_created_note(_StageError(step_name, detail))
        elif step_name in GUARD_STEPS:
            # A guard fired: the portal was on the wrong causa. Nothing was
            # created, so the row is safely retryable once it is corrected.
            estado = STATUS_REVISAR
            note = _causa_mismatch_note(_MismatchError(step_name, detail))
        else:
            estado = STATUS_ERROR
            note = None

        self._finish_row_unlocked(estado, detail=detail, note=note)

        if self.finished:
            return
        # Put the portal back on a known screen before the next row.
        self.phase = "recover"
        self.step_index = 0

    def _finish_row_unlocked(
        self,
        estado: str,
        *,
        detail: str = "",
        note: str | None = None,
    ) -> None:
        row = self.rows[self.cursor]
        excel_row = int(row["excel_row"])
        entry = self.results.setdefault(excel_row, _blank_result(row))
        entry["estado"] = estado
        entry["detail"] = detail
        entry["verificada"] = self.row_verified
        if note:
            entry["note"] = note

        self.rows_done += 1
        if estado == STATUS_OK:
            self.rows_ok += 1
            self.consecutive_failures = 0
            self.logs.append(f"Fila {self.cursor + 1} (ROL {row.get('ROL')}): {STATUS_OK}.")
            self._advance_row_unlocked()
            return

        self.consecutive_failures += 1
        self.logs.append(
            f"Fila {self.cursor + 1} (ROL {row.get('ROL')}): {estado}. {detail}".strip()
        )
        if self.consecutive_failures >= MAX_CONSECUTIVE_ROW_FAILURES:
            self.error = (
                f"{self.consecutive_failures} filas seguidas fallaron "
                f"(la última: {detail}). Se detuvo la corrida en vez de "
                "quemar el resto de la planilla."
            )
            self.completion_message = (
                f"El bot se detuvo tras {self.consecutive_failures} filas seguidas con error. "
                "Revisa BotManager."
            )
            self.logs.append(self.error)
            self.finished = True

    def _advance_row_unlocked(self) -> None:
        self.cursor += 1
        self.step_index = 0
        self.row_filed = False
        self.row_verified = False
        self.phase = "loop"

    def _outcome_message_unlocked(self) -> str:
        pendientes = sum(
            1 for entry in self.results.values()
            if _norm_status(entry.get("estado")) not in (STATUS_OK, "")
        )
        if not pendientes:
            return f"Listo: {self.rows_ok} escrito(s) ingresado(s) sin incidencias."
        return (
            f"Listo: {self.rows_ok} escrito(s) ingresado(s), "
            f"{pendientes} fila(s) requieren revisión."
        )

    def _report_reply_unlocked(self) -> dict[str, Any]:
        return {
            "ok": True,
            "done": self.finished,
            "message": self.completion_message or DEFAULT_DONE_MESSAGE,
            "error": self.error,
            "rowsDone": self.rows_done,
            "rowTotal": len(self.rows),
            "stepsDone": self.steps_done,
        }

    def _done_step_unlocked(self) -> dict[str, Any]:
        return {
            "action": "done",
            "message": self.completion_message or DEFAULT_DONE_MESSAGE,
            "error": self.error,
            "rowTotal": len(self.rows),
            "rowsDone": self.rows_done,
            "stepsDone": self.steps_done,
            "pdfCount": int(self.escritos.get("pdf_count", 0)),
        }

    # -- handshake ----------------------------------------------------------

    def touch_extension(self) -> None:
        with self.lock:
            self.extension_seen_at = time.time()

    def register_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            self.extension_seen_at = now
            self.started_at = now
            self.portal_url = str(payload.get("url") or "")[:1000]
            self.portal_title = str(payload.get("title") or "")[:300]
            self.logs.append(f"Start recibido desde {self.portal_url or 'el portal PJUD'}.")
            if PORTAL_START_PAGE.lower() not in self.portal_url.lower():
                self.logs.append(
                    "Aviso: el Start no se presionó desde la app "
                    f"{PORTAL_START_PAGE}. Se registró igualmente."
                )

            # Reloading the bot files does NOT reload the extension Chrome has
            # already loaded, so the two can drift: the desktop hands out a step
            # the loaded content script never heard of. Catch that HERE, before
            # anything is touched on the portal, instead of halfway through a
            # form.
            loaded = _normalize_build(payload.get("build"))
            on_disk = _normalize_build(extension_manifest_version())
            if on_disk and loaded != on_disk:
                came_as = loaded or "una versión que no informó su build"
                self.error = (
                    f"La extensión cargada en Chrome es {came_as}, pero el bot "
                    f"instalado es la {on_disk}. Recarga la extensión en "
                    "chrome://extensions y luego recarga la pestaña del portal. "
                    "No se tocó el portal."
                )
                self.completion_message = (
                    f"La extensión cargada ({came_as}) no coincide con el bot "
                    f"({on_disk}). Recárgala en chrome://extensions y luego "
                    "recarga la pestaña del portal."
                )
                self.logs.append(self.error)
                self.finished = True
                # ok=True on purpose: the request WAS handled. The extension
                # treats ok=False as a transport failure and would let the
                # /health poller overwrite this message a second later.
                return {"ok": True, "done": True, "error": self.error,
                        "message": self.completion_message}

            pendientes = sum(
                1 for row in self.rows
                if _should_process(self.results.get(int(row["excel_row"]), {}).get("estado"))
                and int(row["excel_row"]) in self.files
            )
            return {
                "ok": True,
                "message": (
                    f"Conexión confirmada. {pendientes} fila(s) por ingresar de "
                    f"{len(self.rows)} en la planilla."
                ),
                "summary": self._summary_unlocked(),
            }

    def add_log(self, message: str) -> None:
        clean = " ".join(str(message or "").split())
        if not clean:
            return
        with self.lock:
            self.extension_seen_at = time.time()
            self.logs.append(clean[:500])
            self.logs = self.logs[-200:]

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self._summary_unlocked()

    def _summary_unlocked(self) -> dict[str, Any]:
        return {
            "bot_id": BOT_ID,
            "bot_label": BOT_LABEL,
            "extension_seen": self.extension_seen_at > 0,
            "extension_seen_at": self.extension_seen_at,
            "started": self.started_at > 0,
            "started_at": self.started_at,
            "portal_url": self.portal_url,
            "portal_title": self.portal_title,
            "input_path": self.input_path,
            "workbook": dict(self.workbook),
            "escritos": {
                "path": self.escritos.get("path", ""),
                "pdf_count": self.escritos.get("pdf_count", 0),
                "file_count": self.escritos.get("file_count", 0),
                "missing_count": len(self.escritos.get("missing", [])),
            },
            "phase": self.phase,
            "step_total": len(LOOP_STEPS),
            "steps_done": self.steps_done,
            "last_step_done": self.last_step_done,
            "rows_done": self.rows_done,
            "rows_ok": self.rows_ok,
            "row_total": len(self.rows),
            "completion_message": self.completion_message,
            "finished": self.finished,
            "error": self.error,
            "logs": list(self.logs),
        }


class _StageError:
    """Shape _possibly_created_note() expects, without the Playwright plumbing."""

    def __init__(self, stage: str, original: str):
        self.stage = stage
        self.original = original


class _MismatchError:
    """Shape _causa_mismatch_note() expects.

    The extension already produced the human-readable comparison in its error
    message, so it is passed through verbatim rather than re-derived here.
    """

    def __init__(self, step_name: str, detail: str):
        self.what = "Tribunal" if step_name == "select_tribunal" else "Caratulado"
        self.expected = "(ver detalle)"
        self.shown = detail


def _blank_result(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "excel_row": int(row["excel_row"]),
        "rol": str(row.get("ROL") or ""),
        "tribunal": str(row.get("TRIBUNAL") or ""),
        "estado": "",
        "detail": "",
        "note": "",
        "verificada": False,
    }


def _normalize_build(value: Any) -> str:
    text = str(value or "").strip().lower()
    return text[1:] if text.startswith("v") else text


def extension_manifest_version() -> str:
    manifest = Path(__file__).parent / "extension" / "manifest.json"
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    return str(payload.get("version") or "")


# ---------------------------------------------------------------------------
# HTTP bridge
# ---------------------------------------------------------------------------
class Rpa01BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], state: BridgeState):
        super().__init__(server_address, Rpa01BridgeHandler)
        self.state = state


class Rpa01BridgeHandler(BaseHTTPRequestHandler):
    server: Rpa01BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    def do_OPTIONS(self) -> None:
        self._send_empty(204)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "name": "RPA01 PJUD bridge",
                "summary": self.server.state.summary(),
            })
            return
        if self.path.startswith("/file"):
            self._serve_row_file()
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _serve_row_file(self) -> None:
        """Stream THIS row's escrito PDF as raw bytes.

        background.js relays this over the extension channel and base64-encodes
        it for content.js — the page is HTTPS and the bridge is plain HTTP, so
        a content script cannot fetch this endpoint directly.
        """
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        try:
            row_number = int((params.get("row") or [""])[0])
        except (TypeError, ValueError):
            row_number = 0

        path = self.server.state.resolve_row_file(row_number)
        if path is None:
            self._send_json(
                {"ok": False, "error": f"No hay escrito disponible para la fila {row_number}."},
                status=404,
            )
            return
        try:
            data = path.read_bytes()
        except OSError as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=500)
            return

        self.send_response(200)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.send_header("X-Filename", path.name)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self) -> None:
        if self.path.startswith("/start"):
            self._send_json(self.server.state.register_start(self._read_json()))
            return
        if self.path.startswith("/next"):
            self._send_json({"ok": True, "step": self.server.state.next_action()})
            return
        if self.path.startswith("/report"):
            self._send_json(self.server.state.report_action(self._read_json()))
            return
        if self.path.startswith("/log"):
            payload = self._read_json()
            message = str(payload.get("message") or "")
            self.server.state.add_log(message)
            print(f"RPA01[EXT]: {message}")
            self._send_json({"ok": True})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _send_empty(self, status: int) -> None:
        self.send_response(status)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------
def build_bridge_state(
    planilla_path: str,
    escritos_folder: str,
    *,
    documentos_firmados: bool = False,
    verify_tribunal: bool = True,
    fijar_datos: bool = False,
) -> BridgeState:
    """Validate every input and pre-resolve every row's file and status."""
    sheet_name, header, rows, preingreso_index = read_planilla(planilla_path)
    if not preingreso_index:
        preingreso_index = ensure_preingreso_column(planilla_path, sheet_name)
        # The insert shifted every column right by one, so re-read.
        sheet_name, header, rows, preingreso_index = read_planilla(planilla_path)

    escritos = inspect_escritos_folder(escritos_folder, rows, documentos_firmados)

    results: dict[int, dict[str, Any]] = {}
    for row in rows:
        excel_row = int(row["excel_row"])
        entry = _blank_result(row)
        entry["estado"] = _norm_status(row.get(PREINGRESO_COLUMN))
        results[excel_row] = entry

    # A row with no PDF never reaches the portal — flag it now, exactly as the
    # Playwright version did before opening the native file dialog.
    for excel_row, filename in escritos["missing"]:
        entry = results[excel_row]
        if _should_process(entry.get("estado")):
            entry["estado"] = STATUS_REVISAR
            entry["detail"] = f"archivo no encontrado: {filename}"
            entry["note"] = _missing_file_note(filename)

    workbook_info = {
        "filename": Path(planilla_path).name,
        "path": str(planilla_path),
        "sheet_name": sheet_name,
    }

    return BridgeState(
        input_path=str(planilla_path),
        sheet_name=sheet_name,
        workbook=workbook_info,
        escritos=escritos,
        documentos_firmados=documentos_firmados,
        rows=rows,
        source_header=header,
        preingreso_index=preingreso_index,
        verify_tribunal=verify_tribunal,
        fijar_datos=fijar_datos,
        results=results,
        files=escritos["resolved"],
    )


def run_bridge_session(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
    output_dir: str,
    source_path: str,
    output_copy_path: str,
    log_every_seconds: int = 15,
) -> dict[str, Any]:
    """Serve the loopback bridge until the extension finishes the planilla.

    Returns as soon as the session reports itself finished, or once the
    extension has been silent for EXTENSION_IDLE_SECONDS (tab closed mid-run).
    """
    try:
        server = Rpa01BridgeServer((host, port), state)
    except OSError as exc:
        raise InputError(
            f"No se pudo abrir el bridge local en {host}:{port}. "
            "Puede que otra ejecución de RPA01 siga abierta.",
            reason="bridge_ocupado",
            detail=str(exc),
        ) from exc

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"RPA01: bridge escuchando en http://{host}:{port}")
    print(f"[RPA01][SALIDA] {output_dir}")

    deadline = time.time() + timeout_seconds
    last_log = 0.0
    try:
        while time.time() < deadline:
            summary = state.summary()
            now = time.time()
            if summary["finished"]:
                return summary
            if summary["started"] and now - summary["extension_seen_at"] > EXTENSION_IDLE_SECONDS:
                state.add_log(
                    "La extensión dejó de responder tras Start; se cierra la "
                    f"sesión con {state.steps_done} paso(s) completado(s)."
                )
                return state.summary()
            if now - last_log >= log_every_seconds:
                if summary["started"]:
                    print(
                        f"RPA01: en curso | fila={summary['rows_done'] + 1}"
                        f"/{summary['row_total']} pasos_ok={summary['steps_done']}"
                    )
                else:
                    seen = "si" if summary["extension_seen"] else "no"
                    print(f"RPA01: esperando Start | extension_conectada={seen}")
                # Refresh the audit trail on the same tick. tasks.py writes it
                # again at the end, but only if it GETS there — a hard kill
                # never reaches that code, and an escrito already filed with no
                # record of it is exactly what this file exists to prevent.
                try:
                    write_preingreso_results(state, source_path, output_copy_path)
                except Exception as exc:  # noqa: BLE001
                    print(f"RPA01: no se pudo actualizar el resultado parcial ({exc}).")
                last_log = now
            time.sleep(0.5)
        raise TimeoutError(
            "RPA01: timeout esperando la conexión de la extensión de Chrome."
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3.0)


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------
def write_preingreso_results(
    state: BridgeState,
    source_path: str,
    output_copy_path: str,
) -> None:
    """Write PREINGRESO back to the source planilla AND the run's copy.

    The source keeps the run re-runnable (OK and REVISAR_MANUAL rows are never
    reprocessed); the copy is this run's own evidence.
    """
    from openpyxl import load_workbook

    flagged: list[tuple[int, str, str]] = []
    for entry in state.results.values():
        note = str(entry.get("note") or "")
        if note:
            flagged.append((int(entry["excel_row"]), str(entry["estado"]), note))

    for target in (source_path, output_copy_path):
        if not target:
            continue
        try:
            workbook = load_workbook(target)
            sheet = (
                workbook[state.sheet_name]
                if state.sheet_name in workbook.sheetnames
                else workbook.active
            )
            for entry in state.results.values():
                estado = str(entry.get("estado") or "")
                sheet.cell(
                    row=int(entry["excel_row"]),
                    column=state.preingreso_index,
                    value=estado or None,
                )
            workbook.save(target)
            workbook.close()
        except Exception as exc:  # noqa: BLE001
            print(f"[RPA01][WARN] No se pudo escribir PREINGRESO en {target}: {exc}")
            continue
        # Painting and the hover comments are best-effort and run with the
        # workbook closed, so a styling failure can never fail the run.
        _mark_missing_file_cells(target, state.preingreso_index, flagged, state.sheet_name)


def build_result_tally(state: BridgeState) -> str:
    tally: dict[str, int] = {}
    for entry in state.results.values():
        estado = str(entry.get("estado") or "SIN PROCESAR")
        tally[estado] = tally.get(estado, 0) + 1
    return json.dumps(tally, ensure_ascii=False)


def build_result_summary_json(state: BridgeState) -> str:
    rows = [
        {
            "fila": entry["excel_row"],
            "rol": entry["rol"],
            "tribunal": entry["tribunal"],
            "preingreso": entry["estado"],
            "verificada": entry["verificada"],
            "detalle": entry["detail"],
        }
        for entry in sorted(state.results.values(), key=lambda item: item["excel_row"])
    ]
    return json.dumps({"rows": rows}, ensure_ascii=False)


def write_bridge_receipt(summary: dict[str, Any], output_dir: str) -> str:
    """Persist a small receipt proving that the desktop/extension bridge worked."""
    target = Path(output_dir) / "bridge_connection.json"
    payload = dict(summary)
    payload["written_at"] = datetime.now().isoformat(timespec="seconds")
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(target)
