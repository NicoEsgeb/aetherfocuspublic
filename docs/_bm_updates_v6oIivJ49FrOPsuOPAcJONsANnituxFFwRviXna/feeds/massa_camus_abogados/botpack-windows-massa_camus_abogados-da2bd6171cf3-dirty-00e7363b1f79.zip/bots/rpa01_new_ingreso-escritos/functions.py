"""
RPA01 NEW - Ingreso de Escritos — business logic
=================================================

Why the verification layer exists
---------------------------------
ROL numbers are NOT unique across juzgados: in a real client planilla, 31 ROLs
appeared in 2-5 different tribunales (e.g. 1149-2026 exists in 1o, 10o, 20o,
25o and 28o). So when the Tribunal dropdown lands on the wrong juzgado,
"Consulta Rol" still SUCCEEDS — it finds a real, different causa — and the
escrito is filed into the wrong expediente. That single event produces both
symptoms the client reported: one causa gets an extra escrito, the causa it
belonged to gets none.

Two independent guards now sit in front of "Grabar Escrito" (the point of no
return, after which an escrito exists in the Bandeja):

  1. TRIBUNAL  — selected preferring the native <select>, then READ BACK and
                 compared. Never assumed.
  2. CARATULA  — after "Consulta Rol", the carátula shown by PJUD is compared
                 against the planilla's CARATULA column. For all 31 colliding
                 ROLs in the client sample, every tribunal had a DISTINCT
                 carátula, so this alone identifies a wrong causa.

Both guards distinguish "verified and wrong" (abort the row, nothing is
created) from "could not verify" (log loudly, keep going). A run where nothing
can be verified trips a circuit breaker and stops early instead of burning the
whole planilla — see VERIFY_PROBE_ROWS.

Everything either guard sees is written to a per-run debug log next to the
output planilla, so a client validation run can be diagnosed afterwards.
"""
from RPA.Excel.Files import Files as Excel
from robocorp import browser
from robocorp import windows
import json
import os
import re
import shutil
import time
import traceback
import unicodedata
from datetime import datetime
from pathlib import Path


# ---------------------------------------------------------------------------
# Row status vocabulary
# ---------------------------------------------------------------------------
# The critical distinction is whether an escrito may already exist in the
# Bandeja. "Grabar Escrito" creates it; everything after that line can still
# fail. Retrying such a row is exactly how the client ended up with the same
# escrito uploaded two and three times, so it gets its own terminal status.
STATUS_OK = "OK"
STATUS_ERROR = "ERROR"                    # failed BEFORE Grabar Escrito -> safe to retry
STATUS_REVISAR = "REVISAR"                # input/causa problem, nothing created -> safe to retry
STATUS_REVISAR_MANUAL = "REVISAR_MANUAL"  # failed AFTER Grabar Escrito -> NEVER auto-retry

# Statuses that must never be reprocessed automatically.
_TERMINAL_STATUSES = (STATUS_OK, STATUS_REVISAR_MANUAL)


# ---------------------------------------------------------------------------
# Run-time switches
# ---------------------------------------------------------------------------
def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.getenv(name, "").strip().lower()
    if raw in ("1", "true", "si", "sí", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(str(os.getenv(name, "")).strip())
    except (TypeError, ValueError):
        return default


VERIFY_TRIBUNAL = _env_flag("RPA01_VERIFY_TRIBUNAL", True)
VERIFY_CARATULA = _env_flag("RPA01_VERIFY_CARATULA", True)
ENVIO_ENFORCE_COUNT = _env_flag("RPA01_ENVIO_ENFORCE_COUNT", True)

# "off" (default, deterministic clean form) | "on" | "legacy" (blind toggle) | "skip"
FIJAR_DATOS_MODE = (os.getenv("RPA01_FIJAR_DATOS", "off").strip().lower() or "off")

# Circuit breaker: if the first N processed rows yield ZERO successful
# verifications, the portal markup no longer matches our probes. Stop the run
# instead of proceeding blind across the whole planilla.
VERIFY_PROBE_ROWS = _env_int("RPA01_VERIFY_PROBE_ROWS", 5)


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------
class EscritoFileNotFound(Exception):
    """
    Raised when the PDF for a row is missing from the escritos folder.

    Checked BEFORE any portal interaction so the row can be flagged REVISAR and
    the batch can continue — critically, it prevents the native Windows "Abrir"
    file dialog from opening on a non-existent file, which otherwise stays open
    and jams every subsequent row.
    """

    def __init__(self, filename: str, path: str):
        self.filename = filename
        self.path = path
        super().__init__(f"Archivo no encontrado: {filename}")


class CausaVerificationError(Exception):
    """
    Raised when the portal is demonstrably NOT on the causa this row targets.

    Always raised BEFORE "Grabar Escrito", so no escrito is created and the row
    is safely retryable once the planilla or the portal state is corrected.
    """

    def __init__(self, what: str, expected: str, shown: str):
        self.what = what
        self.expected = expected
        self.shown = shown
        super().__init__(
            f"{what} no coincide — planilla esperaba '{expected}' y el portal muestra '{shown}'"
        )


class EscritoPossiblyCreated(Exception):
    """
    Raised when a step FAILED AFTER "Grabar Escrito".

    The escrito may already be sitting in the Bandeja, so the row must never be
    retried automatically — it is flagged REVISAR_MANUAL for a human.
    """

    def __init__(self, stage: str, original: BaseException):
        self.stage = stage
        self.original = original
        super().__init__(f"Falla despues de Grabar Escrito (etapa '{stage}'): {original}")


class VerificationUnavailable(Exception):
    """Circuit breaker: no row could be verified, so the run is aborted early."""


# ---------------------------------------------------------------------------
# Text normalisation
# ---------------------------------------------------------------------------
def _strip_accents(value: str) -> str:
    decomposed = unicodedata.normalize("NFD", str(value or ""))
    return "".join(ch for ch in decomposed if unicodedata.category(ch) != "Mn")


def _norm(value) -> str:
    """
    Uppercase, accent-free, punctuation-free, whitespace-collapsed.

    Also flattens the ordinal indicators, because the planilla writes the
    tribunal with DEGREE SIGN ("10°") while PJUD renders MASCULINE ORDINAL
    ("10º JUZGADO CIVIL DE SANTIAGO"). Comparing them raw never matches.
    """
    text = _strip_accents(value).upper()
    text = re.sub(r"[^A-Z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _norm_status(value) -> str:
    token = str(value if value is not None else "").strip().upper()
    return "" if token in ("", "NONE", "NAN") else token


def _should_process(value) -> bool:
    """
    Whether a planilla row should be (re)processed.

    Deliberately a minimal widening of the old `!= 'OK'` rule: everything still
    retries, EXCEPT rows whose escrito may already exist in the Bandeja.
    """
    return _norm_status(value) not in _TERMINAL_STATUSES


def _tribunal_numero(tribunal_raw) -> str:
    """'10°' -> '10'. Tolerates '10', '10º', '10 °', ' 10° '."""
    digits = re.sub(r"\D", "", str(tribunal_raw or ""))
    if not digits:
        raise ValueError(f"TRIBUNAL invalido en la planilla: '{tribunal_raw}'")
    return str(int(digits))


def _tribunal_portal_label(numero: str) -> str:
    """The option text PJUD renders, lowercase — matching what the bot types."""
    return f"{numero}º juzgado civil de santiago"


def _caratula_key(caratula) -> str:
    """
    The discriminating part of a carátula: whatever follows the last '/'.

    'BANCO ITAU CHILE S.A./GUERRERO' -> 'GUERRERO'. The bank side is identical
    on every row; the demandado is what differs between colliding ROLs.
    """
    text = str(caratula or "")
    part = text.rsplit("/", 1)[-1] if "/" in text else text
    return _norm(part)


def _caratula_matches(expected, shown) -> bool:
    key = _caratula_key(expected)
    shown_norm = _norm(shown)
    if not key or not shown_norm:
        return False
    if key in shown_norm:
        return True
    tokens = [token for token in key.split(" ") if len(token) > 2]
    return bool(tokens) and all(token in shown_norm for token in tokens)


# ---------------------------------------------------------------------------
# Debug log
# ---------------------------------------------------------------------------
class RunDebugLog:
    """
    Per-run trace written next to the output planilla.

    Two files, flushed after every row so a crash still leaves a usable trace:
      rpa01_debug_<task>.log    human readable, one block per row
      rpa01_debug_<task>.jsonl  one JSON object per row, for analysis

    Key lines are also printed with an [RPA01] prefix so they show up in the
    BotManager run log without opening any file.
    """

    def __init__(self, output_dir, task_name: str):
        override = os.getenv("RPA01_DEBUG_DIR", "").strip()
        self.dir = Path(override or output_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.task = task_name
        self.started_at = datetime.now()
        self.txt_path = self.dir / f"rpa01_debug_{task_name}.log"
        self.jsonl_path = self.dir / f"rpa01_debug_{task_name}.jsonl"
        self.rows = []
        self._current = None
        self.verified_rows = 0
        self.unverified_rows = 0

        self._write_txt(
            "=" * 78,
            f"RPA01 · {task_name} · debug log",
            f"inicio            : {self.started_at:%Y-%m-%d %H:%M:%S}",
            f"verificar tribunal: {VERIFY_TRIBUNAL}",
            f"verificar caratula: {VERIFY_CARATULA}",
            f"fijar datos       : {FIJAR_DATOS_MODE}",
            f"envio: contar sel.: {ENVIO_ENFORCE_COUNT}",
            f"filas de sondeo   : {VERIFY_PROBE_ROWS}",
            "=" * 78,
            "",
        )
        print(f"[RPA01][DEBUG_LOG] {self.txt_path}")
        print(f"[RPA01][DEBUG_JSONL] {self.jsonl_path}")

    # -- internals ---------------------------------------------------------
    def _write_txt(self, *lines: str) -> None:
        try:
            with self.txt_path.open("a", encoding="utf-8") as handle:
                for line in lines:
                    handle.write(f"{line}\n")
        except Exception as exc:  # a logging failure must never fail a run
            print(f"[RPA01][DEBUG][WARN] no se pudo escribir el log: {exc}")

    def _tag(self) -> str:
        if not self._current:
            return "[RPA01]"
        return (
            f"[RPA01][fila={self._current['fila']}]"
            f"[rol={self._current['rol']}][trib={self._current['tribunal']}]"
        )

    # -- public API --------------------------------------------------------
    def start_row(self, fila: int, row) -> None:
        self._current = {
            "fila": fila,
            "rol": str(row.get("ROL", "") or ""),
            "tribunal": str(row.get("TRIBUNAL", "") or ""),
            "rut": str(row.get("RUT", "") or ""),
            "dv": str(row.get("DV", "") or ""),
            "caratula_planilla": str(row.get("CARATULA", "") or ""),
            "estado_previo": _norm_status(row.get("PREINGRESO", "")),
            "iniciada": datetime.now().isoformat(timespec="seconds"),
            "eventos": [],
            "checks": {},
        }
        self._write_txt(
            f"--- fila {fila} · ROL {self._current['rol']} · Tribunal "
            f"{self._current['tribunal']} · RUT {self._current['rut']}-{self._current['dv']}"
        )

    def note(self, key: str, value) -> None:
        if self._current is not None:
            self._current["checks"][key] = value
        self._write_txt(f"      {key}: {value}")

    def event(self, level: str, message: str, **fields) -> None:
        entry = {"nivel": level, "mensaje": message, **fields}
        if self._current is not None:
            self._current["eventos"].append(entry)
        detail = " ".join(f"{k}={v!r}" for k, v in fields.items())
        self._write_txt(f"      [{level}] {message}{(' | ' + detail) if detail else ''}")
        if level in ("WARN", "ERROR"):
            print(f"{self._tag()}[{level}] {message}{(' | ' + detail) if detail else ''}")

    def count_verification(self, verified: bool) -> None:
        if verified:
            self.verified_rows += 1
        else:
            self.unverified_rows += 1

    def check_circuit_breaker(self) -> None:
        """Abort the run if the first probe rows produced no verification at all."""
        processed = self.verified_rows + self.unverified_rows
        if self.verified_rows == 0 and processed >= VERIFY_PROBE_ROWS > 0:
            raise VerificationUnavailable(
                f"Ninguna de las primeras {processed} filas pudo verificarse contra el "
                f"portal (ni Tribunal ni Caratulado se pudieron leer). Se detiene la "
                f"corrida para no ingresar escritos a ciegas. Envie el archivo "
                f"'{self.txt_path.name}' para revisar los selectores."
            )

    def end_row(self, status: str, detail: str = "") -> None:
        if self._current is None:
            return
        self._current["estado"] = status
        self._current["detalle"] = detail
        self._current["terminada"] = datetime.now().isoformat(timespec="seconds")
        self.rows.append(self._current)
        self._write_txt(f"   => {status}{(' · ' + detail) if detail else ''}", "")
        try:
            with self.jsonl_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(self._current, ensure_ascii=False) + "\n")
        except Exception as exc:
            print(f"[RPA01][DEBUG][WARN] no se pudo escribir el jsonl: {exc}")
        print(f"{self._tag()} {status}{(' · ' + detail) if detail else ''}")
        self._current = None

    def close(self, summary: dict) -> None:
        summary = dict(summary)
        summary["filas_verificadas"] = self.verified_rows
        summary["filas_sin_verificar"] = self.unverified_rows
        lines = ["", "=" * 78, "RESUMEN"]
        lines += [f"  {key:24}: {value}" for key, value in summary.items()]
        lines += [
            f"  {'duracion':24}: {datetime.now() - self.started_at}",
            "=" * 78,
        ]
        self._write_txt(*lines)
        print(f"[RPA01][DEBUG_LOG] {self.txt_path}")


# ---------------------------------------------------------------------------
# Portal read-back probes
# ---------------------------------------------------------------------------
def _label_pattern(label_text: str) -> re.Pattern:
    spaced = r"\s+".join(re.escape(part) for part in label_text.strip().split())
    return re.compile(spaced, re.IGNORECASE)


def _first_visible_label(page, label_text: str):
    labels = page.locator("label", has_text=_label_pattern(label_text))
    try:
        total = labels.count()
    except Exception:
        return None
    if total == 0:
        return None
    for index in range(total):
        candidate = labels.nth(index)
        try:
            if candidate.is_visible():
                return candidate
        except Exception:
            continue
    return labels.first


def _read_control_text(page, label_text: str, *, timeout_ms: int = 4000):
    """
    Read the value currently shown by the control next to `label_text`.

    Returns (text, strategy). `text` is None when nothing could be read — that
    is reported as "unverified", never silently treated as a match.
    """
    label = _first_visible_label(page, label_text)
    if label is None:
        return None, "label-no-encontrado"

    probes = (
        ("native-select", "xpath=../select[1]"),
        ("native-select-anc", "xpath=ancestor::div[1]//select[1]"),
        ("select2-chosen", "xpath=../div//*[contains(@class,'select2-chosen')][1]"),
        ("select2-chosen-anc", "xpath=ancestor::div[1]//*[contains(@class,'select2-chosen')][1]"),
        ("input", "xpath=../input[not(@type='hidden')][1]"),
        ("input-anc", "xpath=ancestor::div[1]//input[not(@type='hidden')][1]"),
        ("texto", "xpath=../*[self::span or self::p or self::strong or self::b][normalize-space()!=''][1]"),
        ("texto-anc", "xpath=ancestor::div[1]//*[self::span or self::p or self::strong or self::b][normalize-space()!=''][1]"),
    )
    for strategy, xpath in probes:
        try:
            locator = label.locator(xpath).first
            if locator.count() == 0:
                continue
            if strategy.startswith("native-select"):
                text = locator.evaluate(
                    "el => (el.selectedOptions && el.selectedOptions.length)"
                    " ? el.selectedOptions[0].textContent : (el.value || '')"
                )
            elif strategy.startswith("input"):
                text = locator.input_value(timeout=timeout_ms)
            else:
                text = locator.inner_text(timeout=timeout_ms)
            text = str(text or "").strip()
            if text:
                return text, strategy
        except Exception:
            continue

    # Last resort: read the whole container and subtract the label itself. Some
    # OJV read-only fields are plain text nodes with no element of their own.
    try:
        container = label.locator("xpath=ancestor::div[1]").first
        if container.count() > 0:
            whole = str(container.inner_text(timeout=timeout_ms) or "").strip()
            label_text_shown = str(label.inner_text(timeout=timeout_ms) or "").strip()
            remainder = whole.replace(label_text_shown, " ", 1).strip(" :\n\t")
            if remainder:
                return remainder, "contenedor"
    except Exception:
        pass

    return None, "ilegible"


# ---------------------------------------------------------------------------
# Tribunal selection — select, then PROVE it
# ---------------------------------------------------------------------------
def _try_tribunal_native(page, wanted_label: str) -> str | None:
    """Select on the real <select>, which fires proper change events."""
    label = _first_visible_label(page, "Tribunal")
    if label is None:
        return None
    wanted_norm = _norm(wanted_label)
    for xpath in ("xpath=../select[1]", "xpath=ancestor::div[1]//select[1]"):
        try:
            select = label.locator(xpath).first
            if select.count() == 0:
                continue
            options = select.locator("option")
            for index in range(options.count()):
                if _norm(options.nth(index).inner_text() or "") == wanted_norm:
                    select.select_option(index=index)
                    return "native-select"
        except Exception:
            continue
    return None


def _try_tribunal_typeahead(page, numero: str, wanted_label: str) -> str:
    """
    The historical keyboard path, byte-for-byte.

    Kept as a fallback so behaviour degrades to what shipped before rather than
    to nothing — but it is now always followed by a read-back, which is exactly
    what it never had.
    """
    page.locator("xpath=//label[contains(.,'Tribunal')]").wait_for()
    page.locator("xpath=//label[contains(.,'Tribunal')]").click()
    page.press("body", "Tab")
    page.press("body", "ArrowDown")
    page.keyboard.type(wanted_label)
    time.sleep(2)

    entero = int(numero)
    if entero == 2:
        page.press("body", "ArrowDown")
    elif 2 < entero < 10:
        page.press("body", "ArrowDown")
        page.press("body", "ArrowDown")

    time.sleep(1)
    return "typeahead-legacy"


def _select_tribunal_verified(page, tribunal_raw, dbg: RunDebugLog, *, attempts: int = 3) -> bool:
    """
    Select the tribunal and confirm it on screen.

    Returns True when the selection was positively verified, False when it could
    not be read at all. Raises CausaVerificationError when it WAS read and is
    wrong — that is the case that used to file escritos into another causa.
    """
    numero = _tribunal_numero(tribunal_raw)
    wanted_label = _tribunal_portal_label(numero)
    wanted_norm = _norm(wanted_label)
    shown = None
    strategy = "no-intentado"

    for attempt in range(1, attempts + 1):
        method = _try_tribunal_native(page, wanted_label) if attempt == 1 else None
        if method is None:
            method = _try_tribunal_typeahead(page, numero, wanted_label)
        page.press("body", "Tab")

        if not VERIFY_TRIBUNAL:
            dbg.note("tribunal", f"seleccionado via {method} (verificacion desactivada)")
            return False

        shown, strategy = _read_control_text(page, "Tribunal")
        if shown is None:
            dbg.event(
                "WARN",
                "No se pudo LEER el tribunal seleccionado — la fila continua sin verificar",
                via=strategy,
                metodo=method,
            )
            dbg.note("tribunal", f"sin verificar (metodo={method}, sonda={strategy})")
            return False

        if _norm(shown) == wanted_norm or wanted_norm in _norm(shown):
            dbg.note(
                "tribunal",
                f"OK '{shown}' (metodo={method}, sonda={strategy}, intento={attempt})",
            )
            return True

        dbg.event(
            "WARN",
            "Tribunal incorrecto tras seleccionar — reintentando",
            esperado=wanted_label,
            portal=shown,
            metodo=method,
            intento=attempt,
        )

    raise CausaVerificationError("Tribunal", wanted_label, str(shown))


# ---------------------------------------------------------------------------
# Carátula guard
# ---------------------------------------------------------------------------
def _verify_caratula(page, row, dbg: RunDebugLog) -> bool:
    """
    Compare the carátula PJUD shows against the planilla's CARATULA column.

    Returns True when positively verified, False when it could not be checked.
    Raises CausaVerificationError on a real mismatch — before Grabar Escrito, so
    nothing is created.
    """
    if not VERIFY_CARATULA:
        dbg.note("caratula", "verificacion desactivada")
        return False

    expected = str(row.get("CARATULA", "") or "").strip()
    if not expected:
        dbg.event("WARN", "La planilla no trae CARATULA para esta fila — no se puede verificar la causa")
        dbg.note("caratula", "sin verificar (planilla sin CARATULA)")
        return False

    # "Consulta Rol" fills the carátula asynchronously and the LABEL exists
    # before the value does, so poll instead of reading once.
    shown, strategy = None, "ilegible"
    deadline = time.time() + 8
    while time.time() < deadline:
        shown, strategy = _read_control_text(page, "Caratulado")
        if shown:
            break
        time.sleep(0.5)

    if not shown:
        dbg.event("WARN", "No se pudo LEER el Caratulado del portal", via=strategy)
        dbg.note("caratula", "sin verificar (ilegible)")
        return False

    if _caratula_matches(expected, shown):
        dbg.note("caratula", f"OK planilla='{expected}' portal='{shown}' (sonda={strategy})")
        return True

    dbg.event(
        "ERROR",
        "CAUSA EQUIVOCADA — el portal abrio otra caratula para este ROL",
        planilla=expected,
        clave=_caratula_key(expected),
        portal=shown,
    )
    raise CausaVerificationError("Caratulado", expected, shown)


# ---------------------------------------------------------------------------
# "Fijar Datos" — set it, do not toggle it
# ---------------------------------------------------------------------------
def _find_fijar_datos_checkbox(page):
    candidates = (
        "xpath=//label[contains(.,'Fijar Datos')]//input[@type='checkbox']",
        "xpath=//label[contains(.,'Fijar Datos')]/../input[@type='checkbox']",
        "xpath=//label[contains(.,'Fijar Datos')]/preceding-sibling::input[@type='checkbox'][1]",
        "xpath=//input[@type='checkbox'][following-sibling::label[contains(.,'Fijar Datos')]]",
    )
    for selector in candidates:
        try:
            locator = page.locator(selector).first
            if locator.count() > 0:
                return locator
        except Exception:
            continue
    return None


def _click_fijar_datos(page) -> None:
    page.locator("label").filter(has_text="Fijar Datos").locator("path").nth(1).click()


def _set_fijar_datos(page, dbg: RunDebugLog) -> None:
    """
    Historically this was an UNCONDITIONAL click on a checkbox — i.e. a toggle.
    It flipped on/off on alternating rows, so every other escrito was filled
    into a form that PJUD had pre-populated with the previous causa's data.
    That is a large part of why the failures looked random.
    """
    if FIJAR_DATOS_MODE == "skip":
        dbg.note("fijar_datos", "omitido")
        return

    if FIJAR_DATOS_MODE == "legacy":
        _click_fijar_datos(page)
        dbg.note("fijar_datos", "toggle-legacy (comportamiento anterior)")
        return

    desired = FIJAR_DATOS_MODE == "on"
    checkbox = _find_fijar_datos_checkbox(page)
    if checkbox is None:
        dbg.event("WARN", "No se encontro el checkbox 'Fijar Datos' — no se toca (antes se alternaba en cada fila)")
        dbg.note("fijar_datos", "no encontrado (sin accion)")
        return

    try:
        current = checkbox.is_checked()
    except Exception as exc:
        dbg.event("WARN", f"No se pudo leer el estado de 'Fijar Datos' — no se toca: {exc}")
        dbg.note("fijar_datos", "ilegible (sin accion)")
        return

    if current == desired:
        dbg.note("fijar_datos", f"ya estaba {'ON' if desired else 'OFF'}")
        return

    try:
        _click_fijar_datos(page)
    except Exception:
        try:
            checkbox.click(force=True)
        except Exception as exc:
            dbg.event("WARN", f"No se pudo cambiar 'Fijar Datos': {exc}")
            return

    try:
        after = checkbox.is_checked()
    except Exception:
        after = None
    dbg.note("fijar_datos", f"{'ON' if desired else 'OFF'} (antes={current}, despues={after})")


# ---------------------------------------------------------------------------
# Excel helpers
# ---------------------------------------------------------------------------
def _mark_missing_file_cells(xlsx_path, col_index, revisar_rows, sheet="Hoja1"):
    """
    Paint each flagged PREINGRESO cell and attach a hover comment explaining why.

    Uses openpyxl directly (RPA.Excel.Files cannot set fills/comments) and is
    best-effort: a styling failure must never fail the run.
    """
    if not revisar_rows:
        return
    try:
        from openpyxl import load_workbook
        from openpyxl.comments import Comment
        from openpyxl.styles import PatternFill

        fills = {
            STATUS_REVISAR: PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid"),
            STATUS_REVISAR_MANUAL: PatternFill(start_color="FFFFA500", end_color="FFFFA500", fill_type="solid"),
        }
        wb = load_workbook(xlsx_path)
        ws = wb[sheet] if sheet in wb.sheetnames else wb.active
        for row_number, status, note in revisar_rows:
            cell = ws.cell(row=row_number, column=col_index)
            fill = fills.get(status)
            if fill is not None:
                cell.fill = fill
            comment = Comment(note, "RPA01")
            comment.width = 340
            comment.height = 180
            cell.comment = comment
        wb.save(xlsx_path)
    except Exception as exc:
        print(f"[RPA01][PREINGRESO][WARN] No se pudo aplicar estilo REVISAR a {xlsx_path}: {exc}")


def _missing_file_note(filename: str) -> str:
    return (
        "No se encontró el archivo PDF de este escrito:\n"
        f"«{filename}»\n"
        "en la carpeta input/escritos.\n\n"
        "Verifique que el archivo exista y tenga exactamente ese "
        "nombre, luego vuelva a procesar la planilla."
    )


def _causa_mismatch_note(error: CausaVerificationError) -> str:
    return (
        "El bot NO ingresó este escrito porque el portal abrió otra causa.\n\n"
        f"{error.what} esperado según la planilla:\n«{error.expected}»\n"
        f"{error.what} que mostró el Poder Judicial:\n«{error.shown}»\n\n"
        "Los ROL se repiten entre juzgados, así que un tribunal mal seleccionado "
        "abre una causa distinta que igual existe. No se creó ningún escrito: "
        "corrija la fila y vuelva a procesar."
    )


def _possibly_created_note(error: EscritoPossiblyCreated) -> str:
    return (
        "ATENCIÓN — revisar en el Poder Judicial antes de reintentar.\n\n"
        f"El escrito ya fue GRABADO y luego falló en la etapa «{error.stage}»:\n"
        f"{error.original}\n\n"
        "Es probable que el escrito ya esté en la Bandeja. El bot NO volverá a "
        "procesar esta fila automáticamente para no subirlo dos veces. "
        "Verifique la Bandeja: si está completo márquelo OK, si no existe "
        "borre esta celda para reintentar."
    )


def _select_causa_year(page, year: str):
    year_text = str(year).strip()
    if not year_text:
        raise ValueError("Ano vacio para consulta de causa.")

    year_container = page.locator("div.select2-container.pg-select2-year-control").first
    year_container.wait_for()
    selected_year = year_container.locator(".select2-chosen").first

    # Always re-select the year from the dropdown, even when the visible value
    # already matches (e.g. the default 2026). Skipping the selection leaves the
    # form's year/Rol state uncommitted, so "Consulta Rol" does nothing and the
    # bot stalls until the button is clicked manually.
    year_container.locator("a.select2-choice").click()
    dropdown = page.locator("div.select2-drop-active.pg-select2-year-dropdown").first
    dropdown.wait_for(state="visible")

    search_input = dropdown.locator("input.select2-input").first
    search_input.fill("")
    search_input.type(year_text)

    dropdown.locator(".select2-result-label", has_text=year_text).first.click()
    time.sleep(0.5)

    final_year = selected_year.inner_text().strip()
    if final_year != year_text:
        raise RuntimeError(f"No se pudo seleccionar el ano '{year_text}'. Quedo '{final_year}'.")


# ---------------------------------------------------------------------------
# Ingreso — RETIRED Playwright path
# ---------------------------------------------------------------------------
# RPA_01_Ingreso NO LONGER CALLS ANY OF THIS. PJUD's WAF blocks the automated
# browser these functions drive, so the task was moved to the attended
# Chrome-extension bridge in bridge.py (LOOP_STEPS is the step-by-step
# equivalent of fill_form_escritos below, and the extension's content.js
# performs each step on the operator's own logged-in page).
#
# Kept, not deleted, until the attended route has been validated against the
# live portal — three of its steps (solicitante / tipo escrito / materia) were
# blind keyboard typeahead here and their real option wording can only be
# confirmed on the real form. This is the reference for what they used to do.
#
# read_excel_preingreso -> bridge.build_bridge_state + run_bridge_session
# fill_form_escritos    -> bridge.LOOP_STEPS + extension/content.js
# and with them the only functions that still import robocorp.windows.
#
# Everything below is unreachable from tasks.py. Do not add to it: fix the
# bridge instead.
def read_excel_preingreso(path: str, escritos_DCP_Path: str, ingreso_output_dir: str, documentos_firmados: bool = False):
    """
    open and read an excel file for preingreso.
    Writes OK/ERROR to the source (for re-runability) and to a copy in the output dir.
    """
    print('Preingreso')
    dbg = RunDebugLog(ingreso_output_dir, "ingreso")
    source_excel = Excel()
    run_excel = Excel()

    source_path = Path(path)
    output_copy_name = "output_" + source_path.name
    output_copy_path = str(Path(ingreso_output_dir) / output_copy_name)
    shutil.copy2(str(source_path), output_copy_path)
    print(f"[PREINGRESO] Planilla origen: {source_path}")
    print(f"[PREINGRESO] Planilla salida: {output_copy_path}")

    source_excel.open_workbook(str(source_path))
    rows = source_excel.read_worksheet_as_table("Hoja1", header=True)
    preingresoIndex = 1
    if not rows.columns.__contains__("PREINGRESO"):
        source_excel.insert_columns_before(1, 1)
        source_excel.set_cell_value(1, 1, "PREINGRESO")
        source_excel.save_workbook(str(source_path))
    else:
        preingresoIndex = rows.columns.index("PREINGRESO") + 1

    run_excel.open_workbook(output_copy_path)
    run_rows = run_excel.read_worksheet_as_table("Hoja1", header=True)
    run_preingresoIndex = 1
    if not run_rows.columns.__contains__("PREINGRESO"):
        run_excel.insert_columns_before(1, 1)
        run_excel.set_cell_value(1, 1, "PREINGRESO")
        run_excel.save_workbook(output_copy_path)
    else:
        run_preingresoIndex = run_rows.columns.index("PREINGRESO") + 1

    # Clear previous values in the run copy so it reflects only this run
    run_rows = run_excel.read_worksheet_as_table("Hoja1", header=True)
    for i, _ in enumerate(run_rows):
        run_excel.set_cell_value(i + 2, run_preingresoIndex, "")
    run_excel.save_workbook(output_copy_path)

    rows = source_excel.read_worksheet_as_table("Hoja1", header=True)
    if not rows.columns.__contains__("CARATULA"):
        print(
            "[RPA01][PREINGRESO][WARN] La planilla no tiene columna CARATULA: no se podra "
            "verificar que el portal abra la causa correcta."
        )

    numero = 2
    print(preingresoIndex)
    processed_count = 0
    ok_count = 0
    error_count = 0
    revisar_count = 0
    manual_count = 0
    skipped_manual = 0
    flagged_cells = []  # (rowNumber, status, note) → styled + hover comment after save
    summary_rows = []
    aborted_reason = ""

    def _record(status: str, note: str | None = None, **extra):
        source_excel.set_cell_value(numero, preingresoIndex, status)
        run_excel.set_cell_value(numero, run_preingresoIndex, status)
        if note is not None:
            flagged_cells.append((numero, status, note))
        summary_rows.append(
            {
                "ok": status == STATUS_OK,
                "rol": str(row.get("ROL", "") or ""),
                "tribunal": str(row.get("TRIBUNAL", "") or ""),
                "preingreso": status,
                "rowNumber": numero,
                **extra,
            }
        )

    try:
        for row in rows:
            previous_status = _norm_status(row.get("PREINGRESO", ""))
            if previous_status == STATUS_REVISAR_MANUAL:
                skipped_manual += 1
                print(
                    f"[RPA01][PREINGRESO][SKIP] fila={numero} rol={row.get('ROL', '')} "
                    f"marcada {STATUS_REVISAR_MANUAL}: el escrito puede existir en la Bandeja, "
                    f"revisar a mano antes de reintentar."
                )

            if _should_process(previous_status):
                processed_count += 1
                dbg.start_row(numero, row)
                try:
                    verified = fill_form_escritos(row, escritos_DCP_Path, documentos_firmados, dbg)
                    dbg.count_verification(verified)
                    _record(STATUS_OK)
                    ok_count += 1
                    dbg.end_row(STATUS_OK)
                    print(row["ROL"])

                except EscritoFileNotFound as e:
                    # Missing input PDF — flag REVISAR (not ERROR) and keep going.
                    # No portal interaction happened, so no browser reset is needed.
                    print(f"[RPA01][PREINGRESO][REVISAR] fila={numero} rol={row.get('ROL', '')} archivo_no_encontrado={e.filename}")
                    _record(STATUS_REVISAR, _missing_file_note(e.filename), archivo=e.filename)
                    revisar_count += 1
                    dbg.end_row(STATUS_REVISAR, f"archivo no encontrado: {e.filename}")

                except CausaVerificationError as e:
                    # Verified wrong causa — nothing was created, safe to retry.
                    print(
                        f"[RPA01][PREINGRESO][REVISAR] fila={numero} rol={row.get('ROL', '')} "
                        f"causa_incorrecta {e.what}: esperado='{e.expected}' portal='{e.shown}'"
                    )
                    _record(STATUS_REVISAR, _causa_mismatch_note(e), motivo=str(e))
                    revisar_count += 1
                    dbg.count_verification(True)
                    dbg.end_row(STATUS_REVISAR, str(e))
                    browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")

                except EscritoPossiblyCreated as e:
                    # Failed AFTER Grabar Escrito: never auto-retry this row.
                    print(
                        f"[RPA01][PREINGRESO][REVISAR_MANUAL] fila={numero} rol={row.get('ROL', '')} "
                        f"etapa={e.stage} error={e.original}"
                    )
                    _record(STATUS_REVISAR_MANUAL, _possibly_created_note(e), etapa=e.stage, motivo=str(e.original))
                    manual_count += 1
                    dbg.end_row(STATUS_REVISAR_MANUAL, f"etapa={e.stage}: {e.original}")
                    browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")

                except Exception as e:
                    print(f"[RPA01][PREINGRESO][ERROR] fila={numero} rol={row.get('ROL', '')} error={e}")
                    dbg.event("ERROR", "Falla antes de Grabar Escrito", error=str(e))
                    dbg.event("ERROR", "traceback", detalle=traceback.format_exc(limit=6))
                    _record(STATUS_ERROR, motivo=str(e))
                    error_count += 1
                    dbg.end_row(STATUS_ERROR, str(e))
                    browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")

                dbg.check_circuit_breaker()

            source_excel.save_workbook(str(source_path))
            run_excel.save_workbook(output_copy_path)
            numero = numero + 1

    except VerificationUnavailable as e:
        aborted_reason = str(e)
        print(f"[RPA01][PREINGRESO][ABORTADO] {e}")

    source_excel.save_workbook(str(source_path))
    run_excel.save_workbook(output_copy_path)
    source_excel.close_workbook()
    run_excel.close_workbook()

    # Paint flagged cells + attach the explanatory hover comment. Done after the
    # RPA workbooks are closed so the files aren't locked.
    _mark_missing_file_cells(str(source_path), preingresoIndex, flagged_cells)
    _mark_missing_file_cells(output_copy_path, run_preingresoIndex, flagged_cells)

    summary = {
        "rows": summary_rows,
        "processed": processed_count,
        "ok": ok_count,
        "error": error_count,
        "revisar": revisar_count,
        "revisar_manual": manual_count,
        "omitidas_revisar_manual": skipped_manual,
        "verificadas": dbg.verified_rows,
        "sin_verificar": dbg.unverified_rows,
        "abortado": aborted_reason,
        "debug_log": str(dbg.txt_path),
    }
    summary_path = Path(ingreso_output_dir) / "ingreso_escritos_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[RPA01][SUMMARY_JSON] {summary_path}")

    dbg.close(
        {
            "procesadas": processed_count,
            "ok": ok_count,
            "error": error_count,
            "revisar": revisar_count,
            "revisar_manual": manual_count,
            "omitidas_revisar_manual": skipped_manual,
            "abortado": aborted_reason or "no",
        }
    )
    print(
        f"Done Ingreso Escritos | procesadas={processed_count} ok={ok_count} "
        f"error={error_count} revisar={revisar_count} revisar_manual={manual_count}"
    )
    print('Done Preingreso')

    if aborted_reason:
        raise VerificationUnavailable(aborted_reason)


def fill_form_escritos(row, escritos_DCP_Path: str, documentos_firmados: bool = False, dbg: RunDebugLog | None = None) -> bool:
    """
    Fill and submit one escrito.

    Returns True when the target causa was positively verified (tribunal or
    carátula read back and matched), False when it could only be assumed.
    """
    dbg = dbg or RunDebugLog(os.getenv("RPA01_DEBUG_DIR", ".") or ".", "ingreso")

    # Build the target PDF path from row data (no page state needed) and verify
    # it exists BEFORE touching the portal. A missing file is raised immediately
    # so the row is flagged REVISAR and the batch continues — this is what keeps
    # the native "Abrir" dialog from opening on a non-existent file and jamming
    # every subsequent row. It also avoids creating an orphan draft escrito
    # (Grabar Escrito is only clicked further down, for files that exist).
    format_rut = int(row["RUT"])
    format_rut = f"{format_rut:,}".replace(",", ".")
    ruta_escrito_operacion = escritos_DCP_Path + "\\Trib_" + str(row["TRIBUNAL"])[:-1] + "°_ROL_" + str(row["ROL"]) + "_"
    ruta_escrito_operacion += format_rut + "-" + str(row["DV"])
    if documentos_firmados:
        ruta_escrito_operacion += "_firmado"
    ruta_escrito_operacion += ".pdf"
    dbg.note("pdf", ruta_escrito_operacion)
    if not Path(ruta_escrito_operacion).exists():
        raise EscritoFileNotFound(Path(ruta_escrito_operacion).name, ruta_escrito_operacion)

    page = browser.page()
    page.get_by_text("Ingresar Escrito").click()

    time.sleep(1)

    page.get_by_text("Competencia").wait_for()
    page.get_by_text("Competencia").click()
    page.press("body", "Tab")
    page.keyboard.type("Civil")
    page.press("body", "Tab")

    _set_fijar_datos(page, dbg)

    page.locator("xpath=//label[contains(.,'Tipo')]").wait_for()
    page.locator("xpath=//label[contains(.,'Tipo')]").click()
    page.press("body", "Tab")
    page.locator("xpath=//select[contains(@data-bind,'tiposCausas')]").select_option("option", label="C")
    time.sleep(2)

    # GUARD 1 — the tribunal is selected and then PROVEN, because a wrong
    # tribunal still finds a valid causa (ROLs repeat across juzgados).
    tribunal_verified = _select_tribunal_verified(page, row["TRIBUNAL"], dbg)

    rol = str(row["ROL"])

    page.locator("xpath=//label[contains(.,'Rol')]/../input").fill(rol.split('-')[0])
    ano = rol.split('-')[1]
    _select_causa_year(page, ano)
    print(f"[RPA01][CONSULTA_ROL] rol={rol.split('-')[0]} ano={ano}")

    time.sleep(1)
    page.locator("xpath=//button[contains(.,' Consulta Rol')]").click()

    page.locator("xpath=//label[contains(.,'Caratulado')]").wait_for()

    # GUARD 2 — the carátula PJUD just loaded must be the one the planilla
    # expects. This is the check that catches a wrong causa even when the
    # tribunal read-back was unavailable.
    caratula_verified = _verify_caratula(page, row, dbg)

    page.locator("xpath=//label[contains(.,'Caratulado')]").click()

    page.press("body", "Tab")
    time.sleep(2)
    """ Selecciono el cuaderno"""
    page.press("body", "ArrowDown")
    page.press("body", "Tab")

    time.sleep(2)

    page.keyboard.type("joa")

    page.press("body", "Tab")
    page.press("body", "Tab")
    page.press("body", "Tab")

    time.sleep(2)

    page.keyboard.type("gen")

    time.sleep(2)

    page.press("body", "Tab")

    time.sleep(2)

    page.keyboard.type("da cuenta de pag")

    page.press("body", "Tab")

    # ------------------------------------------------------------------
    # POINT OF NO RETURN. From here the escrito EXISTS in the Bandeja, so
    # every later failure is wrapped as EscritoPossiblyCreated and the row is
    # flagged REVISAR_MANUAL instead of being retried into a duplicate.
    # ------------------------------------------------------------------
    dbg.note("grabar_escrito", "click")
    page.locator("xpath=//button[contains(.,' Grabar Escrito')]").click()
    dbg.note("estado", "ESCRITO GRABADO — cualquier falla posterior es REVISAR_MANUAL")

    stage = "grabar-escrito"
    try:
        time.sleep(1)

        stage = "adjuntar-archivos"
        page.get_by_text("Adjuntar Archivos").wait_for()
        page.get_by_text("Adjuntar Archivos").click()
        page.locator("#dDPrincipal").get_by_role("button", name="Adjuntar").click()

        stage = "dialogo-windows"
        app = windows.find_window('regex:.*Oficina Judicial Virtual - Portal*')
        # ruta_escrito_operacion was already built and existence-checked at the top.
        app.find('class:"Edit" and name:"Nombre:"').set_value(ruta_escrito_operacion)
        app.find('class:"Button" and name:"Abrir"').click()
        time.sleep(3)

        stage = "tipo-documento-escrito"
        page.get_by_text("Escrito", exact=True).wait_for()
        page.get_by_text("Escrito", exact=True).click()

        stage = "cerrar-y-continuar"
        page.get_by_role("button", name="Cerrar y Continuar").click()

        stage = "volver-tramite-facil"
        page.get_by_text("Trámite Fácil").click()
    except Exception as exc:
        raise EscritoPossiblyCreated(stage, exc) from exc

    dbg.note("verificado", f"tribunal={tribunal_verified} caratula={caratula_verified}")
    return bool(tribunal_verified or caratula_verified)


# ---------------------------------------------------------------------------
# Envío
# ---------------------------------------------------------------------------
def _count_selected_escritos(page):
    """
    How many escritos are currently ticked in the Bandeja.

    "Seleccionar Todo" is itself a checkbox, so it is counted separately and
    subtracted. Both raw numbers go to the debug log for calibration.
    """
    total = 0
    scope = "ninguno"
    for selector in ("table input[type='checkbox']", "input[type='checkbox']"):
        try:
            locator = page.locator(selector)
            count = locator.count()
            if count:
                total = page.locator(f"{selector}:checked").count()
                scope = selector
                break
        except Exception:
            continue

    select_all_checked = 0
    try:
        select_all = page.locator(
            "xpath=//label[contains(.,'Seleccionar Todo')]//input[@type='checkbox']"
            " | //label[contains(.,'Seleccionar Todo')]/../input[@type='checkbox']"
        )
        for index in range(select_all.count()):
            if select_all.nth(index).is_checked():
                select_all_checked += 1
    except Exception:
        pass

    return max(0, total - select_all_checked), total, select_all_checked, scope


def read_excel_envio(path: str, envio_output_dir: str | None = None):
    """
    open and read an excel file for envio
    """
    print('Envio')
    dbg = RunDebugLog(envio_output_dir or str(Path(path).parent), "envio")
    excel = Excel()
    excel.open_workbook(path)
    rows = excel.read_worksheet_as_table("Hoja1", header=True)
    numero = 2
    envioIndex = 1
    if not rows.columns.__contains__("ENVIO"):
        excel.insert_columns_before(1, 1)
        excel.set_cell_value(1, 1, "ENVIO")
        excel.save_workbook()
    else:
        envioIndex = rows.columns.index("ENVIO") + 1

    rows = excel.read_worksheet_as_table("Hoja1", header=True)
    print(envioIndex)

    # How many escritos legitimately belong to each causa, so "Seleccionar Todo"
    # picking up MORE than that can be caught before dispatching them.
    esperados: dict[tuple[str, str], int] = {}
    for row in rows:
        clave = (_norm(row.get("ROL", "")), _norm(row.get("TRIBUNAL", "")))
        if clave != ("", ""):
            esperados[clave] = esperados.get(clave, 0) + 1

    ok_count = 0
    error_count = 0
    manual_count = 0
    skipped_manual = 0

    for row in rows:
        envio_previo = _norm_status(row.get("ENVIO", ""))
        if envio_previo == STATUS_REVISAR_MANUAL:
            skipped_manual += 1
            print(
                f"[RPA01][ENVIO][SKIP] fila={numero} rol={row.get('ROL', '')} marcada "
                f"{STATUS_REVISAR_MANUAL}: revisar la Bandeja a mano."
            )

        if _should_process(envio_previo) and _norm_status(row.get("PREINGRESO", "")) == STATUS_OK:
            dbg.start_row(numero, row)
            clave = (_norm(row.get("ROL", "")), _norm(row.get("TRIBUNAL", "")))
            try:
                fill_form_envio(row, dbg, esperados.get(clave, 1))
                excel.set_cell_value(numero, envioIndex, STATUS_OK)
                ok_count += 1
                dbg.end_row(STATUS_OK)
                print(row["ROL"])
            except CausaVerificationError as e:
                # Wrong tribunal / too many escritos selected: nothing was sent.
                print(f"[RPA01][ENVIO][REVISAR] fila={numero} rol={row.get('ROL', '')} {e}")
                excel.set_cell_value(numero, envioIndex, STATUS_REVISAR)
                error_count += 1
                dbg.end_row(STATUS_REVISAR, str(e))
                browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")
            except EscritoPossiblyCreated as e:
                # Failed after clicking "Enviar Poder Judicial": may already be sent.
                print(f"[RPA01][ENVIO][REVISAR_MANUAL] fila={numero} rol={row.get('ROL', '')} etapa={e.stage} error={e.original}")
                excel.set_cell_value(numero, envioIndex, STATUS_REVISAR_MANUAL)
                manual_count += 1
                dbg.end_row(STATUS_REVISAR_MANUAL, f"etapa={e.stage}: {e.original}")
                browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")
            except Exception as e:
                # Was a bare `except: pass` — the reason is now recorded.
                print(f"[RPA01][ENVIO][ERROR] fila={numero} rol={row.get('ROL', '')} error={e}")
                dbg.event("ERROR", "Falla en envio", error=str(e))
                dbg.event("ERROR", "traceback", detalle=traceback.format_exc(limit=6))
                excel.set_cell_value(numero, envioIndex, STATUS_ERROR)
                error_count += 1
                dbg.end_row(STATUS_ERROR, str(e))
                browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")

        excel.save_workbook()
        numero = numero + 1

    excel.save_workbook(path)
    excel.close_workbook()
    dbg.close(
        {
            "ok": ok_count,
            "error": error_count,
            "revisar_manual": manual_count,
            "omitidas_revisar_manual": skipped_manual,
        }
    )
    print(f"Done Envio | ok={ok_count} error={error_count} revisar_manual={manual_count}")


def fill_form_envio(row, dbg: RunDebugLog | None = None, esperados: int = 1):
    dbg = dbg or RunDebugLog(".", "envio")

    page = browser.page()
    page.get_by_text("Bandeja Escrito").click()

    time.sleep(2)

    page.locator("xpath=//label[contains(.,'Competencia:')]").wait_for()
    page.locator("xpath=//label[contains(.,'Competencia:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("Civil")
    page.press("body", "Tab")
    time.sleep(1)

    # Same guard as Ingreso: the Bandeja filter used the identical blind
    # keyboard selection, so it could query — and then dispatch — another
    # juzgado's escritos for a ROL that exists in both.
    tribunal_verified = _select_tribunal_verified_bandeja(page, row["TRIBUNAL"], dbg)
    dbg.note("tribunal_envio_verificado", tribunal_verified)

    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Space")
    page.press("body", "Tab")
    page.keyboard.type("C")
    page.press("body", "Tab")

    rol = str(row["ROL"])
    page.keyboard.type(rol.split('-')[0])
    page.press("body", "Tab")
    page.keyboard.type(rol.split('-')[1])
    page.press("body", "Tab")

    page.get_by_role("button", name="Consultar Escritos").click()

    time.sleep(2)

    page.locator("xpath=//label[contains(.,'Seleccionar Todo')]").first.click()
    time.sleep(1)

    # "Seleccionar Todo" dispatches EVERYTHING sitting in the Bandeja for the
    # queried causa — including duplicates and leftovers from earlier runs.
    # That is how 60 planilla rows became 70 uploads. Count before sending.
    seleccionados, crudos, select_all, scope = _count_selected_escritos(page)
    dbg.note(
        "seleccion",
        f"escritos={seleccionados} (checkboxes={crudos}, seleccionar_todo={select_all}, "
        f"scope={scope}) esperados={esperados}",
    )

    if ENVIO_ENFORCE_COUNT:
        if crudos == 0:
            dbg.event("WARN", "No se pudieron contar los escritos seleccionados — se envia sin verificar")
        elif seleccionados == 0:
            raise CausaVerificationError("Escritos seleccionados", f"{esperados}", "0")
        elif seleccionados > esperados:
            dbg.event(
                "ERROR",
                "La Bandeja tiene MAS escritos que los que corresponden a esta fila — NO se envia",
                seleccionados=seleccionados,
                esperados=esperados,
            )
            raise CausaVerificationError("Escritos seleccionados", f"{esperados}", str(seleccionados))

    # ------------------------------------------------------------------
    # POINT OF NO RETURN for envío.
    # ------------------------------------------------------------------
    dbg.note("enviar", "click Enviar Poder Judicial")
    page.locator("xpath=//button[contains(.,'Enviar Poder Judicial')]").click()

    stage = "confirmar-envio"
    try:
        time.sleep(1)
        page.locator("#modalConfirmarEnvioSinFirma").wait_for()
        page.locator("xpath=//div[@id='modalConfirmarEnvioSinFirma']/div/div/div[3]/div/div/div[2]/button").click()
        time.sleep(2)

        stage = "volver-mantenedor"
        page.get_by_text("Mantenedor").click()
    except Exception as exc:
        raise EscritoPossiblyCreated(stage, exc) from exc

    """
    Este codigo a continuacion, elimina las operaciones segun el rol

    page.locator("xpath=//button[contains(.,'Eliminar Escritos')]").click()
    time.sleep(1)
    page.locator("#modalConfirmarEnvioSinFirma").wait_for()
    page.locator("xpath=//div[@id='modalConfirmarEnvioSinFirma']/div/div/div[2]/div/div/div[2]/button").click()

    page.get_by_text("Mantenedor").click()

    """


def _select_tribunal_verified_bandeja(page, tribunal_raw, dbg: RunDebugLog) -> bool:
    """
    Bandeja variant: the label is 'Tribunal Origen' and the legacy keyboard path
    differs slightly from the Ingreso form.
    """
    numero = _tribunal_numero(tribunal_raw)
    wanted_label = _tribunal_portal_label(numero)
    wanted_norm = _norm(wanted_label)

    page.locator("xpath=//label[contains(.,'Tribunal Origen')]").wait_for()
    page.locator("xpath=//label[contains(.,'Tribunal Origen')]").click()
    page.press("body", "Tab")
    page.press("body", "ArrowDown")
    page.keyboard.type(wanted_label)
    time.sleep(1)

    entero = int(numero)
    if entero == 2:
        page.press("body", "ArrowDown")
    elif 2 < entero < 10:
        page.press("body", "ArrowDown")
        page.press("body", "ArrowDown")

    # This Tab commits the selection AND advances the focus chain that the rest
    # of fill_form_envio walks by keyboard. It belongs to this block — dropping
    # it shifts every later Tab by one field.
    page.press("body", "Tab")

    if not VERIFY_TRIBUNAL:
        return False

    shown, strategy = _read_control_text(page, "Tribunal Origen")
    if shown is None:
        dbg.event("WARN", "No se pudo LEER el Tribunal Origen en la Bandeja", via=strategy)
        return False

    if _norm(shown) == wanted_norm or wanted_norm in _norm(shown):
        dbg.note("tribunal_origen", f"OK '{shown}' (sonda={strategy})")
        return True

    dbg.event(
        "ERROR",
        "Tribunal Origen incorrecto en la Bandeja — NO se envia",
        esperado=wanted_label,
        portal=shown,
    )
    raise CausaVerificationError("Tribunal Origen", wanted_label, shown)


def compare_results():

    page = browser.page()
    page.get_by_text("Bandeja Escrito").click()

    time.sleep(5)

    page.locator("xpath=//label[contains(.,'Competencia:')]").wait_for()
    page.locator("xpath=//label[contains(.,'Competencia:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("Civil")
    page.press("body", "Tab")

    page.locator("a:has-text('Escritos Enviados')").click()
    time.sleep(2)
    #page.press("body", "Tab")
    #page.press("body", "Enter")
    page.locator("xpath=//button[contains(.,'Exportar Excel')]").click()
    time.sleep(120)
