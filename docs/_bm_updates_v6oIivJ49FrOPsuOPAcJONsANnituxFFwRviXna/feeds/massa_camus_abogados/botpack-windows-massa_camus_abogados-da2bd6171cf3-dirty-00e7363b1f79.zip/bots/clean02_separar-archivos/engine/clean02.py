"""
clean02 — PDF page classifier core library (proof of concept)
=============================================================
Splits a scanned multi-doc PDF into named documents, the same way a human does:
    CHECKLIST -> LIQUIDACION_DEUDA -> INFORME_DEUDA -> PAGARE(s) -> [HOJA_DE_FIRMA]
    -> [CEDULA_IDENTIDAD] -> [ANEXO_CONTRATO]
Everything else (blank backs, separators, "Condiciones Generales" boilerplate) is dropped.

The PDFs have NO text layer (pure scans), so:
  - text-rich pages are classified by OCR + keyword anchors
  - the two faint form pages (LIQUIDACION, INFORME) won't OCR, so they are
    classified by visual template matching against known examples
  - blank/back pages are dropped by low ink density

This module stays framework-agnostic so it can later become the bot's functions.py.
"""
from __future__ import annotations

import functools
import hashlib
import io
import os
import pickle
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

# ----------------------------------------------------------------------------
# Document type labels
# ----------------------------------------------------------------------------
CHECKLIST = "CHECKLIST"
LIQUIDACION = "LIQUIDACION_DEUDA"
INFORME = "INFORME_DEUDA"
PAGARE_MP = "PAGARE_MP"
PAGARE_LP = "PAGARE_LP"
PAGARE_TC = "PAGARE_TC"          # credit-card pagaré ("PRODUCTO: TC")
HOJA_DE_FIRMA = "HOJA_DE_FIRMA"
CEDULA = "CEDULA_IDENTIDAD"
ANEXO = "ANEXO_CONTRATO"
DROP = "DROP"  # pages the human did not extract

PAGARE_TYPES = {PAGARE_MP, PAGARE_LP, PAGARE_TC}

# ----------------------------------------------------------------------------
# Per-page features
# ----------------------------------------------------------------------------
OCR_DPI = 300
VIS_SIZE = 64          # visual fingerprint is VIS_SIZE x VIS_SIZE grayscale
HASH_SCALE = 0.2       # low-res render used for page<->page image matching

_CACHE_DIR = Path(__file__).parent / ".cache"


@dataclass
class PageFeatures:
    index: int                      # 0-based page index in the main PDF
    text: str                       # raw OCR text (Spanish)
    text_upper: str                 # uppercased, accent-folded
    n_chars: int                    # length of stripped OCR text
    n_words: int                    # count of alphabetic words >= 3 chars
    ink_density: float              # fraction of dark pixels (blank detection)
    vvec: np.ndarray                # normalized visual fingerprint (VIS_SIZE**2,)
    img_hash: str                   # hash of low-res render (for GT matching)


def _fold(s: str) -> str:
    if not s:
        return ""
    repl = str.maketrans("ÁÉÍÓÚÜÑáéíóúüñ", "AEIOUUNAEIOUUN")
    return s.upper().translate(repl)


def _render_png_bytes(page: fitz.Page, dpi: int) -> bytes:
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72))
    return pix.tobytes("png")


# ----------------------------------------------------------------------------
# Tesseract binary + language-data resolution
# ----------------------------------------------------------------------------
# The engine shells out to the Tesseract OCR binary (a SYSTEM package, NOT a pip
# dependency). On a fresh Windows machine it may not be on PATH — even right after
# BotManager_Initializer.bat installs it, because winget updates the registry
# PATH but an already-running process keeps its old environment. winget also may
# install per-MACHINE (C:\Program Files) when elevated or per-USER
# (%LOCALAPPDATA%\Programs) when not — so we probe both, fall back to a bounded
# filesystem search, and locate the Spanish data explicitly.


def _repo_root() -> Path:
    # .../BotManager/bots/<bot>/engine/clean02.py -> BotManager/
    return Path(__file__).resolve().parents[3]


def _win_tesseract_dirs() -> list[Path]:
    """Well-known `tesseract.exe` locations on Windows, drive/locale-aware via the
    environment (Program Files can be on a non-C: drive or localized). Covers both
    per-machine (Program Files) and per-user (%LOCALAPPDATA%\\Programs) installs."""
    roots: list[Path] = []
    for var in ("ProgramW6432", "ProgramFiles", "ProgramFiles(x86)"):
        v = os.environ.get(var)
        if v:
            roots.append(Path(v))
    roots += [Path(r"C:\Program Files"), Path(r"C:\Program Files (x86)")]
    local = os.environ.get("LOCALAPPDATA")
    if local:
        roots.append(Path(local) / "Programs")
    out: list[Path] = []
    seen: set[str] = set()
    for r in roots:
        exe = r / "Tesseract-OCR" / "tesseract.exe"
        key = str(exe).lower()
        if key not in seen:
            seen.add(key)
            out.append(exe)
    return out


def _search_tesseract() -> Optional[str]:
    """Last-resort bounded search for tesseract.exe under the per-user install
    roots (small trees), in case winget used a non-default folder name."""
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        return None
    for sub in ("Programs", r"Microsoft\WinGet\Packages"):
        root = Path(local) / sub
        if not root.is_dir():
            continue
        try:
            hit = next(root.rglob("tesseract.exe"), None)
        except (OSError, PermissionError):
            hit = None
        if hit:
            return str(hit)
    return None


@functools.lru_cache(maxsize=1)
def _resolve_tesseract() -> tuple[Optional[str], Optional[str]]:
    """Locate (tesseract_exe, tessdata_dir). Either may be None if not found.

    Exe search order: explicit env var (TESSERACT_EXE/TESSERACT_CMD) -> PATH ->
    well-known Windows install dirs (per-machine AND per-user) -> repo-local
    tools/tesseract -> bounded search of the per-user roots. Spanish data:
    TESSDATA_PREFIX env -> repo-local tools/tessdata (a no-admin fallback the
    .bat populates)."""
    exe: Optional[str] = None
    for var in ("TESSERACT_EXE", "TESSERACT_CMD"):
        val = os.environ.get(var)
        if val and Path(val).exists():
            exe = val
            break
    if not exe:
        exe = shutil.which("tesseract")
    if not exe:
        for cand in _win_tesseract_dirs():
            if cand.exists():
                exe = str(cand)
                break
    if not exe:
        for name in ("tesseract.exe", "tesseract"):
            cand = _repo_root() / "tools" / "tesseract" / name
            if cand.exists():
                exe = str(cand)
                break
    if not exe:
        exe = _search_tesseract()

    tessdata: Optional[str] = os.environ.get("TESSDATA_PREFIX") or None
    if not tessdata:
        local_td = _repo_root() / "tools" / "tessdata"
        if (local_td / "spa.traineddata").exists():
            tessdata = str(local_td)
    return exe, tessdata


def assert_tesseract_ready() -> None:
    """Raise a clear Spanish ValueError if Tesseract (with the 'spa' data) is not
    usable. Called once per run as a preflight, so a missing engine fails loudly
    instead of silently producing an empty output folder."""
    exe, tessdata = _resolve_tesseract()
    if not exe:
        # Diagnostic to the run log (helps remote debugging) before failing loudly.
        print("[clean02] Tesseract no encontrado. Revisado:", flush=True)
        print(f"  PATH(which)={shutil.which('tesseract')!r}", flush=True)
        print(f"  TESSERACT_EXE={os.environ.get('TESSERACT_EXE')!r}", flush=True)
        for _c in _win_tesseract_dirs():
            print(f"  {_c} -> {'OK' if _c.exists() else 'no'}", flush=True)
        print(f"  busqueda={_search_tesseract()!r}", flush=True)
        # Machine-readable marker for the desktop pop-up (parsed in
        # app/desktop/qml/Main.qml -> missingDependencyCompletionNotification).
        # Without it the pop-up can only say "terminó con un error", which is what
        # made this failure look silent on the first client machine.
        print("[CLEAN02][DEPENDENCIA_FALTANTE] tesseract", flush=True)
        raise ValueError(
            "Falta instalar Tesseract OCR en este computador.\n"
            "Este bot lee PDF escaneados con Tesseract, un programa gratuito que "
            "se instala una sola vez.\n"
            "  - Abre la pestaña 'Información del bot' y sigue la sección "
            "'Cómo instalar Tesseract' (tiene el paso a paso y el comando listo "
            "para copiar).\n"
            "  - En Windows, en una terminal:\n"
            "      winget install -e --id UB-Mannheim.TesseractOCR\n"
            "  - Despues de instalarlo CIERRA y vuelve a abrir BotManager, para "
            "que tome el nuevo PATH.\n"
            "El idioma español ya viene incluido en BotManager: no hay que "
            "descargarlo aparte."
        )
    try:
        cmd = [exe, "--list-langs"] + (["--tessdata-dir", tessdata] if tessdata else [])
        out = subprocess.run(
            cmd, capture_output=True, encoding="utf-8", errors="replace", timeout=30,
        )
        langs = ((out.stdout or "") + " " + (out.stderr or "")).split()
        if "spa" not in langs:
            print("[CLEAN02][DEPENDENCIA_FALTANTE] tesseract_spa", flush=True)
            raise ValueError(
                "Tesseract está instalado, pero no encuentra el idioma español "
                "('spa').\n"
                "  - Abre la pestaña 'Información del bot' y revisa la sección "
                "'Cómo instalar Tesseract'.\n"
                "  - En Mac: brew install tesseract-lang\n"
                "  - En Windows normalmente basta con cerrar y volver a abrir "
                "BotManager (el idioma español viene incluido); si sigue igual, "
                "avisa a soporte."
            )
    except (OSError, subprocess.SubprocessError):
        # Could not verify languages, but the binary exists — proceed. A truly
        # missing 'spa' will surface during OCR and be caught by the task's
        # empty-output guard rather than silently passing.
        pass


def _ocr(png_bytes: bytes, lang: str = "spa", psm: int = 4) -> str:
    exe, tessdata = _resolve_tesseract()
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        f.write(png_bytes)
        path = f.name
    try:
        cmd = [exe or "tesseract", path, "stdout", "-l", lang, "--psm", str(psm)]
        if tessdata:
            cmd += ["--tessdata-dir", tessdata]
        # Tesseract always emits UTF-8. Force it: with text=True alone, Python
        # decodes via the OS locale codec (cp1252 on Windows), which raises
        # UnicodeDecodeError on accented bytes -> out.stdout becomes None ->
        # downstream None.upper() crash. errors="replace" keeps OCR identical to
        # the Mac/Linux UTF-8 path so the text anchors match across machines.
        out = subprocess.run(
            cmd, capture_output=True, encoding="utf-8", errors="replace",
            timeout=120,
        )
        return out.stdout or ""
    finally:
        os.unlink(path)


def _visual_vector(page: fitz.Page, size: int = VIS_SIZE) -> np.ndarray:
    pix = page.get_pixmap(matrix=fitz.Matrix(0.5, 0.5), colorspace=fitz.csGRAY)
    img = Image.open(io.BytesIO(pix.tobytes("png"))).convert("L").resize((size, size))
    v = np.asarray(img, dtype=np.float32).ravel()
    return (v - v.mean()) / (v.std() + 1e-6)


def _ink_density(page: fitz.Page) -> float:
    pix = page.get_pixmap(matrix=fitz.Matrix(0.25, 0.25), colorspace=fitz.csGRAY)
    arr = np.frombuffer(pix.samples, dtype=np.uint8)
    return float((arr < 128).mean())


def _img_hash(page: fitz.Page) -> str:
    pix = page.get_pixmap(matrix=fitz.Matrix(HASH_SCALE, HASH_SCALE))
    return hashlib.md5(pix.samples).hexdigest()


def extract_features(pdf_path: Path, use_cache: bool = True) -> list[PageFeatures]:
    """Render + OCR + fingerprint every page. Cached by path + mtime."""
    pdf_path = Path(pdf_path)
    key = hashlib.md5(f"{pdf_path}:{pdf_path.stat().st_mtime}:{OCR_DPI}".encode()).hexdigest()
    cache_file = _CACHE_DIR / f"{key}.pkl"
    if use_cache and cache_file.exists():
        with open(cache_file, "rb") as f:
            return pickle.load(f)

    doc = fitz.open(pdf_path)
    feats: list[PageFeatures] = []
    for i, page in enumerate(doc):
        text = _ocr(_render_png_bytes(page, OCR_DPI))
        up = _fold(text)
        words = re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,}", text)
        feats.append(PageFeatures(
            index=i,
            text=text,
            text_upper=up,
            n_chars=len(text.strip()),
            n_words=len(words),
            ink_density=_ink_density(page),
            vvec=_visual_vector(page),
            img_hash=_img_hash(page),
        ))
    doc.close()

    if use_cache:
        _CACHE_DIR.mkdir(exist_ok=True)
        with open(cache_file, "wb") as f:
            pickle.dump(feats, f)
    return feats


def clear_feature_cache() -> int:
    """Delete every cached OCR page-feature file so the next run re-OCRs from
    scratch. Returns the number of files removed (0 if the cache is empty or
    absent). The cache is a pure speed optimization -- OCR is deterministic --
    so clearing it only costs time, never correctness. Used by the desktop
    "Re-procesar desde cero" toggle and to recover from a half-written cache."""
    if not _CACHE_DIR.exists():
        return 0
    removed = 0
    for cache_file in _CACHE_DIR.glob("*.pkl"):
        try:
            cache_file.unlink()
            removed += 1
        except OSError:
            pass
    return removed


# ----------------------------------------------------------------------------
# Ground truth: map each human split file back to page ranges in the main PDF
# ----------------------------------------------------------------------------
def _page_hashes(pdf_path: Path) -> list[str]:
    doc = fitz.open(pdf_path)
    hashes = [_img_hash(p) for p in doc]
    doc.close()
    return hashes


def split_tag(filename: str, rut: str) -> str:
    """`10.140.233-9_PAGARE_MP.pdf` -> `PAGARE_MP`."""
    stem = Path(filename).stem
    return stem[len(rut) + 1:] if stem.startswith(rut + "_") else stem


def _find_run(hay: list[str], needle: list[str]) -> Optional[int]:
    """First index where `needle` appears contiguously inside `hay`, else None."""
    if not needle or len(needle) > len(hay):
        return None
    for start in range(len(hay) - len(needle) + 1):
        if hay[start:start + len(needle)] == needle:
            return start
    return None


def _tokens(text_upper: str) -> set[str]:
    return {w for w in text_upper.split() if len(w) >= 4}


def ground_truth(case_dir: Path, rut: str) -> dict[int, str]:
    """Return {page_index_0based: LABEL} for the main PDF, DROP for unextracted pages.

    Fast path: locate each human split as a contiguous run of identical page images
    in the main PDF. Fallback (for splits the human re-saved — different bytes — and/or
    assembled non-contiguously, skipping an interleaved court certificate): match each
    split page to a main page by exact image hash, else by OCR token overlap. This
    keeps the gold faithful to what the human actually extracted, page by page."""
    case_dir = Path(case_dir)
    main = case_dir / f"{rut}.pdf"
    main_hashes = _page_hashes(main)
    n = len(main_hashes)
    labels: dict[int, str] = {i: DROP for i in range(n)}
    taken: set[int] = set()
    main_tok: Optional[list[set[str]]] = None   # lazy: only OCR the main if a split needs it

    for split in sorted(case_dir.glob(f"{rut}_*.pdf")):
        tag = split_tag(split.name, rut)
        sh = _page_hashes(split)
        run = _find_run(main_hashes, sh)
        if run is not None:
            for off in range(len(sh)):
                labels[run + off] = tag
                taken.add(run + off)
            continue

        if main_tok is None:
            main_tok = [_tokens(f.text_upper) for f in extract_features(main)]
        doc = fitz.open(split)
        for sp in doc:
            h = _img_hash(sp)
            idx = next((k for k in range(n) if k not in taken and main_hashes[k] == h), None)
            if idx is None:
                st = _tokens(_fold(_ocr(_render_png_bytes(sp, OCR_DPI))))
                best = 0.55
                for k in range(n):
                    if k in taken or not st or not main_tok[k]:
                        continue
                    jac = len(st & main_tok[k]) / len(st | main_tok[k])
                    if jac > best:
                        best, idx = jac, k
            if idx is not None:
                labels[idx] = tag
                taken.add(idx)
        doc.close()
    return labels
