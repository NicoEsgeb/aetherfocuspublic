"""
clean03 — OCR engine (render + Tesseract + orientation correction + cache)
===========================================================================
The input PDFs are pure scans with NO text layer, so every page must be OCR'd
(same situation as clean02). Two clean03-specific needs on top of clean02:

  1. Orientation correction. The INFORME_DEUDA pages are scanned sideways
     (rotated 90°/270°). OCR'd as-is they return garbage; rotated upright they
     OCR cleanly. So each page is OCR'd at the orientation that yields the most
     real words.
  2. A page-text cache keyed by (path, mtime, dpi) so re-runs are instant. The
     "Re-procesar desde cero" toggle clears it.

The Tesseract binary resolution is copied from clean02's engine (battle-tested
across macOS / Linux / Windows). Tesseract is a SYSTEM dependency (not pip).
"""
from __future__ import annotations

import functools
import hashlib
import io
import os
import pickle
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import fitz  # PyMuPDF
from PIL import Image

OCR_DPI = 300
_CACHE_DIR = Path(__file__).parent / ".cache"

# A page is considered "already upright" when its OCR hits at least this many
# domain vocabulary words. Pagaré/hoja/correctly-rotated informe pages hit far
# more; a sideways informe hits ~0, which triggers the rotation sweep.
#
# NOTE: a plain "count tokens >= 4 letters" score does NOT work — sideways OCR
# garbage produces hundreds of 4+ char gibberish tokens ("ANAAMVO", "DOUANNON")
# that masquerade as words. Scoring against real Spanish bank-document words
# instead cleanly separates a readable orientation from noise.
_UPRIGHT_MIN_HITS = 6

_WORD_RE = re.compile(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{3,}")

# Common words across the documents this bot reads (pagaré, informe, hoja de
# firma). Accent-folded, uppercased. Used only to score OCR orientation quality.
_VOCAB = frozenset({
    "BANCO", "PAGARE", "DEUDA", "INFORME", "CLIENTE", "DEUDOR", "SUSCRIPTOR",
    "OPERACION", "CAPITAL", "INTERES", "INTERESES", "CUOTA", "CUOTAS", "MENSUAL",
    "TASA", "RESUMEN", "PESOS", "TOTAL", "SALDO", "INSOLUTO", "FECHA", "EMISION",
    "VALOR", "PRESTAMO", "MONEDA", "PAGO", "DOMICILIO", "COMUNA", "SANTIAGO",
    "CHILE", "NACIONAL", "CONTRATO", "FIRMA", "NOTARIO", "REPERTORIO", "DIRECCION",
    "IDENTIDAD", "CONSUMO", "CREDITO", "OBLIGACION", "VENCIMIENTO", "PRORROGA",
    "MONTO", "ITAU", "REPORTE", "CANCELACION", "OTORGAMIENTO", "PRIMER", "ULTIMO",
    "DOCUMENTO", "GENERAL", "DIRECTA", "MONEDAS", "REFERENCIA", "ADEUDADO",
})


def fold(s: str) -> str:
    """Uppercase + strip Spanish accents, for accent-insensitive matching."""
    if not s:
        return ""
    repl = str.maketrans("ÁÉÍÓÚÜÑáéíóúüñ", "AEIOUUNAEIOUUN")
    return s.upper().translate(repl)


# ---------------------------------------------------------------------------
# Tesseract binary + Spanish language-data resolution (copied from clean02).
# ---------------------------------------------------------------------------
def _repo_root() -> Path:
    # .../BotManager/bots/<bot>/engine/ocr.py -> BotManager/
    return Path(__file__).resolve().parents[3]


def _win_tesseract_dirs() -> list[Path]:
    roots: list[Path] = []
    for var in ("ProgramW6432", "ProgramFiles", "ProgramFiles(x86)"):
        v = os.environ.get(var)
        if v:
            roots.append(Path(v))
    roots += [Path(r"C:\Program Files"), Path(r"C:\Program Files (x86)")]
    local = os.environ.get("LOCALAPPDATA")
    if local:
        roots.append(Path(local) / "Programs")
    out: list[Path] = []
    seen: set[str] = set()
    for r in roots:
        exe = r / "Tesseract-OCR" / "tesseract.exe"
        key = str(exe).lower()
        if key not in seen:
            seen.add(key)
            out.append(exe)
    return out


def _search_tesseract() -> Optional[str]:
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        return None
    for sub in ("Programs", r"Microsoft\WinGet\Packages"):
        root = Path(local) / sub
        if not root.is_dir():
            continue
        try:
            hit = next(root.rglob("tesseract.exe"), None)
        except (OSError, PermissionError):
            hit = None
        if hit:
            return str(hit)
    return None


@functools.lru_cache(maxsize=1)
def _resolve_tesseract() -> tuple[Optional[str], Optional[str]]:
    """Locate (tesseract_exe, tessdata_dir). Either may be None if not found."""
    exe: Optional[str] = None
    for var in ("TESSERACT_EXE", "TESSERACT_CMD"):
        val = os.environ.get(var)
        if val and Path(val).exists():
            exe = val
            break
    if not exe:
        exe = shutil.which("tesseract")
    if not exe:
        for cand in _win_tesseract_dirs():
            if cand.exists():
                exe = str(cand)
                break
    if not exe:
        for name in ("tesseract.exe", "tesseract"):
            cand = _repo_root() / "tools" / "tesseract" / name
            if cand.exists():
                exe = str(cand)
                break
    if not exe:
        exe = _search_tesseract()

    tessdata: Optional[str] = os.environ.get("TESSDATA_PREFIX") or None
    if not tessdata:
        local_td = _repo_root() / "tools" / "tessdata"
        if (local_td / "spa.traineddata").exists():
            tessdata = str(local_td)
    return exe, tessdata


def assert_tesseract_ready() -> None:
    """Raise a clear Spanish ValueError if Tesseract (with 'spa') is unusable."""
    exe, tessdata = _resolve_tesseract()
    if not exe:
        print("[clean03] Tesseract no encontrado. Revisado:", flush=True)
        print(f"  PATH(which)={shutil.which('tesseract')!r}", flush=True)
        print(f"  TESSERACT_EXE={os.environ.get('TESSERACT_EXE')!r}", flush=True)
        for _c in _win_tesseract_dirs():
            print(f"  {_c} -> {'OK' if _c.exists() else 'no'}", flush=True)
        # Machine-readable marker for the desktop pop-up (parsed in
        # app/desktop/qml/Main.qml -> missingDependencyCompletionNotification).
        # Without it the pop-up can only say "terminó con un error", which is what
        # made this failure look silent on the first client machine.
        print("[CLEAN03][DEPENDENCIA_FALTANTE] tesseract", flush=True)
        raise ValueError(
            "Falta instalar Tesseract OCR en este computador.\n"
            "Este bot lee PDF escaneados con Tesseract, un programa gratuito que "
            "se instala una sola vez.\n"
            "  - Abre la pestaña 'Información del bot' y sigue la sección "
            "'Cómo instalar Tesseract' (tiene el paso a paso y el comando listo "
            "para copiar).\n"
            "  - En Windows, en una terminal:\n"
            "      winget install -e --id UB-Mannheim.TesseractOCR\n"
            "  - Despues de instalarlo CIERRA y vuelve a abrir BotManager, para "
            "que tome el nuevo PATH.\n"
            "El idioma español ya viene incluido en BotManager: no hay que "
            "descargarlo aparte."
        )
    try:
        cmd = [exe, "--list-langs"] + (["--tessdata-dir", tessdata] if tessdata else [])
        out = subprocess.run(
            cmd, capture_output=True, encoding="utf-8", errors="replace", timeout=30,
        )
        langs = ((out.stdout or "") + " " + (out.stderr or "")).split()
        if "spa" not in langs:
            print("[CLEAN03][DEPENDENCIA_FALTANTE] tesseract_spa", flush=True)
            raise ValueError(
                "Tesseract está instalado, pero no encuentra el idioma español "
                "('spa').\n"
                "  - Abre la pestaña 'Información del bot' y revisa la sección "
                "'Cómo instalar Tesseract'.\n"
                "  - En Mac: brew install tesseract-lang\n"
                "  - En Windows normalmente basta con cerrar y volver a abrir "
                "BotManager (el idioma español viene incluido); si sigue igual, "
                "avisa a soporte."
            )
    except (OSError, subprocess.SubprocessError):
        pass


# ---------------------------------------------------------------------------
# Rendering + OCR
# ---------------------------------------------------------------------------
def _render_gray(page: fitz.Page, dpi: int) -> Image.Image:
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72))
    return Image.open(io.BytesIO(pix.tobytes("png"))).convert("L")


def _ocr_image(img: Image.Image, psm: int = 4) -> str:
    exe, tessdata = _resolve_tesseract()
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        img.save(f, "PNG")
        path = f.name
    try:
        cmd = [exe or "tesseract", path, "stdout", "-l", "spa", "--psm", str(psm)]
        if tessdata:
            cmd += ["--tessdata-dir", tessdata]
        # Force UTF-8 decoding (Tesseract always emits UTF-8). With text=True
        # alone, Python would decode via the OS locale codec (cp1252 on Windows)
        # and crash on accented bytes.
        out = subprocess.run(
            cmd, capture_output=True, encoding="utf-8", errors="replace", timeout=180,
        )
        return out.stdout or ""
    finally:
        os.unlink(path)


def _orientation_score(text: str) -> int:
    """How many domain vocabulary words appear in the OCR text (with repeats).
    A readable orientation scores high; sideways/garbage scores ~0."""
    folded = fold(text)
    return sum(1 for w in _WORD_RE.findall(folded) if w in _VOCAB)


def _ocr_page_oriented(page: fitz.Page, dpi: int) -> str:
    """OCR a page, auto-correcting orientation.

    Fast path: OCR upright; if it already reads as Spanish bank text, keep it.
    Otherwise OCR the three 90° rotations and return whichever reads best
    (rotations are exact, lossless transposes, so this is cheap and safe). The
    270° (clockwise) rotation is tried first because that is what the sideways
    INFORME_DEUDA scans need."""
    base = _render_gray(page, dpi)
    best_txt = _ocr_image(base)
    best_score = _orientation_score(best_txt)
    if best_score >= _UPRIGHT_MIN_HITS:
        return best_txt
    for transpose in (Image.ROTATE_270, Image.ROTATE_90, Image.ROTATE_180):
        txt = _ocr_image(base.transpose(transpose))
        score = _orientation_score(txt)
        if score > best_score:
            best_txt, best_score = txt, score
    return best_txt


# ---------------------------------------------------------------------------
# Public API — OCR a whole PDF, cached by (path, mtime, dpi)
# ---------------------------------------------------------------------------
def ocr_pdf(pdf_path: str | Path, *, dpi: int = OCR_DPI, use_cache: bool = True) -> list[str]:
    """Return one orientation-corrected OCR text string per page. Cached."""
    pdf_path = Path(pdf_path)
    key = hashlib.md5(
        f"{pdf_path}:{pdf_path.stat().st_mtime}:{dpi}:v1".encode()
    ).hexdigest()
    cache_file = _CACHE_DIR / f"{key}.pkl"
    if use_cache and cache_file.exists():
        try:
            with open(cache_file, "rb") as f:
                return pickle.load(f)
        except (pickle.PickleError, EOFError, OSError):
            pass  # corrupt cache -> re-OCR

    doc = fitz.open(pdf_path)
    pages = [_ocr_page_oriented(page, dpi) for page in doc]
    doc.close()

    if use_cache:
        _CACHE_DIR.mkdir(exist_ok=True)
        try:
            with open(cache_file, "wb") as f:
                pickle.dump(pages, f)
        except OSError:
            pass
    return pages


def ocr_pdf_text(pdf_path: str | Path, **kwargs) -> str:
    """Convenience: all pages joined into one text blob (page break = form feed)."""
    return "\n\f\n".join(ocr_pdf(pdf_path, **kwargs))


def clear_cache() -> int:
    """Delete every cached OCR file so the next run re-OCRs from scratch.
    Returns the number of files removed. Used by the desktop
    "Re-procesar desde cero" toggle and to heal a half-written cache."""
    if not _CACHE_DIR.exists():
        return 0
    removed = 0
    for cache_file in _CACHE_DIR.glob("*.pkl"):
        try:
            cache_file.unlink()
            removed += 1
        except OSError:
            pass
    return removed
