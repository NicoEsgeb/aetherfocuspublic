import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color accentStrong: Common.Theme.accent
    property color success: Common.Theme.success
    property int infoTabIndex: 0

    Label {
        text: "Informacion del Bot"
        color: root.textMain
        font.pixelSize: 16
        font.bold: true
        width: root.width
    }

    Common.ExternalDependencyWarning {
        width: root.width
        dependencies: root.botInfo && root.botInfo.missingExternalDependencies
            ? root.botInfo.missingExternalDependencies : []
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: processLabel.implicitWidth + 20
        color: Common.Theme.successSoft
        border.width: 1
        border.color: Common.Theme.success

        Label {
            id: processLabel
            anchors.centerIn: parent
            text: "Proceso CLEAN_BBRR"
            color: Common.Theme.success
            font.pixelSize: 12
            font.bold: true
        }
    }

    Rectangle {
        radius: 8
        implicitHeight: 24
        implicitWidth: localLabel.implicitWidth + 20
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.accent

        Label {
            id: localLabel
            anchors.centerIn: parent
            text: "100% local - sin nube"
            color: Common.Theme.accent
            font.pixelSize: 12
            font.bold: true
        }
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Separar Archivos"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: 12
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: separarInfoComponent
    }

    Component {
        id: separarInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: CLEAN02_SEPARAR_ARCHIVOS"
                color: root.textMain
                font.bold: true
                font.pixelSize: 13
                width: parent.width
            }

            Label {
                text: "Divide PDF escaneados (cada uno nombrado por su RUT) en sus documentos individuales, tal como lo haria una persona. Todo el procesamiento ocurre de forma local en este equipo: no se envia ningun archivo a la nube ni a servicios externos."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
                font.pixelSize: 12
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: 13
                width: parent.width
            }

            Repeater {
                model: [
                    "Task a ejecutar: CLEAN02_SEPARAR_ARCHIVOS.",
                    "Una carpeta con los PDF escaneados (cada archivo nombrado por su RUT), o un PDF individual.",
                    "Cada PDF de entrada debe contener los documentos de un solo RUT, en orden de escaneo."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: 12
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: 13
                width: parent.width
            }

            Repeater {
                model: [
                    "Por cada documento detectado genera <RUT>_<ETIQUETA>.pdf (CHECKLIST, LIQUIDACION_DEUDA, INFORME_DEUDA, PAGARE_*, etc.).",
                    "Los documentos con baja confianza se envian a la subcarpeta _REVISAR/ para revision humana.",
                    "Genera <rut>_manifest.json con el detalle de la clasificacion de cada documento.",
                    "Todo se guarda en una carpeta de salida con marca de tiempo dentro de output/."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: 12
                    }
                }
            }
        }
    }
}
