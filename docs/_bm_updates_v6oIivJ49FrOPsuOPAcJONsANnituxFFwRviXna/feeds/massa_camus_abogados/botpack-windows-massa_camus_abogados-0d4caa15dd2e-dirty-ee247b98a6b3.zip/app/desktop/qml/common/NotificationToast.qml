import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Completion notification, per Phase 1 §5 NotificationToast: AppCard surface + a
// 3px left border in the status colour + a StatusPill + bot/run text, slide+fade
// in 240ms. It stays a modal action dialog because it hosts REQUIRED action
// buttons (bot06 retry/finalize pending, open output) and the onClosing finalize
// safety — i.e. the "existing show/dismiss logic unchanged" the spec mandates.
// All properties/signals/functions and the trigger/action flow are unchanged.
Popup {
    id: root
    parent: Overlay.overlay
    modal: true
    focus: true
    closePolicy: Popup.NoAutoClose
    anchors.centerIn: parent
    width: Math.min(560, parent ? parent.width - 40 : 560)
    height: Math.min(360, parent ? parent.height - 40 : 360)
    padding: 0

    property string titleText: ""
    property string messageText: ""
    property string tone: "info"
    property string confirmText: "Ok"
    property string confirmTone: "primary"
    property string confirmAction: ""
    property string secondaryText: ""
    property string secondaryTone: "warning"
    property string secondaryAction: ""
    property var detailLines: []

    signal acknowledged()
    signal actionTriggered(string actionKey)

    function detailLineCount() {
        if (root.detailLines === undefined || root.detailLines === null) {
            return 0
        }
        if (root.detailLines.length !== undefined) {
            return Number(root.detailLines.length)
        }
        if (root.detailLines.count !== undefined) {
            return Number(root.detailLines.count)
        }
        return 0
    }

    function toneColor() {
        var normalized = String(tone || "info").toLowerCase()
        if (normalized === "success") {
            return Theme.success
        }
        if (normalized === "warning") {
            return Theme.warning
        }
        if (normalized === "error") {
            return Theme.danger
        }
        return Theme.accent
    }

    function statusPillVariant() {
        var normalized = String(tone || "info").toLowerCase()
        if (normalized === "success") {
            return "ok"
        }
        if (normalized === "warning") {
            return "queued"
        }
        if (normalized === "error") {
            return "fail"
        }
        return "info"
    }

    function statusPillLabel() {
        var normalized = String(tone || "info").toLowerCase()
        if (normalized === "success") {
            return "Éxito"
        }
        if (normalized === "warning") {
            return "Atención"
        }
        if (normalized === "error") {
            return "Error"
        }
        return "Info"
    }

    function buttonFill(buttonTone) {
        var normalized = String(buttonTone || "primary").toLowerCase()
        if (normalized === "danger" || normalized === "error") {
            return Theme.danger
        }
        if (normalized === "warning") {
            return Theme.warning
        }
        return Theme.accent
    }

    function hasSecondaryButton() {
        return String(root.secondaryText || "").trim().length > 0
    }

    onClosed: acknowledged()

    // Slide + fade in (240ms) per §5; dismiss logic is unchanged.
    enter: Transition {
        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: 240; easing.type: Easing.OutCubic }
        NumberAnimation { property: "scale"; from: 0.97; to: 1; duration: 240; easing.type: Easing.OutCubic }
    }

    Overlay.modal: Rectangle {
        color: "#7f000000"
    }

    // AppCard surface + a 3px left border in the tone colour.
    background: Rectangle {
        radius: Theme.radiusCard
        color: Theme.panel
        border.width: 1
        border.color: Theme.lineSoft

        Rectangle {
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            width: 3
            radius: 2
            color: root.toneColor()
        }
    }

    contentItem: ColumnLayout {
        anchors.fill: parent
        anchors.margins: 22
        spacing: 12

        ScrollView {
            id: contentScroll
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            ScrollBar.horizontal: StyledScrollBar {
                policy: ScrollBar.AlwaysOff
                visible: false
                interactive: false
            }
            ScrollBar.vertical: StyledScrollBar {
                policy: ScrollBar.AsNeeded
            }
            contentWidth: availableWidth

            ColumnLayout {
                width: contentScroll.availableWidth > 0 ? contentScroll.availableWidth : contentScroll.width
                spacing: 12

                // StatusPill + bot/run text
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    StatusPill {
                        variant: root.statusPillVariant()
                        text: root.statusPillLabel()
                    }

                    Label {
                        Layout.fillWidth: true
                        visible: titleText.trim().length > 0
                        text: titleText
                        color: Theme.text
                        font.pixelSize: 16
                        font.weight: Font.DemiBold
                        wrapMode: Text.Wrap
                    }
                }

                Label {
                    Layout.fillWidth: true
                    visible: messageText.trim().length > 0
                    text: messageText
                    color: Theme.text2
                    font.pixelSize: 14
                    wrapMode: Text.Wrap
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    visible: root.detailLineCount() > 0

                    Repeater {
                        model: root.detailLines ? root.detailLines : []
                        delegate: Label {
                            property var lineData: modelData
                            Layout.fillWidth: true
                            text: lineData && lineData.text !== undefined ? String(lineData.text) : ""
                            color: lineData && lineData.color !== undefined ? String(lineData.color) : Theme.text2
                            font.pixelSize: lineData && lineData.pixelSize !== undefined ? Number(lineData.pixelSize) : 14
                            font.bold: lineData && lineData.bold !== undefined ? Boolean(lineData.bold) : true
                            wrapMode: Text.Wrap
                        }
                    }
                }
            }
        }

        RowLayout {
            Layout.alignment: Qt.AlignRight
            spacing: 10

            Button {
                id: secondaryButton
                visible: root.hasSecondaryButton()
                enabled: visible
                text: root.secondaryText
                hoverEnabled: true
                leftPadding: 22
                rightPadding: 22
                implicitWidth: Math.max(150, implicitContentWidth + leftPadding + rightPadding)
                implicitHeight: 44
                onClicked: {
                    var action = String(root.secondaryAction || "").trim()
                    if (action.length === 0) {
                        action = "secondary"
                    }
                    root.actionTriggered(action)
                    root.close()
                }

                contentItem: Text {
                    text: secondaryButton.text
                    color: "#ffffff"
                    font.pixelSize: 14
                    font.bold: true
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    radius: Theme.radiusInner
                    color: root.buttonFill(root.secondaryTone)
                    opacity: secondaryButton.down ? 0.85 : (secondaryButton.hovered ? 0.92 : 1.0)
                }
            }

            Button {
                id: confirmButton
                text: root.confirmText
                hoverEnabled: true
                leftPadding: 22
                rightPadding: 22
                implicitWidth: Math.max(150, implicitContentWidth + leftPadding + rightPadding)
                implicitHeight: 44
                onClicked: {
                    var action = String(root.confirmAction || "").trim()
                    if (action.length === 0) {
                        action = "confirm"
                    }
                    root.actionTriggered(action)
                    root.close()
                }

                contentItem: Text {
                    text: confirmButton.text
                    color: root.confirmTone === "primary" ? Theme.onAccent : "#ffffff"
                    font.pixelSize: 14
                    font.bold: true
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    radius: Theme.radiusInner
                    color: root.buttonFill(root.confirmTone)
                    opacity: confirmButton.down ? 0.85 : (confirmButton.hovered ? 0.92 : 1.0)
                }
            }
        }
    }
}
