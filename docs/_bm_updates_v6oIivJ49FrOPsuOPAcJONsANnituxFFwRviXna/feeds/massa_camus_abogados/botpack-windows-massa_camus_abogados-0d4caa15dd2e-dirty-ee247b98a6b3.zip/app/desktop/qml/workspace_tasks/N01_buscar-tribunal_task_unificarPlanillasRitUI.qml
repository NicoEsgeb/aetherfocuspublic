import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string planillaPath: ""

    property string estadoDiarioPath: ""
    property string movimientosPath: ""

    function validate() {
        if (String(estadoDiarioPath || "").trim().length === 0) {
            return "Selecciona la Planilla Estado Diario."
        }
        if (String(movimientosPath || "").trim().length === 0) {
            return "Selecciona la Planilla Movimientos y Estado Diario."
        }
        if (typeof controller !== "undefined" && controller !== null) {
            var errorMsg = controller.validatePlanilla(String(estadoDiarioPath || "").trim())
            if (errorMsg && errorMsg.length > 0) {
                var lines = errorMsg.split("\n")
                validationNotification.titleText = "Planilla Estado Diario: " + lines[0]
                validationNotification.messageText = lines.length > 1 ? lines.slice(1).join("\n") : ""
                validationNotification.open()
                return errorMsg
            }
            var errorMsg2 = controller.validateMovimientosPlanilla(String(movimientosPath || "").trim())
            if (errorMsg2 && errorMsg2.length > 0) {
                var lines2 = errorMsg2.split("\n")
                validationNotification.titleText = "Planilla Movimientos: " + lines2[0]
                validationNotification.messageText = lines2.length > 1 ? lines2.slice(1).join("\n") : ""
                validationNotification.open()
                return errorMsg2
            }
        }
        return ""
    }

    function buildPayload() {
        return {
            estado_diario_path: String(estadoDiarioPath || "").trim(),
            movimientos_path: String(movimientosPath || "").trim()
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    // --- Planilla: Estado Diario ---
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: estadoDiarioCardLayout.implicitHeight + 18

        ColumnLayout {
            id: estadoDiarioCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Planilla: Estado Diario"
                color: Common.Theme.text
                font.pixelSize: 13
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: estadoDiarioField
                    Layout.fillWidth: true
                    text: root.estadoDiarioPath
                    color: Common.Theme.text
                    placeholderText: "estado_diario.xlsx"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Button {
                    id: selectEstadoDiarioButton
                    text: "Seleccionar Planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            estadoDiarioFileDialog.currentFolder = root.toFileUrl(folder)
                        }
                        estadoDiarioFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: selectEstadoDiarioButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: selectEstadoDiarioButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: selectEstadoDiarioButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: selectEstadoDiarioButton.text
                        color: Common.Theme.text
                        font.pixelSize: 12
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    // --- Planilla: Movimientos y Estado Diario ---
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: movimientosCardLayout.implicitHeight + 18

        ColumnLayout {
            id: movimientosCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Planilla: Movimientos y Estado Diario"
                color: Common.Theme.text
                font.pixelSize: 13
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: movimientosField
                    Layout.fillWidth: true
                    text: root.movimientosPath
                    color: Common.Theme.text
                    placeholderText: "movimientos_estado_diario.xlsx"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Button {
                    id: selectMovimientosButton
                    text: "Seleccionar Planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            movimientosFileDialog.currentFolder = root.toFileUrl(folder)
                        }
                        movimientosFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: selectMovimientosButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: selectMovimientosButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: selectMovimientosButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: selectMovimientosButton.text
                        color: Common.Theme.text
                        font.pixelSize: 12
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    Common.NotificationToast {
        id: validationNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
        confirmTone: "primary"
    }

    FileDialog {
        id: estadoDiarioFileDialog
        title: "Seleccionar Planilla Estado Diario"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.estadoDiarioPath = root.toLocalPath(selectedFile)
    }

    FileDialog {
        id: movimientosFileDialog
        title: "Seleccionar Planilla Movimientos y Estado Diario"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.movimientosPath = root.toLocalPath(selectedFile)
    }
}
