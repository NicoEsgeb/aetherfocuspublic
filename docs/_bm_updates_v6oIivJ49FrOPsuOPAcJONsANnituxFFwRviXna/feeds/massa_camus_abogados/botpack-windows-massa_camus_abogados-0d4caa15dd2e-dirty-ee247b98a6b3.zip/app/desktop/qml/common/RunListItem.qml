import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// One row in the run history: #id (mono) + name/time stacked + StatusPill.
// hover = panel2; selected = accentSoft bg + accent border.
Item {
    id: item

    property string runId: ""
    property string name: ""
    property string time: ""
    property string statusVariant: "ok"
    property string statusText: ""
    property bool selected: false
    signal clicked()

    implicitHeight: 56

    Rectangle {
        anchors.fill: parent
        radius: Theme.radiusInner
        color: item.selected ? Theme.accentSoft : (hoverArea.containsMouse ? Theme.panel2 : "transparent")
        border.width: 1
        border.color: item.selected ? Theme.accent : "transparent"
        Behavior on color { ColorAnimation { duration: 120 } }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 13
        anchors.rightMargin: 13
        spacing: 11

        Label {
            text: item.runId
            color: item.selected ? Theme.accent : Theme.text3
            font.pixelSize: 13
            font.weight: Font.Bold
            font.family: "Menlo, Consolas, monospace"
            Layout.preferredWidth: 40
            elide: Text.ElideRight
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 2

            Label {
                text: item.name
                color: Theme.text
                font.pixelSize: 14
                font.weight: Font.DemiBold
                elide: Text.ElideRight
                Layout.fillWidth: true
            }

            Label {
                text: item.time
                color: Theme.text3
                font.pixelSize: 12
                elide: Text.ElideRight
                Layout.fillWidth: true
            }
        }

        StatusPill {
            variant: item.statusVariant
            text: item.statusText
        }
    }

    MouseArea {
        id: hoverArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: item.clicked()
    }
}
