import QtQuick
import QtQuick.Controls

// Summary stat tile: panel2 bg, radius 8; label 12px/600 text3 + value 21px/700.
// variant = "" | green | amber colours the value.
Rectangle {
    id: tile

    property string label: ""
    property string value: ""
    property string variant: ""

    readonly property color valueColor: {
        if (variant === "green") return Theme.success
        if (variant === "amber") return Theme.warning
        return Theme.text
    }

    color: Theme.panel2
    radius: Theme.radiusInner
    border.width: 1
    border.color: Theme.lineSoft
    implicitHeight: col.implicitHeight + 24
    implicitWidth: Math.max(col.implicitWidth + 28, 96)

    Column {
        id: col
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.margins: 14
        spacing: 3

        Label {
            text: tile.label
            color: Theme.text3
            font.pixelSize: 12
            font.weight: Font.DemiBold
            font.letterSpacing: 0.3
            elide: Text.ElideRight
            width: parent.width
        }

        Label {
            text: tile.value
            color: tile.valueColor
            font.pixelSize: 21
            font.weight: Font.Bold
            elide: Text.ElideRight
            width: parent.width
        }
    }
}
