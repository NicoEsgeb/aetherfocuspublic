import QtQuick
import QtQuick.Controls

// Primary action button. idle: accent bg / onAccent text. busy: label + 3 pulsing
// dots in a FIXED-width slot (no width jitter). disabled: 40% opacity.
Button {
    id: control

    property bool running: false
    property string idleText: "Iniciar bot"
    property string busyText: "Ejecutando"

    text: running ? busyText : idleText
    hoverEnabled: true
    opacity: enabled ? 1.0 : 0.40
    implicitHeight: 40

    property real pulse: 0
    NumberAnimation on pulse {
        running: control.running && control.visible
        from: 0; to: 1; duration: 1200
        loops: Animation.Infinite
    }

    scale: (hovered && enabled) ? 1.02 : 1.0
    Behavior on scale { NumberAnimation { duration: 120 } }

    background: Rectangle {
        radius: 9
        color: Theme.accent
        Behavior on color { ColorAnimation { duration: 150 } }
    }

    contentItem: Row {
        spacing: 9
        leftPadding: 26
        rightPadding: 26
        topPadding: 11
        bottomPadding: 11

        Label {
            text: control.text
            color: Theme.onAccent
            font.pixelSize: 15
            font.weight: Font.Bold
            font.letterSpacing: 0.2
            anchors.verticalCenter: parent.verticalCenter
        }

        // Fixed-width dots slot: reserved even when idle so text never shifts.
        Row {
            width: 26
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            opacity: control.running ? 1 : 0

            Repeater {
                model: 3
                Rectangle {
                    width: 5
                    height: 5
                    radius: 2.5
                    anchors.verticalCenter: parent.verticalCenter
                    color: Theme.onAccent
                    property real phase: Math.max(0, Math.sin((control.pulse + index * 0.2) * 2 * Math.PI))
                    opacity: 0.25 + 0.75 * phase
                    scale: 0.8 + 0.2 * phase
                }
            }
        }
    }
}
