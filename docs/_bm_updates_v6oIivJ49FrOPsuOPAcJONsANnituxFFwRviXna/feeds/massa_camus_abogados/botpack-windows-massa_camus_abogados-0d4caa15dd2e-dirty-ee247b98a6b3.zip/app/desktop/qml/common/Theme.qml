pragma Singleton
import QtQuick

// Design-token singleton for the Phase 2 UI. One token set, two value columns
// (dark / light) per Expansion_Plan/phase1_design.md §2. `mode` is driven by
// Main.qml from controller.themeMode ("light" | "dark" | "auto"); components read
// ONLY these tokens (no hardcoded colors). Phase 3 branding may override
// `accent`, `accentSoft`, `onAccent` without touching any component.
QtObject {
    id: theme

    // "light" | "dark" | "auto". Set by Main.qml (persisted via controller).
    property string mode: "light"

    // Resolve "auto" against the OS colour scheme (Qt >= 6.5).
    readonly property bool isDark: {
        if (mode === "dark") {
            return true
        }
        if (mode === "light") {
            return false
        }
        return Application.styleHints.colorScheme === Qt.Dark
    }

    // ---- surfaces ----
    readonly property color bg: isDark ? "#111418" : "#f5f6f8"
    readonly property color sidebar: isDark ? "#171b21" : "#ffffff"
    readonly property color panel: isDark ? "#1b2027" : "#ffffff"
    readonly property color panel2: isDark ? "#20262f" : "#f2f4f7"
    readonly property color line: isDark ? "#2a313c" : "#d8dde4"
    readonly property color lineSoft: isDark ? "#242b35" : "#e6e9ee"

    // ---- text ----
    readonly property color text: isDark ? "#e9edf3" : "#1a202c"
    readonly property color text2: isDark ? "#a8b1bd" : "#4a5568"
    readonly property color text3: isDark ? "#77808d" : "#8a94a3"

    // ---- accent (branding override, Phase 3) ----
    // `brandAccent` is bound from Main.qml when branding.json provides a valid
    // accent_color (hex, validated in app/core/branding.py). While it is the
    // empty string (the default), accent/accentSoft/onAccent keep EXACTLY the
    // pre-branding values, so with no branding.json nothing changes.
    property string brandAccent: ""
    readonly property color _brandAccentColor: brandAccent !== "" ? brandAccent : "transparent"
    readonly property real _brandAccentLuma: _brandAccentColor.r * 0.299
                                             + _brandAccentColor.g * 0.587
                                             + _brandAccentColor.b * 0.114
    property color accent: brandAccent !== "" ? _brandAccentColor
                                              : (isDark ? "#4da3ff" : "#2563eb")
    property color accentSoft: brandAccent !== "" ? Qt.alpha(_brandAccentColor, isDark ? 0.22 : 0.15)
                                                  : (isDark ? "#12283f" : "#e8effd")
    property color onAccent: brandAccent !== "" ? (_brandAccentLuma > 0.55 ? "#0b1520" : "#ffffff")
                                                : (isDark ? "#0b1520" : "#ffffff")

    // ---- status ----
    readonly property color success: isDark ? "#3ecf8e" : "#0f9d63"
    readonly property color successSoft: isDark ? "#12291f" : "#e2f6ec"
    readonly property color danger: isDark ? "#f47174" : "#dc3d43"
    readonly property color dangerSoft: isDark ? "#331b1c" : "#fceaea"
    readonly property color warning: isDark ? "#f5b451" : "#b57811"
    readonly property color warningSoft: isDark ? "#33270f" : "#fdf3df"
    readonly property color cancel: isDark ? "#e09a58" : "#a05f1a"
    readonly property color cancelSoft: isDark ? "#2e2114" : "#faedd9"

    // ---- geometry ----
    readonly property int radiusCard: 10
    readonly property int radiusInner: 8
    readonly property int radiusPill: 99
}
