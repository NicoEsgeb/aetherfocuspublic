import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

// Live progress panel for the clean03 "Extraer Datos Pagarés" bot. Rendered in
// the "Resumen del proceso" tab and refreshed every ~2s by the controller while
// the run is active (summaryData is rebuilt from the run log on each refresh).
// Shows a blue determinate bar that fills as each RUT is processed, the count,
// and the elapsed time. Clean03-only -- other bots keep their own summary panels.
Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cAccent: Common.Theme.accent      // blue progress
    readonly property color cAccentGlow: Common.Theme.accent
    readonly property color cSuccess: Common.Theme.success
    readonly property color cDanger: Common.Theme.danger

    function val(key, fallback) {
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null)
            return fallback
        return summaryData[key]
    }
    function isTrue(key) { return root.val(key, false) === true }
    function num(key) { var v = Number(root.val(key, 0)); return isNaN(v) ? 0 : v }
    function hasData() { return root.isTrue("hasData") }
    function frac() {
        var f = root.num("fraction")
        if (f < 0) return 0
        if (f > 1) return 1
        return f
    }
    function barColor() {
        if (root.isTrue("cancelled")) return Common.Theme.cancel  // stopped manually
        if (root.isTrue("failed")) return root.cDanger
        if (root.isTrue("success")) return root.cSuccess
        return root.cAccent
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 14

        // ---- Header: process name + status chip ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Label {
                text: root.val("processLabel", "Extraer Datos Pagarés")
                color: root.cTextMain
                font.pixelSize: 18
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Rectangle {
                radius: 7
                implicitHeight: 24
                implicitWidth: statusWordLabel.implicitWidth + 22
                color: Common.Theme.panel2
                border.width: 1
                border.color: root.barColor()

                Label {
                    id: statusWordLabel
                    anchors.centerIn: parent
                    text: root.val("statusWord", "-")
                    color: root.barColor()
                    font.pixelSize: 12
                    font.bold: true
                }
            }
        }

        // ---- Main card: big headline + blue bar + count/elapsed ----
        Rectangle {
            visible: root.hasData()
            Layout.fillWidth: true
            radius: 14
            color: root.cPanel
            border.width: 1
            border.color: root.cLine
            implicitHeight: cardCol.implicitHeight + 36

            ColumnLayout {
                id: cardCol
                anchors.fill: parent
                anchors.margins: 18
                spacing: 16

                Label {
                    text: root.val("headline", "")
                    color: root.cTextMain
                    font.pixelSize: 26
                    font.bold: true
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                }

                // Shown once the process finishes OK: opens the output folder
                // that holds the generated matriz so the user can open/copy it.
                Button {
                    id: openMatrizButton
                    visible: root.isTrue("success") && String(root.val("outputDir", "")).length > 0
                    Layout.fillWidth: true
                    Layout.preferredHeight: 42
                    text: "Abrir Resultados"
                    hoverEnabled: true
                    onClicked: controller.openPathInExplorer(String(root.val("outputDir", "")))
                    background: Rectangle {
                        radius: 9
                        border.width: 1
                        border.color: openMatrizButton.down ? Common.Theme.success : Common.Theme.success
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: openMatrizButton.down ? Common.Theme.success : Common.Theme.success }
                            GradientStop { position: 1.0; color: openMatrizButton.down ? Common.Theme.success : Common.Theme.success }
                        }
                    }
                    contentItem: Text {
                        text: openMatrizButton.text
                        color: Common.Theme.text
                        font.pixelSize: 14
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                // Blue determinate progress bar
                Rectangle {
                    id: barTrack
                    Layout.fillWidth: true
                    implicitHeight: 18
                    radius: 9
                    color: Common.Theme.panel2
                    border.width: 1
                    border.color: root.cLine
                    clip: true

                    Rectangle {
                        id: barFill
                        height: parent.height
                        width: Math.max(parent.height, parent.width * root.frac())
                        radius: 9
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0.0; color: root.barColor() }
                            GradientStop { position: 1.0; color: root.cAccentGlow }
                        }
                        // Smoothly tween between the 2s refresh updates so the bar
                        // glides forward instead of jumping.
                        Behavior on width {
                            NumberAnimation { duration: 450; easing.type: Easing.OutCubic }
                        }
                    }

                    // Sweeping highlight so the bar looks alive even when a single
                    // big RUT keeps the count steady for a while (running only).
                    Rectangle {
                        id: shimmer
                        visible: root.isTrue("running")
                        height: parent.height
                        width: 80
                        opacity: 0.18
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0.0; color: "transparent" }
                            GradientStop { position: 0.5; color: Common.Theme.text }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                        SequentialAnimation on x {
                            running: shimmer.visible
                            loops: Animation.Infinite
                            NumberAnimation { from: -80; to: barTrack.width; duration: 1400; easing.type: Easing.InOutQuad }
                            PauseAnimation { duration: 350 }
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    Label {
                        text: root.num("done") + " / " + root.num("total") + " RUTs"
                        color: root.cTextMuted
                        font.pixelSize: 13
                        Layout.fillWidth: true
                    }

                    Label {
                        text: "Tiempo: " + root.val("elapsedText", "-")
                        color: root.cTextMuted
                        font.pixelSize: 13
                    }
                }
            }
        }

        // ---- Fallback before the first progress marker arrives ----
        Rectangle {
            visible: !root.hasData()
            Layout.fillWidth: true
            Layout.preferredHeight: 120
            radius: 14
            color: root.cPanel
            border.width: 1
            border.color: root.cLine

            Label {
                anchors.centerIn: parent
                text: root.val("headline", "Preparando el proceso...")
                color: root.cTextMuted
                font.pixelSize: 14
            }
        }

        Item { Layout.fillHeight: true }
    }
}
