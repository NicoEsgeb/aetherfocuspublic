import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property color textMuted: Common.Theme.text2
    // The RUT folders are FIXED at input/ruts/ (not chosen here); only the
    // matriz is selectable.
    property string matrizInputPath: ""

    signal matrizInputPathEdited(string value)

    function validate() {
        if (!String(matrizInputPath || "").trim()) {
            errorNotification.titleText = "Falta la matriz de entrada"
            errorNotification.messageText = "Selecciona la matriz de entrada (.xlsx) desde la carpeta input/matriz."
            errorNotification.open()
            return "Selecciona la matriz de entrada (.xlsx) antes de ejecutar."
        }
        return ""
    }

    function buildPayload() {
        // The RUTs folder is fixed (input/ruts) — only the matriz + the toggle
        // travel in the payload.
        return {
            matriz_input_path: String(matrizInputPath || "").trim(),
            clean03_force_fresh: forceFreshCheck.checked,
            clean03_parallel: parallelCheck.checked
        }
    }

    function inputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function subFolderUrl(sub) {
        var base = root.inputFolder()
        if (base.length === 0)
            return "file:///"
        return root.toFileUrl(base + "/" + sub)
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function")
            return helpers.localPathToFileUrl(pathText)
        return "file:///"
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function")
            return helpers.fileUrlToLocalPath(fileUrl)
        return String(fileUrl || "")
    }

    // -----------------------------------------------------------------------
    // Carpeta de RUTs (fija: input/ruts) — botón para abrirla
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: rutsCardLayout.implicitHeight + 18

        ColumnLayout {
            id: rutsCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Carpeta de RUTs"
                color: Common.Theme.text
                font.pixelSize: 13
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "El bot siempre procesa la carpeta input/ruts. Pega ahí una subcarpeta por RUT (cada una con PAGARE_*, INFORME_DEUDA, HOJA_DE_FIRMA, etc.). Usa el botón para abrirla y revisarla o pegar las carpetas."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Button {
                id: openRutsButton
                text: "Abrir carpeta"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("ruts"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: openRutsButton.down ? Common.Theme.accent : Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: openRutsButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: openRutsButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: openRutsButton.text
                    color: Common.Theme.text
                    font.pixelSize: 12
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Matriz de entrada (.xlsx) — seleccionable, abre en input/matriz
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: matrizCardLayout.implicitHeight + 18

        ColumnLayout {
            id: matrizCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            Label {
                text: "Matriz de entrada (.xlsx)"
                color: Common.Theme.text
                font.pixelSize: 13
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Excel con las filas por RUT/pagaré (RUT, DV, NOMBRE, OPERACIÓN, CARTERA, MORA). Guárdalo en input/matriz. No se modifica: el bot escribe una matriz nueva en output/."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            TextField {
                id: matrizField
                Layout.fillWidth: true
                text: root.matrizInputPath
                color: Common.Theme.text
                placeholderText: "Ninguna matriz seleccionada"
                placeholderTextColor: Common.Theme.text3
                readOnly: true
                background: Rectangle {
                    radius: 8
                    color: Common.Theme.panel2
                    border.width: matrizField.activeFocus ? 2 : 1
                    border.color: matrizField.activeFocus ? Common.Theme.accent : Common.Theme.line
                }
            }

            Button {
                id: selectMatrizButton
                text: "Seleccionar Matriz"
                hoverEnabled: true
                onClicked: {
                    matrizDialog.currentFolder = root.subFolderUrl("matriz")
                    matrizDialog.open()
                }
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: selectMatrizButton.down ? Common.Theme.accent : Common.Theme.accent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: selectMatrizButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                        GradientStop { position: 1.0; color: selectMatrizButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                    }
                }
                contentItem: Text {
                    text: selectMatrizButton.text
                    color: Common.Theme.text
                    font.pixelSize: 12
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Re-procesar desde cero (ignorar cache OCR)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: forceFreshLayout.implicitHeight + 18

        ColumnLayout {
            id: forceFreshLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: forceFreshCheck
                checked: true
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: forceFreshCheck.leftPadding
                    y: forceFreshCheck.height / 2 - height / 2
                    radius: 5
                    color: forceFreshCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: forceFreshCheck.checked ? 2 : 1
                    border.color: forceFreshCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: 14
                        font.bold: true
                        visible: forceFreshCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Re-procesar desde cero (ignorar cache)"
                    color: Common.Theme.text
                    font.pixelSize: 13
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: forceFreshCheck.indicator.width + forceFreshCheck.spacing
                }
            }

            Label {
                text: "Normalmente el bot reutiliza el OCR ya hecho para que volver a correr sea instantaneo. Marca esta casilla para volver a leer (OCR) todos los PDF desde cero, util si una corrida quedo a medias. Es mas lento."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // -----------------------------------------------------------------------
    // Procesar en paralelo (varios RUT a la vez)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: parallelLayout.implicitHeight + 18

        ColumnLayout {
            id: parallelLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 6

            CheckBox {
                id: parallelCheck
                checked: false
                spacing: 8
                Layout.fillWidth: true

                indicator: Rectangle {
                    implicitWidth: 20
                    implicitHeight: 20
                    x: parallelCheck.leftPadding
                    y: parallelCheck.height / 2 - height / 2
                    radius: 5
                    color: parallelCheck.checked ? Common.Theme.line : Common.Theme.panel2
                    border.width: parallelCheck.checked ? 2 : 1
                    border.color: parallelCheck.checked ? Common.Theme.accent : Common.Theme.line

                    Text {
                        anchors.centerIn: parent
                        text: "✓"
                        color: Common.Theme.text
                        font.pixelSize: 14
                        font.bold: true
                        visible: parallelCheck.checked
                    }
                }

                contentItem: Text {
                    text: "Procesar en paralelo"
                    color: Common.Theme.text
                    font.pixelSize: 13
                    font.bold: true
                    verticalAlignment: Text.AlignVCenter
                    leftPadding: parallelCheck.indicator.width + parallelCheck.spacing
                }
            }

            Label {
                text: "Procesa varios RUT a la vez usando todos los nucleos del computador (deja uno libre). El resultado (la matriz) es identico al modo normal, solo que mas rapido. Marca esta casilla cuando tengas muchas carpetas de RUT. El computador puede ir mas lento mientras corre."
                color: root.textMuted
                font.pixelSize: 12
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    FileDialog {
        id: matrizDialog
        title: "Seleccionar la matriz de entrada (.xlsx)"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: {
            root.matrizInputPath = root.toLocalPath(selectedFile)
            root.matrizInputPathEdited(root.matrizInputPath)
        }
    }

    Common.NotificationToast {
        id: errorNotification
        tone: "error"
        titleText: ""
        messageText: ""
        confirmText: "Entendido"
    }
}
