import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarning: Common.Theme.warning

    function hasData() {
        return !!summaryData && summaryData.hasData === true
    }

    function metricValue(key) {
        if (!hasData()) {
            return "-"
        }
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null) {
            return "0"
        }
        return String(summaryData[key])
    }

    function outputExcelPath() {
        if (!summaryData || !summaryData.outputExcelPath) return ""
        return String(summaryData.outputExcelPath).trim()
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 10

        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.preferredHeight: 108
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: root.cLine

                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    Label {
                        text: "Exhortos Procesados"
                        color: root.cTextMuted
                        font.pixelSize: 12
                    }

                    Label {
                        text: root.metricValue("exhortosProcesados")
                        color: root.cTextMain
                        font.pixelSize: 34
                        font.bold: true
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.preferredHeight: 108
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: Common.Theme.success

                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    Row {
                        spacing: 6

                        Label {
                            text: "✓"
                            color: root.cSuccess
                            font.pixelSize: 14
                            font.bold: true
                        }

                        Label {
                            text: "Causas Origen Encontradas"
                            color: root.cTextMuted
                            font.pixelSize: 12
                        }
                    }

                    Label {
                        text: root.metricValue("causasOrigenEncontradas")
                        color: root.cSuccess
                        font.pixelSize: 34
                        font.bold: true
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.preferredHeight: 108
                radius: 12
                color: root.cPanel
                border.width: 1
                border.color: Common.Theme.warningSoft

                Column {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    Row {
                        spacing: 6

                        Label {
                            text: "•"
                            color: root.cWarning
                            font.pixelSize: 14
                            font.bold: true
                        }

                        Label {
                            text: "Exhortos Pendientes"
                            color: root.cTextMuted
                            font.pixelSize: 12
                        }
                    }

                    Label {
                        text: root.metricValue("exhortosPendientes")
                        color: root.cWarning
                        font.pixelSize: 34
                        font.bold: true
                    }
                }
            }
        }

        Button {
            id: abrirPlanillaButton
            visible: root.outputExcelPath().length > 0
            text: "Abrir planilla de Exhortos Procesados"
            Layout.alignment: Qt.AlignLeft
            hoverEnabled: true
            onClicked: {
                var path = root.outputExcelPath()
                if (path.length > 0 && typeof controller !== "undefined" && controller !== null) {
                    controller.openFile(path)
                }
            }
            background: Rectangle {
                radius: 8
                border.width: 1
                border.color: abrirPlanillaButton.down ? Common.Theme.accent : Common.Theme.accent
                gradient: Gradient {
                    GradientStop { position: 0.0; color: abrirPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                    GradientStop { position: 1.0; color: abrirPlanillaButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                }
            }
            contentItem: Text {
                text: abrirPlanillaButton.text
                color: Common.Theme.text
                font.pixelSize: 12
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }

        Rectangle {
            visible: !root.hasData()
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine

            Label {
                anchors.centerIn: parent
                text: "Sin datos disponibles para esta corrida."
                color: root.cTextMuted
                font.pixelSize: 13
                horizontalAlignment: Text.AlignHCenter
            }
        }

        Item {
            visible: root.hasData()
            Layout.fillHeight: true
        }
    }
}
