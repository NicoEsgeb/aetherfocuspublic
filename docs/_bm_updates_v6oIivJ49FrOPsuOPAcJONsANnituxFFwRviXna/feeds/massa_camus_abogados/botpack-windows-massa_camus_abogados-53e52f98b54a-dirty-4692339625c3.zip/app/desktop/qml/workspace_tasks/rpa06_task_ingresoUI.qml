import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property string matrixPath: ""
    property string fechaDesde: ""
    property string fechaHasta: ""
    property string informePath: ""
    property string caratulasFolderPath: ""
    property string demandasPath: ""
    property var workspaceConfig: ({})
    property var helpers: ({})
    property bool enableMatrixSelection: false

    signal matrixPathEdited(string value)
    signal fechaDesdeEdited(string value)
    signal fechaHastaEdited(string value)
    signal informePathEdited(string value)

    function validate() {
        return ""
    }

    function buildPayload() {
        var payload = {}
        var matrix = String(matrixPath || "").trim()
        if (matrix.length > 0) {
            payload.matriz_demandas_path = matrix
        }
        return payload
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultMatrixFolder() {
        var demandasFolder = String(demandasPath || "").trim()
        if (demandasFolder.length > 0) {
            var needsSlash = !demandasFolder.endsWith("/") && !demandasFolder.endsWith("\\")
            if (needsSlash) {
                demandasFolder += Qt.platform.os === "windows" ? "\\" : "/"
            }
            return demandasFolder + "Matriz_Demandas"
        }
        if (workspaceConfig && workspaceConfig.defaultMatrixFolder) {
            return String(workspaceConfig.defaultMatrixFolder || "").trim()
        }
        return ""
    }

    function demandasRootFolder() {
        var demandasFolder = String(demandasPath || "").trim()
        if (demandasFolder.length > 0) {
            return demandasFolder
        }
        var matrixFolder = String(defaultMatrixFolder() || "").trim()
        if (matrixFolder.length === 0) {
            return ""
        }
        var slashIndex = Math.max(matrixFolder.lastIndexOf("/"), matrixFolder.lastIndexOf("\\"))
        if (slashIndex < 0) {
            return ""
        }
        return matrixFolder.substring(0, slashIndex)
    }

    function pathJoin(basePath, folderName) {
        var base = String(basePath || "").trim()
        if (base.length === 0) {
            return ""
        }
        var separator = base.indexOf("\\") >= 0 ? "\\" : "/"
        if (base.endsWith("/") || base.endsWith("\\")) {
            return base + folderName
        }
        return base + separator + folderName
    }

    function openInputFolder(folderName) {
        var rootFolder = demandasRootFolder()
        var targetPath = pathJoin(rootFolder, folderName)
        if (targetPath.length === 0) {
            return
        }
        if (typeof controller !== "undefined" && controller !== null) {
            controller.openPathInExplorer(targetPath)
        }
    }

    function isAbsolutePath(pathText) {
        var value = String(pathText || "").trim()
        if (value.length === 0) {
            return false
        }
        if (value.startsWith("/") || value.startsWith("\\\\")) {
            return true
        }
        return /^[A-Za-z]:[\\/]/.test(value)
    }

    function absoluteMatrixPath() {
        var configured = String(matrixPath || "").trim()
        if (configured.length === 0) {
            configured = "Matriz_Demandas/BOT_MATRIZ_DEMANDAS_ingreso.xlsx"
        }
        if (configured.startsWith("file://")) {
            return toLocalPath(configured)
        }
        if (isAbsolutePath(configured)) {
            return configured
        }
        var rootFolder = demandasRootFolder()
        if (rootFolder.length === 0) {
            return configured
        }
        return pathJoin(rootFolder, configured)
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: foldersCardLayout.implicitHeight + 18

        ColumnLayout {
            id: foldersCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Carpeta de carga para el Ingreso de Demandas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Usa estos accesos para abrir las carpetas donde debes pegar los archivos antes de ejecutar."
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Common.InsetAlloyButton {
                    id: openDemandasFirmadasButton
                    text: "Demandas firmadas"
                    Layout.fillWidth: true
                    hoverEnabled: true
                    onClicked: root.openInputFolder("01_Demandas_firmadas")
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: openDemandasFirmadasButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: openDemandasFirmadasButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: openDemandasFirmadasButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: openDemandasFirmadasButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Common.InsetAlloyButton {
                    id: openDocumentosButton
                    text: "Documents"
                    Layout.fillWidth: true
                    hoverEnabled: true
                    onClicked: root.openInputFolder("02_Documentos")
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: openDocumentosButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: openDocumentosButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: openDocumentosButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: openDocumentosButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }

                Common.InsetAlloyButton {
                    id: openMandatosButton
                    text: "Mandatos"
                    Layout.fillWidth: true
                    hoverEnabled: true
                    onClicked: root.openInputFolder("03_Mandatos")
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: openMandatosButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: openMandatosButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: openMandatosButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: openMandatosButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    Rectangle {
        Layout.fillWidth: true
        radius: 10
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: matrixCardLayout.implicitHeight + 18

        ColumnLayout {
            id: matrixCardLayout
            anchors.fill: parent
            anchors.margins: 9
            spacing: 8

            Label {
                text: "Matriz a utilizar para Ingresar Demandas"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: root.enableMatrixSelection
                    ? "Selecciona la matriz Excel que utilizará el bot para ingresar las demandas."
                    : "Usa este acceso para abrir y modificar la matriz que vas a utilizar."
                color: Common.Theme.text2
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    id: matrixField
                    visible: root.enableMatrixSelection
                    Layout.fillWidth: true
                    text: root.matrixPath
                    color: Common.Theme.text
                    placeholderText: "BOT_MATRIZ_DEMANDAS_ingreso.xlsx"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: matrixField.activeFocus ? 2 : 1
                        border.color: matrixField.activeFocus ? Common.Theme.accent : Common.Theme.line
                    }
                }

                Common.InsetAlloyButton {
                    id: openMatrixButton
                    text: root.enableMatrixSelection
                        ? "Seleccionar matriz"
                        : "Matriz Demandas para Ingreso"
                    hoverEnabled: true
                    Layout.alignment: Qt.AlignLeft
                    onClicked: {
                        if (root.enableMatrixSelection) {
                            var folderPath = root.defaultMatrixFolder()
                            if (folderPath.length > 0) {
                                matrixFileDialog.currentFolder = root.toFileUrl(folderPath)
                            }
                            matrixFileDialog.open()
                            return
                        }

                        var targetPath = root.absoluteMatrixPath()
                        if (targetPath.length <= 0) {
                            return
                        }
                        var opened = Qt.openUrlExternally(root.toFileUrl(targetPath))
                        if (!opened && typeof controller !== "undefined" && controller !== null) {
                            controller.openPathInExplorer(targetPath)
                        }
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: openMatrixButton.down ? Common.Theme.accent : Common.Theme.accent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: openMatrixButton.down ? Common.Theme.accentSoft : Common.Theme.line }
                            GradientStop { position: 1.0; color: openMatrixButton.down ? Common.Theme.accentSoft : Common.Theme.accentSoft }
                        }
                    }
                    contentItem: Text {
                        text: openMatrixButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }
    }

    FileDialog {
        id: matrixFileDialog
        title: "Seleccionar matriz de demandas"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm *.xls)", "Todos los archivos (*)"]
        onAccepted: root.matrixPathEdited(root.toLocalPath(selectedFile))
    }
}
