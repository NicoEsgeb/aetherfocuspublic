# Clean08 Chrome extension (local)

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select this `extension` folder.
4. Start Clean08 in BotManager after selecting the workbook.
5. In the authenticated PJUD `indexN.php` page, press **Start** in the Clean08 panel.

The extension talks only to the Clean08 loopback bridge at
`http://127.0.0.1:8769`. Build `0.17.0` executes the following fifteen guarded
steps for every populated Excel row, in sheet order:

1. Click the visible menu item **Ingresar Escrito**.
2. Open the **Competencia** Select2 control and select **Civil**, with an exact
   visible-text match and read-back verification.
3. Read **Tribunal** from the current Excel row, convert (for example) `15` to
   **15º Juzgado Civil de Santiago**, and select that exact option with read-back
   verification.
4. Select **C** in the native **Tipo** dropdown by visible option text and verify
   the selected option.
5. Read **ROL** from the current Excel row, enter it in the numeric **Rol** field,
   and verify the resulting field value.
6. Read **Año** from the current Excel row, select that exact year in the **Año**
   Select2 control, and verify the visible selection.
7. Wait until **Consulta Rol** is visible and enabled, then click it once.
8. Wait for the result form, select **1 Principal** in **Cuaderno**, and verify
   the visible selection.
9. Select **AB.DTE-JOAQUÍN MAURICIO CARRILLO MORENO** in **Parte que Presenta**
   and verify the visible selection.
10. Select **Escritos Generales** in **Grupo Escrito** and verify the visible
    selection.
11. Select **Señala domicilio** in **Tipo Escrito** and verify the visible
    selection.
12. Wait until **Grabar Escrito** is visible and enabled, then click it exactly
    once. This is treated as the point of no return: after the click, the
    extension stops if it cannot report the result instead of repeating it.
13. Read the current row's **Archivo** value, fetch that PDF from
    `input/escritos-pdfs` through the local bridge, inject it into the hidden
    `#uploadMultiFileDocPrincipal` input with `DataTransfer`, verify the staged
    filename and byte size, and click the scoped **Adjuntar** button once.
14. Wait up to three minutes for PJUD to add a new Documento Principal card.
    Confirm it by matching the card's displayed `tamano()` in MB against the
    exact uploaded byte count, including a pre-click count baseline so an older
    same-sized card cannot be mistaken for this upload.
15. Find the visible button with Knockout binding `cerrarAdjuntar`, verify its
    text is **Cerrar y Continuar**, click it once, and wait until both the button
    and `#dDPrincipal` are no longer visible before reporting success.

All rows and their referenced PDFs are validated before the bridge starts. Each
step reports success or failure with its number, action, label, and portal detail.
When a portal step fails, the bridge records that row (including whether it had
already passed **Grabar Escrito**), runs a best-effort cleanup of open Select2 or
attachment UI, and advances to Step 1 of the next row. It never retries the
failed row, which avoids creating a duplicate after the point of no return.

Input/preflight errors and loss of the bridge connection remain fatal because
the extension cannot safely determine whether an unreported action happened.

After all rows have been attempted, the bot writes
`output/Resultado_<nombre original>.xlsx`. It is a copy of the selected workbook
with `ESTADO ESCRITO` inserted as the first column:

- **Ingresado** (green): PJUD displayed the uploaded PDF as a confirmed
  Documento Principal. A later failure to close the attachment window does not
  erase this confirmation.
- **No ingresado** (yellow): the row failed before `Grabar Escrito` was pressed.
- **Revisar manualmente** (orange): `Grabar Escrito` was pressed, so the escrito
  may exist, but the PDF was not confirmed. The row must be checked before any
  retry.

Failed or ambiguous status cells contain an Excel note explaining the portal
location in plain language without internal step numbers.
