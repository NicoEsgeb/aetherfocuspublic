(() => {
  const MESSAGE_TYPE = "CLEAN05_BRIDGE_REQUEST";
  const PANEL_ID = "clean05-emerix-panel";
  // Shown in the panel title. Reloading the extension does NOT re-inject this
  // script into tabs that are already open, so this marker is the way to tell
  // whether the page is running the current build or a stale one.
  const BUILD = "v0.23.0";

  // Emerix is an Angular SPA. The "_ngcontent-pib-cNNN" attributes are build
  // scoped and change on every Emerix deploy, and the "ng-pristine/ng-dirty"
  // classes flip as soon as we type, so neither is usable as a selector.
  // The BEM class on the input is the stable handle.
  const SEARCH_INPUT_SELECTORS = [
    "input.headerSearch__form__container--input",
    ".headerSearch__form__container input:not([type='hidden'])",
    ".headerSearch input:not([type='hidden'])"
  ];

  // The magnifier <i> is only the icon; the clickable element is its button.
  const SEARCH_BUTTON_SELECTORS = [
    "button.searchSubmit",
    ".headerSearch__form__container--groupBtn button.searchSubmit",
    ".headerSearch__form__container--groupBtn button:has(i.fa-search)"
  ];

  // Every button in the person-record menu bar carries the same classes
  // ("mat-menu-trigger menu menu__button"), so they can only be told apart by
  // their label. Angular Material renders the dropdown itself into a CDK
  // overlay on <body>, not inside the trigger, hence the separate selector.
  const MENU_TRIGGER_SELECTOR = "button.mat-menu-trigger";
  const MENU_BAR_SELECTOR = ".person-record-menu__container";
  const MENU_ITEM_SELECTOR = ".mat-menu-content button[mat-menu-item], .mat-menu-content button";
  const MENU_PANEL_SELECTOR = ".mat-menu-content";

  // "Nuevo" in the Gastos panel is an <a>, not a <button>, and its BEM class
  // is specific enough that no label disambiguation is needed.
  const NEW_BUTTON_SELECTORS = [
    "a.parametric-crud-new-btn",
    ".parametric-crud-new a",
    ".parametric-crud-new-btn"
  ];

  // In the "Nuevo" dialog the only stable handle on the Tipo de Gasto select is
  // its reactive-form control name. "id=mat-select-N" is auto-numbered by
  // Angular Material and "ng-tns-cNNN-NN" is a dynamic animation namespace, so
  // neither survives a re-render. The visible label is the fallback.
  const GASTO_TYPE_SELECT_SELECTORS = ['mat-select[formcontrolname="SubconceptId"]'];
  const GASTO_TYPE_LABEL = "Tipo de Gasto";
  const SELECT_PANEL_SELECTOR = ".mat-select-panel, .cdk-overlay-pane mat-option";

  // Proveedor is a mat-autocomplete feeding a mat-chip-list: typing only opens
  // the suggestion panel, the value is not accepted until an option is picked.
  // "id=mat-chip-list-input-N" is auto-numbered, so key off the placeholder.
  const PROVEEDOR_INPUT_SELECTORS = [
    'input.mat-chip-input[placeholder="Selección de proveedor"]',
    'input[placeholder="Selección de proveedor"]',
    "input.mat-autocomplete-trigger.mat-chip-input"
  ];
  const PROVEEDOR_PLACEHOLDER_HINT = "proveedor";
  const PROVEEDOR_LABEL = "Proveedor";
  const AUTOCOMPLETE_PANEL_SELECTOR = ".mat-autocomplete-panel mat-option, .cdk-overlay-pane mat-option";
  // The accepted value materialises as a chip inside the list wrapper, which is
  // what proves the autocomplete took it rather than just holding loose text.
  const CHIP_SELECTOR = "mat-chip-list .mat-chip, mat-chip-list mat-chip, .mat-chip-list-wrapper .mat-chip";

  // Importe is a plain number input bound to formcontrolname="Monto"; the
  // "id=mat-input-N" is auto-numbered, so key off the form control name. The
  // "Importe" label is the fallback.
  const IMPORTE_INPUT_SELECTORS = ['input[formcontrolname="Monto"]'];
  const IMPORTE_LABEL = "Importe";

  // BOLETA -> "Nro Comprobante", a plain text input bound to VoucherNumber.
  // "id=mat-input-N" is auto-numbered, so key off the form control name.
  const BOLETA_INPUT_SELECTORS = ['input[formcontrolname="VoucherNumber"]'];
  const BOLETA_LABEL = "Nro Comprobante";

  // The identificador is a second mat-select in the Nuevo form (the causa the
  // gasto is filed against). Its reactive-form control name is "ObjectId" and
  // its visible label is "Gestión judicial"; the "id=mat-select-N" and
  // "ng-tns-cNNN" classes are auto-generated, so key off the control name with
  // the label as the fallback. The Tipo de Gasto select ("SubconceptId") is
  // excluded so the fallbacks cannot land on it by mistake.
  const IDENTIFICADOR_SELECT_SELECTORS = ['mat-select[formcontrolname="ObjectId"]'];
  const IDENTIFICADOR_LABEL = "Gestión judicial";
  const GASTO_TYPE_CONTROL = "SubconceptId";
  // Selection rule: the identificador is ALWAYS the ROL/causa in "C-####-AAAA"
  // format (e.g. C-6879-2026). EJEC/other formats are ignored. If there is not
  // exactly one ROL option, the bot stops and the row is flagged for review.
  // Tolerant of the spacing Emerix puts around the dashes.
  const IDENTIFICADOR_ROL_RE = /^C-\s*\d+\s*-\s*\d{4}$/i;

  // "Comentario" is a <textarea> bound to formcontrolname="Comment" (filled with
  // the row's DS column). The "id=mat-input-N" is auto-numbered, so key off the
  // control name with the "Comentario" label as the fallback.
  const COMENTARIO_INPUT_SELECTORS = ['textarea[formcontrolname="Comment"]'];
  const COMENTARIO_LABEL = "Comentario";

  // The dialog's X (close) button. Angular Material renders the directive
  // [mat-dialog-close] as the attribute "matdialogclose"/"mat-dialog-close";
  // that attribute is the stable handle. The fallback is the icon button whose
  // <mat-icon> reads "close" inside the open dialog. NOTE: this deliberately
  // closes the form WITHOUT pressing "Grabar", so nothing is committed.
  const CLOSE_DIALOG_SELECTORS = [
    "button[mat-dialog-close]",
    "button[matdialogclose]",
    ".mat-dialog-container button[mat-dialog-close]",
    ".mat-dialog-container button[matdialogclose]"
  ];
  const DIALOG_CONTAINER_SELECTOR = "mat-dialog-container, .mat-dialog-container";

  let connected = false;
  let starting = false;
  let verified = false;
  let workTimer = 0;
  let busy = false;
  // Set once the desktop reports the whole planilla is finished, so the panel
  // shows a friendly "done" message instead of a scary "connection lost" when
  // the bridge server shuts down right after the last row.
  let completed = false;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean05-title">Clean05 · Emerix · ${BUILD}</div>
      <div class="clean05-status" data-role="status">Esperando BotManager...</div>
      <div class="clean05-details" data-role="details">Excel sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    return panel;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean05-ok", tone === "ok");
    status.classList.toggle("clean05-error", tone === "error");
  }

  function renderWorkbook(summary) {
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const details = createPanel().querySelector('[data-role="details"]');
    details.textContent = workbook.filename
      ? `${workbook.filename} · ${workbook.sheet_count || 0} hoja(s) · ${workbook.data_rows || 0} fila(s)`
      : "Excel sin confirmar";
  }

  function findBySelectors(selectors) {
    for (const selector of selectors) {
      let element = null;
      try {
        element = document.querySelector(selector);
      } catch (_) {
        continue; // e.g. :has() on an engine that does not support it
      }
      if (element) {
        return element;
      }
    }
    return null;
  }

  // Labels arrive padded (" Gestión ") and accented, so compare on a folded
  // form: collapsed whitespace, lowercased, accents stripped.
  function foldLabel(value) {
    return String(value == null ? "" : value)
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "");
  }

  function findByLabel(selector, label, root) {
    const target = foldLabel(label);
    const scope = root || document;
    let candidates = [];
    try {
      candidates = Array.from(scope.querySelectorAll(selector));
    } catch (_) {
      return null;
    }
    // Exact label first: "Gestión" must not match "Historial de gestiones".
    return candidates.find((el) => foldLabel(el.textContent) === target)
      || candidates.find((el) => foldLabel(el.textContent).includes(target))
      || null;
  }

  // The header renders asynchronously after the SPA route settles, so poll
  // instead of assuming the element exists the moment we look.
  function waitFor(probe, errorMessage, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const immediate = probe();
      if (immediate) {
        resolve(immediate);
        return;
      }
      const deadline = Date.now() + timeoutMs;
      const timer = window.setInterval(() => {
        const found = probe();
        if (found) {
          window.clearInterval(timer);
          resolve(found);
        } else if (Date.now() > deadline) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }

  function waitForSearchInput() {
    return waitFor(
      () => findBySelectors(SEARCH_INPUT_SELECTORS),
      "No se encontró el buscador de Emerix en la página."
    );
  }

  const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

  function setNativeValue(input, value) {
    // Assigning input.value directly bypasses Angular's change detection, so
    // write through the native setter it patches over.
    const descriptor = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    );
    if (descriptor && descriptor.set) {
      descriptor.set.call(input, value);
    } else {
      input.value = value;
    }
  }

  function dispatchKey(input, type, key) {
    input.dispatchEvent(new KeyboardEvent(type, {
      key,
      bubbles: true,
      cancelable: true
    }));
  }

  // Emerix enables the search button from a keyboard handler, not from the
  // "input" event, so setting the value alone leaves the button disabled even
  // though the text is visible. Replay a real key sequence per character.
  async function typeIntoInput(input, value) {
    input.focus();
    input.click();
    setNativeValue(input, "");
    input.dispatchEvent(new Event("input", { bubbles: true }));

    for (const char of value) {
      dispatchKey(input, "keydown", char);
      dispatchKey(input, "keypress", char);
      setNativeValue(input, input.value + char);
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        data: char,
        inputType: "insertText"
      }));
      dispatchKey(input, "keyup", char);
      await sleep(25);
    }
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function fillSearch(step) {
    const rut = String(step.rut || "").trim();
    if (!rut) {
      throw new Error(`Fila ${step.row_number}: el RUT viene vacío en el Excel.`);
    }
    const input = await waitForSearchInput();
    await typeIntoInput(input, rut);

    const written = String(input.value || "");
    if (written !== rut) {
      throw new Error(`El buscador quedó con "${written}" en vez de "${rut}".`);
    }

    // Observed on Emerix: pressing Enter in the box is what flips the search
    // button from disabled to enabled. Only nudge if typing did not do it.
    const button = findBySelectors(SEARCH_BUTTON_SELECTORS);
    if (button && button.disabled) {
      dispatchKey(input, "keydown", "Enter");
      dispatchKey(input, "keypress", "Enter");
      dispatchKey(input, "keyup", "Enter");
      await sleep(150);
    }

    const buttonState = button
      ? (button.disabled ? "botón aún deshabilitado" : "botón habilitado")
      : "botón no encontrado";
    return `Fila ${step.row_number}/${step.total} (Excel ${step.excel_row}): ` +
      `RUT ${step.rut_original} escrito como ${rut} (${buttonState}).`;
  }

  async function clickSearch(step) {
    const button = await waitFor(
      () => findBySelectors(SEARCH_BUTTON_SELECTORS),
      "No se encontró el botón de búsqueda de Emerix."
    );
    // Angular keeps the button disabled until it accepts the typed value.
    await waitFor(
      () => (button.disabled ? null : button),
      "El botón de búsqueda siguió deshabilitado; Emerix no aceptó el RUT.",
      8000
    );
    button.click();
    return `Fila ${step.row_number}/${step.total}: búsqueda ejecutada.`;
  }

  async function openGestionMenu(step) {
    // The search navigates to /app/personRecord/<id>/..., so give the new
    // route time to render its menu bar before looking for the trigger.
    const menuBar = await waitFor(
      () => document.querySelector(MENU_BAR_SELECTOR),
      "No se cargó la ficha del deudor tras la búsqueda."
    );
    const trigger = await waitFor(
      () => findByLabel(MENU_TRIGGER_SELECTOR, "Gestión", menuBar),
      "No se encontró el botón Gestión en la ficha del deudor."
    );
    trigger.click();
    await waitFor(
      () => document.querySelector(MENU_PANEL_SELECTOR),
      "El menú Gestión no se desplegó.",
      8000
    );
    return `Fila ${step.row_number}/${step.total}: menú Gestión abierto.`;
  }

  async function clickGastos(step) {
    const item = await waitFor(
      () => findByLabel(MENU_ITEM_SELECTOR, "Gastos"),
      "No se encontró la opción Gastos dentro del menú Gestión.",
      8000
    );
    item.click();
    return `Fila ${step.row_number}/${step.total}: opción Gastos seleccionada.`;
  }

  async function clickNuevo(step) {
    // The Gastos panel loads its own expansion body after the menu click, so
    // poll rather than assuming the button is present immediately.
    const link = await waitFor(
      () => findBySelectors(NEW_BUTTON_SELECTORS)
        || findByLabel("a, button", "Nuevo"),
      "No se encontró el botón Nuevo en la sección Gastos."
    );
    link.click();
    return `Fila ${step.row_number}/${step.total}: botón Nuevo presionado.`;
  }

  function findGastoTypeSelect() {
    const direct = findBySelectors(GASTO_TYPE_SELECT_SELECTORS);
    if (direct) {
      return direct;
    }
    // Fallback: the select whose surrounding field is labelled "Tipo de Gasto".
    // Walk ancestors rather than assuming a <mat-form-field> wrapper, since the
    // label may sit several levels up from the select.
    const target = foldLabel(GASTO_TYPE_LABEL);
    const selects = Array.from(document.querySelectorAll("mat-select"));
    return selects.find((select) => {
      let node = select.parentElement;
      for (let depth = 0; node && depth < 5; depth += 1) {
        if (foldLabel(node.textContent).includes(target)) {
          return true;
        }
        node = node.parentElement;
      }
      return false;
    }) || null;
  }

  async function selectTipoGasto(step) {
    const target = String(step.tipo_gasto || "").trim();
    if (!target) {
      throw new Error(
        `Fila ${step.row_number}: "${step.resultado_gestion}" no tiene traducción ` +
        `a "${GASTO_TYPE_LABEL}".`
      );
    }

    const select = await waitFor(
      findGastoTypeSelect,
      `No se encontró el desplegable "${GASTO_TYPE_LABEL}" en el formulario Nuevo.`
    );
    // Material opens the panel from the trigger, not from <mat-select> itself.
    const trigger = select.querySelector(".mat-select-trigger") || select;
    trigger.click();
    await waitFor(
      () => document.querySelector(SELECT_PANEL_SELECTOR),
      `El desplegable "${GASTO_TYPE_LABEL}" no se abrió.`,
      8000
    );

    // Emerix populates the real options asynchronously; the panel opens with
    // only the "-- Seleccione un Tipo de Gastos --" placeholder, so poll for the
    // target instead of reading the list once.
    const foldedTarget = foldLabel(target);
    const realOptions = () => Array.from(document.querySelectorAll("mat-option"))
      .filter((el) => !foldLabel(el.textContent).startsWith("-- ")
        && !foldLabel(el.textContent).startsWith("seleccione"));
    let option = null;
    try {
      option = await waitFor(
        () => realOptions().find((el) => foldLabel(el.textContent) === foldedTarget)
          || realOptions().find((el) => foldLabel(el.textContent).includes(foldedTarget))
          || null,
        "sin opción",
        10000
      );
    } catch (_) {
      option = null;
    }
    if (!option) {
      // List what Emerix actually offers so the translation can be corrected.
      const available = realOptions()
        .map((el) => String(el.textContent || "").replace(/\s+/g, " ").trim())
        .filter(Boolean)
        .join(" | ");
      throw new Error(
        `No se encontró la opción "${target}" para "${step.resultado_gestion}". ` +
        `Opciones disponibles: ${available || "(la lista no terminó de cargar)"}`
      );
    }
    option.click();
    return `Fila ${step.row_number}/${step.total}: "${step.resultado_gestion}" ` +
      `→ "${target}" seleccionado.`;
  }

  function findProveedorInput() {
    const direct = findBySelectors(PROVEEDOR_INPUT_SELECTORS);
    if (direct) {
      return direct;
    }
    // Fallback by placeholder text, in case the accent or wording differs.
    const hint = foldLabel(PROVEEDOR_PLACEHOLDER_HINT);
    const byPlaceholder = Array.from(document.querySelectorAll("input")).find((input) =>
      foldLabel(input.getAttribute("placeholder")).includes(hint)
    );
    if (byPlaceholder) {
      return byPlaceholder;
    }
    // Last resort: the chip input sitting under the "Proveedor *" label.
    const target = foldLabel(PROVEEDOR_LABEL);
    return Array.from(document.querySelectorAll("mat-chip-list input, input.mat-chip-input"))
      .find((input) => {
        let node = input.parentElement;
        for (let depth = 0; node && depth < 5; depth += 1) {
          if (foldLabel(node.textContent).includes(target)) {
            return true;
          }
          node = node.parentElement;
        }
        return false;
      }) || null;
  }

  async function fillProveedor(step) {
    const proveedor = String(step.proveedor || "").trim();
    if (!proveedor) {
      throw new Error(`Fila ${step.row_number}: el Proveedor viene vacío en el Excel.`);
    }

    const input = await waitFor(
      findProveedorInput,
      "No se encontró el campo Proveedor en el formulario Nuevo."
    );
    // No Enter is sent here on purpose: the panel carries
    // autoactivefirstoption, so Enter would commit whichever name happens to be
    // first ("VICTOR RODRIGO MOYA CASTRO" for a "RODRIG" prefix) instead of ours.
    await typeIntoInput(input, proveedor);

    const folded = foldLabel(proveedor);
    const currentOptions = () => Array.from(document.querySelectorAll("mat-option"));

    // Resolve the option to click. Emerix filters server-side, so prefer an
    // exact name and only accept a partial match when it is unambiguous;
    // picking blindly out of a long list would file the expense against the
    // wrong provider.
    let note = "";
    const resolveOption = async () => {
      try {
        return await waitFor(
          () => currentOptions().find((el) => foldLabel(el.textContent) === folded) || null,
          "sin coincidencia exacta",
          10000
        );
      } catch (_) {
        const contains = currentOptions()
          .filter((el) => foldLabel(el.textContent).includes(folded));
        if (contains.length === 1) {
          note = " (coincidencia parcial única)";
          return contains[0];
        }
        const available = currentOptions()
          .map((el) => String(el.textContent || "").replace(/\s+/g, " ").trim())
          .filter(Boolean);
        const shown = available.slice(0, 12).join(" | ")
          + (available.length > 12 ? ` … (+${available.length - 12} más)` : "");
        throw new Error(
          `No se encontró una coincidencia única para el proveedor "${proveedor}". ` +
          `${available.length} sugerencia(s): ${shown || "(ninguna)"}`
        );
      }
    };

    // A late response for an earlier prefix can re-render the panel and detach
    // the node we matched; clicking a destroyed option does nothing. Re-resolve
    // and retry until a chip actually appears.
    let chip = null;
    let chosen = "";
    for (let attempt = 1; attempt <= 3 && !chip; attempt += 1) {
      const option = await resolveOption();
      chosen = String(option.textContent || "").replace(/\s+/g, " ").trim();
      if (!document.contains(option)) {
        continue; // panel re-rendered while we were choosing
      }
      option.click();
      try {
        chip = await waitFor(() => document.querySelector(CHIP_SELECTOR), "sin chip", 2500);
      } catch (_) {
        chip = null;
      }
    }
    if (!chip) {
      throw new Error(
        `Se eligió "${chosen}" pero el Proveedor no quedó fijado en el campo.`
      );
    }
    const chipText = String(chip.textContent || "").replace(/\s+/g, " ").trim();
    // Last line of defence: a mis-click on the wrong suggestion would still
    // produce a chip, so confirm the chip carries the provider we asked for.
    if (!foldLabel(chipText).includes(folded)) {
      throw new Error(
        `El Proveedor quedó como "${chipText}" en vez de "${proveedor}".`
      );
    }
    return `Fila ${step.row_number}/${step.total}: proveedor "${proveedor}" ` +
      `→ "${chosen}"${note}, chip confirmado: "${chipText}".`;
  }

  function findImporteInput() {
    const direct = findBySelectors(IMPORTE_INPUT_SELECTORS);
    if (direct) {
      return direct;
    }
    // Fallback: the input under the "Importe *" label.
    const target = foldLabel(IMPORTE_LABEL);
    return Array.from(document.querySelectorAll('input[type="number"], input')).find((input) => {
      let node = input.parentElement;
      for (let depth = 0; node && depth < 5; depth += 1) {
        if (foldLabel(node.textContent).includes(target)) {
          return true;
        }
        node = node.parentElement;
      }
      return false;
    }) || null;
  }

  async function fillImporte(step) {
    const importe = String(step.importe || "").trim();
    if (!importe) {
      throw new Error(
        `Fila ${step.row_number}: el "Valor recibo" ("${step.importe_original}") ` +
        `no es un número válido.`
      );
    }

    const input = await waitFor(
      findImporteInput,
      "No se encontró el campo Importe en el formulario Nuevo."
    );
    // type="number" ignores a bare value assignment the same way the search box
    // did, so type it through the keyboard-event path.
    await typeIntoInput(input, importe);

    // A number input reports "" via .value when its contents are not a valid
    // number, so compare on valueAsNumber to confirm what actually landed.
    const landed = Number.isNaN(input.valueAsNumber) ? input.value : String(input.valueAsNumber);
    if (landed !== importe) {
      throw new Error(
        `El Importe quedó como "${input.value}" en vez de "${importe}".`
      );
    }
    return `Fila ${step.row_number}/${step.total}: importe "${step.importe_original}" ` +
      `→ ${importe} ingresado.`;
  }

  // Find an input by its stable selectors, falling back to the input whose
  // surrounding field carries the given label.
  function findLabelledInput(selectors, label) {
    const direct = findBySelectors(selectors);
    if (direct) {
      return direct;
    }
    const target = foldLabel(label);
    return Array.from(document.querySelectorAll("input")).find((input) => {
      let node = input.parentElement;
      for (let depth = 0; node && depth < 5; depth += 1) {
        if (foldLabel(node.textContent).includes(target)) {
          return true;
        }
        node = node.parentElement;
      }
      return false;
    }) || null;
  }

  async function fillBoleta(step) {
    const boleta = String(step.boleta || "").trim();
    if (!boleta) {
      throw new Error(`Fila ${step.row_number}: la BOLETA viene vacía en el Excel.`);
    }
    const input = await waitFor(
      () => findLabelledInput(BOLETA_INPUT_SELECTORS, BOLETA_LABEL),
      `No se encontró el campo "${BOLETA_LABEL}" en el formulario Nuevo.`
    );
    await typeIntoInput(input, boleta);
    if (String(input.value || "") !== boleta) {
      throw new Error(`La BOLETA quedó como "${input.value}" en vez de "${boleta}".`);
    }
    return `Fila ${step.row_number}/${step.total}: BOLETA ${boleta} ingresada en "${BOLETA_LABEL}".`;
  }

  function isVisible(el) {
    if (!el) {
      return false;
    }
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  // Every mat-select except the already-filled Tipo de Gasto one, and only the
  // ones actually on screen (the dialog may keep hidden selects in the DOM).
  function candidateIdentificadorSelects() {
    return Array.from(document.querySelectorAll("mat-select"))
      .filter((select) => select.getAttribute("formcontrolname") !== GASTO_TYPE_CONTROL)
      .filter(isVisible);
  }

  // Describe a mat-select for the diagnostic log: its form control name, the
  // nearest field label, and whether it still shows a placeholder. This is what
  // tells us the real handle when the label guess is wrong.
  function describeSelect(select) {
    const control = select.getAttribute("formcontrolname") || "?";
    const field = select.closest("mat-form-field") || select.parentElement;
    const labelEl = field ? field.querySelector("mat-label, label") : null;
    const label = labelEl ? String(labelEl.textContent || "").replace(/\s+/g, " ").trim() : "";
    const empty = select.querySelector(".mat-select-placeholder") ? "vacío" : "con-valor";
    return `[control=${control} label="${label || "?"}" ${empty}]`;
  }

  // Locate the identificador mat-select without depending on a guessed label,
  // in order of confidence:
  //   1) a field whose label text contains "Identificador",
  //   2) the only still-empty select (Tipo de Gasto is already filled by now),
  //   3) the only non-Gasto select left in the form.
  function findIdentificadorSelect() {
    // Stable handle first: the reactive-form control name.
    const direct = findBySelectors(IDENTIFICADOR_SELECT_SELECTORS);
    if (direct) {
      return direct;
    }

    const candidates = candidateIdentificadorSelects();
    if (!candidates.length) {
      return null;
    }

    const target = foldLabel(IDENTIFICADOR_LABEL);
    let best = null;
    let bestDepth = Infinity;
    for (const select of candidates) {
      let node = select.parentElement;
      for (let depth = 0; node && depth < 6; depth += 1) {
        if (foldLabel(node.textContent).includes(target)) {
          if (depth < bestDepth) {
            best = select;
            bestDepth = depth;
          }
          break;
        }
        node = node.parentElement;
      }
    }
    if (best) {
      return best;
    }

    const empty = candidates.filter((select) => select.querySelector(".mat-select-placeholder"));
    if (empty.length === 1) {
      return empty[0];
    }
    if (candidates.length === 1) {
      return candidates[0];
    }
    return null;
  }

  async function selectIdentificador(step) {
    let select = null;
    try {
      select = await waitFor(findIdentificadorSelect, "sin desplegable", 8000);
    } catch (_) {
      // Report every mat-select on the page so the correct handle is visible in
      // the log even though the automatic finder gave up.
      const all = Array.from(document.querySelectorAll("mat-select"))
        .map(describeSelect)
        .join(" ");
      throw new Error(
        `No se encontró el desplegable de identificador en el formulario Nuevo. ` +
        `mat-selects en la página: ${all || "(ninguno)"}`
      );
    }
    // Material opens the panel from the trigger, not from <mat-select> itself.
    const trigger = select.querySelector(".mat-select-trigger") || select;
    trigger.click();
    await waitFor(
      () => document.querySelector(SELECT_PANEL_SELECTOR),
      `El desplegable "${IDENTIFICADOR_LABEL}" no se abrió.`,
      8000
    );

    // Real identificadores are the enabled, non-placeholder options. Emerix may
    // fill the list asynchronously, so poll until at least one appears.
    const realOptions = () => Array.from(document.querySelectorAll("mat-option"))
      .filter((el) => el.getAttribute("aria-disabled") !== "true"
        && !foldLabel(el.textContent).startsWith("-- ")
        && !foldLabel(el.textContent).startsWith("seleccione"));
    let options = [];
    try {
      await waitFor(() => (realOptions().length ? realOptions() : null), "sin opciones", 10000);
      options = realOptions();
    } catch (_) {
      options = [];
    }

    const labelOf = (el) => String(el.textContent || "").replace(/\s+/g, " ").trim();
    if (!options.length) {
      throw new Error(
        `El desplegable "${IDENTIFICADOR_LABEL}" no ofreció ningún identificador.`
      );
    }

    // Keep only ROL/causa options ("C-####-AAAA"); the gasto is always filed
    // against that one. A deudor may list several identificadores, but exactly
    // one ROL is expected.
    const rolOptions = options.filter((el) => IDENTIFICADOR_ROL_RE.test(labelOf(el)));
    const shownAll = options.map(labelOf).filter(Boolean).join(" | ");

    if (rolOptions.length === 0) {
      throw new Error(
        `No hay identificador tipo ROL (C-####-AAAA) para elegir. ` +
        `Opciones disponibles: ${shownAll || "(ninguna)"}. Revisar manualmente.`
      );
    }
    if (rolOptions.length > 1) {
      const shownRol = rolOptions.map(labelOf).join(" | ");
      throw new Error(
        `Hay ${rolOptions.length} identificadores tipo ROL y no está definido ` +
        `cuál elegir: ${shownRol}. Revisar manualmente.`
      );
    }

    const option = rolOptions[0];
    const chosen = labelOf(option);
    option.click();
    return `Fila ${step.row_number}/${step.total}: identificador "${chosen}" seleccionado.`;
  }

  // Locate the "Comentario" textarea, by control name first and the field label
  // as the fallback (walk the ancestors for the "Comentario" mat-label).
  function findComentarioTextarea() {
    const direct = findBySelectors(COMENTARIO_INPUT_SELECTORS);
    if (direct) {
      return direct;
    }
    const target = foldLabel(COMENTARIO_LABEL);
    return Array.from(document.querySelectorAll("textarea")).find((area) => {
      let node = area.parentElement;
      for (let depth = 0; node && depth < 6; depth += 1) {
        if (foldLabel(node.textContent).includes(target)) {
          return true;
        }
        node = node.parentElement;
      }
      return false;
    }) || null;
  }

  async function fillComentario(step) {
    const comentario = String(step.comentario || "").trim();
    if (!comentario) {
      throw new Error(`Fila ${step.row_number}: la columna DS viene vacía en el Excel.`);
    }
    const area = await waitFor(
      findComentarioTextarea,
      `No se encontró el campo "${COMENTARIO_LABEL}" en el formulario Nuevo.`
    );
    // A <textarea> needs the HTMLTextAreaElement value setter, not the input one,
    // to write through Angular's change detection. No per-key replay is needed
    // here (unlike the search box), so set the value and fire input/change.
    area.focus();
    const descriptor = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype,
      "value"
    );
    if (descriptor && descriptor.set) {
      descriptor.set.call(area, comentario);
    } else {
      area.value = comentario;
    }
    area.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      data: comentario,
      inputType: "insertText"
    }));
    area.dispatchEvent(new Event("change", { bubbles: true }));
    area.blur();

    const written = String(area.value || "");
    if (written !== comentario) {
      throw new Error(`El comentario quedó como "${written}" en vez de "${comentario}".`);
    }
    return `Fila ${step.row_number}/${step.total}: comentario ingresado en "${COMENTARIO_LABEL}".`;
  }

  // Find the dialog's X button: the [mat-dialog-close] control, or an icon
  // button whose <mat-icon> reads "close" inside the open dialog.
  function findCloseDialogButton() {
    const direct = findBySelectors(CLOSE_DIALOG_SELECTORS);
    if (direct) {
      return direct;
    }
    const scope = document.querySelector(DIALOG_CONTAINER_SELECTOR) || document;
    const icon = Array.from(scope.querySelectorAll("button mat-icon"))
      .find((el) => foldLabel(el.textContent) === "close");
    return icon ? icon.closest("button") : null;
  }

  async function closeDialog(step) {
    const button = await waitFor(
      findCloseDialogButton,
      "No se encontró el botón X para cerrar el formulario."
    );
    button.click();
    // Confirm the dialog actually closed; otherwise the operator could think the
    // row finished when the form is still open.
    await waitFor(
      () => (document.querySelector(DIALOG_CONTAINER_SELECTOR) ? null : true),
      "El formulario no se cerró tras presionar la X.",
      8000
    );
    return `Fila ${step.row_number}/${step.total}: formulario cerrado con la X (no se grabó).`;
  }

  // Recovery close used after a step failed: close the form if one is open, but
  // do NOT fail when there is no dialog (the failure may have happened before
  // the form opened). Only a dialog that refuses to close is fatal, since it
  // would block the next row's search.
  async function abandonRow(step) {
    const button = findCloseDialogButton();
    if (!button) {
      return `Fila ${step.row_number}/${step.total}: sin formulario abierto que cerrar.`;
    }
    button.click();
    try {
      await waitFor(
        () => (document.querySelector(DIALOG_CONTAINER_SELECTOR) ? null : true),
        "sin cierre",
        8000
      );
    } catch (_) {
      throw new Error("No se pudo cerrar el formulario tras un error.");
    }
    return `Fila ${step.row_number}/${step.total}: formulario cerrado tras error.`;
  }

  const STEP_HANDLERS = {
    fill_search: fillSearch,
    click_search: clickSearch,
    open_gestion_menu: openGestionMenu,
    click_gastos: clickGastos,
    click_nuevo: clickNuevo,
    select_tipo_gasto: selectTipoGasto,
    fill_proveedor: fillProveedor,
    fill_importe: fillImporte,
    fill_boleta: fillBoleta,
    select_identificador: selectIdentificador,
    fill_comentario: fillComentario,
    close_dialog: closeDialog,
    abandon_row: abandonRow
  };

  async function pumpWork() {
    if (!verified || busy || completed) {
      return;
    }
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};

      if (step.action === "wait") {
        return;
      }
      if (step.action === "idle") {
        setStatus(step.message || "En espera.", "ok");
        return;
      }
      if (step.action === "done") {
        completed = true;
        setStatus("¡Proceso finalizado! Ve a BotManager y revisa los resultados.", "ok");
        window.clearInterval(workTimer);
        return;
      }
      const handler = STEP_HANDLERS[step.action];
      if (!handler) {
        return;
      }

      if (step.step_number) {
        setStatus(
          `Fila ${step.row_number}/${step.total} · paso ${step.step_number}/${step.step_total}...`
        );
      } else {
        setStatus(`Fila ${step.row_number}/${step.total} · recuperando...`);
      }
      try {
        const detail = await handler(step);
        setStatus(detail, "ok");
        logToBridge(detail);
        const reportResp = await bridgeRequest("/report", { method: "POST", body: { ok: true, detail } });
        if (reportResp && reportResp.done) {
          // Whole planilla finished. Stop pumping and show the friendly message
          // with the totals before the bridge server shuts down (this replaces
          // the old "connection lost" and is the end-of-run summary pop-up).
          completed = true;
          const okc = Number(reportResp.okCount || 0);
          const revc = Number(reportResp.revisarCount || 0);
          const tot = Number(reportResp.total || (okc + revc));
          let msg = "¡Proceso finalizado! " + tot + " boleta(s): " + okc + " OK";
          if (revc > 0) {
            msg += ", " + revc + " por revisar";
          }
          msg += ". Revisa los resultados en BotManager.";
          setStatus(msg, "ok");
          window.clearInterval(workTimer);
          return;
        }
      } catch (error) {
        const detail = String(error && error.message ? error.message : error);
        setStatus(`Error: ${detail}`, "error");
        logToBridge(detail);
        // Report the failure but KEEP pumping: the desktop side decides how to
        // recover (it sends an abandon_row to close the form and move on). Only
        // a "done" from the desktop stops the loop.
        await bridgeRequest("/report", { method: "POST", body: { ok: false, detail } });
      }
    } catch (_) {
      if (completed) {
        return; // finished cleanly; the server just shut down.
      }
      connected = false;
      setStatus("Se perdió la conexión con BotManager.", "error");
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    if (verified || starting || completed) {
      return;
    }
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderWorkbook(payload.summary);
      setStatus("Bridge conectado. Presiona Start.", "ok");
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean05 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified) {
      return;
    }
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) {
        await bridgeRequest("/health");
      }
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title }
      });
      verified = true;
      renderWorkbook(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
