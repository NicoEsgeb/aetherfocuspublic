# Clean05 - Emerix (Edge extension)

This provisional bot contains the attended-browser foundation for Clean05:

1. BotManager receives one `.xlsx` or `.xlsm` input.
2. The user opens normal Microsoft Edge. The panel appears from the Emerix login
   page onward, then the user logs in manually.
3. BotManager starts a local bridge on `http://127.0.0.1:8766`.
4. On `https://itau.emerix.net/emerix.ui/app/dashboard`, the user presses
   **Start** in the Clean05 panel.
5. The task records a `bridge_connection.json` receipt under `output/`.

The future Emerix navigation and Excel row-processing logic intentionally is not
implemented yet. It will stay local to this bot once the client defines the
workflow.

## Load the extension in Edge

Open `edge://extensions`, enable **Developer mode**, choose **Load unpacked**,
and select:

```text
bots/clean05_emerix-extension/extension
```

After installing or updating the unpacked extension, reload the Emerix tab once.
