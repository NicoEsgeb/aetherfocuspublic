"""
Runtime splitter for the clean02 "Separar archivos" bot.
====================================================================
Adapted from the proof-of-concept `pipeline.split_with_review`, but with the
training/eval dependencies removed: it loads the pre-built visual templates from
`templates.pkl` (shipped with the bot) instead of rebuilding them from labelled
example folders. Brand-new PDFs are therefore classified against a fixed set of
parameters, exactly as the deployed bot must behave.

For one scanned, RUT-named PDF it:
  1. classifies every page (OCR text anchors + visual template matching),
  2. groups contiguous pages into named documents,
  3. scores each document's confidence + tier,
  4. writes high-confidence documents straight into `out_dir`, routes uncertain
     ones to `out_dir/_REVISAR/` for a human, and
  5. writes `<rut>_manifest.json` describing every produced file.

These modules are imported flat (clean02, classifier) — see engine/__init__.py.
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path

import fitz  # PyMuPDF

import clean02 as c
import classifier as clf

ENGINE_DIR = Path(__file__).parent
TEMPLATES_PKL = ENGINE_DIR / "templates.pkl"


def load_templates(pkl_path: Path | None = None) -> clf.Templates:
    """Load the bundled visual templates. Raises if the file is missing —
    the bot cannot classify the faint form/cedula pages without it."""
    pkl_path = Path(pkl_path) if pkl_path else TEMPLATES_PKL
    if not pkl_path.exists():
        raise FileNotFoundError(
            f"No se encontró el archivo de plantillas (templates.pkl): {pkl_path}"
        )
    with open(pkl_path, "rb") as fh:
        return pickle.load(fh)


# A dropped page with almost no dark pixels is a true blank/back page; anything
# above this still carries visible content a human should glance at. Kept low on
# purpose -- better to over-report "con contenido" than to call a faint but real
# page (e.g. a document type the bot has not been taught yet) "en blanco" and
# have the reviewer skip past it.
_BLANK_INK = 0.02


def _drop_reason(f: c.PageFeatures) -> str:
    """Coarse, human-facing reason a page was dropped: a near-empty page is
    'en blanco', anything with visible ink is 'con contenido' (worth a look)."""
    return "en blanco" if f.ink_density < _BLANK_INK else "con contenido"


def _write_dropped_pages(src, feats, labels, review_dir, rut) -> dict:
    """Collect EVERY page the classifier dropped into one review PDF
    (`_REVISAR/<rut>_DESCARTADAS.pdf`) plus a sidecar `<rut>_DESCARTADAS.json`
    mapping each to its original page number and a coarse reason.

    This is the safeguard: nothing the bot removes is destroyed -- a human can
    flip through and confirm no readable page was tossed, including brand-new
    document types the parameters have never seen (they match nothing -> DROP ->
    land here as 'con contenido'), which is exactly the feedback signal for
    teaching the classifier later.

    Returns a small summary; `pdf_name` is None when nothing was dropped."""
    dropped_idx = [i for i, lab in enumerate(labels) if lab == c.DROP]
    summary = {"pdf_name": None, "count": len(dropped_idx), "blank": 0, "content": 0}
    if not dropped_idx:
        return summary

    review_dir.mkdir(parents=True, exist_ok=True)
    out = fitz.open()
    entries: list[dict] = []
    for p in dropped_idx:
        out.insert_pdf(src, from_page=p, to_page=p)
        reason = _drop_reason(feats[p])
        summary["blank" if reason == "en blanco" else "content"] += 1
        entries.append({"source_page": p + 1, "reason": reason})

    name = f"{rut}_DESCARTADAS.pdf"
    out.save(str(review_dir / name))
    out.close()
    summary["pdf_name"] = name

    with open(review_dir / f"{rut}_DESCARTADAS.json", "w", encoding="utf-8") as fh:
        json.dump(
            {
                "rut": rut,
                "dropped_count": summary["count"],
                "blank": summary["blank"],
                "content": summary["content"],
                "pages": entries,
            },
            fh,
            indent=2,
            ensure_ascii=False,
        )
    return summary


def split_pdf_with_review(
    pdf_path: Path,
    out_dir: Path,
    tpl: clf.Templates,
    auto_min: float = clf.AUTO_MIN,
) -> tuple[list[dict], dict]:
    """Split one PDF into named documents, routing each to `out_dir` (AUTO) or
    `out_dir/_REVISAR` (uncertain). Writes `<rut>_manifest.json`, and every
    dropped page into `_REVISAR/<rut>_DESCARTADAS.pdf` so nothing readable is
    silently discarded.

    Returns `(manifest, reconciliation)` where `manifest` has one entry per
    produced document and `reconciliation` is a page-conservation summary
    (`total_pages`, `kept_pages`, `dropped_pages`, `dropped_blank`,
    `dropped_content`, `descartadas_pdf`, `balanced`)."""
    pdf_path, out_dir = Path(pdf_path), Path(out_dir)
    rut = pdf_path.stem
    feats = c.extract_features(pdf_path)
    labels = clf.classify(feats, tpl)
    sections = clf.group_sections(labels, clf.pagare_boundaries(feats, labels))

    out_dir.mkdir(parents=True, exist_ok=True)
    review_dir = out_dir / "_REVISAR"
    src = fitz.open(pdf_path)
    manifest: list[dict] = []
    seen: dict[str, int] = {}
    prev_end = -1

    for label, pages in sections:
        conf, tier, why = clf.document_confidence(feats, label, pages, tpl, prev_end)
        route = clf.route_document(label, conf, auto_min)
        prev_end = pages[-1]

        seen[label] = seen.get(label, 0) + 1
        suffix = "" if seen[label] == 1 else f"_{seen[label]}"
        name = f"{rut}_{label}{suffix}.pdf"
        dest = out_dir if route == "AUTO" else review_dir
        dest.mkdir(parents=True, exist_ok=True)

        doc = fitz.open()
        for p in pages:
            doc.insert_pdf(src, from_page=p, to_page=p)
        doc.save(str(dest / name))
        doc.close()

        manifest.append({
            "file": name,
            "label": label,
            "route": route,
            "tier": tier,
            "confidence": round(conf, 2),
            "pages": [p + 1 for p in pages],
            "pages0": list(pages),
            "why": why,
        })
    # Safeguard: write every dropped page into _REVISAR/<rut>_DESCARTADAS.pdf
    # (must happen before src.close(), since pages are copied from src).
    dropped = _write_dropped_pages(src, feats, labels, review_dir, rut)
    src.close()

    # Page-conservation cross-check: every source page must end up either in a
    # named document OR in the descartadas PDF, exactly once. kept_pages is
    # counted from the sections actually written; dropped from the DROP labels.
    # If they don't add up to the page count, a page silently vanished -> the
    # caller flags it loudly.
    kept_pages = sum(len(pages) for _, pages in sections)
    reconciliation = {
        "total_pages": len(feats),
        "kept_pages": kept_pages,
        "dropped_pages": dropped["count"],
        "dropped_blank": dropped["blank"],
        "dropped_content": dropped["content"],
        "descartadas_pdf": dropped["pdf_name"],
        "balanced": kept_pages + dropped["count"] == len(feats),
    }

    with open(out_dir / f"{rut}_manifest.json", "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, ensure_ascii=False)
    return manifest, reconciliation
