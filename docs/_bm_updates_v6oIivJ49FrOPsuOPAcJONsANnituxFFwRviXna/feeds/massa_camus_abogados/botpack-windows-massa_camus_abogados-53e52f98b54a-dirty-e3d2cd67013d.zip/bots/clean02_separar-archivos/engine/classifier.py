"""
clean02 — page classifier + section grouper (proof of concept)
==============================================================
Given per-page features (clean02.PageFeatures) and visual templates, decide the
label of every page, then group contiguous pages into named output documents.

Strategy (mirrors the rigid human order):
  CHECKLIST -> [forms: LIQUIDACION, INFORME] -> PAGARE(s) -> [HOJA] [CEDULA] [ANEXO]
  everything else -> DROP

Text-rich pages (CHECKLIST, PAGARE, HOJA, CEDULA, ANEXO, junk) -> OCR anchors.
Faint form pages (LIQUIDACION, INFORME) -> visual template matching.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

import clean02 as c
from clean02 import (
    CHECKLIST, LIQUIDACION, INFORME, PAGARE_MP, PAGARE_LP, PAGARE_TC,
    HOJA_DE_FIRMA, CEDULA, ANEXO, DROP, PageFeatures,
)


# ----------------------------------------------------------------------------
# Text anchors (operate on PageFeatures.text_upper = folded uppercase OCR text)
# ----------------------------------------------------------------------------
def has(f: PageFeatures, *needles: str) -> bool:
    return any(n in f.text_upper for n in needles)


CHECKLIST_ANCHORS = ("ANTECEDENTES DEL CLIENTE", "ANTECEDENTES DEUDA",
                     "COBRANZA JUDICIAL", "CHECKLIST", "NOMBRE SUCURSAL",
                     "ANTECEDENTES DEL CUENTE")  # last one: OCR variant of CLIENTE
PAGARE_ANCHORS = ("OPERACION", "PRODUCTO:", "DEBO Y PAGAR", "REFINANCIAMIENTO",
                  "CREDITO CONSUMO", "CREDITO DE CONSUMO", "A PLAZO", "PRESIDENTE RIESCO")
CEDULA_ANCHORS = ("SERVICIO DE REGISTRO", "REGISTRO CIVIL", "REPUBLICA DE CHILE",
                  "CEDULA DE IDENTIDAD")
# Back-of-card fields + the machine-readable zone (chevron filler). These appear
# only on a Chilean ID-card scan, never on a pagaré or a form, so they're a strong
# cedula signal even when the registry header itself doesn't OCR.
CARD_FACE_ANCHORS = ("<<<<", "PROFESION", "NACIO EN", "NACIONALIDAD",
                     "N DE SERIE", "NRO DE SERIE", "NUMERO DE SERIE",
                     "INSC NAC", "NO DONANTE")


def is_checklist(f: PageFeatures) -> bool:
    return has(f, *CHECKLIST_ANCHORS)


# A real pagaré leads with "PAGARÉ" in its heading; a Contrato / Condiciones
# Generales only names a pagaré deep in its body ("...el Pagaré que se suscriba").
# Require the word within this many leading characters so a contract — whose first
# "PAGARE" sits ~3000 chars in — is not grouped as a pagaré. Real pagarés in the
# sample carry it within the first ~45 chars, so the margin is wide.
PAGARE_HEADER_CHARS = 160


def is_pagare_header(f: PageFeatures) -> bool:
    if is_checklist(f) or not has(f, "PAGARE"):
        return False
    if "PAGARE" not in f.text_upper[:PAGARE_HEADER_CHARS]:
        return False
    return has(f, *PAGARE_ANCHORS)


def pagare_type(f: PageFeatures) -> str:
    if has(f, "PRODUCTO: TC", "PRODUCTO TC"):
        return PAGARE_TC
    if has(f, "PRODUCTO: LP", "A PLAZO", "LINEA PREFERENCIAL"):
        return PAGARE_LP
    return PAGARE_MP


def is_hoja_start(f: PageFeatures) -> bool:
    """A real 'Hoja de Firma' cover page: the phrase leads the page text.
    Excludes 'Hoja Resumen' boilerplate and pages that merely mention firma
    further down. Both Productos and Crédito de Consumo variants are kept."""
    head = f.text_upper[:60]
    if "RESUMEN" in head:
        return False
    # canonical phrasing, plus an OCR-garble fallback: scanners sometimes mangle
    # the leading "HOJA D" (-> "EJA DE FIRMA ..."), but the distinctive
    # "FIRMA CONTRATO CREDITO DE CONSUMO" run survives.
    return ("HOJA DE FIRMA" in head or "HOJA DF FIRMA" in head
            or "FIRMA CONTRATO CREDITO DE CONSUMO" in head)


def is_cedula_page(f: PageFeatures) -> bool:
    """An ID-card scan, in either photocopy style:
      - dark image of the card (high ink), with or without OCR'd text
      - faint card image that barely OCRs (few words, some ink)
      - near-white page where the registry header OCRs (few words)"""
    if f.ink_density >= 0.20:                       # dark photocopy of a card
        return True
    if f.n_words <= 5 and f.ink_density >= 0.03:    # faint card image, no real text
        return True
    return has(f, *CEDULA_ANCHORS, *CARD_FACE_ANCHORS) and f.n_words <= 60


def is_anexo(f: PageFeatures) -> bool:
    """The kept 'Anexo Contrato' cover — not the dropped 'Anexo Resumen
    Principales Cláusulas', nor the insurance 'Anexo Solicitud de Incorporación'."""
    head = f.text_upper[:200]
    if "RESUMEN" in head or "PRINCIPALES CLAUSULAS" in head or "SOLICITUD DE INCORPORACION" in head:
        return False
    # NOTE: "Anexo Productos y Servicios Contratados" is deliberately NOT matched here.
    # The human keeps it in some cases (14.016, 14.026) but drops the identical
    # boilerplate in others (15.509), so it's an unresolvable keep/drop judgment by
    # content alone — left to DROP rather than guess (it would route to _REVISAR if kept).
    return "ANEXO" in head and "CONTRATO" in head and has(f, "EL PRESENTE ANEXO", "CORRESPONDE AL CONTRATO")


def _ps_anchor(f: PageFeatures) -> bool:
    """Strict opening marker of an 'Anexo Productos y Servicios Contratados'
    block — the notarised products/services annex a few files carry where a Hoja
    de Firma would otherwise sit. Two unambiguous markers, verified to fire on
    ZERO perfect case in the sample (only on 17.052, 25.585, 15.509):
      - the 'ANEXO PRODUCTOS Y SERVICIOS' heading (the annex's own title), or
      - the protocolisation repertorio number '2.868' that every copy of this
        annex shares.
    The generic 'protocolizad…' / 'repertorio' / 'se encuentran protoco…' wording
    is deliberately NOT used: it also appears on ordinary Hoja de Firma pages and
    would corrupt the clean cases."""
    t = f.text_upper
    return "ANEXO PRODUCTOS Y SERVICIOS" in t or "2.868" in t


def _ps_member(f: PageFeatures) -> bool:
    """A continuation page of an anexo-productos block (see _ps_anchor): it
    mentions 'Productos y Servicios' and is tied to the block by an anchor, a
    'Condiciones Generales' heading, or the 'Hoja Resumen' summary — but is NOT
    itself a kept 'Anexo Contrato' page (that one is claimed separately by the
    ANEXO step and must end the block)."""
    t = f.text_upper
    if "PRODUCTOS Y SERVICIOS" not in t or is_anexo(f):
        return False
    return _ps_anchor(f) or "CONDICIONES GENERALES" in t or "HOJA RESUMEN" in t


def is_ojv_certificate(f: PageFeatures) -> bool:
    """A Poder Judicial 'Oficina Judicial Virtual' certificate (e.g. 'Certificado de
    Envío de Causa') scanned into the batch. Never part of any kept document, and may
    land in the middle of a pagaré — so the pagaré must bridge over it."""
    return has(f, "OFICINA JUDICIAL VIRTUAL") or (
        has(f, "CERTIFICADO DE ENVIO", "CERTIFICADO DE NOTIFICACION")
        and has(f, "CAUSA", "ROL/RIT", "JUZGADO"))


def is_junk(f: PageFeatures) -> bool:
    """Condiciones Generales / contract boilerplate that the human discards."""
    return has(f, "BANKBOSTON", "BOSTON WAY", "HOJA RESUMEN",
               "CONTRATO CREDITO DE CONSUMO") or f.n_words > 450


def starts_known_section(f: PageFeatures) -> bool:
    """Start of a *kept* document (no junk) — used to bound the LP pagare unit."""
    return is_pagare_header(f) or is_hoja_start(f) or is_cedula_page(f) or is_anexo(f)


def is_new_section(f: PageFeatures) -> bool:
    return starts_known_section(f) or is_junk(f)


# ----------------------------------------------------------------------------
# Visual templates (for LIQUIDACION & INFORME, which do not OCR)
# ----------------------------------------------------------------------------
@dataclass
class Templates:
    liq: list[np.ndarray]     # LIQUIDACION pages
    inf1: list[np.ndarray]    # INFORME first page
    inf2: list[np.ndarray]    # INFORME second page (the faint back), when present
    ced: list[np.ndarray]     # CEDULA_IDENTIDAD pages (gates the faint-photo branch)


def best_sim(vec: np.ndarray, refs: list[np.ndarray]) -> float:
    if not refs:
        return -1.0
    return max(float(np.dot(vec, r) / len(vec)) for r in refs)


def build_templates(cases: dict[str, tuple[list[PageFeatures], dict[int, str]]]) -> Templates:
    """Build visual templates from a set of (features, ground_truth) cases."""
    liq, inf1, inf2, ced = [], [], [], []
    for feats, gt in cases.values():
        inf_pages = sorted(i for i, lab in gt.items() if lab == INFORME)
        for i, lab in gt.items():
            if lab == LIQUIDACION:
                liq.append(feats[i].vvec)
            elif lab == CEDULA:
                ced.append(feats[i].vvec)
        if inf_pages:
            inf1.append(feats[inf_pages[0]].vvec)
            for j in inf_pages[1:]:
                inf2.append(feats[j].vvec)
    return Templates(liq=liq, inf1=inf1, inf2=inf2, ced=ced)


# A page in the forms region counts as a real form (vs a blank/back page) when its
# best similarity to any LIQ/INFORME template clears this bar. Observed margin is wide:
# real forms score ~0.47-0.98, blank/back pages ~0.07-0.20.
FORM_MIN = 0.35

# The faint-photo branch of cedula detection (few words + some ink) also fires on
# faint NON-card forms (e.g. a "Resguardo / Antecedentes del Pago" sheet). Gate that
# branch by visual similarity to known cedula scans. Real faint cards score ~0.45-0.55;
# faint non-card forms score ~0.33.
CED_MIN = 0.40


def is_cedula_emit(f: PageFeatures, tpl: Templates) -> bool:
    """Stricter than is_cedula_page: used when actually emitting a CEDULA label.
    The dark-card, MRZ/card-face, and registry-text branches are unambiguous; the
    faint-photo branches are gated by a visual template so faint non-card forms are
    rejected."""
    if f.ink_density >= 0.20:                                  # dark photocopy of a card
        return True
    if has(f, *CARD_FACE_ANCHORS) and f.n_words <= 60:         # MRZ chevrons / back-of-card fields
        return True
    if has(f, *CEDULA_ANCHORS) and f.n_words <= 60:            # registry / title text
        return True
    if f.n_words <= 45 and best_sim(f.vvec, tpl.ced) >= 0.50:  # faint card, strong visual match
        return True                                            # (nw cap keeps faint debt tables out)
    if f.n_words <= 5 and f.ink_density >= 0.03:               # near-blank faint card image
        thr = 0.30 if f.ink_density >= 0.10 else CED_MIN
        return best_sim(f.vvec, tpl.ced) >= thr
    return False


# ----------------------------------------------------------------------------
# Classification
# ----------------------------------------------------------------------------
def classify(feats: list[PageFeatures], tpl: Templates) -> list[str]:
    n = len(feats)
    labels = [DROP] * n

    # 1. CHECKLIST — first matching page in the first 3 (fallback to page 0)
    ck = next((f.index for f in feats[:3] if is_checklist(f)), 0)
    labels[ck] = CHECKLIST

    # 2. first PAGARE header after the checklist
    first_pag = next((f.index for f in feats[ck + 1:] if is_pagare_header(f)), n)

    # 3. forms region (between checklist and first pagare): LIQ then INFORME by vision
    _assign_forms(feats, ck + 1, first_pag, labels, tpl)

    # 3b. A Hoja de Firma occasionally sits BEFORE the pagare (e.g. the "Hoja de
    #     Firma del Contrato de Productos y Servicios Bancarios" variant). The tail
    #     scan only looks after the pagares, so it would miss it; claim any hoja
    #     cover page that landed in the forms region here. is_hoja_start is specific
    #     (leading "HOJA DE FIRMA", excludes "Hoja Resumen") so it never grabs a
    #     faint LIQ/INFORME form page.
    for j in range(ck + 1, first_pag):
        if is_hoja_start(feats[j]):
            labels[j] = HOJA_DE_FIRMA

    # 4. PAGARE blocks: header + continuation until a new section / junk / end.
    #    LP and TC are 2-page instruments (header + an "aval" page) whose trailing
    #    pages are boilerplate the human discards, so they are bounded structurally
    #    (header + 1) instead of by junk detection. MP keeps everything to the next
    #    section.
    i = first_pag
    while i < n and is_pagare_header(feats[i]):
        typ = pagare_type(feats[i])
        labels[i] = typ
        j = i + 1
        if typ in (PAGARE_LP, PAGARE_TC):
            if j < n and not starts_known_section(feats[j]):
                labels[j] = typ
                j += 1
        else:
            while j < n and not is_new_section(feats[j]):
                labels[j] = DROP if is_ojv_certificate(feats[j]) else typ
                j += 1
        i = j

    # 5. tail (after the pagares), in the human's fixed order: first
    #    HOJA_DE_FIRMA, then the first CEDULA group, then ANEXO. Anything not
    #    claimed here is DROP (co-signer cedulas, boilerplate, blank backs).
    _assign_tail(feats, i, labels, tpl)
    return labels


def _assign_tail(feats: list[PageFeatures], start: int, labels: list[str], tpl: Templates) -> None:
    n = len(feats)
    k = start

    hoja = next((j for j in range(k, n) if is_hoja_start(feats[j])), None)
    if hoja is not None:
        j = hoja
        while j < n and is_hoja_start(feats[j]):   # a hoja can span >1 firma cover page
            labels[j] = HOJA_DE_FIRMA
            j += 1
        k = j

    # 'Anexo Productos y Servicios Contratados' block: a few files carry this
    # notarised annex (heading "ANEXO PRODUCTOS Y SERVICIOS", plus a "Hoja
    # Resumen" summary and a protocolisation page) where the Hoja de Firma would
    # normally be. Claim the contiguous block as HOJA_DE_FIRMA (TIER3 -> routed to
    # _REVISAR for a human). The strict anchor fires on no perfect case, so a clean
    # file never enters this branch; the span runs forward from the first anchor
    # and stops at the first kept 'Anexo Contrato' page or any non-PS page.
    anchor = next((j for j in range(k, n) if _ps_anchor(feats[j])), None)
    if anchor is not None:
        j = anchor
        while j < n and (_ps_anchor(feats[j]) or _ps_member(feats[j])):
            labels[j] = HOJA_DE_FIRMA
            j += 1
        k = max(k, j)

    ced = next((j for j in range(k, n) if is_cedula_emit(feats[j], tpl)), None)
    if ced is not None:
        j = ced
        while j < n and is_cedula_emit(feats[j], tpl):   # only the first contiguous group
            labels[j] = CEDULA
            j += 1
        k = j

    anexo = next((j for j in range(k, n) if is_anexo(feats[j])), None)
    if anexo is not None:
        labels[anexo] = ANEXO


def _assign_forms(feats, lo, hi, labels, tpl: Templates):
    """Order is always LIQUIDACION then INFORME, but LIQUIDACION is sometimes
    absent. Keep the form pages and drop blanks; the first form page is normally
    LIQUIDACION and every later form page is INFORME.

    Exception (no LIQUIDACION): when the INFORME stands alone as its own two
    contiguous pages (front+back). Its signature is that the first form page
    looks more like an INFORME front than a LIQUIDACION, and the very next page
    strongly matches an INFORME back. A real LIQUIDACION+INFORME pair instead has
    the first page clearly matching the LIQUIDACION template (or the two pages
    separated by a blank), so it is not mistaken for this."""
    def sims(i: int) -> tuple[float, float, float]:
        v = feats[i].vvec
        return best_sim(v, tpl.liq), best_sim(v, tpl.inf1), best_sim(v, tpl.inf2)

    forms = [i for i in range(lo, hi) if max(sims(i)) >= FORM_MIN]
    if not forms:
        return

    # A single form page is normally the INFORME: across most labelled cases the
    # INFORME is present while the LIQUIDACION is the optional one, so a lone form
    # defaults to informe. BUT trust the vision when that page is a near-perfect
    # match to the LIQUIDACION template and beats both INFORME views — that is a
    # standalone LIQUIDACION (a file with a liquidacion but no informe). The LIQ
    # template separates cleanly (true LIQ scores ~0.96, other forms <=~0.6), so a
    # 0.85 floor flips only genuine liquidaciones and never a real informe.
    if len(forms) == 1:
        liq0, inf1_0, inf2_0 = sims(forms[0])
        labels[forms[0]] = (
            LIQUIDACION if liq0 >= 0.85 and liq0 > max(inf1_0, inf2_0) else INFORME
        )
        return

    no_liq = False
    if len(forms) >= 2 and forms[1] == forms[0] + 1:
        liq0, inf1_0, _ = sims(forms[0])
        _, _, inf2_1 = sims(forms[1])
        # standalone INFORME front+back: first page looks like an informe front, the
        # next strongly matches an informe back, AND the first page does NOT itself
        # look like a liquidacion (a real LIQ scores noticeably higher on tpl.liq).
        if inf1_0 > liq0 and liq0 < 0.68 and inf2_1 >= 0.85:
            no_liq = True

    if not no_liq:
        labels[forms[0]] = LIQUIDACION
        forms = forms[1:]
    for i in forms:
        labels[i] = INFORME


# ----------------------------------------------------------------------------
# Group contiguous labels into output sections
# ----------------------------------------------------------------------------
def pagare_boundaries(feats: list[PageFeatures], labels: list[str]) -> set[int]:
    """Page indices that each START a distinct pagaré instrument and must open
    their own output document (never merged into the previous section).

    A RUT can carry several pagarés of the *same* type (e.g. 4 separate MP
    operations for one debtor). classify() already labels each with its own type
    and, in step 4, only advances to a new block at an is_pagare_header page — so
    every kept page that is BOTH a pagaré type AND a header is a genuine new
    instrument. group_sections() otherwise flattens the type into one label and
    would fuse them; these boundaries keep them apart while still letting a single
    pagaré bridge over an internal dropped page (a court certificate is DROP, not a
    header, so it is never a boundary)."""
    return {
        i for i, lab in enumerate(labels)
        if lab in (PAGARE_MP, PAGARE_LP, PAGARE_TC) and is_pagare_header(feats[i])
    }


def group_sections(labels: list[str],
                   boundaries: set[int] | None = None) -> list[tuple[str, list[int]]]:
    """[(label, [page_indices]), ...] for kept labels.

    Consecutive runs of the same label separated *only* by DROP pages are merged
    into one (non-contiguous) document — this is how a single pagaré whose middle
    page is a dropped court certificate still emits as one file.

    `boundaries` (page indices from `pagare_boundaries`) are HARD splits: a run
    stops at one and never merges backwards across it, so two adjacent pagarés of
    the same type emit as separate documents instead of being fused into one."""
    boundaries = boundaries or set()
    out: list[tuple[str, list[int]]] = []
    i = 0
    n = len(labels)
    while i < n:
        lab = labels[i]
        if lab == DROP:
            i += 1
            continue
        j = i + 1
        while j < n and labels[j] == lab and j not in boundaries:
            j += 1
        if out and out[-1][0] == lab and i not in boundaries:  # merge over DROP-only gap
            out[-1][1].extend(range(i, j))
        else:
            out.append((lab, list(range(i, j))))
        i = j
    return out


# ----------------------------------------------------------------------------
# Confidence scoring + human-review routing (hybrid auto / _REVISAR pipeline)
# ----------------------------------------------------------------------------
# How a document is detected drives how much we trust it on an UNSEEN batch:
#   TIER1 — text-anchored + position-pinned (exact Spanish phrases, OCR-clean):
#           robust by construction -> auto-emit.
#   TIER2 — faint forms matched by visual similarity to the labelled examples:
#           perfect on the sample but threshold-based -> auto-emit only when the
#           similarity margin is comfortable, else route to review.
#   TIER3 — keep/drop judgment calls (hoja, anexo) -> always route to review.
TIER1 = {CHECKLIST, PAGARE_MP, PAGARE_LP, PAGARE_TC}
TIER2 = {LIQUIDACION, INFORME, CEDULA}
TIER3 = {HOJA_DE_FIRMA, ANEXO}

AUTO_MIN = 0.75       # TIER2 needs at least this confidence to auto-emit
TIER1_MIN = 0.60      # TIER1 below this (e.g. a defaulted checklist) also gets reviewed


def _norm_sim(sim: float, lo: float = FORM_MIN, hi: float = 0.90) -> float:
    """Map a visual similarity in [lo, hi] onto a confidence in [0.50, 0.97]."""
    if sim <= lo:
        return 0.50
    if sim >= hi:
        return 0.97
    return 0.50 + 0.47 * (sim - lo) / (hi - lo)


def document_confidence(feats: list[PageFeatures], label: str, pages: list[int],
                        tpl: Templates, prev_end: int = -1) -> tuple[float, str, str]:
    """Return (confidence in [0,1], tier, human-readable reason) for one document."""
    f0 = feats[pages[0]]

    if label == CHECKLIST:
        hits = [a for a in CHECKLIST_ANCHORS if a in f0.text_upper]
        if hits and f0.index <= 2:
            return 0.97, "T1", f"checklist anchor {hits[0]!r} on p{f0.index + 1}"
        if hits:
            return 0.80, "T1", f"checklist anchor {hits[0]!r} (late, p{f0.index + 1})"
        return 0.45, "T1", "no checklist anchor — defaulted to first page"

    if label in (PAGARE_MP, PAGARE_LP, PAGARE_TC):
        hits = [a for a in PAGARE_ANCHORS if a in f0.text_upper]
        conf = 0.97 if len(hits) >= 2 else (0.85 if hits else 0.55)
        sub = {PAGARE_LP: "LP", PAGARE_TC: "TC"}.get(label, "MP")
        return conf, "T1", f"{len(hits)} pagaré anchor(s), {f0.n_words}w, {sub}"

    if label in (LIQUIDACION, INFORME):
        refs = tpl.liq if label == LIQUIDACION else (tpl.inf1 + tpl.inf2)
        s = min(best_sim(feats[p].vvec, refs) for p in pages)
        return _norm_sim(s), "T2", f"visual match {s:.2f} (weakest of {len(pages)}p)"

    if label == CEDULA:
        if f0.ink_density >= 0.20:
            return 0.92, "T2", f"dark card scan (ink {f0.ink_density:.2f})"
        if has(f0, *CEDULA_ANCHORS):
            return 0.90, "T2", "registry text anchor"
        s = best_sim(f0.vvec, tpl.ced)
        return _norm_sim(s, lo=CED_MIN, hi=0.55), "T2", f"faint card visual match {s:.2f}"

    if label == HOJA_DE_FIRMA:
        gap = pages[0] - prev_end - 1            # dropped pages between body and this hoja
        conf = max(0.30, 0.70 - min(0.35, 0.04 * max(0, gap)))
        return conf, "T3", f"hoja de firma, {gap} dropped pages before it"

    if label == ANEXO:
        return 0.60, "T3", "anexo contrato (rare type — verify)"

    return 0.50, "T3", "unrecognised"


def route_document(label: str, conf: float, auto_min: float = AUTO_MIN) -> str:
    """'AUTO' (write to output) or 'REVIEW' (route to _REVISAR for a human)."""
    if label in TIER3:
        return "REVIEW"
    if label in TIER1:
        return "AUTO" if conf >= TIER1_MIN else "REVIEW"
    return "AUTO" if conf >= auto_min else "REVIEW"
