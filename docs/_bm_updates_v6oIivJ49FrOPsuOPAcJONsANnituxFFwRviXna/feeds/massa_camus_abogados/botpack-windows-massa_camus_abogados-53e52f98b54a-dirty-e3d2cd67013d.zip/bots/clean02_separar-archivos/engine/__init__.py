# clean02 "Separar archivos" engine package.
# The modules (clean02, classifier, splitter) are imported as *top-level* modules
# after adding this directory to sys.path — NOT as engine.clean02 — because the
# bundled templates.pkl was pickled referencing the top-level name `classifier.Templates`.
# functions.py handles the sys.path insertion.
