# bots/shared/
# Shared library for all BotManager bots.
# Import from here to avoid duplicating common infrastructure across bots.
#
# Modules:
#   ojv_portal  - OJV portal login, URL resolution, modal/warning handling
#   artifacts   - Robocorp output artifact snapshot and move helpers
#   output_dirs - Timestamped output directory creation helpers
