"""
shared/artifacts.py
-------------------
Robocorp output artifact management shared across all bots.

Provides:
  - snapshot_output_artifacts        -> Record current artifact mtimes before a run
  - move_updated_artifacts_to_run_dir -> Move new/updated artifacts into the run folder
  - register_pending_artifact_move   -> Register a deferred move (flushed on exit via atexit)
"""
from __future__ import annotations

import atexit
from pathlib import Path


# ---------------------------------------------------------------------------
# Internal state for deferred artifact move (registered via atexit)
# ---------------------------------------------------------------------------

_PENDING_ARTIFACT_MOVE: tuple[Path, Path, dict[str, float]] | None = None


def _flush_pending_artifacts() -> None:
    global _PENDING_ARTIFACT_MOVE
    if not _PENDING_ARTIFACT_MOVE:
        return
    output_root, run_output, baseline = _PENDING_ARTIFACT_MOVE
    move_updated_artifacts_to_run_dir(
        output_root=output_root,
        run_output=run_output,
        baseline=baseline,
    )
    _PENDING_ARTIFACT_MOVE = None


atexit.register(_flush_pending_artifacts)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_robocorp_output_artifact(file_path: Path) -> bool:
    """Return True if the file looks like a Robocorp-generated artifact."""
    name = file_path.name.lower()
    if name in {"log.html", "output.xml"}:
        return True
    if name.endswith(".robolog"):
        return True
    if name.startswith("output_") and file_path.suffix.lower() in {".json", ".log", ".txt"}:
        return True
    return False


def snapshot_output_artifacts(output_root: Path) -> dict[str, float]:
    """
    Record the current modification times of all artifacts in output_root.
    Call this BEFORE starting a task to establish a baseline.
    """
    snapshot: dict[str, float] = {}
    if not output_root.exists():
        return snapshot
    for child in output_root.iterdir():
        if not child.is_file() or not is_robocorp_output_artifact(child):
            continue
        try:
            snapshot[str(child)] = child.stat().st_mtime
        except OSError:
            continue
    return snapshot


def move_updated_artifacts_to_run_dir(
    output_root: Path,
    run_output: Path,
    baseline: dict[str, float],
) -> None:
    """
    Move any artifacts in output_root that are newer than the baseline into run_output.
    Best-effort: errors on individual files are silently skipped.
    """
    if not output_root.exists() or not run_output.exists():
        return

    for child in output_root.iterdir():
        if not child.is_file() or not is_robocorp_output_artifact(child):
            continue
        source_key = str(child)
        previous_mtime = baseline.get(source_key)
        try:
            current_mtime = child.stat().st_mtime
        except OSError:
            continue

        if previous_mtime is not None and current_mtime <= previous_mtime:
            continue

        target = run_output / child.name
        try:
            if target.exists():
                target.unlink()
            child.replace(target)
        except OSError:
            try:
                if target.exists():
                    target.unlink()
                with open(child, "rb") as src, open(target, "wb") as dst:
                    dst.write(src.read())
            except OSError:
                continue


def register_pending_artifact_move(
    output_root: Path,
    run_output: Path,
    baseline: dict[str, float],
) -> None:
    """
    Register a deferred artifact move to be flushed on process exit.
    Call this after a task finishes (even in a finally block) so that any
    artifacts written after the explicit move are still captured.
    """
    global _PENDING_ARTIFACT_MOVE
    _PENDING_ARTIFACT_MOVE = (output_root, run_output, baseline)
