"""
clean03 — pipeline / orchestration
==================================
For every RUT folder, match the input-matriz rows to the pagaré PDFs inside it,
OCR + extract each one, and assemble the output rows with the right flags:

  * CARTERA decides which pagaré file a row uses (MP and RE both live in the
    *_PAGARE_MP.pdf file; LP -> *_PAGARE_LP.pdf; TC -> *_PAGARE_TC.pdf).
  * MP / RE  -> full extraction from the pagaré + MONTO_ADEUDADO / cuota-impaga
    from the INFORME_DEUDA.
  * TC / LP  -> simple extraction; MONTO_ADEUDADO = MONTO_PAGARE.
  * An MP/RE that arrives as a simple (TC-shaped) pagaré -> MONTO_ADEUDADO =
    MONTO_PAGARE, flagged REVISAR when a HOJA_DE_FIRMA is present.
  * A matriz row whose pagaré is absent -> whole row painted red (MISSING).
  * A pagaré with no matching matriz row -> extra row painted yellow (EXTRA).
  * Any field that should have been found but was not -> NO_ENCONTRADO (yellow).
"""
from __future__ import annotations

import os
import re
import sys
from collections import OrderedDict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

from . import extract, ocr
from .matriz import read_input_matriz, rut_digits, write_output_matriz

# Bot directory (parent of engine/) — must be on sys.path for `import
# engine.pipeline` to resolve inside a freshly 'spawn'ed worker process.
_BOT_DIR = Path(__file__).resolve().parents[1]

# CARTERA -> pagaré file type. RE shares the MP file format.
_CARTERA_TO_FILETYPE = {"MP": "MP", "RE": "MP", "LP": "LP", "TC": "TC"}
_MP_RE = {"MP", "RE"}
_SIMPLE = {"TC", "LP"}

# Fields the full MP/RE pagaré must yield (else NO_ENCONTRADO).
_PAGARE_FULL_FIELDS = [
    "monto_pagare", "tasa_interes", "num_cuotas", "monto_cuota",
    "monto_ultima_cuota", "fecha_vcto_1ra_cuota", "dia_del_mes_vcto_cuota",
    "fecha_vcto_ultima_cuota", "fecha_suscripcion_pagare",
    "domicilio_deudor", "comuna_deudor",
]
_INFORME_FIELDS = ["monto_adeudado", "nro_1ra_cuota_imp", "fecha_1ra_cuota_imp"]

# CARTERA_A_PROCESAR: an MP whose pagaré carries NONE of these cuota fields has
# no installment structure and must be processed "a la Vista" (VI). A field that
# was expected but unreadable (flagged NO_ENCONTRADO) counts as present, so a
# real MP whose extraction failed stays MP (flagged) instead of being downgraded.
_CARTERA_VI_FIELDS = ("tasa_interes", "num_cuotas", "monto_cuota", "monto_ultima_cuota")


def _cartera_a_procesar(cartera: str, values: dict, cell_flags: dict) -> str:
    """CARTERA_A_PROCESAR = copy of CARTERA_ORIGINAL, except an MP with no cuota
    data becomes 'VI' (procesar a la Vista). This is the column clean04 uses to
    pick the demanda template."""
    if cartera != "MP":
        return cartera
    for f in _CARTERA_VI_FIELDS:
        if values.get(f) not in (None, "") or cell_flags.get(f) == "NO_ENCONTRADO":
            return "MP"
    return "VI"


# --------------------------------------------------------------------------
# Folder / file discovery
# --------------------------------------------------------------------------
def _parse_folder_rut(name: str) -> str:
    """Folder '7.512.305-1' -> '7512305' (RUT digits, DV dropped)."""
    name = name.strip()
    m = re.match(r"^([\d.]+)\s*-\s*([0-9kK])$", name)
    if m:
        return rut_digits(m.group(1))
    digits = rut_digits(name)
    return digits[:-1] if len(digits) >= 2 else digits


def index_folders(input_path: Path) -> "OrderedDict[str, Path]":
    """{rut_key: folder Path} for each RUT subfolder under input_path."""
    folders: "OrderedDict[str, Path]" = OrderedDict()
    for child in sorted(p for p in input_path.iterdir() if p.is_dir()):
        if child.name.startswith("."):
            continue
        key = _parse_folder_rut(child.name)
        if key:
            folders.setdefault(key, child)
    return folders


def find_pagares(folder: Path) -> "OrderedDict[str, list[Path]]":
    """{filetype: [paths]} for *_PAGARE_<TYPE>.pdf inside the folder."""
    out: "OrderedDict[str, list[Path]]" = OrderedDict()
    for pdf in sorted(folder.glob("*.pdf")):
        m = re.search(r"PAGARE[_\s]+([A-Z]{2})", pdf.name.upper())
        if m:
            out.setdefault(m.group(1), []).append(pdf)
    return out


def _find_one(folder: Path, pattern: str) -> Optional[Path]:
    hits = sorted(folder.glob(pattern))
    return hits[0] if hits else None


def find_informe(folder: Path) -> Optional[Path]:
    # Prefer the canonical "<rut>_INFORME_DEUDA.pdf"; ignore mail/ESPAÑOL variants.
    for pdf in sorted(folder.glob("*.pdf")):
        if re.search(r"_INFORME_DEUDA\.pdf$", pdf.name, re.I):
            return pdf
    return None


def find_hoja(folder: Path) -> Optional[Path]:
    return _find_one(folder, "*HOJA_DE_FIRMA*.pdf") or _find_one(folder, "*HOJA*FIRMA*.pdf")


# --------------------------------------------------------------------------
# Row building
# --------------------------------------------------------------------------
def _seed_values(mr: dict) -> dict:
    return {
        "rut": mr["rut"], "dv": mr["dv"], "nombre": mr["nombre"],
        "operacion": mr["operacion"], "cartera": mr["cartera"], "mora": mr["mora"],
        # Default = copy of CARTERA_ORIGINAL; build_row overrides for MP-sin-cuotas.
        "cartera_a_procesar": mr["cartera"],
    }


def _hoja_fields(values: dict, cell_flags: dict, hoja_path: Optional[Path]) -> None:
    if hoja_path is None:
        values["hoja_de_firma"] = "NO"
        return
    values["hoja_de_firma"] = "SI"
    cod = extract.extract_cod_contrato(ocr.ocr_pdf_text(hoja_path))
    if cod is not None:
        values["cod_contrato"] = cod
    else:
        cell_flags["cod_contrato"] = "NO_ENCONTRADO"


def _fill_with_flags(values: dict, cell_flags: dict, data: dict, fields: list[str]) -> None:
    for k in fields:
        v = data.get(k)
        values[k] = v
        if v in (None, ""):
            cell_flags[k] = "NO_ENCONTRADO"


def build_row(mr: dict, pagare_path: Path, informe_path: Optional[Path],
              hoja_path: Optional[Path]) -> dict:
    """Assemble one output row for a matched matriz row + pagaré file."""
    values = _seed_values(mr)
    cell_flags: dict = {}
    cartera = mr["cartera"]
    pagare_text = ocr.ocr_pdf_text(pagare_path)
    # Presence flag — does the pagaré say the last cuota will be smaller?
    # Always a definitive SI/NO (absence of the clause IS "NO"), so no flag.
    values["pagare_ultima_cuota_inferior"] = (
        "SI" if extract.has_ultima_cuota_inferior(pagare_text) else "NO")
    hoja_present = hoja_path is not None
    _hoja_fields(values, cell_flags, hoja_path)

    if cartera in _MP_RE and not extract.is_simple_pagare(pagare_text):
        # Full MP/RE pagaré.
        _fill_with_flags(values, cell_flags, extract.extract_pagare_full(pagare_text),
                         _PAGARE_FULL_FIELDS)
        if informe_path is not None:
            inf = extract.extract_informe(ocr.ocr_pdf_text(informe_path), mr.get("operacion"))
            _fill_with_flags(values, cell_flags, inf, _INFORME_FIELDS)
            # RE pagarés lack the "En <ciudad>, a <día> de <mes>" suscripción
            # line; fall back to the informe's Otorgamiento date.
            if values.get("fecha_suscripcion_pagare") in (None, "") and inf.get("otorgamiento"):
                values["fecha_suscripcion_pagare"] = inf["otorgamiento"]
                cell_flags.pop("fecha_suscripcion_pagare", None)
        else:
            for k in _INFORME_FIELDS:
                cell_flags[k] = "NO_ENCONTRADO"
    elif cartera in _MP_RE and extract.is_simple_pagare(pagare_text):
        # MP/RE delivered as a simple pagaré: MONTO_ADEUDADO = MONTO_PAGARE,
        # REVISAR when there is also a Hoja de Firma.
        simple = extract.extract_pagare_simple(pagare_text)
        _fill_with_flags(values, cell_flags, simple,
                         ["monto_pagare", "fecha_suscripcion_pagare",
                          "domicilio_deudor", "comuna_deudor"])
        values["monto_adeudado"] = simple.get("monto_pagare")
        if values["monto_adeudado"] is None:
            cell_flags["monto_adeudado"] = "NO_ENCONTRADO"
        elif hoja_present:
            cell_flags["monto_adeudado"] = "REVISAR"
    else:
        # TC / LP simple pagaré.
        simple = extract.extract_pagare_simple(pagare_text)
        _fill_with_flags(values, cell_flags, simple,
                         ["monto_pagare", "fecha_suscripcion_pagare",
                          "domicilio_deudor", "comuna_deudor"])
        values["monto_adeudado"] = simple.get("monto_pagare")
        if values["monto_adeudado"] is None:
            cell_flags["monto_adeudado"] = "NO_ENCONTRADO"

    values["cartera_a_procesar"] = _cartera_a_procesar(cartera, values, cell_flags)
    return {"values": values, "cell_flags": cell_flags, "row_flag": None,
            "source_row": mr.get("source_row", 0)}


def _missing_row(mr: dict) -> dict:
    return {"values": _seed_values(mr), "cell_flags": {}, "row_flag": "MISSING",
            "source_row": mr.get("source_row", 0)}


def _extra_row(folder: Path, filetype: str, pagare_path: Path,
               informe_path: Optional[Path], hoja_path: Optional[Path],
               source_row: int) -> dict:
    """A pagaré with no matriz row. Process it as best we can and flag EXTRA."""
    key = _parse_folder_rut(folder.name)
    pseudo = {
        "rut": int(key) if key else None, "dv": "", "nombre": "",
        "operacion": "", "cartera": filetype, "mora": None, "source_row": source_row,
    }
    row = build_row(pseudo, pagare_path, informe_path, hoja_path)
    row["row_flag"] = "EXTRA"
    row["values"]["nota"] = "PAGARE EXTRA (no estaba en la matriz)"
    return row


def _op_digits(value) -> str:
    """Operation number as digits only (matriz cell or pagaré header)."""
    return re.sub(r"\D", "", str(value or ""))


def _index_by_operacion(paths: list[Path]) -> dict[str, Path]:
    """{op_digits: path} for a type that carries 2+ pagaré files, so a row can be
    paired to the file whose printed OPERACIÓN matches it (not just scan order).
    Only called for ambiguous types — a lone file skips this OCR entirely."""
    idx: dict[str, Path] = {}
    for p in paths:
        od = _op_digits(extract.extract_operacion(ocr.ocr_pdf_text(p)))
        if len(od) >= 5:
            idx.setdefault(od, p)   # first file wins on the rare duplicate read
    return idx


def _process_rut(folder: Path, rows: list[dict]) -> tuple[list[dict], list[dict]]:
    pagares = find_pagares(folder)
    informe = find_informe(folder)
    hoja = find_hoja(folder)

    # When a RUT has several pagarés of the SAME type (clean02 now splits them
    # into one file each), pair every file to the matriz row whose OPERACIÓN it
    # prints. Single-file types keep the cheap positional path (no extra OCR,
    # behaviour identical to before); unread operations fall back to positional.
    op_index: dict[str, dict[str, Path]] = {
        ftype: _index_by_operacion(paths)
        for ftype, paths in pagares.items() if len(paths) >= 2
    }

    claimed: set[Path] = set()
    assigned: dict[int, Path] = {}
    # Pass 1 — OPERACIÓN match (only for the ambiguous, multi-file types).
    for ri, mr in enumerate(rows):
        filetype = _CARTERA_TO_FILETYPE.get(mr["cartera"])
        idx = op_index.get(filetype) if filetype else None
        if not idx:
            continue
        cand = idx.get(_op_digits(mr.get("operacion")))
        if cand is not None and cand not in claimed:
            assigned[ri] = cand
            claimed.add(cand)

    # Pass 2 — positional fallback (first unclaimed file of the type) for every
    # row not paired by OPERACIÓN, in matriz order.
    filled: list[dict] = []
    for ri, mr in enumerate(rows):
        path = assigned.get(ri)
        if path is None:
            filetype = _CARTERA_TO_FILETYPE.get(mr["cartera"])
            if filetype:
                for cand in pagares.get(filetype, []):
                    if cand not in claimed:
                        path = cand
                        claimed.add(cand)
                        break
        if path is None:
            filled.append(_missing_row(mr))
        else:
            filled.append(build_row(mr, path, informe, hoja))

    last_src = rows[-1].get("source_row", 0) if rows else 0
    extras = [
        _extra_row(folder, ftype, p, informe, hoja, last_src)
        for ftype, paths in pagares.items() for p in paths if p not in claimed
    ]
    return filled, extras


# --------------------------------------------------------------------------
# Parallelism — fan the per-RUT OCR/extraction out over processes
# --------------------------------------------------------------------------
# Each RUT is processed independently (its own folder, its own OCR) and OCR is
# deterministic, so the per-RUT rows are identical no matter which core computes
# them. Only the OCR-heavy `_process_rut` runs in parallel; the rows are then
# ASSEMBLED serially in the original matriz order (and the output is finally
# sorted by source_row anyway), so the written matriz is byte-for-byte identical
# to a serial run. Processes, not threads: PyMuPDF is not thread-safe.


def _resolve_workers(parallel: bool, n_tasks: int, max_workers: int | None) -> int:
    """How many RUT folders to OCR at once. 1 = serial. Parallelism only helps
    with 2+ folders; the default leaves one core free so the machine stays usable."""
    if not parallel or n_tasks <= 1:
        return 1
    if max_workers and max_workers > 0:
        return min(max_workers, n_tasks)
    return min(n_tasks, max(1, (os.cpu_count() or 2) - 1))


def _process_rut_worker(folder_str: str, rows: list[dict]) -> tuple:
    """ProcessPool worker: run `_process_rut` in its own process. Returns a
    picklable tuple ('ok', filled, extras) or ('err', message) — a per-RUT failure
    is captured, not raised, so one bad folder never kills the pool."""
    if str(_BOT_DIR) not in sys.path:          # re-establish the engine import root ('spawn')
        sys.path.insert(0, str(_BOT_DIR))
    try:
        filled, extras = _process_rut(Path(folder_str), rows)
        return ("ok", filled, extras)
    except Exception as exc:
        return ("err", str(exc))


def _compute_ruts_parallel(by_rut: "OrderedDict[str, list[dict]]",
                           folders: "OrderedDict[str, Path]",
                           n_workers: int, n_tasks: int) -> dict:
    """Run `_process_rut` for every RUT-with-folder over a process pool. Prints
    live progress as each finishes; returns {rut_key: ('ok', filled, extras) |
    ('err', message)}. Row assembly is done afterwards, in input order."""
    tasks = [(rk, rows, folders[rk]) for rk, rows in by_rut.items()
             if folders.get(rk) is not None]
    results: dict = {}
    done = 0
    with ProcessPoolExecutor(max_workers=n_workers) as ex:
        fut_to_rk = {ex.submit(_process_rut_worker, str(folder), rows): rk
                     for rk, rows, folder in tasks}
        for fut in as_completed(fut_to_rk):
            rk = fut_to_rk[fut]
            done += 1
            print(f"[CLEAN03][PROGRESS] {done}/{n_tasks}", flush=True)
            try:
                results[rk] = fut.result()
            except Exception as exc:            # a worker process crashed outright
                results[rk] = ("err", str(exc))
    return results


def _assemble_rows(by_rut: "OrderedDict[str, list[dict]]",
                   folders: "OrderedDict[str, Path]", summary: dict,
                   out_rows: list[dict], resolve, emit_progress: bool,
                   total: int) -> None:
    """Single ordered pass that turns per-RUT results into output rows + summary
    counters + run-log lines. Shared by the serial and parallel paths, so the
    matriz and summary are identical regardless of how the work was scheduled.
    `resolve(rut_key, rows, folder)` returns (filled, extras) or raises."""
    for idx, (rut_key, rows) in enumerate(by_rut.items(), start=1):
        if emit_progress:
            print(f"[CLEAN03][PROGRESS] {idx}/{total}", flush=True)
        folder = folders.get(rut_key)
        if folder is None:
            # Seed RUT has no folder in input/ruts -> whole row painted blue.
            for mr in rows:
                out_rows.append({"values": _seed_values(mr), "cell_flags": {},
                                 "row_flag": "NO_FOLDER", "source_row": mr["source_row"]})
            summary["no_folder_rows"] += len(rows)
            print(f"-- {rut_key}: sin carpeta, filas sin procesar ({len(rows)})", flush=True)
            continue

        try:
            filled, extras = resolve(rut_key, rows, folder)
        except Exception as exc:  # one bad folder must not abort the whole batch
            summary["errors"].append({"rut": rut_key, "error": str(exc)})
            for mr in rows:
                out_rows.append({"values": _seed_values(mr), "cell_flags": {},
                                 "row_flag": "MISSING", "source_row": mr["source_row"]})
            print(f"!! {folder.name}: ERROR — {exc}", flush=True)
            continue
        out_rows.extend(filled)
        out_rows.extend(extras)
        summary["ruts_processed"] += 1

        n_missing = sum(1 for r in filled if r["row_flag"] == "MISSING")
        n_flagcells = sum(len(r["cell_flags"]) for r in filled + extras)
        summary["processed_rows"] += len(filled) - n_missing
        summary["missing_rows"] += n_missing
        summary["extra_rows"] += len(extras)
        summary["flagged_cells"] += n_flagcells
        summary["cases"].append({
            "rut": rut_key, "rows": len(filled), "missing": n_missing,
            "extra": len(extras), "flagged_cells": n_flagcells,
        })
        print(f"OK {folder.name}: {len(filled)} fila(s)"
              f"{f', {n_missing} sin pagaré' if n_missing else ''}"
              f"{f', {len(extras)} extra' if extras else ''}"
              f"{f', {n_flagcells} celda(s) marcada(s)' if n_flagcells else ''}",
              flush=True)


# --------------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------------
def extraer_datos_pagares(pagares_input_path: str | Path, matriz_input_path: str | Path,
                          output_path: str | Path, *, force_fresh: bool = False,
                          parallel: bool = False, max_workers: int | None = None) -> dict:
    """Read the input matriz + the folder of RUT subfolders, OCR/extract every
    pagaré, and write the styled output matriz. Returns a summary dict.

    When `parallel` is True (and there are 2+ RUT folders) the per-RUT OCR runs
    over a process pool of `max_workers` (default: CPU count minus one). Rows are
    assembled serially in matriz order afterwards, so the output matriz and the
    summary are identical to a serial run — only faster."""
    in_folder = Path(str(pagares_input_path).strip()).expanduser()
    if not in_folder.exists() or not in_folder.is_dir():
        raise ValueError(
            "La carpeta de RUTs no existe o no es una carpeta.\n"
            f"Ruta: {in_folder}"
        )
    matriz_path = Path(str(matriz_input_path).strip()).expanduser()
    if not matriz_path.exists() or matriz_path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError(
            "No se encontró la matriz de entrada (.xlsx).\n"
            f"Ruta: {matriz_path}"
        )

    if force_fresh:
        cleared = ocr.clear_cache()
        print(f"[CLEAN03] Re-proceso desde cero: cache OCR limpiada "
              f"({cleared} archivo(s)).", flush=True)
    ocr.assert_tesseract_ready()

    matriz_rows = read_input_matriz(matriz_path)
    folders = index_folders(in_folder)

    by_rut: "OrderedDict[str, list[dict]]" = OrderedDict()
    for mr in matriz_rows:
        by_rut.setdefault(mr["rut_key"], []).append(mr)

    summary = {
        "matriz": str(matriz_path), "input": str(in_folder), "output": str(output_path),
        "matriz_rows": len(matriz_rows), "ruts": len(by_rut),
        "processed_rows": 0, "missing_rows": 0, "extra_rows": 0,
        "no_folder_rows": 0, "ruts_processed": 0, "flagged_cells": 0,
        "cases": [], "errors": [],
    }

    out_rows: list[dict] = []
    total = len(by_rut)
    print(f"[CLEAN03][PROGRESS] 0/{total}", flush=True)

    n_folder_tasks = sum(1 for rk in by_rut if folders.get(rk) is not None)
    n_workers = _resolve_workers(parallel, n_folder_tasks, max_workers)
    if n_workers > 1:
        print(
            f"[CLEAN03] Modo paralelo: hasta {n_workers} RUT a la vez "
            f"(de {os.cpu_count()} nucleos).",
            flush=True,
        )
        precomputed = _compute_ruts_parallel(by_rut, folders, n_workers, n_folder_tasks)

        def _resolve(rut_key, rows, folder):
            res = precomputed[rut_key]
            if res[0] == "err":
                raise RuntimeError(res[1])   # re-raised -> same MISSING rows + log line
            return res[1], res[2]
        # Progress already emitted during the parallel compute above.
        _assemble_rows(by_rut, folders, summary, out_rows, _resolve,
                       emit_progress=False, total=total)
    else:
        _assemble_rows(by_rut, folders, summary, out_rows,
                       lambda rk, rows, folder: _process_rut(folder, rows),
                       emit_progress=True, total=total)

    out_rows.sort(key=lambda r: r.get("source_row", 0))
    write_output_matriz(output_path, out_rows)
    summary["output_rows"] = len(out_rows)
    return summary
