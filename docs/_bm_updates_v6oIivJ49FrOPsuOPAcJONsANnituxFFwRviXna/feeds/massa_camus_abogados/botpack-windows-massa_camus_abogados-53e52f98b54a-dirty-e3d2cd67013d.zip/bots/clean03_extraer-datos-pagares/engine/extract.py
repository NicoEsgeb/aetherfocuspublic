"""
clean03 — field extractors
===========================
Pulls the matriz fields out of the OCR'd text of each document type:

  * PAGARE_MP / "RE" (same file format): principal, tasa, cuotas, montos de
    cuota, fechas de vencimiento, fecha de suscripción, domicilio y comuna.
  * PAGARE_TC / PAGARE_LP (simple format): principal (= monto adeudado),
    fecha de suscripción, domicilio y comuna.
  * INFORME_DEUDA: monto adeudado (Capital de la 1ª operación), número y fecha
    de la primera cuota impaga.
  * HOJA_DE_FIRMA: código de contrato (número de Repertorio).

Every extractor returns a plain dict mapping the canonical field name to its
value, or None when the anchor was not found, so the pipeline can decide when a
missing value deserves a NO_ENCONTRADO flag (e.g. tasa is expected on MP/RE but
not on TC/LP).

All matching is accent-insensitive where it matters. Chilean number format:
"21.687.429" -> 21687429 (dot = thousands), "1,66" -> 1.66 (comma = decimal).
"""
from __future__ import annotations

import re
from typing import Optional

# --------------------------------------------------------------------------
# Month maps
# --------------------------------------------------------------------------
# Pagaré dates are written in full Spanish ("6 de julio de 2025").
_MES_ES = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6,
    "julio": 7, "agosto": 8, "septiembre": 9, "setiembre": 9, "octubre": 10,
    "noviembre": 11, "diciembre": 12,
}
# Informe dates use English 3-letter abbreviations ("6/JAN/2026"). Keys are the
# first three letters; a couple of common OCR slips are folded in.
_MES_EN = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6, "JUL": 7,
    "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
    "0CT": 10, "0CR": 10,  # OCR reads the leading O as 0 sometimes
}

_THOUSANDS = r"\d{1,3}(?:\.\d{3})+"  # 21.687.429 — requires at least one group


def _fold(s: str) -> str:
    repl = str.maketrans("ÁÉÍÓÚÜÑáéíóúüñ", "AEIOUUNAEIOUUN")
    return (s or "").upper().translate(repl)


def parse_monto(raw: str) -> Optional[int]:
    """'21.687.429' / '$ 6.933.690.-' -> 21687429 / 6933690. Dots are thousands
    separators; any trailing ',00' decimals are dropped."""
    if raw is None:
        return None
    s = str(raw).split(",")[0]          # drop ,00 decimals
    digits = re.sub(r"\D", "", s)       # keep only digits
    if not digits:
        return None
    return int(digits)


def parse_decimal(raw: str) -> Optional[float]:
    """'1,66' -> 1.66 (Chilean comma decimal)."""
    if raw is None:
        return None
    s = str(raw).strip().replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _fmt(day: int, month: int, year: int) -> Optional[str]:
    if not (1 <= month <= 12 and 1 <= day <= 31 and 1900 <= year <= 2100):
        return None
    return f"{day:02d}-{month:02d}-{year:04d}"


def _date_es(day: str, month_word: str, year: str) -> Optional[str]:
    month = _MES_ES.get(_fold(month_word).lower())
    if month is None:
        return None
    try:
        return _fmt(int(day), month, int(year))
    except (ValueError, TypeError):
        return None


def _date_en(day: str, mon3: str, year: str) -> Optional[str]:
    month = _MES_EN.get(_fold(mon3))
    if month is None:
        return None
    try:
        return _fmt(int(day), month, int(year))
    except (ValueError, TypeError):
        return None


def _search(pattern: str, text: str) -> Optional[re.Match]:
    return re.search(pattern, text, re.IGNORECASE | re.DOTALL)


def _flat(text: str) -> str:
    """Collapse all runs of whitespace (incl. line/page breaks) to single
    spaces. OCR frequently splits a phrase across a line — e.g. 'la suma\\nde
    $ 41.469.919' — which breaks space-anchored patterns. Used for the
    money/date/code anchors; NOT for domicilio, which relies on line breaks."""
    return re.sub(r"\s+", " ", text or "")


# --------------------------------------------------------------------------
# Domicilio / Comuna (shared by all pagaré formats)
# --------------------------------------------------------------------------
_ADDR_ABBR = [
    (re.compile(r"^AVDA\b\.?", re.I), "AVENIDA"),
    (re.compile(r"^AV\b\.?", re.I), "AVENIDA"),
    (re.compile(r"^PSJE\b\.?", re.I), "PASAJE"),
    (re.compile(r"^PJE\b\.?", re.I), "PASAJE"),
]
# Trailing city / region tokens that are not the comuna.
_CITY_TAIL = {"SANTIAGO", "REGION METROPOLITANA", "RM", "CHILE"}

# Comunas of the Región Metropolitana (folded, uppercased, no accents). The
# "Dirección Informativa" line formats the comuna inconsistently — sometimes
# comma-separated ("..., Pudahuel, Santiago"), sometimes glued to the street
# ("HUENTELAUQUEN 385 LAS CONDES, Santiago") — so a gazetteer match is far more
# reliable than splitting on commas, and it lets us strip the comuna out of the
# domicilio to match the human's street-only address.
_RM_COMUNAS = [
    "CERRILLOS", "CERRO NAVIA", "CONCHALI", "EL BOSQUE", "ESTACION CENTRAL",
    "HUECHURABA", "INDEPENDENCIA", "LA CISTERNA", "LA FLORIDA", "LA GRANJA",
    "LA PINTANA", "LA REINA", "LAS CONDES", "LO BARNECHEA", "LO ESPEJO",
    "LO PRADO", "MACUL", "MAIPU", "NUNOA", "PEDRO AGUIRRE CERDA", "PENALOLEN",
    "PROVIDENCIA", "PUDAHUEL", "QUILICURA", "QUINTA NORMAL", "RECOLETA", "RENCA",
    "SAN JOAQUIN", "SAN MIGUEL", "SAN RAMON", "VITACURA", "PUENTE ALTO",
    "SAN BERNARDO", "LA CISTERNA", "COLINA", "LAMPA", "TILTIL", "BUIN", "PAINE",
    "SAN JOSE DE MAIPO", "PIRQUE", "CALERA DE TANGO", "PADRE HURTADO",
    "PENAFLOR", "TALAGANTE", "EL MONTE", "ISLA DE MAIPO", "MELIPILLA",
    "CURACAVI", "PEÑAFLOR", "SANTIAGO",
]
# Longest first so "LAS CONDES" wins over a bare "CONDES", etc.
_RM_SORTED = sorted({c for c in _RM_COMUNAS}, key=len, reverse=True)


def _find_comuna(folded_line: str) -> Optional[str]:
    """Rightmost RM comuna in the (folded) address line, preferring a real
    comuna over the city 'Santiago'."""
    hits: list[tuple[int, str]] = []
    for c in _RM_SORTED:
        idx = folded_line.rfind(c)
        while idx >= 0:
            before_ok = idx == 0 or not folded_line[idx - 1].isalnum()
            after = idx + len(c)
            after_ok = after >= len(folded_line) or not folded_line[after].isalnum()
            if before_ok and after_ok:
                hits.append((idx, c))
                break
            idx = folded_line.rfind(c, 0, idx)
    if not hits:
        return None
    non_stgo = [(i, c) for i, c in hits if c != "SANTIAGO"]
    pool = non_stgo or hits
    return max(pool, key=lambda x: x[0])[1]


def extract_domicilio_comuna(text: str) -> tuple[Optional[str], Optional[str]]:
    """From 'Dirección Informativa: <dir>, <comuna>, <ciudad>' (MP) or
    'Domicilio : <dir>, <comuna>, <ciudad>' (TC/LP). Returns (domicilio, comuna)
    upper-cased; the comuna is removed from the domicilio so it matches the
    human's street-only address."""
    # RE pagarés use explicit labels: "Domicilio: <dir> Ciudad <x> Comuna <y>".
    m_dom = _search(r"\bDomicilio\s*:\s*(.+?)\s+Ciudad\b", text)
    m_com = _search(
        r"\bComuna\s*:?\s+([A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ.\s]{1,28}?)\s*"
        r"(?:Rut|C[ée]dula|Fono|Tel[eé]fono|Fecha|E-?mail|Celular|Representado|\n|\f|$)",
        text,
    )
    if m_dom and m_com:
        dom = _fold(m_dom.group(1).strip().strip(",."))
        for rx, full in _ADDR_ABBR:
            dom = rx.sub(full, dom).strip()
        com = _fold(m_com.group(1).strip().strip(",."))
        return (dom or None), (com or None)

    # MP uses "Dirección Informativa:"; TC/LP use a labelled "Domicilio :" line.
    # The colon is REQUIRED on the Domicilio fallback so the boilerplate
    # "Domicilio y competencia: Para todos los efectos..." is not picked up.
    m = (_search(r"Direcci[oó]n Informativa\s*:?\s*([^\n\f]+)", text)
         or _search(r"\bDomicilio\s*:\s*([^\n\f]+)", text))
    if not m:
        return None, None
    line = m.group(1).strip()
    line = re.split(r"\b(?:Fecha|Representado|Repres|RUT|C\.?L|Ciudad|Pa[ií]s)\b",
                    line, maxsplit=1)[0].strip().strip(",.").strip()
    if not line:
        return None, None

    comuna = _find_comuna(_fold(line))

    # Domicilio = the address parts minus the comuna and the city tail.
    kept: list[str] = []
    for part in line.split(","):
        fp = _fold(part).strip().strip(".").strip()
        if not fp or fp in _CITY_TAIL or (comuna and fp == comuna):
            continue
        kept.append(part.strip())
    domicilio = ", ".join(kept).strip().strip(",.").strip()
    # If the comuna was glued onto the street (no comma), strip it off the end.
    if comuna and _fold(domicilio).endswith(comuna):
        domicilio = domicilio[: len(domicilio) - len(comuna)].strip().strip(",.").strip()
    for rx, full in _ADDR_ABBR:
        domicilio = rx.sub(full, domicilio).strip()
    domicilio = _fold(domicilio)
    return (domicilio or None), comuna


# --------------------------------------------------------------------------
# Pagaré (MP / RE — full format with cuotas)
# --------------------------------------------------------------------------
def extract_monto_pagare(text: str) -> Optional[int]:
    """Principal: the amount in 'la suma/cantidad de $ <amount> .- (palabras pesos)'.

    Capturing the digits *before* the parenthetical word-amount survives OCR
    noise in the thousands separators (e.g. '$ 16,859.345' where a dot was read
    as a comma), so we strip every non-digit from the capture."""
    text = _flat(text)
    m = _search(r"(?:suma|cantidad)\s+de\s*\$\s*([\d.,\s]{5,}?)\s*[.\-]*\s*\(", text)
    if m:
        digits = re.sub(r"\D", "", m.group(1))
        if 6 <= len(digits) <= 9 and 100_000 <= int(digits) <= 999_999_999:
            return int(digits)
    # Clean thousands-formatted fallback (no parenthetical word-amount).
    for pat in (rf"suma\s+de\s*\$\s*({_THOUSANDS})",
                rf"cantidad\s+de\s*\$\s*({_THOUSANDS})"):
        m = _search(pat, text)
        if m:
            v = parse_monto(m.group(1))
            if v and v >= 100_000:
                return v
    # Last resort: the largest thousands-formatted amount on the document.
    amounts = [parse_monto(a) for a in re.findall(rf"\$\s*({_THOUSANDS})", text)]
    amounts = [a for a in amounts if a and a >= 100_000]
    return max(amounts) if amounts else None


def is_simple_pagare(text: str) -> bool:
    """True when a pagaré has the simple TC/LP shape (no installment plan).
    Used to detect an MP/RE that arrived as a simple pagaré."""
    folded = _fold(text)
    has_cuotas = "CUOTAS" in folded and bool(_search(r"en\s*\d{1,3}\s*cuotas", text))
    has_tasa = bool(_search(r"tasa de\s*[\d,]+\s*%", text))
    return not (has_cuotas or has_tasa)


def has_ultima_cuota_inferior(text: str) -> bool:
    """True when the installment clause states the LAST cuota will simply be
    *smaller* ("salvo la última que será inferior"), as opposed to the standard
    fixed last cuota ("salvo la última que será por $X").

    Anchored on 'última … inferior' within a single sentence (≤40 chars apart,
    no period in between) so the other 'inferior' clauses that share the page are
    NOT matched — the prepago floor ("...no podrá ser inferior al 20% de lo
    adeudado") and the UF cap ("...igual o inferior al equivalente en UF..."),
    both of which can appear on the very same pagaré. Runs on a folded +
    whitespace-flattened copy because OCR splits the phrase across lines."""
    return bool(re.search(r"\bULTIMA\b[^.]{0,40}\bINFERIOR\b", _fold(_flat(text))))


def extract_pagare_full(text: str) -> dict:
    """Extract every MP/RE pagaré field. Missing anchors -> None.

    MP and RE word the installment clause differently:
      MP: 'por la suma de $X cada una ... salvo la última que será por $Y',
          'tasa de 1,66 % mensual', 'días 6 de cada mes', 'el día 6 de julio'.
      RE: 'cada una de ellas por el monto de $X' (no separate última amount,
          so última = cuota), 'tasa del 23,88% anual. (1,99% mensual)',
          'días 1 del (de los) mes', 'el 1 de octubre' (no 'día')."""
    out: dict = {}
    out["monto_pagare"] = extract_monto_pagare(text)

    # Whitespace-flattened text for the money/date anchors (OCR splits phrases
    # across lines); domicilio keeps the original text (it needs line breaks).
    ft = _flat(text)

    # The monthly rate, however it is introduced ("tasa de 1,66 % mensual" or
    # "...(1,99% mensual)"). Always anchored on "% mensual".
    m = _search(r"([\d]+,[\d]+)\s*%\s*mensual", ft)
    out["tasa_interes"] = parse_decimal(m.group(1)) if m else None

    m = _search(r"en\s*(\d{1,3})\s*cuotas", ft)
    out["num_cuotas"] = int(m.group(1)) if m else None

    # MONTO_CUOTA — MP and RE phrasings.
    monto_cuota = None
    for pat in (rf"por la suma\s+de\s*\$\s*({_THOUSANDS})[\s.\-]*cada una",
                rf"cada una(?:\s+de ellas)?\s*por el monto\s+de\s*\$\s*({_THOUSANDS})",
                rf"por el monto\s+de\s*\$\s*({_THOUSANDS})"):
        m = _search(pat, ft)
        if m:
            monto_cuota = parse_monto(m.group(1))
            break
    out["monto_cuota"] = monto_cuota

    # MONTO_ULTIMA_CUOTA — only MP states a distinct last installment. When the
    # pagaré has no "salvo la última ..." clause (RE: all cuotas equal), the last
    # one equals the regular cuota.
    m = _search(rf"[uú]ltima(?:\s+\w+){{0,3}}?\s*(?:por la suma\s+de\s*)?\$\s*({_THOUSANDS})", ft)
    monto_ultima = parse_monto(m.group(1)) if m else None
    if monto_ultima is None and not _search(r"salvo la [uú]ltima|[uú]ltima que ser[áa]", ft):
        monto_ultima = monto_cuota
    out["monto_ultima_cuota"] = monto_ultima

    # "día" is optional (RE drops it).
    m = _search(r"primera cuota el\s*(?:d[ií]a\s*)?(\d{1,2})\s*de\s*([A-Za-zÁ-ú]+)\s*de\s*(\d{4})", ft)
    out["fecha_vcto_1ra_cuota"] = _date_es(*m.groups()) if m else None

    # "de cada mes" (MP) or "del (de los) mes" (RE).
    m = _search(r"d[ií]as?\s*(\d{1,2})\s*(?:de cada mes|del\b)", ft)
    out["dia_del_mes_vcto_cuota"] = int(m.group(1)) if m else None

    m = _search(r"[uú]ltima\s*(?:cuota\s*)?el\s*(?:d[ií]a\s*)?(\d{1,2})\s*de\s*([A-Za-zÁ-ú]+)\s*de\s*(\d{4})", ft)
    out["fecha_vcto_ultima_cuota"] = _date_es(*m.groups()) if m else None

    out["fecha_suscripcion_pagare"] = extract_fecha_suscripcion(text)
    dom, com = extract_domicilio_comuna(text)
    out["domicilio_deudor"] = dom
    out["comuna_deudor"] = com
    return out


def extract_fecha_suscripcion(text: str) -> Optional[str]:
    """'En Santiago, a 27 de mayo de 2025' -> 27-05-2025."""
    m = _search(r"\bEn\s+[A-Za-zÁ-ú]+\s*,?\s*a\s*(\d{1,2})\s*de\s*([A-Za-zÁ-ú]+)\s*de\s*(\d{4})", _flat(text))
    return _date_es(*m.groups()) if m else None


def extract_pagare_simple(text: str) -> dict:
    """TC / LP pagaré: principal, suscripción, domicilio, comuna."""
    dom, com = extract_domicilio_comuna(text)
    return {
        "monto_pagare": extract_monto_pagare(text),
        "fecha_suscripcion_pagare": extract_fecha_suscripcion(text),
        "domicilio_deudor": dom,
        "comuna_deudor": com,
    }


def extract_operacion(text: str) -> Optional[str]:
    """The pagaré's own operation number, printed in its header
    ('N* OPERACION: 60620632'). Returned as a digits-only string, or None.

    Used to pair the right pagaré file to the right matriz row when one RUT
    carries several pagarés of the same type. The header 'OPERACION' is the first
    on the page, so the first match wins; folded text absorbs the accent in
    'OPERACIÓN' and any 'N°/Nº/N*' label noise between the word and the number."""
    m = _search(r"OPERACION[^\d]{0,8}(\d{5,})", _fold(_flat(text)))
    return m.group(1) if m else None


# --------------------------------------------------------------------------
# Informe de deuda (rotated upright by the OCR layer before it reaches here)
# --------------------------------------------------------------------------
def extract_informe(text: str, operacion: Optional[str] = None) -> dict:
    """Extract from the section of the operation that matches the pagaré.

    An informe can list several operations (renegociaciones, castigos), each with
    its own cuota table and a 'Resumen ... Capital : X,00'. The human uses the
    Capital / first-impaga of the operation that matches the pagaré's OPERACIÓN —
    NOT the first section, nor the combined 'Resumen Deuda Directa del Cliente'.
    So we scope the search to the text after that operation's header when the
    operation number is known."""
    out: dict = {"monto_adeudado": None, "nro_1ra_cuota_imp": None,
                 "fecha_1ra_cuota_imp": None, "otorgamiento": None}

    text = _flat(text)
    scope = text
    if operacion:
        op_digits = re.sub(r"\D", "", str(operacion))
        if len(op_digits) >= 5:
            # The informe writes it zero-padded ("MP 000060535035"); a substring
            # search finds the matching section header.
            m_op = re.search(re.escape(op_digits), text)
            if m_op:
                scope = text[m_op.end():]

    # "Capital ... <total>,00". [^\n]{0,8}? lazily absorbs ": " / " 5 " OCR noise
    # (including a stray noise digit). The column header "Capital Interes ..." has
    # no amount within reach, so it is skipped.
    m = _search(rf"Capital\b[^\n]{{0,8}}?({_THOUSANDS}),\d{{2}}", scope)
    if m:
        out["monto_adeudado"] = parse_monto(m.group(1))

    # First installment row of the impagas table. Anchored on the date so OCR
    # noise between "Cuota" and the real number is skipped: the row OCRs as
    # "Cuota = 25- 2/JAN/2026" (a dash glued to the number) or "Cuota 3 18 2/JAN"
    # (a noise digit before the real cuota). [^/]{0,15}? lazily eats the noise;
    # the cuota number is the one immediately before the day/MON/year.
    # A separator (space/dash) between the cuota number and the day is REQUIRED
    # so "24/DEC" (where OCR lost the cuota number, e.g. read "1" as "al") is not
    # mis-split into cuota=2 / day=4.
    m = _search(r"Cuota\b[^/]{0,15}?(\d{1,3})[-—\s]+(\d{1,2})\s*/\s*([A-Za-z0]{3})\s*/\s*(\d{4})", scope)
    if m:
        out["nro_1ra_cuota_imp"] = int(m.group(1))
        out["fecha_1ra_cuota_imp"] = _date_en(m.group(2), m.group(3), m.group(4))

    # Loan grant date — used as the FECHA_SUSCRIPCION fallback for RE pagarés,
    # which don't carry an "En <ciudad>, a <día> de <mes>" line.
    m = _search(r"Otorgamiento\b[^\d]{0,4}(\d{1,2})\s*/\s*([A-Za-z0]{3})\s*/\s*(\d{4})", scope)
    if m:
        out["otorgamiento"] = _date_en(m.group(1), m.group(2), m.group(3))
    return out


# --------------------------------------------------------------------------
# Hoja de firma
# --------------------------------------------------------------------------
def extract_cod_contrato(text: str) -> Optional[int]:
    """'Repertorio N* 4.005-2022' -> 4005 (the number before the year)."""
    # OCR renders this inconsistently: "Repertorio N* 4.005-2022",
    # "epertorio N” 48203 / 2017" (R dropped, "/" separator, curly quote), etc.
    # So make the leading R optional and tolerate any marker junk + separator.
    text = _flat(text)
    m = _search(r"R?epertorio\s*N?[°ºo”\"*?.\s]*([\d][\d.]*?)\s*[-—/]\s*\d{4}", text)
    if not m:
        m = _search(r"R?epertorio\s*N?[°ºo”\"*?.\s]*([\d][\d.]*)", text)
    if not m:
        return None
    digits = re.sub(r"\D", "", m.group(1))
    return int(digits) if digits else None
