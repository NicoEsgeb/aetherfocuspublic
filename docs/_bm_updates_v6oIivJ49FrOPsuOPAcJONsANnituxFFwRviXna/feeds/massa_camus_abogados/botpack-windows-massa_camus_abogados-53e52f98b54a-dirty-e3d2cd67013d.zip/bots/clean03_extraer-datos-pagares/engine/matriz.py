"""
clean03 — matriz read / write
=============================
Reads the human-prepared input matriz (only the seed columns RUT, DV, NOMBRE,
OPERACIÓN, CARTERA, MORA are taken from it) and writes the final output matriz
in the layout the human produces by hand:

    RUT, DV, NOMBRE, OPERACIÓN, CARTERA_ORIGINAL, CARTERA_A_PROCESAR, MORA,
    MONTO_PAGARE, MONTO_ADEUDADO,
    TASA_INTERES, NUM_CUOTAS, MONTO_CUOTA, MONTO_ULTIMA_CUOTA,
    PAGARE_ULTIMA_CUOTA_INFERIOR, FECHA_VCTO_1RA_CUOTA, DIA_DEL_MES_VCTO_CUOTA,
    FECHA_VCTO_ULTIMA_CUOTA,
    FECHA_SUSCRIPCION_PAGARE, FECHA_VCTO_PAGARE, NRO_1RA_CUOTA_IMP,
    FECHA_1RA_CUOTA_IMP, DOMICILIO_DEUDOR, COMUNA_DEUDOR, REGION_DEUDOR,
    PAGARE_FIRMADO_CLIENTE, CONTRATO_MANDATO_FIRMADO_CLIENTE, HOJA_DE_FIRMA,
    COD_CONTRATO, NOTARIO, FECHA_PROTOCOLI, NOTA, COD_FORM_DDA

The input file is never modified — a brand new workbook is written.

Cell colours:
  * green  (#92D050) — normal filled cell (matches the human's "done" look)
  * red    (#FF0000) — header of a column the human fills in later, and an
                       entire row whose pagaré was expected but not found
  * yellow (#FFFF00) — a cell flagged NO_ENCONTRADO, and an entire row for an
                       EXTRA pagaré found that the matriz did not list
  * orange (#FFA500) — a cell flagged REVISAR (value kept but needs a human
                       check) — kept distinct from yellow so the two don't blur
  * purple (#CC99FF) — CARTERA_A_PROCESAR cell whose value is RE: the bot mirrors
                       the RE (does NOT auto-resolve it) and colours it so the
                       human changes it to MP or VI by hand (clean04 reads this col)
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

import openpyxl
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

# (header text, internal field key) in output column order A..AD
COLUMNS: list[tuple[str, str]] = [
    ("RUT", "rut"),
    ("DV", "dv"),
    ("NOMBRE", "nombre"),
    ("OPERACIÓN", "operacion"),
    ("CARTERA_ORIGINAL", "cartera"),
    ("CARTERA_A_PROCESAR", "cartera_a_procesar"),
    ("MORA", "mora"),
    ("MONTO_PAGARE", "monto_pagare"),
    ("MONTO_ADEUDADO", "monto_adeudado"),
    ("TASA_INTERES", "tasa_interes"),
    ("NUM_CUOTAS", "num_cuotas"),
    ("MONTO_CUOTA", "monto_cuota"),
    ("MONTO_ULTIMA_CUOTA", "monto_ultima_cuota"),
    ("PAGARE_ULTIMA_CUOTA_INFERIOR", "pagare_ultima_cuota_inferior"),
    ("FECHA_VCTO_1RA_CUOTA", "fecha_vcto_1ra_cuota"),
    ("DIA_DEL_MES_VCTO_CUOTA", "dia_del_mes_vcto_cuota"),
    ("FECHA_VCTO_ULTIMA_CUOTA", "fecha_vcto_ultima_cuota"),
    ("FECHA_SUSCRIPCION_PAGARE", "fecha_suscripcion_pagare"),
    ("FECHA_VCTO_PAGARE", "fecha_vcto_pagare"),
    ("NRO_1RA_CUOTA_IMP", "nro_1ra_cuota_imp"),
    ("FECHA_1RA_CUOTA_IMP", "fecha_1ra_cuota_imp"),
    ("DOMICILIO_DEUDOR", "domicilio_deudor"),
    ("COMUNA_DEUDOR", "comuna_deudor"),
    ("REGION_DEUDOR", "region_deudor"),
    ("PAGARE_FIRMADO_CLIENTE", "pagare_firmado_cliente"),
    ("CONTRATO_MANDATO_FIRMADO_CLIENTE", "contrato_mandato_firmado_cliente"),
    ("HOJA_DE_FIRMA", "hoja_de_firma"),
    ("COD_CONTRATO", "cod_contrato"),
    ("NOTARIO", "notario"),
    ("FECHA_PROTOCOLI", "fecha_protocoli"),
    ("NOTA", "nota"),
    ("COD_FORM_DDA", "cod_form_dda"),
]

# Columns the human fills in later — header + column painted soft cyan, blank.
FILL_LATER = {"region_deudor", "pagare_firmado_cliente",
              "contrato_mandato_firmado_cliente", "notario",
              "fecha_protocoli", "nota", "cod_form_dda"}

# Human-filled columns that get an Excel SI/NO dropdown (data validation),
# so the human picks from a list instead of typing free text.
_DROPDOWN_SI_NO = {"pagare_firmado_cliente", "contrato_mandato_firmado_cliente"}

GREEN = "FF92D050"    # data extracted OK
RED = "FFFF0000"      # whole row: expected pagaré missing in the RUT folder
YELLOW = "FFFFFF00"   # cell flagged NO_ENCONTRADO; or whole extra row
ORANGE = "FFFFA500"   # cell flagged REVISAR (value kept, needs manual check)
BLUE = "FF5B9BD5"     # whole row: RUT seed not found in the input folders
CYAN = "FFB7E4F0"     # "fill-later" columns (manual) — header + whole column
CREAM = "FFF5E6C8"    # column headers with bot-extracted data
PURPLE = "FFCC99FF"   # CARTERA_A_PROCESAR = RE: human changes it to MP or VI

_FILL_GREEN = PatternFill("solid", fgColor=GREEN)
_FILL_RED = PatternFill("solid", fgColor=RED)
_FILL_YELLOW = PatternFill("solid", fgColor=YELLOW)
_FILL_ORANGE = PatternFill("solid", fgColor=ORANGE)
_FILL_BLUE = PatternFill("solid", fgColor=BLUE)
_FILL_CYAN = PatternFill("solid", fgColor=CYAN)
_FILL_CREAM = PatternFill("solid", fgColor=CREAM)
_FILL_PURPLE = PatternFill("solid", fgColor=PURPLE)

# Grid borders: a thin line around every cell so the divisions are clearly
# visible on top of the fills, and a thicker line around the header row.
_SIDE_THIN = Side(style="thin", color="FF808080")
_SIDE_HEADER = Side(style="medium", color="FF404040")
_BORDER_DATA = Border(left=_SIDE_THIN, right=_SIDE_THIN, top=_SIDE_THIN, bottom=_SIDE_THIN)
_BORDER_HEADER = Border(left=_SIDE_HEADER, right=_SIDE_HEADER,
                        top=_SIDE_HEADER, bottom=_SIDE_HEADER)


# --------------------------------------------------------------------------
# Read
# --------------------------------------------------------------------------
def rut_digits(value: Any) -> str:
    """'7.512.305-1' / '7512305' / 7512305 -> '7512305' (digits only, no DV)."""
    s = re.sub(r"\D", "", str(value or ""))
    return s


def read_input_matriz(path: str | Path) -> list[dict]:
    """Return the seed rows from the input matriz, in order. Each row dict has
    rut/dv/nombre/operacion/cartera/mora plus `rut_key` (digits only) and
    `source_row` (1-based row index in the input)."""
    path = Path(path)
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb.active
    rows: list[dict] = []
    for r, values in enumerate(ws.iter_rows(values_only=True), start=1):
        if r == 1:
            continue  # header
        cells = list(values) + [None] * 6
        rut_raw, dv, nombre, operacion, cartera, mora = cells[:6]
        if rut_raw in (None, "") and (cartera in (None, "")):
            continue  # blank row
        key = rut_digits(rut_raw)
        if not key:
            continue
        rows.append({
            "rut_key": key,
            "rut": int(key),
            "dv": str(dv).strip() if dv not in (None, "") else "",
            "nombre": str(nombre).strip() if nombre not in (None, "") else "",
            "operacion": str(operacion).strip() if operacion not in (None, "") else "",
            "cartera": str(cartera).strip().upper() if cartera not in (None, "") else "",
            "mora": _as_int(mora),
            "source_row": r,
        })
    wb.close()
    return rows


def _as_int(value: Any) -> Optional[int]:
    if value in (None, ""):
        return None
    try:
        return int(float(str(value).replace(".", "").replace(",", ".")))
    except (ValueError, TypeError):
        return None


# --------------------------------------------------------------------------
# Write
# --------------------------------------------------------------------------
def write_output_matriz(path: str | Path, rows: list[dict]) -> None:
    """Write the final styled matriz + a colour-legend sheet. Each row dict:
      values: {field_key: value}
      cell_flags: {field_key: "NO_ENCONTRADO" | "REVISAR"}
      row_flag: None | "MISSING" | "EXTRA" | "NO_FOLDER"
    """
    path = Path(path)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Asignacion"

    header_font = Font(bold=True, color="FF000000")
    # Header row: cream for extracted columns, soft cyan for the manual ones.
    for col_idx, (header, key) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = _FILL_CYAN if key in FILL_LATER else _FILL_CREAM
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _BORDER_HEADER

    # Data rows
    for out_r, row in enumerate(rows, start=2):
        values = row.get("values", {})
        cell_flags = row.get("cell_flags", {})
        row_flag = row.get("row_flag")

        for col_idx, (_, key) in enumerate(COLUMNS, start=1):
            flag = cell_flags.get(key)
            # NO_ENCONTRADO replaces the (missing) value with the marker text;
            # REVISAR keeps the extracted value and adds an orange + comment so the
            # number is still usable but flagged for a human check.
            if flag == "NO_ENCONTRADO":
                value: Any = "NO_ENCONTRADO"
            else:
                value = values.get(key)
            cell = ws.cell(row=out_r, column=col_idx, value=value)

            # Fill precedence: the "fill-later" columns are ALWAYS soft cyan —
            # the whole column, top to bottom — so they read as "complete this
            # manually" regardless of the row's status. Everything else follows
            # the row flag, then the cell flag, then normal green.
            if key in FILL_LATER:
                cell.fill = _FILL_CYAN
            elif row_flag == "MISSING":
                cell.fill = _FILL_RED
            elif row_flag == "NO_FOLDER":
                cell.fill = _FILL_BLUE
            elif row_flag == "EXTRA":
                cell.fill = _FILL_YELLOW
            elif key == "cartera_a_procesar" and str(value).strip().upper() == "RE":
                # RE (renegociación) is NOT auto-resolved: clean04 can't tell from
                # the cartera alone whether it goes to Plantilla A or "a la Vista".
                # Mirror the RE and colour it so the human sets MP or VI by hand —
                # this is the column clean04 reads to pick the template.
                cell.fill = _FILL_PURPLE
                cell.comment = Comment(
                    "RE (renegociación): cambiar a mano a MP o VI. clean04 elige "
                    "la plantilla con esta columna (CARTERA_A_PROCESAR).", "clean03")
            elif flag == "REVISAR":
                cell.fill = _FILL_ORANGE
                cell.comment = Comment(
                    "REVISAR: pagaré con formato simple (tipo TC) y Hoja de "
                    "Firma presente. MONTO_ADEUDADO se tomó = MONTO_PAGARE; "
                    "verificar manualmente.", "clean03")
            elif flag:
                cell.fill = _FILL_YELLOW
            else:
                cell.fill = _FILL_GREEN
            cell.border = _BORDER_DATA

    _add_si_no_dropdowns(ws, len(rows))
    _autosize(ws)
    _write_legend_sheet(wb)
    wb.save(path)


def _add_si_no_dropdowns(ws, n_rows: int) -> None:
    """Attach an Excel SI/NO dropdown (data validation) to the manual SI/NO
    columns, over their data cells. The human picks from the list instead of
    typing; blank is allowed until they fill it in."""
    if n_rows < 1:
        return
    last_row = n_rows + 1  # row 1 is the header
    for col_idx, (_, key) in enumerate(COLUMNS, start=1):
        if key not in _DROPDOWN_SI_NO:
            continue
        col = openpyxl.utils.get_column_letter(col_idx)
        dv = DataValidation(type="list", formula1='"SI,NO"', allow_blank=True)
        dv.prompt = "Seleccione SI o NO"
        dv.promptTitle = "SI / NO"
        ws.add_data_validation(dv)
        dv.add(f"{col}2:{col}{last_row}")


def _write_legend_sheet(wb) -> None:
    """Second sheet explaining what each colour / marker means (in Spanish)."""
    ws = wb.create_sheet("Explicacion Colores")
    title = ws.cell(row=1, column=1, value="Explicación de colores — Matriz de Asignación")
    title.font = Font(bold=True, size=13, color="FF000000")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=3)

    hf = Font(bold=True, color="FF000000")
    for col, text in ((1, "Color / Marca"), (2, "Significado")):
        c = ws.cell(row=3, column=col, value=text)
        c.font = hf
        c.fill = _FILL_CREAM
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = _BORDER_HEADER

    # (swatch label, swatch fill, explanation)
    legend = [
        ("Verde", _FILL_GREEN,
         "Dato extraído y procesado correctamente por el bot."),
        ("NO_ENCONTRADO (amarillo)", _FILL_YELLOW,
         "El bot no pudo leer/encontrar el dato en el documento (o falta el "
         "archivo). Revisar y completar manualmente."),
        ("REVISAR (naranja con dato)", _FILL_ORANGE,
         "Pagaré MP/RE en formato simple (tipo TC) con Hoja de Firma. Se asumió "
         "MONTO_ADEUDADO = MONTO_PAGARE; verificar el monto adeudado manualmente."),
        ("Azul (fila completa)", _FILL_BLUE,
         "El RUT de esta fila no se encontró en la carpeta de entrada "
         "(input/ruts). Fila NO procesada — falta la carpeta de ese RUT."),
        ("Rojo (fila completa)", _FILL_RED,
         "Se encontró la carpeta del RUT pero faltó el pagaré esperado de esa "
         "fila. Fila NO procesada — revisar la carpeta del RUT."),
        ("Cian (columnas manuales)", _FILL_CYAN,
         "Columnas que se completan manualmente más adelante (REGION_DEUDOR, "
         "PAGARE_FIRMADO_CLIENTE, CONTRATO_MANDATO_FIRMADO_CLIENTE, NOTARIO, "
         "FECHA_PROTOCOLI, NOTA, COD_FORM_DDA): llenar datos manualmente. "
         "PAGARE_FIRMADO_CLIENTE y CONTRATO_MANDATO_FIRMADO_CLIENTE tienen lista SI/NO."),
        ("Crema (encabezados)", _FILL_CREAM,
         "Encabezados de las columnas que el bot completa con datos extraídos."),
        ("Morado (CARTERA_A_PROCESAR = RE)", _FILL_PURPLE,
         "La cartera es RE (renegociación). El bot la copia tal cual en "
         "CARTERA_A_PROCESAR pero NO decide la plantilla: cambiar esta celda a "
         "mano a MP o VI según el pagaré (es la columna que usa clean04)."),
    ]
    for i, (label, fill, meaning) in enumerate(legend, start=4):
        sw = ws.cell(row=i, column=1, value=label)
        sw.fill = fill
        sw.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sw.font = Font(bold=True, color="FF000000")
        sw.border = _BORDER_DATA
        mc = ws.cell(row=i, column=2, value=meaning)
        mc.alignment = Alignment(vertical="center", wrap_text=True)
        mc.border = _BORDER_DATA

    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 90
    for r in range(4, 4 + len(legend)):
        ws.row_dimensions[r].height = 34


def _autosize(ws) -> None:
    widths = {
        "rut": 11, "dv": 5, "nombre": 34, "operacion": 18, "cartera": 16,
        "cartera_a_procesar": 18, "mora": 7,
        "monto_pagare": 14, "monto_adeudado": 15, "tasa_interes": 12, "num_cuotas": 11,
        "monto_cuota": 13, "monto_ultima_cuota": 16,
        "pagare_ultima_cuota_inferior": 16, "fecha_vcto_1ra_cuota": 18,
        "dia_del_mes_vcto_cuota": 18, "fecha_vcto_ultima_cuota": 18,
        "fecha_suscripcion_pagare": 18, "fecha_vcto_pagare": 16, "nro_1ra_cuota_imp": 15,
        "fecha_1ra_cuota_imp": 16, "domicilio_deudor": 40, "comuna_deudor": 18,
        "region_deudor": 14, "pagare_firmado_cliente": 22,
        "contrato_mandato_firmado_cliente": 30,
        "hoja_de_firma": 12, "cod_contrato": 12, "notario": 14,
        "fecha_protocoli": 14, "nota": 14, "cod_form_dda": 14,
    }
    for col_idx, (_, key) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = widths.get(key, 14)
