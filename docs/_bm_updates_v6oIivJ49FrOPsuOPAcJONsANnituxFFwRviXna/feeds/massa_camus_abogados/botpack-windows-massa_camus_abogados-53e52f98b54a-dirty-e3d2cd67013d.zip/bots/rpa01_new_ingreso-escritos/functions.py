from RPA.Excel.Files import Files as Excel
from robocorp import browser
from robocorp import windows
import json
import shutil
import time
from pathlib import Path


class EscritoFileNotFound(Exception):
    """
    Raised when the PDF for a row is missing from the escritos folder.

    Checked BEFORE any portal interaction so the row can be flagged REVISAR and
    the batch can continue — critically, it prevents the native Windows "Abrir"
    file dialog from opening on a non-existent file, which otherwise stays open
    and jams every subsequent row.
    """

    def __init__(self, filename: str, path: str):
        self.filename = filename
        self.path = path
        super().__init__(f"Archivo no encontrado: {filename}")


def _mark_missing_file_cells(xlsx_path, col_index, revisar_rows, sheet="Hoja1"):
    """
    Paint each missing-file PREINGRESO cell yellow and attach a hover comment.

    Uses openpyxl directly (RPA.Excel.Files cannot set fills/comments) and is
    best-effort: a styling failure must never fail the run.
    """
    if not revisar_rows:
        return
    try:
        from openpyxl import load_workbook
        from openpyxl.comments import Comment
        from openpyxl.styles import PatternFill

        yellow = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")
        wb = load_workbook(xlsx_path)
        ws = wb[sheet] if sheet in wb.sheetnames else wb.active
        for row_number, filename in revisar_rows:
            cell = ws.cell(row=row_number, column=col_index)
            cell.fill = yellow
            note = (
                "No se encontró el archivo PDF de este escrito:\n"
                f"«{filename}»\n"
                "en la carpeta input/escritos.\n\n"
                "Verifique que el archivo exista y tenga exactamente ese "
                "nombre, luego vuelva a procesar la planilla."
            )
            comment = Comment(note, "RPA01")
            comment.width = 320
            comment.height = 160
            cell.comment = comment
        wb.save(xlsx_path)
    except Exception as exc:
        print(f"[RPA01][PREINGRESO][WARN] No se pudo aplicar estilo REVISAR a {xlsx_path}: {exc}")


def _select_causa_year(page, year: str):
    year_text = str(year).strip()
    if not year_text:
        raise ValueError("Ano vacio para consulta de causa.")

    year_container = page.locator("div.select2-container.pg-select2-year-control").first
    year_container.wait_for()
    selected_year = year_container.locator(".select2-chosen").first

    # Always re-select the year from the dropdown, even when the visible value
    # already matches (e.g. the default 2026). Skipping the selection leaves the
    # form's year/Rol state uncommitted, so "Consulta Rol" does nothing and the
    # bot stalls until the button is clicked manually.
    year_container.locator("a.select2-choice").click()
    dropdown = page.locator("div.select2-drop-active.pg-select2-year-dropdown").first
    dropdown.wait_for(state="visible")

    search_input = dropdown.locator("input.select2-input").first
    search_input.fill("")
    search_input.type(year_text)

    dropdown.locator(".select2-result-label", has_text=year_text).first.click()
    time.sleep(0.5)

    final_year = selected_year.inner_text().strip()
    if final_year != year_text:
        raise RuntimeError(f"No se pudo seleccionar el ano '{year_text}'. Quedo '{final_year}'.")

def read_excel_preingreso(path: str, escritos_DCP_Path: str, ingreso_output_dir: str, documentos_firmados: bool = False):
    """
    open and read an excel file for preingreso.
    Writes OK/ERROR to the source (for re-runability) and to a copy in the output dir.
    """
    print('Preingreso')
    source_excel = Excel()
    run_excel = Excel()

    source_path = Path(path)
    output_copy_name = "output_" + source_path.name
    output_copy_path = str(Path(ingreso_output_dir) / output_copy_name)
    shutil.copy2(str(source_path), output_copy_path)
    print(f"[PREINGRESO] Planilla origen: {source_path}")
    print(f"[PREINGRESO] Planilla salida: {output_copy_path}")

    source_excel.open_workbook(str(source_path))
    rows = source_excel.read_worksheet_as_table("Hoja1", header=True)
    preingresoIndex = 1
    if not rows.columns.__contains__("PREINGRESO"):
        source_excel.insert_columns_before(1, 1)
        source_excel.set_cell_value(1, 1, "PREINGRESO")
        source_excel.save_workbook(str(source_path))
    else:
        preingresoIndex = rows.columns.index("PREINGRESO") + 1

    run_excel.open_workbook(output_copy_path)
    run_rows = run_excel.read_worksheet_as_table("Hoja1", header=True)
    run_preingresoIndex = 1
    if not run_rows.columns.__contains__("PREINGRESO"):
        run_excel.insert_columns_before(1, 1)
        run_excel.set_cell_value(1, 1, "PREINGRESO")
        run_excel.save_workbook(output_copy_path)
    else:
        run_preingresoIndex = run_rows.columns.index("PREINGRESO") + 1

    # Clear previous values in the run copy so it reflects only this run
    run_rows = run_excel.read_worksheet_as_table("Hoja1", header=True)
    for i, _ in enumerate(run_rows):
        run_excel.set_cell_value(i + 2, run_preingresoIndex, "")
    run_excel.save_workbook(output_copy_path)

    rows = source_excel.read_worksheet_as_table("Hoja1", header=True)
    numero = 2
    print(preingresoIndex)
    processed_count = 0
    ok_count = 0
    error_count = 0
    revisar_count = 0
    revisar_cells = []  # (rowNumber, filename) → painted yellow + hover comment after save
    summary_rows = []
    for row in rows:
        if str(row["PREINGRESO"]) != 'OK':
            processed_count += 1
            try:
                fill_form_escritos(row, escritos_DCP_Path, documentos_firmados)
                source_excel.set_cell_value(numero, preingresoIndex, "OK")
                run_excel.set_cell_value(numero, run_preingresoIndex, "OK")
                ok_count += 1
                summary_rows.append({"ok": True, "rol": str(row.get("ROL", "") or ""), "preingreso": "OK", "rowNumber": numero})
                print(row["ROL"])
            except EscritoFileNotFound as e:
                # Missing input PDF — flag REVISAR (not ERROR) and keep going.
                # No portal interaction happened, so no browser reset is needed.
                print(f"[RPA01][PREINGRESO][REVISAR] fila={numero} rol={row.get('ROL', '')} archivo_no_encontrado={e.filename}")
                source_excel.set_cell_value(numero, preingresoIndex, "REVISAR")
                run_excel.set_cell_value(numero, run_preingresoIndex, "REVISAR")
                revisar_count += 1
                revisar_cells.append((numero, e.filename))
                summary_rows.append({"ok": False, "rol": str(row.get("ROL", "") or ""), "preingreso": "REVISAR", "archivo": e.filename, "rowNumber": numero})
            except Exception as e:
                print(f"[RPA01][PREINGRESO][ERROR] fila={numero} rol={row.get('ROL', '')} error={e}")
                source_excel.set_cell_value(numero, preingresoIndex, "ERROR")
                run_excel.set_cell_value(numero, run_preingresoIndex, "ERROR")
                error_count += 1
                summary_rows.append({"ok": False, "rol": str(row.get("ROL", "") or ""), "preingreso": "ERROR", "rowNumber": numero})
                browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")

        source_excel.save_workbook(str(source_path))
        run_excel.save_workbook(output_copy_path)
        numero = numero + 1

    source_excel.save_workbook(str(source_path))
    run_excel.save_workbook(output_copy_path)
    source_excel.close_workbook()
    run_excel.close_workbook()

    # Paint REVISAR cells yellow + attach the "archivo no encontrado" hover
    # comment. Done after the RPA workbooks are closed so the files aren't locked.
    _mark_missing_file_cells(str(source_path), preingresoIndex, revisar_cells)
    _mark_missing_file_cells(output_copy_path, run_preingresoIndex, revisar_cells)

    summary_path = Path(ingreso_output_dir) / "ingreso_escritos_summary.json"
    summary_path.write_text(
        json.dumps({"rows": summary_rows, "processed": processed_count, "ok": ok_count, "error": error_count, "revisar": revisar_count}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"[RPA01][SUMMARY_JSON] {summary_path}")
    print(f"Done Ingreso Escritos | procesadas={processed_count} ok={ok_count} error={error_count} revisar={revisar_count}")
    print('Done Preingreso')

def fill_form_escritos(row, escritos_DCP_Path: str, documentos_firmados: bool = False):

    # Build the target PDF path from row data (no page state needed) and verify
    # it exists BEFORE touching the portal. A missing file is raised immediately
    # so the row is flagged REVISAR and the batch continues — this is what keeps
    # the native "Abrir" dialog from opening on a non-existent file and jamming
    # every subsequent row. It also avoids creating an orphan draft escrito
    # (Grabar Escrito is only clicked further down, for files that exist).
    format_rut = int(row["RUT"])
    format_rut = f"{format_rut:,}".replace(",", ".")
    ruta_escrito_operacion = escritos_DCP_Path + "\\Trib_" + str(row["TRIBUNAL"])[:-1] + "°_ROL_" + str(row["ROL"]) + "_"
    ruta_escrito_operacion += format_rut + "-" + str(row["DV"])
    if documentos_firmados:
        ruta_escrito_operacion += "_firmado"
    ruta_escrito_operacion += ".pdf"
    if not Path(ruta_escrito_operacion).exists():
        raise EscritoFileNotFound(Path(ruta_escrito_operacion).name, ruta_escrito_operacion)

    page = browser.page()
    page.get_by_text("Ingresar Escrito").click()

    time.sleep(1)

    page.get_by_text("Competencia").wait_for()
    page.get_by_text("Competencia").click()
    page.press("body", "Tab")
    page.keyboard.type("Civil") 
    page.press("body", "Tab")

    page.locator("label").filter(has_text="Fijar Datos").locator("path").nth(1).click()

    page.locator("xpath=//label[contains(.,'Tipo')]").wait_for()
    page.locator("xpath=//label[contains(.,'Tipo')]").click()
    page.press("body", "Tab")
    page.locator("xpath=//select[contains(@data-bind,'tiposCausas')]").select_option("option", label="C")
    time.sleep(2)
    page.locator("xpath=//label[contains(.,'Tribunal')]").wait_for()
    page.locator("xpath=//label[contains(.,'Tribunal')]").click()
    page.press("body", "Tab") 
    page.press("body", "ArrowDown") 

    tribunal = str(row["TRIBUNAL"])
    num_tribunal = tribunal[0:len(tribunal)-1]
    tribunal = str(num_tribunal).strip() + "º juzgado civil de santiago"
    page.keyboard.type(tribunal) 
    time.sleep(2)    
    
    if int(num_tribunal) == 2:
        page.press("body", "ArrowDown")
    elif int(num_tribunal) > 2 and int(num_tribunal) < 10:
        page.press("body", "ArrowDown")
        page.press("body", "ArrowDown")
    
    time.sleep(1) 
    page.press("body", "Tab") 

    rol = str(row["ROL"])
    
    page.locator("xpath=//label[contains(.,'Rol')]/../input").fill(rol.split('-')[0])
    ano = rol.split('-')[1]
    _select_causa_year(page, ano)
    print(f"[RPA01][CONSULTA_ROL] rol={rol.split('-')[0]} ano={ano}")

    time.sleep(1)
    page.locator("xpath=//button[contains(.,' Consulta Rol')]").click()        

    page.locator("xpath=//label[contains(.,'Caratulado')]").wait_for()
    page.locator("xpath=//label[contains(.,'Caratulado')]").click()

    page.press("body", "Tab")
    time.sleep(2)
    """ Selecciono el cuaderno"""
    page.press("body", "ArrowDown")
    page.press("body", "Tab")

    time.sleep(2)

    page.keyboard.type("joa") 
    
    page.press("body", "Tab")
    page.press("body", "Tab")
    page.press("body", "Tab")
    
    time.sleep(2)
    
    page.keyboard.type("gen")
     
    time.sleep(2)
     
    page.press("body", "Tab")
    
    time.sleep(2)

    page.keyboard.type("da cuenta de pag") 
    
    page.press("body", "Tab") 
  
    page.locator("xpath=//button[contains(.,' Grabar Escrito')]").click()

    time.sleep(1)

    page.get_by_text("Adjuntar Archivos").wait_for();
    page.get_by_text("Adjuntar Archivos").click()
    page.locator("#dDPrincipal").get_by_role("button", name="Adjuntar").click()
    app = windows.find_window('regex:.*Oficina Judicial Virtual - Portal*')
    # ruta_escrito_operacion was already built and existence-checked at the top.
    app.find('class:"Edit" and name:"Nombre:"').set_value(ruta_escrito_operacion)

    app.find('class:"Button" and name:"Abrir"').click()
    time.sleep(3)
    
    page.get_by_text("Escrito", exact=True).wait_for()
    page.get_by_text("Escrito", exact=True).click()
    page.get_by_role("button", name="Cerrar y Continuar").click()
    
    page.get_by_text("Trámite Fácil").click()


def read_excel_envio(path: str):
    """
    open and read an excel file for envio

    """
    print('Envio')
    excel = Excel()
    excel.open_workbook(path)
    rows = excel.read_worksheet_as_table("Hoja1", header=True)
    numero = 2;
    envioIndex = 1;
    if not rows.columns.__contains__("ENVIO") :
        excel.insert_columns_before(1,1)
        #envioIndex = rows._add_column("ENVIO")        
        excel.set_cell_value(1,1,"ENVIO")
        excel.save_workbook()
    else :
        envioIndex = rows.columns.index("ENVIO") + 1
    
    rows = excel.read_worksheet_as_table("Hoja1", header=True)
    print(envioIndex)
    for row in rows:
        if (str(row["ENVIO"]) != 'OK' and str(row["PREINGRESO"]) == 'OK') :
            try :
                fill_form_envio(row)
                excel.set_cell_value(numero,envioIndex,"OK")
                print(row["ROL"])
            except :
                excel.set_cell_value(numero,envioIndex,"ERROR")
                browser.goto("https://ojv.pjud.cl/kpitec-ojv-web/index#facil/tramite")
                pass
            
        excel.save_workbook()
        numero = numero + 1
   
    excel.save_workbook(path)
    excel.close_workbook()
    print('Done Envio')

def fill_form_envio(row):

    page = browser.page()
    page.get_by_text("Bandeja Escrito").click()
    
    time.sleep(2)

    page.locator("xpath=//label[contains(.,'Competencia:')]").wait_for()
    page.locator("xpath=//label[contains(.,'Competencia:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("Civil") 
    page.press("body", "Tab")
    time.sleep(1)
    
    page.locator("xpath=//label[contains(.,'Tribunal Origen')]").wait_for()
    page.locator("xpath=//label[contains(.,'Tribunal Origen')]").click()
    page.press("body", "Tab") 
    page.press("body", "ArrowDown") 

    tribunal = str(row["TRIBUNAL"])
    num_tribunal = tribunal[0:len(tribunal)-1]
    tribunal = str(num_tribunal).strip() + "º juzgado civil de santiago"
    page.keyboard.type(tribunal) 
    time.sleep(1)
    
    if int(num_tribunal) == 2:
        page.press("body", "ArrowDown")
    elif int(num_tribunal) > 2 and int(num_tribunal) < 10:
        page.press("body", "ArrowDown")
        page.press("body", "ArrowDown")
    
    page.press("body", "Tab") 
        
    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Tab")
    time.sleep(1)
    page.press("body", "Space") 
    page.press("body", "Tab")
    page.keyboard.type("C") 
    page.press("body", "Tab")

    rol = str(row["ROL"])   
    page.keyboard.type(rol.split('-')[0])  
    page.press("body", "Tab")
    page.keyboard.type(rol.split('-')[1])  
    page.press("body", "Tab")

    page.get_by_role("button", name="Consultar Escritos").click()

    time.sleep(2)

    page.locator("xpath=//label[contains(.,'Seleccionar Todo')]").first.click()  
 
    page.locator("xpath=//button[contains(.,'Enviar Poder Judicial')]").click()
    time.sleep(1)
    page.locator("#modalConfirmarEnvioSinFirma").wait_for()
    page.locator("xpath=//div[@id='modalConfirmarEnvioSinFirma']/div/div/div[3]/div/div/div[2]/button").click()
    time.sleep(2)

    page.get_by_text("Mantenedor").click()

    """
    Este codigo a continuacion, elimina las operaciones segun el rol
    
    page.locator("xpath=//button[contains(.,'Eliminar Escritos')]").click()
    time.sleep(1)
    page.locator("#modalConfirmarEnvioSinFirma").wait_for()
    page.locator("xpath=//div[@id='modalConfirmarEnvioSinFirma']/div/div/div[2]/div/div/div[2]/button").click()

    page.get_by_text("Mantenedor").click()
    
    """
def compare_results() :
        
    page = browser.page()
    page.get_by_text("Bandeja Escrito").click()
    
    time.sleep(5)

    page.locator("xpath=//label[contains(.,'Competencia:')]").wait_for()
    page.locator("xpath=//label[contains(.,'Competencia:')]").click()
    page.press("body", "Tab")
    page.keyboard.type("Civil") 
    page.press("body", "Tab")

    page.locator("a:has-text('Escritos Enviados')").click()
    time.sleep(2)
    #page.press("body", "Tab")
    #page.press("body", "Enter")
    page.locator("xpath=//button[contains(.,'Exportar Excel')]").click()
    time.sleep(120)
