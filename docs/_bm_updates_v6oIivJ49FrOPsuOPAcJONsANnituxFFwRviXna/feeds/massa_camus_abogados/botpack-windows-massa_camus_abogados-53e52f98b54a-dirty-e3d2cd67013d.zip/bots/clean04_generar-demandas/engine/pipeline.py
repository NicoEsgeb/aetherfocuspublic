"""
clean04 — orchestration
========================
Reads the matriz → ensures the ESTADO column → groups rows by RUT → for each
RUT: skip if already OK, else validate; on OK render the demanda PDF and mark
the rows OK; on REVISAR paint the missing cells; on ERROR mark red. Finally
saves the annotated matriz in place. Never stops on a bad RUT; never emits an
incomplete demanda.

Design law: OK ⇔ the PDF for that RUT was successfully written. Nothing is
marked OK unless render_demanda returned a real file.
"""
from __future__ import annotations

from collections import OrderedDict
from pathlib import Path

from .matriz_io import Matriz, Row
from .demanda_builder import build_demanda, validate_rut, select_template
from .render import render_demanda_pdf
from .docx_render import render_demanda_docx


def _group_by_rut(rows: list[Row]) -> "OrderedDict[str, list[Row]]":
    groups: "OrderedDict[str, list[Row]]" = OrderedDict()
    for row in rows:
        groups.setdefault(row.rut_key, []).append(row)
    return groups


def generar_demandas(matriz_input_path: str, run_dir: str, *,
                     force_all: bool = False) -> dict:
    matriz = Matriz(matriz_input_path)
    groups = _group_by_rut(matriz.rows)

    # The annotated matriz is written as a COPY inside the run's output folder —
    # the original input matriz is never modified.
    out_matriz_path = Path(run_dir) / f"{matriz.path.stem}_ESTADO{matriz.path.suffix}"
    # Each valid RUT produces two deliverables: a filed-ready PDF and an editable
    # Word doc (the client tweaks wording in Word before filing). Kept in sibling
    # subfolders so both sets are easy to grab.
    pdf_dir = Path(run_dir) / "demandas_pdf"
    word_dir = Path(run_dir) / "demandas_word"

    summary = {
        "matriz_path": str(out_matriz_path),
        "matriz_original": str(matriz.path),
        "run_dir": str(run_dir),
        "ruts_total": len(groups),
        "ruts_ok": 0,
        "ruts_skipped": 0,
        "ruts_revisar": 0,
        "ruts_error": 0,
        "pdfs_generated": 0,
        # Pagaré-level counts (one matriz row = one pagaré).
        "filas_total": len(matriz.rows),
        "filas_ok": 0,
        "filas_revisar": 0,
        "filas_error": 0,
        "filas_skipped": 0,
    }

    def _mark_rut(rut_key: str, estado: str, n: int) -> None:
        """Structured per-RUT marker the Clean04Plugin parses into the run table."""
        print(f"[CLEAN04][RUT] rut={rut_key} estado={estado} pagares={n}")

    total = len(groups)
    for index, (rut_key, grp) in enumerate(groups.items(), start=1):
        print(f"[CLEAN04][PROGRESS] {index}/{total} RUT {rut_key}")
        n = len(grp)

        # Resume behaviour: skip a RUT only when every one of its rows already
        # reads OK (its PDF was written in a previous run). --force ignores this.
        if not force_all and all(r.estado == "OK" for r in grp):
            summary["ruts_skipped"] += 1
            summary["filas_skipped"] += n
            _mark_rut(rut_key, "OMITIDO", n)
            print(f"[CLEAN04]   {rut_key}: ya estaba OK — omitido (PDF previo).")
            continue

        result = validate_rut(grp)
        status = result["status"]

        if status == "OK":
            document = build_demanda(grp, result["templates"])
            try:
                pdf_path = render_demanda_pdf(document, pdf_dir)
                render_demanda_docx(document, word_dir)
            except Exception as exc:  # write failure (PDF or Word) → ERROR, keep going
                matriz.mark_error(grp, f"No se pudo escribir la demanda: {exc}")
                summary["ruts_error"] += 1
                summary["filas_error"] += n
                _mark_rut(rut_key, "ERROR", n)
                print(f"[CLEAN04]   {rut_key}: ERROR al escribir la demanda ({exc}).")
                continue
            matriz.mark_ok(grp)
            summary["ruts_ok"] += 1
            summary["filas_ok"] += n
            summary["pdfs_generated"] += 1
            _mark_rut(rut_key, "OK", n)
            tpls = "".join(sorted({result["templates"][r.excel_row] for r in grp}))
            print(f"[CLEAN04]   {rut_key}: OK [{tpls}] → {Path(pdf_path).name}")

        elif status == "REVISAR":
            matriz.mark_revisar(grp, result["missing_by_row"])
            summary["ruts_revisar"] += 1
            summary["filas_revisar"] += n
            _mark_rut(rut_key, "REVISAR", n)
            faltan = sorted({f for fields in result["missing_by_row"].values()
                             for f in fields})
            print(f"[CLEAN04]   {rut_key}: REVISAR — faltan {', '.join(faltan)}.")

        else:  # ERROR (unresolved RE, etc.)
            matriz.mark_error(grp, result["error_reason"], result["error_cells"])
            summary["ruts_error"] += 1
            summary["filas_error"] += n
            _mark_rut(rut_key, "ERROR", n)
            print(f"[CLEAN04]   {rut_key}: ERROR — {result['error_reason']}")

    Path(run_dir).mkdir(parents=True, exist_ok=True)
    matriz.save(out_matriz_path)
    print(f"[CLEAN04][SALIDA] {run_dir}")
    print(f"[CLEAN04] Original SIN modificar : {matriz.path}")
    print(f"[CLEAN04] Copia anotada (ESTADO) : {out_matriz_path}")
    return summary
