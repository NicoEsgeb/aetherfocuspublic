"""
clean04 — PDF layout / render
=============================
Lays out a demanda (the structured blocks from demanda_builder) into an A4 PDF.

Uses PyMuPDF's TextWriter with the base-14 Helvetica / Helvetica-Bold fonts and
a small hand-rolled paragraph engine (word wrap + full justification + inline
bold + pagination). This is deliberate: PyMuPDF's higher-level Story engine
applies HarfBuzz "fi/fl" ligatures, which land in the PDF text layer as the
single glyph "ﬁ" — the golden demandas (from Word) keep plain "fi", and a court
e-filing text layer should too. TextWriter maps glyph-by-glyph, so the extracted
text is clean. No office engine, no extra dependency (PyMuPDF ships with
clean02/clean03).

Conventions matched to the golden demandas:
  * A4, ~2 cm margins, Helvetica 11 pt, justified body.
  * merge-field values + section keywords in bold (mail-merge look).
  * header block as a label : value table (values bold).
  * centered page number at the bottom of every page.
  * NO digital-signature footer (the human signs afterwards) and NO
    page-header code (#12).
"""
from __future__ import annotations

import re
from pathlib import Path

import fitz

_PAGE = fitz.paper_rect("a4")
_LEFT = 56.0
_RIGHT = _PAGE.width - 56.0
_TOP = 52.0
_BOTTOM = _PAGE.height - 56.0
_CONTENT_W = _RIGHT - _LEFT

_SIZE = 11.0
# Baseline-to-baseline pitch measured on the client's golden demandas: 19 pt for
# 11 pt text (≈ Word "1.5 lines") with a 6 pt gap between paragraphs (→ 25 pt
# paragraph-to-paragraph, matching the goldens). Keep the Word renderer in sync.
_LEADING = 19.0          # body line height (matches the golden PDFs)
_HEADER_LEADING = 25.0   # header block rows are more airy in the goldens (25 pt)
_PARA_GAP = 6.0          # extra space after a paragraph
_ITEM_INDENT = 22.0      # hanging indent for numbered documents

_FONT_REG = fitz.Font("helv")
_FONT_BOLD = fitz.Font("hebo")
_SPACE_W = _FONT_REG.text_length(" ", _SIZE)


def _font(bold: bool) -> fitz.Font:
    return _FONT_BOLD if bold else _FONT_REG


def _piece_w(text: str, bold: bool) -> float:
    return _font(bold).text_length(text, _SIZE)


def _word_w(word) -> float:
    return sum(_piece_w(t, b) for t, b in word)


def _split_words(runs):
    """Turn runs [(text, bold), ...] into words. A word is a list of (text,
    bold) pieces with no spaces (a single visual word may mix bold, e.g.
    '24.084.981' + '.-'). Whitespace collapses to word boundaries."""
    words = []
    cur = []
    for text, bold in runs:
        for part in re.split(r"(\s+)", text):
            if part == "":
                continue
            if part.isspace():
                if cur:
                    words.append(cur)
                    cur = []
            else:
                cur.append((part, bold))
    if cur:
        words.append(cur)
    return words


class _Layout:
    def __init__(self):
        self.doc = fitz.open()
        self._new_page()

    def _new_page(self):
        self.page = self.doc.new_page(width=_PAGE.width, height=_PAGE.height)
        self.tw = fitz.TextWriter(self.page.rect)
        self.y = _TOP + _SIZE  # baseline of the first line

    def _flush(self):
        self.tw.write_text(self.page)

    def _line_break(self):
        self._flush()
        self._new_page()

    def _ensure(self, height: float):
        if self.y + height > _BOTTOM:
            self._line_break()

    # -- paragraph ---------------------------------------------------------
    def paragraph(self, runs, align="justify", left=_LEFT, right=_RIGHT):
        width = right - left
        words = _split_words(runs)
        if not words:
            self.y += _LEADING
            return
        lines = self._wrap(words, width)
        for i, line in enumerate(lines):
            self._ensure(_LEADING)
            last = i == len(lines) - 1
            self._draw_line(line, align, last, left, width)
            self.y += _LEADING
        self.y += _PARA_GAP

    def _wrap(self, words, width):
        lines = []
        cur, cur_w = [], 0.0
        for w in words:
            ww = _word_w(w)
            add = ww if not cur else cur_w + _SPACE_W + ww
            if cur and add > width:
                lines.append(cur)
                cur, cur_w = [w], ww
            else:
                cur.append(w)
                cur_w = add
        if cur:
            lines.append(cur)
        return lines

    def _draw_line(self, line, align, last, left, width):
        total_words = sum(_word_w(w) for w in line)
        n = len(line)
        if align == "center":
            natural = total_words + _SPACE_W * (n - 1)
            x = left + (width - natural) / 2
            gap = _SPACE_W
        elif align == "justify" and not last and n > 1:
            x = left
            gap = (width - total_words) / (n - 1)
        else:
            x = left
            gap = _SPACE_W
        for w in line:
            for t, b in w:
                self.tw.append((x, self.y), t, font=_font(b), fontsize=_SIZE)
                x += _piece_w(t, b)
            x += gap

    # -- header table ------------------------------------------------------
    def header_table(self, pairs):
        colon_x = _LEFT + max(_piece_w(lbl, False) for lbl, _ in pairs) + 8
        for label, value in pairs:
            self._ensure(_HEADER_LEADING)
            self.tw.append((_LEFT, self.y), label, font=_FONT_REG, fontsize=_SIZE)
            x = colon_x
            self.tw.append((x, self.y), ": ", font=_FONT_REG, fontsize=_SIZE)
            x += _piece_w(": ", False)
            self.tw.append((x, self.y), value, font=_FONT_BOLD, fontsize=_SIZE)
            self.y += _HEADER_LEADING
        self.y += _PARA_GAP

    # -- numbered document (hanging indent) --------------------------------
    def item(self, num, runs):
        self._ensure(_LEADING)
        self.tw.append((_LEFT, self.y), num, font=_FONT_REG, fontsize=_SIZE)
        self.paragraph(runs, align="justify", left=_LEFT + _ITEM_INDENT, right=_RIGHT)

    # -- finish ------------------------------------------------------------
    def finish(self, out_path: Path):
        self._flush()
        for i, page in enumerate(self.doc, start=1):
            label = str(i)
            w = _FONT_REG.text_length(label, 10)
            page.insert_text(((_PAGE.width - w) / 2, _PAGE.height - 30),
                             label, fontname="helv", fontsize=10)
        self.doc.save(str(out_path))
        self.doc.close()


def render_demanda_pdf(document: dict, out_dir: str | Path) -> Path:
    """Render one demanda (dict with 'basename' + 'blocks') into out_dir as a
    PDF. Returns the written path. Raises on write failure (caller marks ERROR)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{document['basename']}.pdf"

    layout = _Layout()
    for block in document["blocks"]:
        kind = block["kind"]
        if kind == "header_table":
            layout.header_table(block["pairs"])
        elif kind == "p":
            layout.paragraph(block["runs"], align=block.get("align", "justify"))
        elif kind == "item":
            layout.item(block["num"], block["runs"])
        if len(layout.doc) > 200:  # runaway-layout safety valve
            layout.doc.close()
            raise RuntimeError(
                f"La demanda {document['basename']} superó 200 páginas; "
                "posible error de maquetación.")
    layout.finish(out_path)
    return out_path
