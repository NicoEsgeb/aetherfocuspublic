"""
clean04 — Word (.docx) render
=============================
Writes the SAME structured demanda (the blocks from demanda_builder) as an
editable Word document, so the client can tweak wording before filing. Uses
python-docx. Kept byte-for-byte in sync with the PDF renderer by consuming the
exact same block model — only the output format differs.

Layout matched to the PDF: Arial 11 pt, justified body, bold merge-field values +
section keywords, a borderless label:value header table, hanging-indent numbered
documents, and a centered page-number field in the footer.
"""
from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

_FONT = "Arial"
_SIZE = Pt(11)
_SPACE_AFTER = Pt(6)
# 1.5 lines reproduces the golden demandas' ~19 pt baseline pitch for 11 pt Arial
# (kept in sync with render.py's _LEADING = 19). Editable/natural in Word.
_LINE = 1.5
_HANG = Cm(0.7)  # hanging indent for numbered documents


def _style_normal(doc: Document) -> None:
    normal = doc.styles["Normal"]
    normal.font.name = _FONT
    normal.font.size = _SIZE
    # Ensure the East-Asian/complex fallbacks also use Arial (Word quirk).
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(attr), _FONT)


def _margins(doc: Document) -> None:
    for section in doc.sections:
        section.left_margin = Cm(2)
        section.right_margin = Cm(2)
        section.top_margin = Cm(1.8)
        section.bottom_margin = Cm(2)


def _page_number_footer(doc: Document) -> None:
    """Centered 'PAGE' field in the footer (Word renders the live page number)."""
    para = doc.sections[0].footer.paragraphs[0]
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = para.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(begin)
    run._r.append(instr)
    run._r.append(end)


def _add_runs(paragraph, runs) -> None:
    for text, bold in runs:
        r = paragraph.add_run(text)
        r.bold = bool(bold)


def _paragraph(doc: Document, runs, align: str) -> None:
    p = doc.add_paragraph()
    p.alignment = (WD_ALIGN_PARAGRAPH.CENTER if align == "center"
                   else WD_ALIGN_PARAGRAPH.JUSTIFY)
    pf = p.paragraph_format
    pf.space_after = _SPACE_AFTER
    pf.line_spacing = _LINE
    _add_runs(p, runs)


def _item(doc: Document, num: str, runs) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf = p.paragraph_format
    pf.space_after = _SPACE_AFTER
    pf.line_spacing = _LINE
    pf.left_indent = _HANG
    pf.first_line_indent = -_HANG
    p.add_run(f"{num}\t")
    _add_runs(p, runs)


def _header_table(doc: Document, pairs) -> None:
    table = doc.add_table(rows=len(pairs), cols=2)  # no style => borderless
    table.autofit = False
    for i, (label, value) in enumerate(pairs):
        # The goldens space the header rows more airily than the body (~25 pt
        # pitch); give each row a 25 pt min height with vertically-centred text.
        row = table.rows[i]
        row.height = Pt(25)
        row.height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST
        left = table.cell(i, 0)
        left.width = Cm(6.5)
        left.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        lp = left.paragraphs[0]
        lp.paragraph_format.space_after = Pt(0)
        lp.add_run(label)
        right = table.cell(i, 1)
        right.width = Cm(10)
        right.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        rp = right.paragraphs[0]
        rp.paragraph_format.space_after = Pt(0)
        rp.add_run(": ")
        rp.add_run(value).bold = True
    doc.add_paragraph()  # small gap after the header block


def render_demanda_docx(document: dict, out_dir: str | Path) -> Path:
    """Render one demanda (dict with 'basename' + 'blocks') into out_dir as an
    editable .docx. Returns the written path. Raises on write failure (the caller
    marks ERROR so the RUT is never left OK without both deliverables)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{document['basename']}.docx"

    doc = Document()
    _style_normal(doc)
    _margins(doc)
    _page_number_footer(doc)

    for block in document["blocks"]:
        kind = block["kind"]
        if kind == "header_table":
            _header_table(doc, block["pairs"])
        elif kind == "p":
            _paragraph(doc, block["runs"], block.get("align", "justify"))
        elif kind == "item":
            _item(doc, block["num"], block["runs"])

    doc.save(str(out_path))
    return out_path
