"""
clean04 — matriz read / annotate (the resumable ESTADO column)
==============================================================
clean04 works on ONE matriz (the clean03 output, one row per pagaré). It reads
it, and — after generating the demandas — writes an annotated COPY (with a first
`ESTADO` column) into the run's output folder. The ORIGINAL input matriz is only
read, never modified; `save(path)` writes the copy elsewhere. The bot is still
re-runnable on that annotated copy (its ESTADO drives the skip-if-OK resume).

Everything is keyed by HEADER NAME, never by fixed column letter (the clean04
matriz may add/drop trailing columns). The matriz is loaded ONCE (styles kept)
and saved to the copy path, preserving clean03's colours / borders / SI-NO
dropdowns.

ESTADO (uniform within each RUT — 1 PDF = 1 RUT = several rows):
  * OK      (green)  — the demanda PDF for that RUT was written.
  * REVISAR (yellow) — a required field was missing → no PDF. The specific
                       missing cells are painted yellow + a comment naming them.
  * ERROR   (red)    — CARTERA_A_PROCESAR still = RE (human must set MP/VI), or
                       the PDF could not be written.

Idempotency: clean04 only ever *adds* the ESTADO cell + yellow "missing" marks.
Every mark it writes carries the author "clean04", so on a re-run it can wipe
its own previous marks on a RUT (comment + fill) before re-evaluating — without
disturbing clean03's own colouring. A RUT is skipped entirely (its PDF assumed
to already exist) only when every one of its rows already reads ESTADO == "OK".
"""
from __future__ import annotations

import re
from datetime import date, datetime
from pathlib import Path
from typing import Any, Optional

import openpyxl
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.worksheet.cell_range import MultiCellRange

# --------------------------------------------------------------------------
# Logical field -> accepted header names (normalized, upper-case). The FIRST
# match found in the sheet wins, so aliases are tried in priority order.
# --------------------------------------------------------------------------
FIELD_HEADERS: dict[str, list[str]] = {
    "rut": ["RUT"],
    "dv": ["DV"],
    "nombre": ["NOMBRE"],
    "operacion": ["OPERACIÓN", "OPERACION"],
    "cartera_original": ["CARTERA_ORIGINAL", "CARTERA"],
    # The template selector. Falls back to CARTERA_ORIGINAL/CARTERA if a very old
    # matriz predates the split (then RE/MP are read straight from the cartera).
    "cartera_a_procesar": ["CARTERA_A_PROCESAR", "CARTERA_ORIGINAL", "CARTERA"],
    "mora": ["MORA"],
    "monto_pagare": ["MONTO_PAGARE"],
    "monto_adeudado": ["MONTO_ADEUDADO"],
    "tasa_interes": ["TASA_INTERES"],
    "num_cuotas": ["NUM_CUOTAS"],
    "monto_cuota": ["MONTO_CUOTA"],
    "monto_ultima_cuota": ["MONTO_ULTIMA_CUOTA"],
    "pagare_ultima_cuota_inferior": ["PAGARE_ULTIMA_CUOTA_INFERIOR"],
    "fecha_vcto_1ra_cuota": ["FECHA_VCTO_1RA_CUOTA"],
    "dia_del_mes_vcto_cuota": ["DIA_DEL_MES_VCTO_CUOTA"],
    "fecha_vcto_ultima_cuota": ["FECHA_VCTO_ULTIMA_CUOTA"],
    "fecha_suscripcion_pagare": ["FECHA_SUSCRIPCION_PAGARE"],
    "fecha_vcto_pagare": ["FECHA_VCTO_PAGARE"],
    "nro_1ra_cuota_imp": ["NRO_1RA_CUOTA_IMP"],
    "fecha_1ra_cuota_imp": ["FECHA_1RA_CUOTA_IMP"],
    "domicilio_deudor": ["DOMICILIO_DEUDOR"],
    "comuna_deudor": ["COMUNA_DEUDOR"],
    "region_deudor": ["REGION_DEUDOR"],
    "pagare_firmado_cliente": ["PAGARE_FIRMADO_CLIENTE"],
    "contrato_mandato_firmado_cliente":
        ["CONTRATO_MANDATO_FIRMADO_CLIENTE", "CONTRATO_FIRMADO_CLIENTE"],
    "hoja_de_firma": ["HOJA_DE_FIRMA"],
    "cod_contrato": ["COD_CONTRATO"],
    "notario": ["NOTARIO"],
    "fecha_protocoli": ["FECHA_PROTOCOLI"],
    "nota": ["NOTA"],
    "cod_form_dda": ["COD_FORM_DDA"],
}

# Human-readable label for the header of the missing cell's comment.
FIELD_LABEL = {key: headers[0] for key, headers in FIELD_HEADERS.items()}

ESTADO_HEADER = "ESTADO"
AUTHOR = "clean04"

# Same palette as clean03 so the annotated matriz reads consistently.
GREEN = "FF92D050"
YELLOW = "FFFFFF00"
RED = "FFFF0000"
CREAM = "FFF5E6C8"

_FILL_GREEN = PatternFill("solid", fgColor=GREEN)
_FILL_YELLOW = PatternFill("solid", fgColor=YELLOW)
_FILL_RED = PatternFill("solid", fgColor=RED)
_FILL_CREAM = PatternFill("solid", fgColor=CREAM)
_FILL_NONE = PatternFill(fill_type=None)

_SIDE_THIN = Side(style="thin", color="FF808080")
_SIDE_HEADER = Side(style="medium", color="FF404040")
_BORDER_DATA = Border(left=_SIDE_THIN, right=_SIDE_THIN, top=_SIDE_THIN, bottom=_SIDE_THIN)
_BORDER_HEADER = Border(left=_SIDE_HEADER, right=_SIDE_HEADER,
                        top=_SIDE_HEADER, bottom=_SIDE_HEADER)


def _norm(text: Any) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip()).upper()


def rut_digits(value: Any) -> str:
    """'7.512.305-1' / '7512305' / 7512305 -> '7512305' (digits only, no DV)."""
    return re.sub(r"\D", "", str(value or ""))


def is_missing(value: Any) -> bool:
    """A field is missing if empty or the OCR marker NO_ENCONTRADO."""
    if value is None:
        return True
    s = str(value).strip()
    return s == "" or s.upper() == "NO_ENCONTRADO"


class Row:
    """One matriz row (one pagaré). Knows its excel row index and how to read
    any logical field by header name."""

    def __init__(self, matriz: "Matriz", excel_row: int):
        self._m = matriz
        self.excel_row = excel_row

    def get(self, field: str) -> Any:
        """Raw cell value for a logical field, or None if the column is absent."""
        col = self._m.col_of(field)
        if col is None:
            return None
        return self._m.ws.cell(self.excel_row, col).value

    def get_str(self, field: str) -> str:
        v = self.get(field)
        if v is None:
            return ""
        # A human who edits the matriz by hand types dates into Excel, so openpyxl
        # returns a datetime/date whose str() is "2005-11-23 00:00:00". clean03's
        # own dates are already DD-MM-YYYY text. Render both the same way so the
        # demanda never leaks a raw timestamp. (datetime is a subclass of date.)
        if isinstance(v, date):
            return v.strftime("%d-%m-%Y")
        return str(v).strip()

    def has(self, field: str) -> bool:
        return not is_missing(self.get(field))

    @property
    def rut_key(self) -> str:
        """Groups pagarés of the same demanda: digits(RUT) + '-' + DV."""
        return f"{rut_digits(self.get('rut'))}-{self.get_str('dv').upper()}"

    @property
    def estado(self) -> str:
        col = self._m.estado_col
        return _norm(self._m.ws.cell(self.excel_row, col).value)


class Matriz:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        if not self.path.exists():
            raise ValueError(f"No existe la matriz: {self.path}")
        self.is_xlsm = self.path.suffix.lower() == ".xlsm"
        try:
            self.wb = openpyxl.load_workbook(self.path, keep_vba=self.is_xlsm)
        except Exception as exc:  # pragma: no cover - defensive
            raise ValueError(f"No se pudo abrir la matriz ({self.path.name}): {exc}")
        self.ws = self.wb.active

        self._index_headers()
        self.estado_col = self._ensure_estado_column()
        self._index_headers()  # ESTADO insert may have shifted every column
        self.estado_col = self._header_col.get(ESTADO_HEADER, 1)
        self.rows: list[Row] = self._read_rows()

    # -- header / column resolution ---------------------------------------
    def _index_headers(self) -> None:
        self._header_col: dict[str, int] = {}
        for col in range(1, self.ws.max_column + 1):
            name = _norm(self.ws.cell(1, col).value)
            if name and name not in self._header_col:
                self._header_col[name] = col
        # Resolve each logical field to a concrete column (first alias present).
        self._field_col: dict[str, int] = {}
        for field, headers in FIELD_HEADERS.items():
            for header in headers:
                col = self._header_col.get(_norm(header))
                if col is not None:
                    self._field_col[field] = col
                    break

    def col_of(self, field: str) -> Optional[int]:
        return self._field_col.get(field)

    # -- ESTADO column ----------------------------------------------------
    def _ensure_estado_column(self) -> int:
        """Return the ESTADO column, inserting it at A (shifting everything
        right) if it doesn't exist yet. Reuses it wherever it is if present."""
        existing = self._header_col.get(ESTADO_HEADER)
        if existing is not None:
            self._style_estado_header(existing)
            return existing

        self.ws.insert_cols(1)
        # insert_cols shifts cell values/styles/comments but NOT data validations
        # or column widths — fix both so the SI/NO dropdowns and widths stay put.
        self._shift_data_validations(1)
        self._shift_column_widths(1)
        self.ws.column_dimensions["A"].width = 12
        self._style_estado_header(1)
        return 1

    def _style_estado_header(self, col: int) -> None:
        cell = self.ws.cell(1, col, value=ESTADO_HEADER)
        cell.font = Font(bold=True, color="FF000000")
        cell.fill = _FILL_CREAM
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _BORDER_HEADER

    def _shift_data_validations(self, by: int) -> None:
        for dv in list(self.ws.data_validations.dataValidation):
            shifted = MultiCellRange()
            for rng in dv.sqref.ranges:
                rng.shift(col_shift=by)
                shifted.add(rng)
            dv.sqref = shifted

    def _shift_column_widths(self, by: int) -> None:
        widths: dict[int, float] = {}
        for letter, dim in self.ws.column_dimensions.items():
            if dim.width:
                widths[column_index_from_string(letter)] = dim.width
        for idx in sorted(widths, reverse=True):
            self.ws.column_dimensions[get_column_letter(idx + by)].width = widths[idx]

    # -- reading ----------------------------------------------------------
    def _read_rows(self) -> list[Row]:
        rut_col = self.col_of("rut")
        if rut_col is None:
            raise ValueError(
                "La matriz no tiene una columna RUT reconocible. Revisa los "
                "encabezados (fila 1)."
            )
        rows: list[Row] = []
        for r in range(2, self.ws.max_row + 1):
            rut_val = self.ws.cell(r, rut_col).value
            if rut_digits(rut_val) == "":
                continue  # blank / separator row
            rows.append(Row(self, r))
        return rows

    # -- annotation -------------------------------------------------------
    def _clear_marks(self, row: Row) -> None:
        """Wipe clean04's own previous marks (comment + fill) on this row, so a
        re-run reflects the current state. Only cells clean04 authored are
        touched — clean03's colouring is left intact."""
        for col in range(1, self.ws.max_column + 1):
            cell = self.ws.cell(row.excel_row, col)
            if cell.comment is not None and cell.comment.author == AUTHOR:
                cell.comment = None
                cell.fill = _FILL_NONE

    def _set_estado(self, row: Row, text: str, fill: PatternFill) -> None:
        cell = self.ws.cell(row.excel_row, self.estado_col, value=text)
        cell.fill = fill
        cell.font = Font(bold=True, color="FF000000")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = _BORDER_DATA

    def mark_ok(self, rows: list[Row]) -> None:
        for row in rows:
            self._clear_marks(row)
            self._set_estado(row, "OK", _FILL_GREEN)

    def mark_revisar(self, rows: list[Row], missing_by_row: dict[int, list[str]]) -> None:
        for row in rows:
            self._clear_marks(row)
            self._set_estado(row, "REVISAR", _FILL_YELLOW)
            for field in missing_by_row.get(row.excel_row, []):
                self._paint_missing(row, field)

    def mark_error(self, rows: list[Row], reason: str,
                   cell_fields_by_row: Optional[dict[int, list[str]]] = None) -> None:
        cell_fields_by_row = cell_fields_by_row or {}
        for row in rows:
            self._clear_marks(row)
            self._set_estado(row, "ERROR", _FILL_RED)
            for field in cell_fields_by_row.get(row.excel_row, []):
                col = self.col_of(field)
                if col is None:
                    continue
                cell = self.ws.cell(row.excel_row, col)
                cell.fill = _FILL_RED
                cell.comment = Comment(reason, AUTHOR)

    def _paint_missing(self, row: Row, field: str) -> None:
        col = self.col_of(field)
        label = FIELD_LABEL.get(field, field.upper())
        if col is None:
            # Column absent entirely — flag the ESTADO cell with the note.
            cell = self.ws.cell(row.excel_row, self.estado_col)
            cell.comment = Comment(
                f"Falta la columna «{label}» en la matriz (requerida para la "
                "demanda).", AUTHOR)
            return
        cell = self.ws.cell(row.excel_row, col)
        cell.fill = _FILL_YELLOW
        cell.comment = Comment("Falta información para Generar la demanda", AUTHOR)

    def save(self, path: str | Path | None = None) -> None:
        """Write the annotated workbook to `path` (a COPY in the run's output
        folder). The ORIGINAL input matriz is only ever read, never modified —
        openpyxl loaded it read-only-in-spirit and we save elsewhere. Falls back
        to the original path only if no target is given (not used in production)."""
        self.wb.save(Path(path) if path is not None else self.path)
