async function runInMainWorld(tabId, action, args) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: (actionName, actionArgs) => {
      const dispatchValueEvents = (element) => {
        element.dispatchEvent(new Event("input", { bubbles: true }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
      };

      const selectPickerAvailable = () => (
        Boolean(window.jQuery) &&
        Boolean(window.jQuery.fn) &&
        Boolean(window.jQuery.fn.selectpicker)
      );

      if (actionName === "selectPickerValue") {
        const select = document.getElementById(actionArgs.selectId);
        if (!select) {
          return { ok: false, error: `select not found: ${actionArgs.selectId}` };
        }
        if (selectPickerAvailable()) {
          window.jQuery(select).selectpicker("val", actionArgs.value);
          window.jQuery(select).trigger("change");
        } else {
          for (const option of select.options || []) {
            option.selected = String(option.value || option.textContent || "").trim() === String(actionArgs.value).trim();
          }
          dispatchValueEvents(select);
        }
        return { ok: true };
      }

      if (actionName === "selectPickerAll") {
        const select = document.getElementById(actionArgs.selectId);
        if (!select) {
          return { ok: false, error: `select not found: ${actionArgs.selectId}` };
        }
        if (selectPickerAvailable()) {
          window.jQuery(select).selectpicker("selectAll");
          window.jQuery(select).trigger("change");
        } else {
          for (const option of select.options || []) {
            option.selected = true;
          }
          dispatchValueEvents(select);
        }
        return { ok: true };
      }

      if (actionName === "setInputValue") {
        const input = document.querySelector(actionArgs.selector);
        if (!input) {
          return { ok: false, error: `input not found: ${actionArgs.selector}` };
        }
        input.focus();
        input.value = "";
        dispatchValueEvents(input);
        input.value = String(actionArgs.value ?? "");
        dispatchValueEvents(input);
        return { ok: true };
      }

      return { ok: false, error: `unknown action: ${actionName}` };
    },
    args: [action, args || {}]
  });
  return results && results[0] ? results[0].result : { ok: false, error: "no result" };
}

async function bridgeRequest(path, options) {
  const response = await fetch(`http://127.0.0.1:8765${path}`, {
    method: options && options.method ? options.method : "GET",
    headers: { "Content-Type": "application/json" },
    body: options && Object.prototype.hasOwnProperty.call(options, "body")
      ? JSON.stringify(options.body)
      : undefined
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    return {
      ok: false,
      error: payload.error || `Bridge ${response.status}`
    };
  }
  return payload;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) {
    return false;
  }
  if (message.type === "N03_BRIDGE_REQUEST") {
    bridgeRequest(message.path || "/", message.options || {})
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({
        ok: false,
        error: String(error && error.message ? error.message : error)
      }));
    return true;
  }
  if (message.type !== "N03_MAIN_WORLD") {
    return false;
  }
  const tabId = sender && sender.tab && sender.tab.id;
  if (!tabId) {
    sendResponse({ ok: false, error: "No sender tab id" });
    return false;
  }
  runInMainWorld(tabId, message.action, message.args)
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({ ok: false, error: String(error && error.message ? error.message : error) }));
  return true;
});
