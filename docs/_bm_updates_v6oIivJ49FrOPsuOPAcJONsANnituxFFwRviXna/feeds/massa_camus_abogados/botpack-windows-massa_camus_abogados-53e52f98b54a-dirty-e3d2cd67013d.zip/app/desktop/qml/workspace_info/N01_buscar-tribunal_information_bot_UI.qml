import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color success: Common.Theme.success
    property color warning: Common.Theme.warning
    property int infoTabIndex: 0

    Common.BotInfoHeader {
        themeSource: Common.Theme
        width: root.width
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Buscar Tribunal"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: buscarTribunalInfoComponent
    }

    Component {
        id: buscarTribunalInfoComponent

        Column {
            width: root.width
            spacing: 12

            // Badge
            Rectangle {
                radius: 8
                implicitHeight: 24
                implicitWidth: badgeLabel.implicitWidth + 20
                color: Common.Theme.successSoft
                border.width: 1
                border.color: Common.Theme.success

                Label {
                    id: badgeLabel
                    anchors.centerIn: parent
                    text: "Proceso CAE"
                    color: Common.Theme.success
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                }
            }

            Label {
                text: "¿Qué hace este bot?"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Toma la Planilla Estado Diario en Excel, identifica los exhortos (filas con letra E en el Rol) y consulta automáticamente el portal PJUD para encontrar la Causa Origen y el Tribunal Origen de cada uno. El resultado se guarda en una copia de la planilla con dos columnas nuevas."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
                font.pixelSize: Common.Theme.fontSize(12)
            }

            Label {
                text: "¿Qué necesita para ejecutarse?"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Planilla 'Estado Diario' en formato .xlsx (colocarla en la carpeta input/ del bot o seleccionarla al ejecutar).",
                    "Conexión a internet para acceder al portal PJUD.",
                    "Credenciales de acceso al portal configuradas en el bot."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, bulletText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: bulletText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }

            Label {
                text: "¿Qué genera como resultado?"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Copia de la planilla original con dos columnas nuevas: 'Causa Origen' y 'Tribunal Origen' (celdas en verde).",
                    "Filas donde no se encontró resultado quedan marcadas como 'Pendiente' en naranja.",
                    "Archivo guardado en output/CAE-N01_Buscar-Tribunal_[Fecha]_[Hora]/."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }

            Label {
                text: "Notas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Las filas con letra C en el Rol se omiten automáticamente.",
                    "Si el tribunal no se encuentra en el primer intento, el bot reintenta la búsqueda una vez más antes de marcarlo como Pendiente.",
                    "La planilla original nunca se modifica, siempre se trabaja sobre una copia."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, noteText.implicitHeight) + 2

                    Rectangle {
                        width: 6; height: 6; radius: 3
                        color: root.warning
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: noteText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                        font.pixelSize: Common.Theme.fontSize(12)
                    }
                }
            }
        }
    }
}
