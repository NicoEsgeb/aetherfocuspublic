import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color accentStrong: Common.Theme.accent
    property color success: Common.Theme.success
    property int infoTabIndex: 0

    Common.BotInfoHeader {
        themeSource: Common.Theme
        width: root.width
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Ingreso"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }

            TabButton {
                text: "Envio"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }

            TabButton {
                text: "Comparacion"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: root.infoTabIndex === 0
            ? ingresoInfoComponent
            : (root.infoTabIndex === 1 ? envioInfoComponent : comparacionInfoComponent)
    }

    Component {
        id: ingresoInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: RPA_01_Ingreso"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Realiza el preingreso de escritos en PJUD leyendo la matriz Excel y adjuntando los documentos por cada fila pendiente."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Task a ejecutar: RPA_01_Ingreso.",
                    "Archivo Excel de entrada en input/CPago_151_sin_22.xlsx (hoja Hoja1).",
                    "Carpeta de documentos en input/documentos con estructura por mes y archivo PDF esperado.",
                    "Credenciales y perfil PJUD habilitados para operar."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Marca PREINGRESO como OK o ERROR por fila en la matriz.",
                    "Crea y adjunta el escrito en PJUD para cada caso procesado.",
                    "Mantiene la trazabilidad de la corrida mediante logs de ejecucion."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }
        }
    }

    Component {
        id: envioInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: RPA_01_Envio"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Toma los escritos ya preingresados y ejecuta su envio a PJUD desde la bandeja de escritos."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Task a ejecutar: RPA_01_Envio.",
                    "Matriz Excel con PREINGRESO=OK para los registros a enviar.",
                    "Acceso al perfil PJUD que permite enviar escritos."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.accentStrong
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Marca ENVIO como OK o ERROR por fila en la matriz.",
                    "Envia los escritos seleccionados al Poder Judicial.",
                    "Deja los resultados listos para la etapa de comparacion."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }
        }
    }

    Component {
        id: comparacionInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: RPA_01_Compare_results"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Descarga el informe de escritos enviados desde PJUD, lo cruza con la matriz del bot y genera un archivo final de control."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Task a ejecutar: RPA_01_Compare_results.",
                    "Matriz del bot con columna ENVIO actualizada.",
                    "Permisos para descargar Excel desde bandeja de escritos enviados en PJUD."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.accentStrong
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Descarga el Excel de PJUD en la carpeta processing.",
                    "Cruza los roles enviados del bot con los registros de PJUD.",
                    "Genera output/RESULTADO.xlsx con coincidencias destacadas en verde."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }
        }
    }
}
