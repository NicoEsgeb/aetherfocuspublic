import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

RowLayout {
    id: root

    property string title: "Información del bot"
    property QtObject themeSource: Theme
    property color textColor: themeSource.text
    property color panelColor: themeSource.panel2
    property color lineColor: themeSource.line
    property color accentColor: themeSource.accent
    property color accentSoftColor: themeSource.accentSoft
    property real innerRadius: themeSource.radiusInner
    property int titleFontSize: themeSource.fontSize(16)
    property int buttonFontSize: themeSource.fontSize(12)
    default property alias badges: badgeRow.data

    spacing: 8
    implicitHeight: Math.max(titleLabel.implicitHeight,
                             badgeRow.implicitHeight,
                             openBotFolderButton.implicitHeight)

    function botFolderPath() {
        if (typeof controller === "undefined" || controller === null || !controller.selectedBot)
            return ""
        return String(controller.selectedBot.workingDir || "").trim()
    }

    Label {
        id: titleLabel
        text: root.title
        color: root.textColor
        font.pixelSize: root.titleFontSize
        font.bold: true
        Layout.fillWidth: true
        wrapMode: Text.Wrap
    }

    RowLayout {
        id: badgeRow
        spacing: 8
        visible: children.length > 0
    }

    Rectangle {
        id: openBotFolderButton
        objectName: "openBotFolderButton"
        property string text: "Abrir ubicación del Bot"

        function activate() {
            if (!enabled)
                return
            var targetPath = root.botFolderPath()
            if (targetPath.length > 0)
                controller.openPathInExplorer(targetPath)
        }

        implicitWidth: buttonContent.implicitWidth + 24
        implicitHeight: 34
        enabled: root.botFolderPath().length > 0
        opacity: enabled ? 1.0 : 0.42
        radius: root.innerRadius
        color: hoverHandler.hovered || tapHandler.pressed
               ? root.accentSoftColor : root.panelColor
        border.width: 1
        border.color: hoverHandler.hovered ? root.accentColor : root.lineColor
        activeFocusOnTab: true
        scale: tapHandler.pressed ? 0.98 : (hoverHandler.hovered ? 1.01 : 1.0)

        Accessible.role: Accessible.Button
        Accessible.name: text
        Accessible.onPressAction: activate()

        Keys.onPressed: function(event) {
            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter || event.key === Qt.Key_Space) {
                activate()
                event.accepted = true
            }
        }

        Behavior on scale {
            NumberAnimation {
                duration: tapHandler.pressed ? 65 : 150
                easing.type: tapHandler.pressed ? Easing.OutCubic : Easing.OutBack
            }
        }

        Behavior on color { ColorAnimation { duration: 120 } }
        Behavior on border.color { ColorAnimation { duration: 120 } }

        transform: Translate {
            y: tapHandler.pressed ? 1 : (hoverHandler.hovered ? -1 : 0)
            Behavior on y { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
        }

        HoverHandler {
            id: hoverHandler
            enabled: openBotFolderButton.enabled
        }

        TapHandler {
            id: tapHandler
            enabled: openBotFolderButton.enabled
            onTapped: openBotFolderButton.activate()
        }

        RowLayout {
            id: buttonContent
            anchors.centerIn: parent
            spacing: 7

            Item {
                Layout.preferredWidth: 17
                Layout.preferredHeight: 15

                Rectangle {
                    x: 1
                    y: 4
                    width: 15
                    height: 10
                    radius: 2
                    color: "transparent"
                    border.width: 1.4
                    border.color: root.textColor
                }

                Rectangle {
                    x: 2
                    y: 1
                    width: 7
                    height: 5
                    radius: 1
                    color: "transparent"
                    border.width: 1.4
                    border.color: root.textColor
                }
            }

            Label {
                text: openBotFolderButton.text
                color: root.textColor
                font.pixelSize: root.buttonFontSize
                font.weight: Font.DemiBold
            }
        }
    }
}
