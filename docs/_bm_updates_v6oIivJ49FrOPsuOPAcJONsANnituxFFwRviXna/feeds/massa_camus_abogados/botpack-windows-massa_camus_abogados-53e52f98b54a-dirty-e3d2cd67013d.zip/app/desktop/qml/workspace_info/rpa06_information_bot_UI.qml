import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

Column {
    id: root
    spacing: 10
    height: childrenRect.height

    property var botInfo: ({})
    property string selectedBotName: ""
    property color textMain: Common.Theme.text
    property color textMuted: Common.Theme.text2
    property color accent: Common.Theme.accent
    property color accentStrong: Common.Theme.accent
    property color success: Common.Theme.success
    property int infoTabIndex: 0

    Common.BotInfoHeader {
        themeSource: Common.Theme
        width: root.width
    }

    Rectangle {
        width: root.width
        implicitHeight: infoTabBar.implicitHeight + 10
        radius: 9
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line

        TabBar {
            id: infoTabBar
            anchors.fill: parent
            anchors.margins: 5
            spacing: 6
            clip: true
            currentIndex: root.infoTabIndex
            onCurrentIndexChanged: root.infoTabIndex = currentIndex
            background: Rectangle {
                radius: 8
                color: Common.Theme.panel2
                border.width: 0
            }

            TabButton {
                text: "Ingresar Demandas"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }

            TabButton {
                text: "Descargar Caratulas"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }

            TabButton {
                text: "Descargar Informe"
                width: implicitWidth + 8
                contentItem: Text {
                    text: parent.text
                    color: parent.checked ? root.textMain : root.textMuted
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    elide: Text.ElideRight
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: parent.checked
                }
                background: Rectangle {
                    radius: 7
                    color: parent.checked ? Common.Theme.accentSoft : Common.Theme.panel2
                    border.width: 1
                    border.color: parent.checked ? Common.Theme.accent : Common.Theme.line
                }
            }
        }
    }

    Loader {
        id: tabContentLoader
        width: root.width
        sourceComponent: root.infoTabIndex === 0
            ? ingresarInfoComponent
            : (root.infoTabIndex === 1 ? caratulasInfoComponent : informeInfoComponent)
    }

    Component {
        id: ingresarInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: RPA_06_Ingreso"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Automatiza el ingreso de demandas y documentos en el portal de la Oficina Judicial Virtual."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Task a ejecutar: RPA_06_Ingreso.",
                    "Matriz a utilizar (Matriz_Demandas/BOT_MATRIZ_DEMANDAS_ingreso.xlsx)."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.accent
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Actualiza la matriz *_terminado.xlsx con estado OK/error por fila.",
                    "Genera evidencias de ejecucion (PNG, robolog, log.html)."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }
        }
    }

    Component {
        id: caratulasInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: RPA_06_GET_CARATULAS"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Descarga caratulas en PJUD por tribunal y rango de fechas, luego cruza RIT/RUT con Informe Causas y Matriz GET_CARATULAS."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
            }

            Label {
                text: "Entradas requeridas"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Task a ejecutar: RPA_06_GET_CARATULAS.",
                    "Matriz GET_CARATULAS (hoja BOT con ARCH_DEMANDA; INGRESO es opcional).",
                    "Archivo Informe Causas (hoja Demandas Enviadas).",
                    "Fecha desde y fecha hasta (dd/mm/yyyy).",
                    "Carpeta de salida para caratulas."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, inputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.accentStrong
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: inputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }

            Label {
                text: "Resultado esperado"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Repeater {
                model: [
                    "Descarga caratulas por tribunal y marca DESCARGA_CARATULA=OK en Informe Causas.",
                    "Conserva solo PDFs que cruzan con la matriz y genera CaratulasUnidas.pdf.",
                    "Si habia tribunales pendientes y no se descarga ningun PDF, la task falla con error controlado."
                ]

                delegate: Item {
                    width: parent.width
                    implicitHeight: Math.max(6, outputText.implicitHeight) + 2

                    Rectangle {
                        width: 6
                        height: 6
                        radius: 3
                        color: root.success
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.topMargin: 6
                    }

                    Text {
                        id: outputText
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.right: parent.right
                        color: root.textMuted
                        text: String(modelData)
                        wrapMode: Text.WrapAnywhere
                    }
                }
            }
        }
    }

    Component {
        id: informeInfoComponent

        Column {
            width: root.width
            spacing: 10

            Label {
                text: "Task: Descargar Informe"
                color: root.textMain
                font.bold: true
                font.pixelSize: Common.Theme.fontSize(13)
                width: parent.width
            }

            Label {
                text: "Sin contenido por ahora."
                color: root.textMuted
                wrapMode: Text.WrapAnywhere
                width: parent.width
            }
        }
    }
}
