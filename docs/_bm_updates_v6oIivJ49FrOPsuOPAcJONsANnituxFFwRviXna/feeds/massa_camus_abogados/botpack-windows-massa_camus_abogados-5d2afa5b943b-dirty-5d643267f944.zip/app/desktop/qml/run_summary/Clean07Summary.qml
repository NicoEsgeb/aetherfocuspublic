import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../common" as Common

// Run-detail table for the clean07 "Ingreso Demandas BBRR" bot.
//
// IMPORTANT: this is a pure-QML log parser (no Python plugin), so it ships as
// a bot-pack/QML update — never a core rebuild (app/desktop/bot_plugins/ is
// outside the bot-pack's allowed prefixes). It receives the raw run log via
// summaryData.logText (wired as a fallback in Main.qml) and parses the bot's
// own [CLEAN07][DETALLE] / [CLEAN07][SALIDA] / [CLEAN07][PASO_ERROR] markers
// itself. [CLEAN07][DETALLE] carries the SAME table Clean07_Resultado.xlsx
// holds (functions.py's build_result_summary_json / write_result_excel share
// the exact same column-building code), one row per RUT, columns built
// dynamically (PAGARE-1..N grows with whichever RUT has the most pagarés) —
// so this panel and the output file can never disagree.
Item {
    id: root
    property var summaryData: ({})

    readonly property color cPanel: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarn: Common.Theme.warning

    function val(key, fallback) {
        if (!summaryData || summaryData[key] === undefined || summaryData[key] === null)
            return fallback
        return summaryData[key]
    }
    function logText() { return String(root.val("logText", "")) }

    // Last capture group 1 of `pattern` across the whole log ("" when absent).
    function lastCapture(pattern) {
        var text = root.logText()
        var last = ""
        var m
        pattern.lastIndex = 0
        while ((m = pattern.exec(text)) !== null)
            last = String(m[1] || "").trim()
        return last
    }

    // Why the run stopped. Empty when it died for some other reason, then the
    // headline falls back to generic wording.
    function failureCause() {
        var faltantes = root.lastCapture(/\[CLEAN07\]\[COLUMNAS_FALTANTES\]\s+([^\r\n]+)/g)
        if (faltantes.length > 0)
            return "Faltan columnas obligatorias: " + faltantes
        var entrada = root.lastCapture(/\[CLEAN07\]\[ENTRADA_INVALIDA\]\s+([^\r\n]+)/g)
        if (entrada.length > 0)
            return entrada
        return root.lastCapture(/\[CLEAN07\]\[PASO_ERROR\]\s+([^\r\n]+)/g)
    }
    function technicalStatus() { return String(root.val("statusTechnical", "")).toLowerCase() }
    function isSuccess() { return root.technicalStatus() === "success" }
    function isFailed() { return root.technicalStatus() === "failed" }
    function isCancelled() { return root.technicalStatus() === "cancelled" }
    function isRunning() {
        var s = root.technicalStatus()
        return s === "" || s === "running" || s === "queued"
    }

    // ---- table data: [CLEAN07][DETALLE] {"columns":[...],"rows":[[...],...]} ----
    function tableObj() {
        var raw = root.lastCapture(/\[CLEAN07\]\[DETALLE\]\s+([^\r\n]+)/g)
        if (raw.length === 0)
            return { "columns": [], "rows": [] }
        try {
            var parsed = JSON.parse(raw)
            return { "columns": parsed.columns || [], "rows": parsed.rows || [] }
        } catch (e) {
            return { "columns": [], "rows": [] }
        }
    }
    function columns() { return root.tableObj().columns }
    function dataRows() { return root.tableObj().rows }

    function outDir() {
        var last = root.lastCapture(/\[CLEAN07\]\[SALIDA\]\s+([^\r\n]+)/g)
        return last.replace(/\s+$/, "")
    }

    // ---- derived counts (by ESTADO, column 0) ----
    function countByEstado(estado) {
        var rows = root.dataRows()
        var n = 0
        for (var i = 0; i < rows.length; i++)
            if (String(rows[i][0] || "") === estado) n++
        return n
    }
    function countIngresadas() { return root.countByEstado("Ingresada") }
    function countNoIngresadas() { return root.countByEstado("Causa no ingresada") }
    function countNoProcesadas() { return root.countByEstado("No procesada") }
    function countTotal() { return root.dataRows().length }
    function needsAttention() { return root.countNoIngresadas() > 0 || root.countNoProcesadas() > 0 }

    function statusWord() {
        if (root.isCancelled()) return "Detenido"
        if (root.isFailed()) return "Con errores"
        if (root.isSuccess()) return root.needsAttention() ? "Con pendientes" : "Completado"
        return "En proceso"
    }
    function headline() {
        if (root.isCancelled()) return "Proceso detenido manualmente"
        if (root.isFailed()) {
            var cause = root.failureCause()
            return cause.length > 0 ? cause : "El proceso se detuvo"
        }
        if (root.isSuccess())
            return "Listo: " + root.countIngresadas() + " ingresada(s), "
                + root.countNoIngresadas() + " no ingresada(s), "
                + root.countNoProcesadas() + " sin procesar"
        return root.countTotal() > 0 ? ("Procesando — " + root.countTotal() + " RUT(s) hasta ahora")
                                     : "Comenzando el proceso..."
    }
    function statusColor() {
        if (root.isCancelled()) return Common.Theme.cancel
        if (root.isFailed()) return Common.Theme.danger
        if (root.isSuccess()) return root.needsAttention() ? root.cWarn : root.cSuccess
        return Common.Theme.accent
    }

    // ---- table layout ----
    function columnWidth(header) {
        if (header === "ESTADO") return 150
        if (header === "RUT") return 120
        if (header === "DETALLE") return 260
        return 116 // DEMANDA / MANDATO-x / RESOLUCION / CERTIFICADO / CONTRATO / PAGARE-x
    }
    function tableWidth() {
        var cols = root.columns()
        var w = 0
        for (var i = 0; i < cols.length; i++) w += root.columnWidth(cols[i])
        return w
    }
    function cellText(value) {
        if (value === null || value === undefined || String(value).length === 0) return "—"
        return String(value)
    }
    function cellColor(header, value) {
        if (header === "ESTADO") return value === "Ingresada" ? root.cSuccess : root.cWarn
        if (header === "RUT" || header === "DETALLE") return root.cTextMain
        if (value === null || value === undefined || String(value).length === 0 || value === "Ingresado")
            return root.cSuccess
        return root.cWarn
    }
    // Flattened once per render: one entry per data row, each carrying its
    // own cells (header/value pairs) so the inner Repeater needs no outside
    // state beyond what its own delegate already has.
    function tableRows() {
        var cols = root.columns()
        var rows = root.dataRows()
        var out = []
        for (var r = 0; r < rows.length; r++) {
            var cells = []
            for (var c = 0; c < cols.length; c++)
                cells.push({ "header": cols[c], "value": rows[r][c] })
            out.push({ "rowIndex": r, "cells": cells })
        }
        return out
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 12

        // ---- Header: process name + status chip ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Label {
                text: "Ingreso Demandas BBRR"
                color: root.cTextMain
                font.pixelSize: Common.Theme.fontSize(18)
                font.bold: true
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            Rectangle {
                radius: 7
                implicitHeight: 24
                implicitWidth: statusWordLabel.implicitWidth + 22
                color: Common.Theme.panel2
                border.width: 1
                border.color: root.statusColor()

                Label {
                    id: statusWordLabel
                    anchors.centerIn: parent
                    text: root.statusWord()
                    color: root.statusColor()
                    font.pixelSize: Common.Theme.fontSize(12)
                    font.bold: true
                }
            }
        }

        Label {
            text: root.headline()
            color: root.cTextMain
            font.pixelSize: Common.Theme.fontSize(14)
            font.bold: true
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
        }

        // ---- Counts row ----
        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Repeater {
                model: [
                    { "label": "Ingresadas", "value": root.countIngresadas(), "color": root.cSuccess },
                    { "label": "No ingresadas", "value": root.countNoIngresadas(), "color": root.cWarn },
                    { "label": "Sin procesar", "value": root.countNoProcesadas(), "color": root.cTextMuted },
                    { "label": "RUTs", "value": root.countTotal(), "color": root.cTextMuted }
                ]
                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: 46
                    radius: 10
                    color: root.cPanel
                    border.width: 1
                    border.color: root.cLine

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 0
                        Label {
                            text: String(modelData.value)
                            color: modelData.color
                            font.pixelSize: Common.Theme.fontSize(18)
                            font.bold: true
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Label {
                            text: modelData.label
                            color: root.cTextMuted
                            font.pixelSize: Common.Theme.fontSize(12)
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                }
            }
        }

        // ---- Open output folder ----
        Common.InsetAlloyButton {
            id: openButton
            alloyTone: "success"
            visible: root.outDir().length > 0
            Layout.fillWidth: true
            Layout.preferredHeight: 40
            text: "Abrir carpeta de salida"
            hoverEnabled: true
            onClicked: controller.openPathInExplorer(root.outDir())
            background: Rectangle {
                radius: 9
                border.width: 1
                border.color: Common.Theme.success
                gradient: Gradient {
                    GradientStop { position: 0.0; color: Common.Theme.success }
                    GradientStop { position: 1.0; color: Common.Theme.success }
                }
            }
            contentItem: Text {
                text: openButton.text
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(14)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }

        // ---- Table: same columns as Clean07_Resultado.xlsx ----
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 12
            color: root.cPanel
            border.width: 1
            border.color: root.cLine
            clip: true

            Flickable {
                id: tableFlick
                anchors.fill: parent
                anchors.margins: 1
                contentWidth: Math.max(width, headerAndRows.implicitWidth)
                contentHeight: headerAndRows.implicitHeight
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                ScrollBar.horizontal: Common.StyledScrollBar { policy: ScrollBar.AsNeeded }
                ScrollBar.vertical: Common.StyledScrollBar { policy: ScrollBar.AsNeeded }

                Column {
                    id: headerAndRows
                    spacing: 0

                    // header row
                    Row {
                        spacing: 0
                        Repeater {
                            model: root.columns()
                            delegate: Rectangle {
                                width: root.columnWidth(modelData)
                                height: 34
                                color: Common.Theme.accentSoft
                                Label {
                                    anchors.fill: parent
                                    anchors.leftMargin: 10
                                    anchors.rightMargin: 6
                                    verticalAlignment: Text.AlignVCenter
                                    text: modelData
                                    color: root.cTextMuted
                                    font.pixelSize: Common.Theme.fontSize(12)
                                    font.bold: true
                                    elide: Text.ElideRight
                                }
                            }
                        }
                    }

                    // data rows
                    Repeater {
                        model: root.tableRows()
                        delegate: Rectangle {
                            width: root.tableWidth()
                            implicitHeight: 32
                            color: (modelData.rowIndex % 2 === 0) ? "transparent" : "#10294780"

                            Row {
                                anchors.fill: parent
                                spacing: 0
                                Repeater {
                                    model: modelData.cells
                                    delegate: Rectangle {
                                        width: root.columnWidth(modelData.header)
                                        height: parent.height
                                        color: "transparent"
                                        Label {
                                            anchors.fill: parent
                                            anchors.leftMargin: 10
                                            anchors.rightMargin: 6
                                            verticalAlignment: Text.AlignVCenter
                                            text: root.cellText(modelData.value)
                                            color: root.cellColor(modelData.header, modelData.value)
                                            font.bold: modelData.header === "ESTADO"
                                            font.pixelSize: Common.Theme.fontSize(12)
                                            elide: Text.ElideRight
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Label {
                anchors.centerIn: parent
                visible: root.countTotal() === 0
                text: root.headline()
                color: root.cTextMuted
                font.pixelSize: Common.Theme.fontSize(13)
            }
        }
    }
}
