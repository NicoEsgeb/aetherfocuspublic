import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import "../common" as Common

ColumnLayout {
    id: root
    spacing: 8
    implicitHeight: childrenRect.height

    property var workspaceConfig: ({})
    property var helpers: ({})
    property string workspaceTaskName: ""
    // Entradas 1-4 (01_mandatos, 02_contratos, 03_demandas, 04_Carpeta-Ruts)
    // son FIJAS: sólo se abren con un botón cada una.
    // Entrada 5 (la planilla) es seleccionable y viaja en el payload.
    property string planillaPath: ""
    property color textMuted: Common.Theme.text2

    signal workspaceTaskNameEdited(string value)
    signal planillaPathEdited(string value)

    Component.onCompleted: {
        if (!workspaceTaskName || workspaceTaskName.length === 0) {
            workspaceTaskNameEdited("CLEAN07_INGRESAR_DEMANDAS_BBRR")
        }
    }

    function validate() {
        var path = String(planillaPath || "").trim()
        if (path.length === 0) {
            return "Selecciona la planilla de ingreso que utilizará Clean07."
        }
        var lower = path.toLowerCase()
        if (!lower.endsWith(".xlsx") && !lower.endsWith(".xlsm")) {
            return "La planilla debe estar en formato .xlsx o .xlsm."
        }
        return ""
    }

    function buildPayload() {
        return {
            planilla_path: String(planillaPath || "").trim(),
            task_name: "CLEAN07_INGRESAR_DEMANDAS_BBRR"
        }
    }

    function toLocalPath(fileUrl) {
        if (helpers && typeof helpers.fileUrlToLocalPath === "function") {
            return helpers.fileUrlToLocalPath(fileUrl)
        }
        return String(fileUrl || "")
    }

    function toFileUrl(pathText) {
        if (helpers && typeof helpers.localPathToFileUrl === "function") {
            return helpers.localPathToFileUrl(pathText)
        }
        return "file:///"
    }

    function defaultInputFolder() {
        return String(workspaceConfig && workspaceConfig.defaultInputFolder ? workspaceConfig.defaultInputFolder : "").trim()
    }

    function subFolderUrl(sub) {
        var base = root.defaultInputFolder()
        if (base.length === 0)
            return "file:///"
        return root.toFileUrl(base + "/" + sub)
    }

    // -----------------------------------------------------------------------
    // Entradas 1-4 — carpetas fijas (01_mandatos, 02_contratos, 03_demandas,
    // 04_Carpeta-Ruts)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: foldersLayout.implicitHeight + 20

        ColumnLayout {
            id: foldersLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "1-4. Carpetas de entrada"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            Label {
                text: "El bot siempre procesa estas cuatro carpetas fijas. Usa los botones para abrirlas y revisarlas."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openMandatosButton
                Layout.fillWidth: true
                text: "Abrir carpeta 01_mandatos"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("01_mandatos"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.line
                    color: openMandatosButton.down ? Common.Theme.accentSoft : Common.Theme.panel2
                }
                contentItem: Text {
                    text: openMandatosButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Label {
                text: "Documentos fijos, iguales en toda corrida: 1_Mandato_11709-2026.pdf, 2_Mandato_37590-2016.pdf, 3_Resolucion_409.pdf, 4_Certificado_2215.pdf, 5_Mandato_9342-2016.pdf. Si falta alguno, el bot no inicia."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openContratosButton
                Layout.fillWidth: true
                text: "Abrir carpeta 02_contratos"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("02_contratos"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.line
                    color: openContratosButton.down ? Common.Theme.accentSoft : Common.Theme.panel2
                }
                contentItem: Text {
                    text: openContratosButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Label {
                text: "Contratos referenciados por la planilla (columna 6_Contrato_CPSB). Si falta alguno de los que la planilla necesita, el bot no inicia."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openDemandasButton
                Layout.fillWidth: true
                text: "Abrir carpeta 03_demandas"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("03_demandas"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.line
                    color: openDemandasButton.down ? Common.Theme.accentSoft : Common.Theme.panel2
                }
                contentItem: Text {
                    text: openDemandasButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Label {
                text: "Un PDF plano por RUT: <RUT-DV>_DEMANDA_firmado.pdf. El bot exige la demanda firmada de CADA fila de la planilla — si falta alguna, no inicia."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Common.InsetAlloyButton {
                id: openCarpetaRutsButton
                Layout.fillWidth: true
                text: "Abrir carpeta 04_Carpeta-Ruts"
                hoverEnabled: true
                onClicked: Qt.openUrlExternally(root.subFolderUrl("04_Carpeta-Ruts"))
                background: Rectangle {
                    radius: 8
                    border.width: 1
                    border.color: Common.Theme.line
                    color: openCarpetaRutsButton.down ? Common.Theme.accentSoft : Common.Theme.panel2
                }
                contentItem: Text {
                    text: openCarpetaRutsButton.text
                    color: Common.Theme.text
                    font.pixelSize: Common.Theme.fontSize(12)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Label {
                text: "Una subcarpeta por RUT con el resto de los documentos de cada demanda (pagarés, cédula, etc.). El bot exige al menos un RUT de la planilla presente aquí."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // -----------------------------------------------------------------------
    // Entrada 5 — planilla de ingreso (seleccionable, abre input/planilla_ingreso)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: planillaLayout.implicitHeight + 20

        ColumnLayout {
            id: planillaLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8

            Label {
                text: "5. Planilla de ingreso"
                color: Common.Theme.text
                font.pixelSize: Common.Theme.fontSize(13)
                font.bold: true
                Layout.fillWidth: true
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TextField {
                    Layout.fillWidth: true
                    text: root.planillaPath
                    color: Common.Theme.text
                    placeholderText: "Selecciona la planilla (.xlsx o .xlsm)"
                    placeholderTextColor: Common.Theme.text3
                    readOnly: true
                    background: Rectangle {
                        radius: 8
                        color: Common.Theme.panel2
                        border.width: 1
                        border.color: Common.Theme.line
                    }
                }

                Common.InsetAlloyButton {
                    id: selectPlanillaButton
                    text: "Seleccionar planilla"
                    hoverEnabled: true
                    onClicked: {
                        var folder = root.defaultInputFolder()
                        if (folder.length > 0) {
                            planillaFileDialog.currentFolder = root.subFolderUrl("planilla_ingreso")
                        }
                        planillaFileDialog.open()
                    }
                    background: Rectangle {
                        radius: 8
                        border.width: 1
                        border.color: Common.Theme.accent
                        color: selectPlanillaButton.down ? Common.Theme.accent : Common.Theme.accentSoft
                    }
                    contentItem: Text {
                        text: selectPlanillaButton.text
                        color: Common.Theme.text
                        font.pixelSize: Common.Theme.fontSize(12)
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }

            Label {
                text: "Antes de abrir el navegador, Clean07 revisa las columnas de la planilla y las cuatro carpetas de entrada (01_mandatos, 02_contratos, 03_demandas, 04_Carpeta-Ruts). Si algo falta, el bot no inicia y verás una notificación con el detalle."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }
    }

    // -----------------------------------------------------------------------
    // Cómo se ejecuta (atendido, con extensión de Chrome)
    // -----------------------------------------------------------------------
    Rectangle {
        Layout.fillWidth: true
        radius: 8
        color: Common.Theme.panel2
        border.width: 1
        border.color: Common.Theme.line
        implicitHeight: bridgeLayout.implicitHeight + 20

        ColumnLayout {
            id: bridgeLayout
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            Label {
                text: "Ejecuta Clean07, inicia sesión manualmente en la Oficina Judicial Virtual y, ya en indexN.php, presiona Start en el panel Clean07. La extensión usa el bridge local 127.0.0.1:8768."
                color: root.textMuted
                font.pixelSize: Common.Theme.fontSize(12)
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }

            Label {
                text: "Extensión Chrome: bots/clean07_ingreso-demandas-bbrr/extension"
                color: Common.Theme.accent
                font.pixelSize: Common.Theme.fontSize(11)
                Layout.fillWidth: true
                wrapMode: Text.WrapAnywhere
            }
        }
    }

    FileDialog {
        id: planillaFileDialog
        title: "Seleccionar planilla de ingreso para Clean07"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Excel (*.xlsx *.xlsm)", "Todos los archivos (*)"]
        onAccepted: root.planillaPathEdited(root.toLocalPath(selectedFile))
    }
}
