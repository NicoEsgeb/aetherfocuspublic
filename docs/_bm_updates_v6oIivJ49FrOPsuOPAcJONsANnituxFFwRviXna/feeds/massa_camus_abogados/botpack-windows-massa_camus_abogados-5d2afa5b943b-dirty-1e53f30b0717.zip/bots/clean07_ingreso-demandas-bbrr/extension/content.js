(() => {
  const MESSAGE_TYPE = "CLEAN07_BRIDGE_REQUEST";
  const PANEL_ID = "clean07-pjud-panel";
  // The N03 bot injects its own panel on the same PJUD origin, anchored to the
  // same corner. When both are loaded, Clean07 stacks itself above N03 instead
  // of covering it.
  const N03_PANEL_ID = "n03-pjud-panel";
  // Shown in the panel title. Reloading the extension does NOT re-inject this
  // script into tabs that are already open, so this marker is the way to tell
  // whether the page is running the current build or a stale one.
  const BUILD = "v0.6.0";
  // The page the operator is meant to press Start from. Start is accepted
  // anywhere on the portal; this only drives the hint text.
  const START_PAGE = "indexn.php";

  let connected = false;
  let starting = false;
  let verified = false;
  let workTimer = 0;
  let busy = false;
  // Set once the desktop confirms the session is done, so the panel shows a
  // friendly message instead of a scary "connection lost" when the bridge
  // server shuts down right after the handshake.
  let completed = false;
  // Repeat guard. The bridge only re-issues a step it never got a report for,
  // so seeing the same one twice means the loop is stuck — and repeating a
  // click on the portal is exactly what gets the session blocked by the WAF.
  let lastStepKey = "";
  let sameStepCount = 0;
  const MAX_STEP_ATTEMPTS = 2;

  async function bridgeRequest(path, options = {}) {
    const payload = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE,
      path,
      options
    });
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  function logToBridge(message) {
    bridgeRequest("/log", { method: "POST", body: { message } }).catch(() => {});
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="clean07-title">Clean07 · Demandas BBRR · ${BUILD}</div>
      <div class="clean07-status" data-role="status">Esperando BotManager...</div>
      <div class="clean07-details" data-role="details">Planilla sin confirmar</div>
      <button type="button" data-role="start">Start</button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", startBridge);
    positionPanel();
    return panel;
  }

  // Keep clear of the N03 panel when both extensions are enabled. Re-checked on
  // every poll because N03 injects asynchronously.
  function positionPanel() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) {
      return;
    }
    const other = document.getElementById(N03_PANEL_ID);
    const offset = other ? other.offsetHeight + 24 : 14;
    panel.style.bottom = `${offset}px`;
  }

  function setStatus(text, tone = "normal") {
    const status = createPanel().querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("clean07-ok", tone === "ok");
    status.classList.toggle("clean07-error", tone === "error");
  }

  function renderSummary(summary) {
    const details = createPanel().querySelector('[data-role="details"]');
    const workbook = summary && summary.workbook ? summary.workbook : {};
    const demandas = summary && summary.demandas ? summary.demandas : {};
    if (!workbook.filename) {
      details.textContent = "Planilla sin confirmar";
      return;
    }
    const rows = summary && summary.row_total ? summary.row_total : 0;
    details.textContent = `${workbook.filename} · ${rows} fila(s) · `
      + `${demandas.pdf_count || 0} PDF(s) en demandas`;
  }

  function onStartPage() {
    return String(window.location.href || "").toLowerCase().includes(START_PAGE);
  }

  // ---------------------------------------------------------------------------
  // Page helpers
  // ---------------------------------------------------------------------------

  // Menu labels arrive padded (" Ingresar Demanda/Recurso") and accented, so
  // compare on a folded form: collapsed whitespace, lowercased, accents removed.
  function foldLabel(value) {
    return String(value == null ? "" : value)
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "");
  }

  function findByLabel(selector, label, root) {
    const target = foldLabel(label);
    const scope = root || document;
    let candidates = [];
    try {
      candidates = Array.from(scope.querySelectorAll(selector));
    } catch (_) {
      return null;
    }
    // Exact label first, so a longer menu entry containing the same words
    // cannot win over the real one.
    return candidates.find((el) => foldLabel(el.textContent) === target)
      || candidates.find((el) => foldLabel(el.textContent).includes(target))
      || null;
  }

  // The portal renders its left menu from Knockout bindings after the page
  // settles, so poll instead of assuming the item exists the moment we look.
  function waitFor(probe, errorMessage, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const immediate = probe();
      if (immediate) {
        resolve(immediate);
        return;
      }
      const deadline = Date.now() + timeoutMs;
      const timer = window.setInterval(() => {
        const found = probe();
        if (found) {
          window.clearInterval(timer);
          resolve(found);
        } else if (Date.now() > deadline) {
          window.clearInterval(timer);
          reject(new Error(errorMessage));
        }
      }, 250);
    });
  }

  // ---------------------------------------------------------------------------
  // Step handlers — one per name in functions.py ROW_STEPS
  // ---------------------------------------------------------------------------

  // The label lives in a <span data-bind="text: ' ' + name">, but the Knockout
  // click binding sits on the .list-group-item wrapper around it, so clicking
  // the span alone would do nothing.
  const MENU_ITEM_SELECTOR = ".list-group-item span, .pg_menu_lt span, li span, a span";
  const MENU_ITEM_WRAPPER = ".list-group-item, .pg_menu_lt, li, a";

  async function clickIngresarDemanda(step) {
    const label = await waitFor(
      () => findByLabel(MENU_ITEM_SELECTOR, "Ingresar Demanda/Recurso"),
      "No se encontró la opción 'Ingresar Demanda/Recurso' en el menú del portal."
    );
    const target = label.closest(MENU_ITEM_WRAPPER) || label.parentElement || label;
    target.click();
    return `Fila ${step.row_number}/${step.total}: se abrió "Ingresar Demanda/Recurso".`;
  }

  // --- select2 v3 driver -----------------------------------------------------
  // The portal keeps ONE shared drop element (#select2-drop) that select2
  // repositions and refills for whichever control is open — the ids inside it
  // (select2-results-27/-28/-1, s2id_autogenN_search) belong to the control,
  // not to the drop, and can shift between page loads. So: open the control,
  // then read whatever the shared drop currently holds. Never the reverse.
  const SELECT2_DROP_ID = "select2-drop";

  function fireMouse(element, type) {
    element.dispatchEvent(new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window,
      button: 0
    }));
  }

  function select2Chosen(container) {
    const chosen = container.querySelector(".select2-chosen");
    return chosen ? foldLabel(chosen.textContent) : "";
  }

  function isVisible(element) {
    return Boolean(element) && window.getComputedStyle(element).display !== "none";
  }

  // Find the drop that belongs to THIS control. The container's focusser carries
  // the control's autogen id (s2id_autogenN) and the open drop holds the matching
  // search input (s2id_autogenN_search) — that link is exact, whereas the
  // #select2-drop id is shared and stale `select2-drop-active` copies of other
  // fields linger in the DOM with display:none.
  function findSelect2Drop(container) {
    const focusser = container.querySelector("input.select2-focusser");
    if (focusser && focusser.id) {
      const search = document.getElementById(`${focusser.id}_search`);
      const own = search && search.closest(".select2-drop");
      if (isVisible(own)) {
        return own;
      }
    }
    const shared = document.getElementById(SELECT2_DROP_ID);
    return isVisible(shared) ? shared : null;
  }

  // Resolve a select2 container that has NO stable id. select2 v3 inserts its
  // container immediately BEFORE the element it decorates, so the Knockout
  // binding name — application source, not a per-render id — is the stable
  // anchor. Procedimiento's source div carries no id (unlike Corte's
  // #select-asientoCorte), so select2 autogenerated #s2id_autogen171 for it;
  // that number drifts between renders (its own focusser was 172) and must
  // never be hardcoded.
  function findSelect2ContainerByBinding(bindingName) {
    const bound = Array.from(document.querySelectorAll("div[data-bind]"))
      .find((el) => el.classList.contains("select2")
        && !el.classList.contains("select2-container")
        && String(el.getAttribute("data-bind")).includes(bindingName));
    const container = bound && bound.previousElementSibling;
    return container && container.classList.contains("select2-container")
      ? container
      : null;
  }

  async function openSelect2El(container, fieldLabel) {
    await waitFor(
      () => !container.classList.contains("select2-container-disabled") || null,
      `El campo ${fieldLabel} sigue deshabilitado.`,
      10000
    );
    const choice = container.querySelector("a.select2-choice");
    if (!choice) {
      throw new Error(`El campo ${fieldLabel} no expone el control select2.`);
    }
    // select2 v3 opens on MOUSEDOWN — a bare .click() leaves it closed.
    fireMouse(choice, "mousedown");
    fireMouse(choice, "mouseup");
    fireMouse(choice, "click");
    const drop = await waitFor(
      () => findSelect2Drop(container),
      `No se abrió el desplegable de ${fieldLabel}.`,
      8000
    );
    return { container, drop };
  }

  // Knockout only renders Corte/Tribunal once Competencia is set, so the
  // container may not exist yet when the step starts.
  async function openSelect2(containerId, fieldLabel) {
    const container = await waitFor(
      () => document.getElementById(containerId),
      `No se encontró el campo ${fieldLabel} (#${containerId}).`,
      10000
    );
    return openSelect2El(container, fieldLabel);
  }

  // Option rows carry padding whitespace ("C.A. de Santiago      ", "   Juzgado
  // de Letras de Colina"), so match on the folded text — and only EXACTLY, so a
  // near neighbour like "C.A. de San Miguel" can never be picked by accident.
  function findSelect2Option(drop, optionLabel) {
    const target = foldLabel(optionLabel);
    const items = Array.from(drop.querySelectorAll("li.select2-result-selectable"));
    return items.find((li) => foldLabel(li.textContent) === target) || null;
  }

  // select2 v3 selects on MOUSEUP, not click, so a bare .click() on the row does
  // nothing. Send the full sequence a real pointer would produce.
  function chooseSelect2Option(item) {
    fireMouse(item, "mousedown");
    fireMouse(item, "mouseup");
    fireMouse(item, "click");
  }

  // Matching stays EXACT, so a near neighbour can never be picked by accident.
  // The cost is that a value whose wording is slightly off just fails — so when
  // it does, report what the portal actually offered. That turns a guessing loop
  // into a single fix.
  function listSelect2Options(drop, max = 30) {
    const items = Array.from(drop.querySelectorAll("li.select2-result-selectable"))
      .map((li) => String(li.textContent).replace(/\s+/g, " ").trim())
      .filter(Boolean);
    if (!items.length) {
      return "(ninguna)";
    }
    const shown = items.slice(0, max).join(" · ");
    return items.length > max ? `${shown} … (+${items.length - max} más)` : shown;
  }

  async function setSelect2El(container, fieldLabel, optionLabel) {
    const { drop } = await openSelect2El(container, fieldLabel);
    let item = null;
    try {
      item = await waitFor(() => findSelect2Option(drop, optionLabel), "no-match", 10000);
    } catch (_) {
      throw new Error(
        `No apareció la opción "${optionLabel}" en ${fieldLabel}. `
        + `El portal ofrece: ${listSelect2Options(drop)}`
      );
    }
    chooseSelect2Option(item);
    // Read back: never move on trusting that the click landed.
    await waitFor(
      () => select2Chosen(container) === foldLabel(optionLabel) || null,
      `${fieldLabel} no quedó en "${optionLabel}" tras seleccionarlo.`,
      8000
    );
  }

  async function setSelect2(containerId, fieldLabel, optionLabel) {
    const container = await waitFor(
      () => document.getElementById(containerId),
      `No se encontró el campo ${fieldLabel} (#${containerId}).`,
      10000
    );
    return setSelect2El(container, fieldLabel, optionLabel);
  }

  // --- steps -----------------------------------------------------------------

  // Competencia is NOT select2: it is a native <select> bound by Knockout. Every
  // <option> carries value="" (Knockout keeps the real objects itself), so
  // assigning .value does nothing — the option must be chosen by index, and the
  // change event dispatched by hand or Knockout never learns about it.
  const COMPETENCIA_SELECT = 'select[data-bind*="options: competencias"]';
  const CORTE_CONTAINER_ID = "s2id_select-asientoCorte";
  const TRIBUNAL_CONTAINER_ID = "s2id_select-tribunales";
  const DIRIGIDO_A_CONTAINER_ID = "s2id_select-usuarios";

  async function selectCompetencia(step) {
    const wanted = String(step.value || "");
    const select = await waitFor(
      () => document.querySelector(COMPETENCIA_SELECT),
      "No se cargó el formulario de ingreso (no apareció Competencia)."
    );
    const option = Array.from(select.options)
      .find((opt) => foldLabel(opt.textContent) === foldLabel(wanted));
    if (!option) {
      throw new Error(`La competencia "${wanted}" no existe en el formulario.`);
    }
    select.selectedIndex = option.index;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    await waitFor(
      () => foldLabel(select.options[select.selectedIndex].textContent)
        === foldLabel(wanted) || null,
      `Competencia no quedó en "${wanted}".`,
      8000
    );
    return `Fila ${step.row_number}/${step.total}: Competencia = ${wanted}.`;
  }

  async function selectCorte(step) {
    const wanted = String(step.value || "");
    await setSelect2(CORTE_CONTAINER_ID, "Corte", wanted);
    return `Fila ${step.row_number}/${step.total}: Corte = ${wanted}.`;
  }

  async function selectTribunal(step) {
    const wanted = String(step.value || "");
    await setSelect2(TRIBUNAL_CONTAINER_ID, "Tribunal", wanted);
    return `Fila ${step.row_number}/${step.total}: Tribunal = ${wanted}.`;
  }

  // "Dirigido a" arrives pre-selected with the patrocinating abogado. Touching a
  // field that is already correct only risks changing it, so this reads first
  // and selects only when the portal defaulted to somebody else.
  async function ensureDirigidoA(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => document.getElementById(DIRIGIDO_A_CONTAINER_ID),
      "No se encontró el campo Dirigido a."
    );
    if (select2Chosen(container) === foldLabel(wanted)) {
      return `Fila ${step.row_number}/${step.total}: Dirigido a ya estaba en ${wanted}.`;
    }
    await setSelect2(DIRIGIDO_A_CONTAINER_ID, "Dirigido a", wanted);
    return `Fila ${step.row_number}/${step.total}: Dirigido a corregido a ${wanted}.`;
  }

  // "Fijar Datos" is a real <input type="checkbox"> paired with a <label for=...>
  // styled as a button — not a select2 widget. Clicking the label toggles the
  // checkbox and fires Knockout's native "checked" binding via the browser's
  // own for/id association, so no synthetic mousedown/mouseup dance is needed
  // here. Only click when it is not already checked, so a re-issued step (a
  // reloaded tab re-asking for this step) never un-checks it by accident.
  // There is MORE THAN ONE "Fijar Datos" on the form — the tribunal block and
  // the Ingreso de Demanda card each have their own, and both render exactly
  // that text. Never find them by label; the checkbox id is the only thing that
  // tells them apart, and it arrives as the step value.
  const FIJAR_DATOS_MODULES = {
    id_check_fijar_mod_tribunal: "tribunal",
    id_check_fijar_mod_materia: "materias"
  };

  async function clickFijarDatos(step) {
    const checkboxId = String(step.value || "").trim();
    if (!checkboxId) {
      throw new Error("El paso 'Fijar Datos' llegó sin el id del checkbox.");
    }
    const where = FIJAR_DATOS_MODULES[checkboxId] || checkboxId;
    const checkbox = await waitFor(
      () => document.getElementById(checkboxId),
      `No se encontró el botón 'Fijar Datos' de ${where} (#${checkboxId}).`
    );
    if (checkbox.checked) {
      return `Fila ${step.row_number}/${step.total}: Fijar Datos (${where}) ya estaba marcado.`;
    }
    const label = document.querySelector(`label[for="${checkboxId}"]`) || checkbox;
    label.click();
    await waitFor(
      () => checkbox.checked || null,
      `'Fijar Datos' (${where}) no quedó marcado tras hacer click.`,
      8000
    );
    return `Fila ${step.row_number}/${step.total}: se marcó "Fijar Datos" (${where}).`;
  }

  // Procedimiento lives in the "Ingreso de Demanda" card, which Knockout renders
  // only for competencias 1/2/3/7/8/9 — Civil is one of them. It has no stable
  // id, so it is reached through its binding (see findSelect2ContainerByBinding).
  const PROCEDIMIENTO_BINDING = "procedimientoSeleccionado";

  async function selectProcedimiento(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => findSelect2ContainerByBinding(PROCEDIMIENTO_BINDING),
      "No se encontró el campo Procedimiento (¿se cargó la tarjeta 'Ingreso de Demanda'?)."
    );
    await setSelect2El(container, "Procedimiento", wanted);
    return `Fila ${step.row_number}/${step.total}: Procedimiento = ${wanted}.`;
  }

  // Materia sits in the same card as Procedimiento and is reached the same way.
  // Unlike Procedimiento it keeps its OWN nested .select2-drop inside the
  // container; while closed that copy is select2-display-none, so the isVisible
  // guard in findSelect2Drop skips it and falls through to the shared drop.
  const MATERIA_BINDING = "materiaSeleccionada";

  async function selectMateria(step) {
    const wanted = String(step.value || "");
    const container = await waitFor(
      () => findSelect2ContainerByBinding(MATERIA_BINDING),
      "No se encontró el campo Materia."
    );
    await setSelect2El(container, "Materia", wanted);
    return `Fila ${step.row_number}/${step.total}: Materia = ${wanted}.`;
  }

  const STEP_HANDLERS = {
    click_ingresar_demanda: clickIngresarDemanda,
    select_competencia: selectCompetencia,
    select_corte: selectCorte,
    select_tribunal: selectTribunal,
    ensure_dirigido_a: ensureDirigidoA,
    click_fijar_datos: clickFijarDatos,
    select_procedimiento: selectProcedimiento,
    select_materia: selectMateria,
    // Same handler; the checkbox id comes from STEP_VALUES.
    click_fijar_datos_materia: clickFijarDatos
  };

  // End of session. Stops the work loop BEFORE the bridge server shuts down, so
  // the panel keeps the result message instead of flipping to "connection lost".
  function finish(payload, tone) {
    completed = true;
    window.clearInterval(workTimer);
    const failed = tone === "error" || Boolean(payload && payload.error);
    const message = (payload && payload.message)
      || (failed ? "El bot se detuvo por un error." : "Conexión verificada con BotManager.");
    // The desktop message is shown verbatim; the hint goes on the second line so
    // the operator reads the outcome first.
    setStatus(message, failed ? "error" : "ok");
    createPanel().querySelector('[data-role="details"]').textContent =
      "Revisa el resultado en BotManager.";
  }

  // Hard stop: no more work is pulled from the bridge. Used whenever continuing
  // could repeat an action on the portal. Recovery is deliberately manual
  // (reload the page and press Start again) so nothing touches PJUD by itself.
  function stopPump(message) {
    completed = true;
    window.clearInterval(workTimer);
    setStatus(message, "error");
    logToBridge(message);
  }

  // Reporting is what lets the bridge advance, so a failed report means the
  // next /next would hand out the SAME step again. Stop instead of looping.
  async function reportStep(body) {
    try {
      return await bridgeRequest("/report", { method: "POST", body });
    } catch (error) {
      const detail = String(error && error.message ? error.message : error);
      stopPump(
        `No se pudo informar el resultado a BotManager (${detail}). `
        + "El bot se detuvo para no repetir el paso en el portal. "
        + "Recarga la página y presiona Start de nuevo."
      );
      return null;
    }
  }

  async function pumpWork() {
    if (!verified || busy || completed) {
      return;
    }
    busy = true;
    try {
      const payload = await bridgeRequest("/next", { method: "POST", body: {} });
      const step = payload.step || {};

      if (step.action === "wait") {
        return;
      }
      if (step.action === "done") {
        finish(step);
        return;
      }

      const handler = STEP_HANDLERS[step.action];
      if (!handler) {
        // The desktop asked for a step this build does not know: the tab is
        // running a stale content script. Say so instead of stalling silently.
        setStatus(
          `Paso desconocido "${step.action}". Recarga la página del portal.`,
          "error"
        );
        return;
      }

      const stepKey = `${step.row_number}:${step.step_number}:${step.action}`;
      if (stepKey === lastStepKey) {
        sameStepCount += 1;
      } else {
        lastStepKey = stepKey;
        sameStepCount = 1;
      }
      if (sameStepCount > MAX_STEP_ATTEMPTS) {
        stopPump(
          `El paso ${step.step_number} se repitió sin avanzar. El bot se detuvo `
          + "para no insistir sobre el portal. Revisa BotManager."
        );
        return;
      }

      setStatus(
        `Fila ${step.row_number}/${step.total} · paso ${step.step_number}/${step.step_total}...`
      );
      try {
        const detail = await handler(step);
        setStatus(detail, "ok");
        logToBridge(detail);
        const reply = await reportStep({ ok: true, detail });
        if (reply && reply.done) {
          finish(reply);
        }
      } catch (error) {
        const detail = String(error && error.message ? error.message : error);
        setStatus(`Error: ${detail}`, "error");
        logToBridge(detail);
        // There is no recovery route on the portal yet, so the desktop stops
        // the run on a failure and answers this report with done.
        const reply = await reportStep({ ok: false, detail });
        if (reply && reply.done) {
          finish(reply, "error");
        }
      }
    } catch (_) {
      if (completed) {
        return; // finished cleanly; the server just shut down.
      }
      connected = false;
      setStatus("Se perdió la conexión con BotManager.", "error");
    } finally {
      busy = false;
    }
  }

  async function pollBridge() {
    positionPanel();
    if (verified || starting || completed) {
      return;
    }
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      setStatus(
        onStartPage()
          ? "Bridge conectado. Presiona Start."
          : "Bridge conectado. Ve a indexN.php y presiona Start.",
        "ok"
      );
    } catch (_) {
      connected = false;
      setStatus("Bridge no conectado. Ejecuta Clean07 en BotManager.", "error");
    }
  }

  async function startBridge() {
    if (starting || verified) {
      return;
    }
    const button = createPanel().querySelector('[data-role="start"]');
    starting = true;
    button.disabled = true;
    setStatus("Enlazando con BotManager...");
    try {
      if (!connected) {
        await bridgeRequest("/health");
      }
      const payload = await bridgeRequest("/start", {
        method: "POST",
        body: { url: window.location.href, title: document.title }
      });
      verified = true;
      renderSummary(payload.summary);
      setStatus(payload.message || "Conexión confirmada.", "ok");
      button.textContent = "Conectado";
      workTimer = window.setInterval(pumpWork, 1200);
      pumpWork();
    } catch (error) {
      connected = false;
      button.disabled = false;
      setStatus(`Error: ${error.message || error}`, "error");
    } finally {
      starting = false;
    }
  }

  createPanel();
  pollBridge();
  window.setInterval(pollBridge, 2500);
})();
