import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import "common" as Common

ApplicationWindow {
    id: root
    width: 1480
    height: 920
    minimumWidth: 1160
    minimumHeight: 740
    visible: true
    title: root.brandDisplayName
    color: Common.Theme.bg

    property var formValues: ({})
    property bool bootAnimationReady: false
    property string workspaceTaskName: ""
    property string workspacePythonOverride: ""
    property string workspaceMatrixPath: ""
    property string workspaceGetCaratulasMatrixPath: ""
    property string workspaceFechaDesdeCaratulas: ""
    property string workspaceFechaHastaCaratulas: ""
    property string workspaceInformeCausasPath: ""
    property string workspaceDemandasPath: ""
    property string workspaceCaratulasPath: ""
    property string workspacePlanillaPath: ""
    property string workspaceEstadoDiarioPath: ""
    property string workspaceMovimientosPath: ""
    property string workspaceConfigSignature: ""
    property string workspaceValidationMessage: ""
    property int runDetailTabIndex: 0
    property int mainTabIndex: 0
    property string runFilter: "todos"
    property int hoveredSidebarBotId: -1
    property string lastCompletionNotificationKey: ""
    property int completionNotificationTargetRunId: 0
    property bool completionNotificationArmed: false
    property var activeCompletionNotification: ({})
    readonly property bool workspaceRunBusy: hasInFlightRun(Number(controller.lastTriggeredRunId || 0))
    readonly property string appVersion: "v 1.0.2"
    readonly property string clientName: ""
    // Branding (Phase 3): read once from controller.branding; every value is
    // "" without a branding.json, so all bindings fall back to today's look.
    readonly property var branding: controller && controller.branding ? controller.branding : ({})
    readonly property string brandCompanyName: branding.companyName ? String(branding.companyName) : ""
    readonly property string brandLogoUrl: branding.logoUrl ? String(branding.logoUrl) : ""
    readonly property string brandDisplayName: brandCompanyName.length > 0 ? brandCompanyName : "Centro de Automatizaciones"
    // License (Phase 4): gatingActive is false in dev mode (no public key), so
    // the banner below never shows and today's UI is untouched.
    readonly property var license: controller && controller.license ? controller.license : ({})
    readonly property bool licenseBlocked: license.gatingActive === true && license.status !== "valid"
    readonly property string licenseMessage: license.message ? String(license.message) : ""

    // Updates (Phase 7): enabled only on packaged installs with an update
    // channel; in dev installs nothing below renders — UI unchanged.
    readonly property var updatesInfo: controller && controller.updates ? controller.updates : ({})
    readonly property bool updatesEnabled: updatesInfo.enabled === true
    readonly property string updatesState: updatesInfo.state ? String(updatesInfo.state) : ""
    readonly property string updatesMessage: updatesInfo.message ? String(updatesInfo.message) : ""
    readonly property string updatesBannerKey: updatesState + "|" + updatesMessage
    readonly property bool updatesBannerVisible: updatesEnabled
        && updatesInfo.announce === true
        && interfaceSettings.dismissedUpdatesBannerKey !== updatesBannerKey
    property real uiScale: controller && controller.uiScale > 0 ? controller.uiScale : 1.0
    readonly property real fontScale: Math.max(0.85, Math.min(1.25, Number(interfaceSettings.fontScale) || 1.0))

    Settings {
        id: interfaceSettings
        category: "Interface"
        property real fontScale: 1.0
        property string dismissedUpdatesBannerKey: ""
    }

    onMainTabIndexChanged: {
        if (mainTabIndex === 1 && controller) {
            controller.refreshBotInfoDependencies()
        }
    }

    // Palette kept as aliases onto the Theme singleton so the existing injected
    // color-prop bindings (into workspace_info / workspace_tasks panels) and any
    // residual references re-theme automatically with the chosen theme.
    readonly property color cGlass: Common.Theme.panel2
    readonly property color cPanel: Common.Theme.panel
    readonly property color cPanelSoft: Common.Theme.panel2
    readonly property color cLine: Common.Theme.line
    readonly property color cTextMain: Common.Theme.text
    readonly property color cTextMuted: Common.Theme.text2
    readonly property color cAccent: Common.Theme.accent
    readonly property color cAccentStrong: Common.Theme.accent
    readonly property color cSuccess: Common.Theme.success
    readonly property color cWarning: Common.Theme.warning
    readonly property color cDanger: Common.Theme.danger

    // Drive the Theme singleton from the persisted controller setting.
    Binding {
        target: Common.Theme
        property: "mode"
        value: controller.themeMode
    }

    Binding {
        target: Common.Theme
        property: "fontScale"
        value: root.fontScale
    }

    // Branding accent (Phase 3): "" when no branding.json → Theme defaults.
    Binding {
        target: Common.Theme
        property: "brandAccent"
        value: root.branding.accentColor ? String(root.branding.accentColor) : ""
    }

    function statusColor(status) {
        var s = String(status).toLowerCase()
        if (s === "success") {
            return Common.Theme.success
        }
        if (s === "failed") {
            return Common.Theme.danger
        }
        if (s === "running") {
            return Common.Theme.accent
        }
        if (s === "queued") {
            return Common.Theme.warning
        }
        if (s === "cancelled" || s === "cancelado" || s === "detenido") {
            return Common.Theme.cancel
        }
        if (s === "pending" || s === "pendientes" || s === "parcial") {
            return Common.Theme.warning
        }
        return Common.Theme.text3
    }

    // Map a technical status to a StatusPill variant (ok/fail/running/queued/cancel).
    function statusVariant(status) {
        var s = String(status).toLowerCase()
        if (s === "success") {
            return "ok"
        }
        if (s === "failed") {
            return "fail"
        }
        if (s === "running") {
            return "running"
        }
        if (s === "cancelled" || s === "cancelado" || s === "detenido") {
            return "cancel"
        }
        if (s === "queued" || s === "pending" || s === "pendientes" || s === "parcial") {
            return "queued"
        }
        return "queued"
    }

    function hasInFlightRun(runId) {
        if (runId <= 0 || !controller) {
            return false
        }

        var runs = controller.runs || []
        for (var i = 0; i < runs.length; i++) {
            var runItem = runs[i]
            if (Number(runItem.id || 0) !== runId) {
                continue
            }
            var runStatus = String(runItem.statusTechnical || runItem.status || "").toLowerCase()
            return runStatus === "queued" || runStatus === "running"
        }

        var detail = controller.runDetail || {}
        if (Number(detail.id || 0) === runId) {
            var detailStatus = String(detail.statusTechnical || detail.status || "").toLowerCase()
            return detailStatus === "queued" || detailStatus === "running"
        }
        return false
    }

    // Filter the run list for the history filter chips (todos/exito/fallidos/curso).
    function filterRuns(runs, filter) {
        var list = runs || []
        if (filter === "todos") {
            return list
        }
        var out = []
        for (var i = 0; i < list.length; i++) {
            var key = String(list[i].statusKey || list[i].statusTechnical || list[i].status || "").toLowerCase()
            if (filter === "exito" && key === "success") {
                out.push(list[i])
            } else if (filter === "fallidos" && key === "failed") {
                out.push(list[i])
            } else if (filter === "curso" && (key === "running" || key === "queued")) {
                out.push(list[i])
            }
        }
        return out
    }

    function detailValue(key, fallback) {
        if (!controller.runDetail || controller.runDetail[key] === undefined || controller.runDetail[key] === null || controller.runDetail[key] === "") {
            return fallback
        }
        return controller.runDetail[key]
    }

    function setFormValue(key, value) {
        var next = {}
        for (var current in formValues) {
            next[current] = formValues[current]
        }
        next[key] = value
        formValues = next
    }

    function getFormValue(key, fallback) {
        if (formValues[key] === undefined || formValues[key] === null) {
            return fallback
        }
        return formValues[key]
    }

    function resetFormFields() {
        var values = {}
        for (var i = 0; i < controller.inputFields.length; i++) {
            var field = controller.inputFields[i]
            if (field.default !== undefined && field.default !== null && field.default !== "") {
                values[field.key] = field.default
            } else {
                values[field.key] = field.type === "boolean" ? false : ""
            }
        }
        formValues = values
    }

    function buildPayload() {
        var payload = {}
        for (var i = 0; i < controller.inputFields.length; i++) {
            var field = controller.inputFields[i]
            payload[field.key] = getFormValue(field.key, field.default !== undefined ? field.default : (field.type === "boolean" ? false : ""))
        }
        return payload
    }

    function syncWorkspaceDefaults() {
        if (!controller.workspaceConfig) {
            workspaceTaskName = ""
            workspacePythonOverride = ""
            workspaceMatrixPath = ""
            workspaceGetCaratulasMatrixPath = ""
            workspaceFechaDesdeCaratulas = ""
            workspaceFechaHastaCaratulas = ""
            workspaceInformeCausasPath = ""
            workspaceDemandasPath = ""
            workspaceCaratulasPath = ""
            workspacePlanillaPath = ""
            workspaceEstadoDiarioPath = ""
            workspaceMovimientosPath = ""
            workspaceConfigSignature = ""
            workspaceValidationMessage = ""
            return
        }

        var signature = String(controller.selectedBot.id || 0)
            + "|" + String(controller.workspaceConfig.workingDir || "")
            + "|" + String(controller.workspaceConfig.kind || "")
        var isSameWorkspace = signature === workspaceConfigSignature

        var defaultTask = controller.workspaceConfig.defaultTask ? String(controller.workspaceConfig.defaultTask) : ""
        var defaultMatrixIngreso = controller.workspaceConfig.defaultMatrixName ? String(controller.workspaceConfig.defaultMatrixName) : ""
        var defaultMatrixGetCaratulas = defaultMatrixIngreso && defaultMatrixIngreso.length > 0
            ? defaultMatrixIngreso
            : "Matriz_Demandas/BOT_MATRIZ_DEMANDAS_ingreso.xlsx"
        var defaultInforme = controller.workspaceConfig.defaultInformePath ? String(controller.workspaceConfig.defaultInformePath) : ""
        var defaultMatrixFolder = controller.workspaceConfig.defaultMatrixFolder ? String(controller.workspaceConfig.defaultMatrixFolder) : ""
        var defaultDemandasFolder = root.pathDirectory(defaultMatrixFolder)
        var defaultCaratulasFolder = controller.workspaceConfig.defaultCaratulasFolder
            ? String(controller.workspaceConfig.defaultCaratulasFolder)
            : ""
        var isPjudIngreso = controller.workspaceConfig.kind && controller.workspaceConfig.kind === "pjud_ingreso"
        var taskOptions = controller.workspaceConfig.taskOptions ? controller.workspaceConfig.taskOptions : []
        if (!defaultTask && taskOptions.length > 0) {
            defaultTask = String(taskOptions[0])
        }
        if (!workspaceTaskName || taskOptions.indexOf(workspaceTaskName) < 0 || !isSameWorkspace) {
            workspaceTaskName = defaultTask
        }
        if (!isSameWorkspace) {
            workspacePythonOverride = ""
            workspaceMatrixPath = isPjudIngreso
                ? (defaultMatrixIngreso && defaultMatrixIngreso.length > 0
                    ? defaultMatrixIngreso
                    : "Matriz_Demandas/BOT_MATRIZ_DEMANDAS_ingreso.xlsx")
                : ""
            workspaceGetCaratulasMatrixPath = isPjudIngreso ? defaultMatrixGetCaratulas : ""
            workspaceFechaDesdeCaratulas = ""
            workspaceFechaHastaCaratulas = ""
            workspaceInformeCausasPath = ""
            workspaceDemandasPath = isPjudIngreso ? defaultDemandasFolder : ""
            workspaceCaratulasPath = isPjudIngreso ? defaultCaratulasFolder : ""
            workspacePlanillaPath = ""
            workspaceEstadoDiarioPath = ""
            workspaceMovimientosPath = ""
            workspaceValidationMessage = ""
        }
        workspaceConfigSignature = signature
    }

    function fileUrlToLocalPath(fileUrl) {
        if (!fileUrl) {
            return ""
        }
        var value = String(fileUrl)
        if (!value.startsWith("file://")) {
            return value
        }
        var path = decodeURIComponent(value.substring(7))
        if (Qt.platform.os === "windows" && path.startsWith("/")) {
            path = path.substring(1)
        }
        return path
    }

    function localPathToFileUrl(localPath) {
        if (!localPath || localPath.length === 0) {
            return "file:///"
        }
        var normalized = String(localPath)
        if (normalized.startsWith("file://")) {
            return normalized
        }
        if (Qt.platform.os === "windows") {
            normalized = normalized.replace(/\\/g, "/")
            if (!normalized.startsWith("/")) {
                normalized = "/" + normalized
            }
        }
        return "file://" + encodeURI(normalized)
    }

    function pathDirectory(pathText) {
        if (!pathText || String(pathText).length === 0) {
            return ""
        }
        var value = String(pathText)
        var slashIndex = Math.max(value.lastIndexOf("/"), value.lastIndexOf("\\"))
        if (slashIndex < 0) {
            return ""
        }
        return value.substring(0, slashIndex)
    }

    function isValidDateDmy(value) {
        var text = String(value || "").trim()
        var match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
        if (!match) {
            return false
        }
        var day = Number(match[1])
        var month = Number(match[2])
        var year = Number(match[3])
        var date = new Date(year, month - 1, day)
        return date.getFullYear() === year
            && date.getMonth() === (month - 1)
            && date.getDate() === day
    }

    function compareDateDmy(dateA, dateB) {
        var a = String(dateA || "").trim().split("/")
        var b = String(dateB || "").trim().split("/")
        if (a.length !== 3 || b.length !== 3) {
            return 0
        }
        var aKey = Number(a[2]) * 10000 + Number(a[1]) * 100 + Number(a[0])
        var bKey = Number(b[2]) * 10000 + Number(b[1]) * 100 + Number(b[0])
        if (aKey < bKey) {
            return -1
        }
        if (aKey > bKey) {
            return 1
        }
        return 0
    }

    function normalizedWorkspaceTask(taskName) {
        return String(taskName || "").replace(/[^A-Za-z0-9]/g, "").toLowerCase()
    }

    function workspaceMatrixValueForTask(taskName) {
        var normalizedTask = normalizedWorkspaceTask(taskName)
        if (normalizedTask === "rpa06getcaratulas") {
            return workspaceGetCaratulasMatrixPath
        }
        return workspaceMatrixPath
    }

    function setWorkspaceMatrixValueForTask(taskName, value) {
        var normalizedTask = normalizedWorkspaceTask(taskName)
        if (normalizedTask === "rpa06getcaratulas") {
            workspaceGetCaratulasMatrixPath = value
            return
        }
        workspaceMatrixPath = value
    }

    function workspaceTasksModuleSource() {
        if (!controller.workspaceConfig) {
            return ""
        }
        if (controller.workspaceConfig.tasksComponent && String(controller.workspaceConfig.tasksComponent).trim().length > 0) {
            return String(controller.workspaceConfig.tasksComponent)
        }
        return ""
    }

    function runWorkspaceConfiguredBot() {
        var payload = {}
        var moduleSource = root.workspaceTasksModuleSource()
        workspaceValidationMessage = ""
        if (!moduleSource || moduleSource.length === 0) {
            workspaceValidationMessage = "Este bot no tiene tasks_component configurado."
            return
        }
        if (workspaceTaskName && workspaceTaskName.length > 0) {
            payload.task_name = workspaceTaskName
        }
        if (!workspaceTasksPanelLoader.item) {
            workspaceValidationMessage = "No se pudo cargar el formulario de la task."
            return
        }
        if (workspaceTasksPanelLoader.item["validate"]) {
            var validationMessage = workspaceTasksPanelLoader.item["validate"]()
            if (validationMessage && validationMessage.length > 0) {
                workspaceValidationMessage = validationMessage
                return
            }
        }
        if (workspaceTasksPanelLoader.item["buildPayload"]) {
            var taskPayload = workspaceTasksPanelLoader.item["buildPayload"]()
            for (var payloadKey in taskPayload) {
                payload[payloadKey] = taskPayload[payloadKey]
            }
        }
        if (workspacePythonOverride && workspacePythonOverride.trim().length > 0) {
            payload.bot_ui_python = workspacePythonOverride.trim()
        }
        if (workspaceDemandasPath && workspaceDemandasPath.trim().length > 0) {
            payload.demandas_folder_path = workspaceDemandasPath.trim()
        }
        if (workspaceCaratulasPath && workspaceCaratulasPath.trim().length > 0) {
            payload.caratulas_folder_path = workspaceCaratulasPath.trim()
        }
        if (workspaceEstadoDiarioPath && workspaceEstadoDiarioPath.trim().length > 0) {
            payload.estado_diario_path = workspaceEstadoDiarioPath.trim()
        }
        if (workspaceMovimientosPath && workspaceMovimientosPath.trim().length > 0) {
            payload.movimientos_path = workspaceMovimientosPath.trim()
        }
        controller.executeCurrentBot(JSON.stringify(payload))
    }

    function lastLogCapture(pattern, groupIndex) {
        var text = String(root.detailValue("logText", ""))
        var match
        var last = ""
        pattern.lastIndex = 0
        while ((match = pattern.exec(text)) !== null) {
            last = String(match[groupIndex] || "").trim()
        }
        return last
    }

    function clean05FallbackCompletionNotification() {
        var status = String(root.detailValue("statusTechnical", "")).toLowerCase()
        var selectedKey = String(controller.selectedBot
                                 ? (controller.selectedBot.key || "") : "").toLowerCase()
        var botName = String(root.detailValue("botName", "")).toLowerCase()
        var isClean05 = selectedKey.indexOf("clean05_emerix_extension") >= 0
            || botName.indexOf("clean05") >= 0
        if (!isClean05 || (status !== "failed" && status !== "success")) {
            return ({ "show": false })
        }

        var runId = Number(root.detailValue("id", 0))
        var missing = root.lastLogCapture(
            /\[CLEAN05\]\[COLUMNAS_FALTANTES\]\s+([^\r\n]+)/g, 1)
        var sheet = root.lastLogCapture(
            /\[CLEAN05\]\[COLUMNAS_HOJA\]\s+([^\r\n]+)/g, 1)
        var filename = root.lastLogCapture(
            /\[CLEAN05\]\[ARCHIVO\]\s+([^\r\n]+)/g, 1)

        if (status === "failed" && missing.length > 0) {
            var missingDetails = [{
                "text": "Columna(s) faltante(s): " + missing,
                "color": String(Common.Theme.danger),
                "bold": true
            }]
            if (filename.length > 0) {
                missingDetails.push({
                    "text": "Archivo: " + filename,
                    "color": String(Common.Theme.text2),
                    "bold": false
                })
            }
            if (sheet.length > 0) {
                missingDetails.push({
                    "text": "Hoja revisada: " + sheet,
                    "color": String(Common.Theme.text2),
                    "bold": false
                })
            }
            return ({
                "show": true,
                "key": "clean05_missing_columns_" + runId,
                "tone": "error",
                "title": "Clean05 no pudo iniciar",
                "message": "El bridge no se abrió porque la planilla no contiene todas las columnas necesarias. Corrige el Excel y vuelve a iniciar el bot.",
                "confirmText": "Entendido",
                "confirmTone": "primary",
                "detailLines": missingDetails
            })
        }

        var logText = String(root.detailValue("logText", ""))
        var gestionPattern = /\[CLEAN05\]\[GESTION_SIN_MAPA\]\s+([^\r\n]+)/g
        var gestionMatch
        var gestionDetails = []
        while ((gestionMatch = gestionPattern.exec(logText)) !== null) {
            gestionDetails.push({
                "text": String(gestionMatch[1] || "").trim(),
                "color": String(Common.Theme.warning),
                "bold": true
            })
        }
        if (status === "failed" && gestionDetails.length > 0) {
            return ({
                "show": true,
                "key": "clean05_unmapped_gestion_" + runId,
                "tone": "error",
                "title": "Clean05 no pudo iniciar",
                "message": "El bridge no se abrió porque hay valores de Resultado Gestión sin traducción a Tipo de Gasto. Corrige la planilla y vuelve a iniciar el bot.",
                "confirmText": "Entendido",
                "confirmTone": "primary",
                "detailLines": gestionDetails
            })
        }

        if (status === "failed") {
            var fatal = root.lastLogCapture(
                /\[CLEAN05\]\[PASO_ERROR\]\s+([^\r\n]+)/g, 1)
            return ({
                "show": true,
                "key": "clean05_failed_" + runId,
                "tone": "error",
                "title": "Clean05 terminó con un error",
                "message": fatal.length > 0
                    ? fatal
                    : "Revisa los detalles técnicos de la ejecución para conocer la causa.",
                "confirmText": "Entendido",
                "confirmTone": "primary",
                "detailLines": []
            })
        }

        var summaryLine = root.lastLogCapture(
            /\[CLEAN05\]\[RESUMEN\]\s+([^\r\n]+)/g, 1)
        function summaryNumber(name) {
            var match = new RegExp("(?:^|\\s)" + name + "=(-?\\d+)").exec(summaryLine)
            return match ? Number(match[1]) : 0
        }
        var total = summaryNumber("boletas")
        var okCount = summaryNumber("ok")
        var pendingCount = summaryNumber("pendientes")
        if (pendingCount === 0)
            pendingCount = summaryNumber("revisar")

        var reasonRows = ({})
        var reasonOrder = []
        var rowPattern = /\[CLEAN05\]\[FILA\]\s+(\{[^\r\n]+\})/g
        var rowMatch
        while ((rowMatch = rowPattern.exec(logText)) !== null) {
            var rowData
            try { rowData = JSON.parse(rowMatch[1]) } catch (e) { continue }
            if (String(rowData.estado || "").toUpperCase() === "OK")
                continue
            var reason = String(rowData.motivo || "Información incompleta.").trim()
            if (reasonRows[reason] === undefined) {
                reasonRows[reason] = []
                reasonOrder.push(reason)
            }
            reasonRows[reason].push(String(rowData.excel || "?"))
        }
        var pendingDetails = []
        for (var reasonIndex = 0; reasonIndex < reasonOrder.length; reasonIndex++) {
            var pendingReason = reasonOrder[reasonIndex]
            pendingDetails.push({
                "text": pendingReason + " | fila(s): " + reasonRows[pendingReason].join(", "),
                "color": String(Common.Theme.warning),
                "bold": true
            })
        }
        if (pendingCount === 0) {
            pendingDetails.push({
                "text": okCount + " fila(s) completadas sin pendientes.",
                "color": String(Common.Theme.success),
                "bold": true
            })
        }

        var inputJson = String(root.detailValue("inputJson", ""))
        var isTestMode = /"clean05_test_mode"\s*:\s*true/i.test(inputJson)
        var completionMessage
        if (isTestMode) {
            completionMessage = "Modo prueba finalizado: no se grabaron boletas. "
                + okCount + " fila(s) fueron verificadas y " + pendingCount
                + " quedaron Pendiente."
        } else if (pendingCount > 0) {
            completionMessage = "Clean05 procesó las filas válidas: " + okCount
                + " quedaron OK y " + pendingCount
                + " quedaron Pendiente sin grabarse. Revisa sus causas abajo y en el Excel de resultados."
        } else {
            completionMessage = "Clean05 finalizó correctamente: " + okCount
                + " de " + total + " fila(s) quedaron OK."
        }
        return ({
            "show": true,
            "key": "clean05_completed_" + runId,
            "tone": pendingCount > 0 ? "warning" : "success",
            "title": pendingCount > 0
                ? "Clean05 finalizó con pendientes"
                : "Clean05 finalizó correctamente",
            "message": completionMessage,
            "confirmText": "Entendido",
            "confirmTone": "primary",
            "detailLines": pendingDetails
        })
    }

    // Completion pop-up for clean06, built here in QML for the same reason as the
    // clean05 one above: clean06 has no Python plugin (app/desktop/bot_plugins/ is
    // outside the bot-pack allowlist, so a plugin would need a core rebuild). The
    // markers parsed below are emitted by bots/clean06_crear-planilla-ingreso-
    // demandas/functions.py -- keep both sides in sync.
    function clean06FallbackCompletionNotification() {
        var status = String(root.detailValue("statusTechnical", "")).toLowerCase()
        var selectedKey = String(controller.selectedBot
                                 ? (controller.selectedBot.key || "") : "").toLowerCase()
        var botName = String(root.detailValue("botName", "")).toLowerCase()
        var isClean06 = selectedKey.indexOf("clean06_crear_planilla_ingreso_demandas") >= 0
            || botName.indexOf("clean06") >= 0
        if (!isClean06 || (status !== "failed" && status !== "success")) {
            return ({ "show": false })
        }

        var runId = Number(root.detailValue("id", 0))
        var archivo = root.lastLogCapture(
            /\[CLEAN06\]\[ARCHIVO\]\s+([^\r\n]+)/g, 1)

        // ---- structural rejection: nothing was processed ----
        if (status === "failed") {
            var faltantes = root.lastLogCapture(
                /\[CLEAN06\]\[COLUMNAS_FALTANTES\]\s+([^\r\n]+)/g, 1)
            var encontradas = root.lastLogCapture(
                /\[CLEAN06\]\[COLUMNAS_ENCONTRADAS\]\s+([^\r\n]+)/g, 1)
            var motivo = root.lastLogCapture(
                /\[CLEAN06\]\[ERROR\]\s+([^\r\n]+)/g, 1)

            if (faltantes.length > 0) {
                var missingDetails = [{
                    "text": "Columna(s) faltante(s): " + faltantes,
                    "color": String(Common.Theme.danger),
                    "bold": true
                }]
                if (archivo.length > 0) {
                    missingDetails.push({
                        "text": "Archivo: " + archivo,
                        "color": String(Common.Theme.text2),
                        "bold": false
                    })
                }
                if (encontradas.length > 0) {
                    missingDetails.push({
                        "text": "Columnas encontradas: " + encontradas,
                        "color": String(Common.Theme.text2),
                        "bold": false
                    })
                }
                return ({
                    "show": true,
                    "key": "clean06_missing_columns_" + runId,
                    "tone": "error",
                    "title": "Clean06 no pudo iniciar",
                    "message": "La planilla no se procesó porque a la Asignación Final le faltan columnas obligatorias. Corrige el Excel y vuelve a iniciar el bot.",
                    "confirmText": "Entendido",
                    "confirmTone": "primary",
                    "detailLines": missingDetails
                })
            }

            var fatalDetails = []
            if (archivo.length > 0) {
                fatalDetails.push({
                    "text": "Archivo: " + archivo,
                    "color": String(Common.Theme.text2),
                    "bold": false
                })
            }
            return ({
                "show": true,
                "key": "clean06_failed_" + runId,
                "tone": "error",
                "title": "Clean06 no pudo generar la planilla",
                "message": motivo.length > 0
                    ? motivo
                    : "Revisa los detalles técnicos de la ejecución para conocer la causa.",
                "confirmText": "Entendido",
                "confirmTone": "primary",
                "detailLines": fatalDetails
            })
        }

        // ---- finished: OK / pendientes ----
        var resumen = root.lastLogCapture(
            /\[CLEAN06\]\[RESUMEN\]\s+([^\r\n]+)/g, 1)
        function resumenNumber(name) {
            var match = new RegExp("(?:^|\\s)" + name + "=(-?\\d+)").exec(resumen)
            return match ? Number(match[1]) : 0
        }
        var total = resumenNumber("total")
        var okCount = resumenNumber("ok")
        var pendingCount = resumenNumber("pendiente")

        var causeRows = ({})
        var causeOrder = []
        var logText = String(root.detailValue("logText", ""))
        var rowPattern = /\[CLEAN06\]\[FILA\]\s+(\{[^\r\n]+\})/g
        var rowMatch
        while ((rowMatch = rowPattern.exec(logText)) !== null) {
            var rowData
            try { rowData = JSON.parse(rowMatch[1]) } catch (e) { continue }
            if (String(rowData.estado || "").toUpperCase() === "OK")
                continue
            var cause = String(rowData.causa || "Información incompleta.").trim()
            if (causeRows[cause] === undefined) {
                causeRows[cause] = []
                causeOrder.push(cause)
            }
            causeRows[cause].push(String(rowData.filaExcel || rowData.fila || "?"))
        }

        var pendingDetails06 = []
        for (var causeIndex = 0; causeIndex < causeOrder.length; causeIndex++) {
            var cause06 = causeOrder[causeIndex]
            pendingDetails06.push({
                "text": cause06 + " | fila(s): " + causeRows[cause06].join(", "),
                "color": String(Common.Theme.warning),
                "bold": true
            })
        }
        if (pendingCount === 0) {
            pendingDetails06.push({
                "text": okCount + " fila(s) quedaron OK, sin pendientes.",
                "color": String(Common.Theme.success),
                "bold": true
            })
        }

        return ({
            "show": true,
            "key": "clean06_completed_" + runId,
            "tone": pendingCount > 0 ? "warning" : "success",
            "title": pendingCount > 0
                ? "Clean06 finalizó con pendientes"
                : "Clean06 finalizó correctamente",
            "message": pendingCount > 0
                ? ("La planilla se generó con " + okCount + " fila(s) OK y "
                   + pendingCount + " en PENDIENTE. Las pendientes están en amarillo, "
                   + "con la causa en un comentario de la celda ESTADO.")
                : ("La planilla se generó correctamente: " + okCount + " de "
                   + total + " fila(s) quedaron OK."),
            "confirmText": "Entendido",
            "confirmTone": "primary",
            "detailLines": pendingDetails06
        })
    }

    // Completion pop-up for clean07, built here in QML for the same reason as
    // the clean05/clean06 ones above: clean07 has no frozen Python plugin
    // (app/desktop/bot_plugins/ is outside the bot-pack allowlist, so a plugin
    // would need a core rebuild). The markers parsed below are emitted by
    // bots/clean07_ingreso-demandas-bbrr/{tasks,functions}.py -- keep both
    // sides in sync.
    function clean07FallbackCompletionNotification() {
        var status = String(root.detailValue("statusTechnical", "")).toLowerCase()
        var selectedKey = String(controller.selectedBot
                                 ? (controller.selectedBot.key || "") : "").toLowerCase()
        var botName = String(root.detailValue("botName", "")).toLowerCase()
        var isClean07 = selectedKey.indexOf("clean07_ingreso_demandas_bbrr") >= 0
            || botName.indexOf("clean07") >= 0
        if (!isClean07 || (status !== "failed" && status !== "success")) {
            return ({ "show": false })
        }

        var runId = Number(root.detailValue("id", 0))
        var archivo07 = root.lastLogCapture(
            /\[CLEAN07\]\[ARCHIVO\]\s+([^\r\n]+)/g, 1)

        // ---- structural rejection: the bridge never opened ----
        if (status === "failed") {
            var faltantes07 = root.lastLogCapture(
                /\[CLEAN07\]\[COLUMNAS_FALTANTES\]\s+([^\r\n]+)/g, 1)
            var hoja07 = root.lastLogCapture(
                /\[CLEAN07\]\[COLUMNAS_HOJA\]\s+([^\r\n]+)/g, 1)

            if (faltantes07.length > 0) {
                var missingDetails07 = [{
                    "text": "Columna(s) faltante(s): " + faltantes07,
                    "color": String(Common.Theme.danger),
                    "bold": true
                }]
                if (archivo07.length > 0) {
                    missingDetails07.push({
                        "text": "Archivo: " + archivo07,
                        "color": String(Common.Theme.text2),
                        "bold": false
                    })
                }
                if (hoja07.length > 0) {
                    missingDetails07.push({
                        "text": "Hoja revisada: " + hoja07,
                        "color": String(Common.Theme.text2),
                        "bold": false
                    })
                }
                return ({
                    "show": true,
                    "key": "clean07_missing_columns_" + runId,
                    "tone": "error",
                    "title": "Clean07 no pudo iniciar",
                    "message": "El bridge no se abrió porque la planilla seleccionada no tiene todas las columnas necesarias. Corrige el Excel y vuelve a iniciar el bot.",
                    "confirmText": "Entendido",
                    "confirmTone": "primary",
                    "detailLines": missingDetails07
                })
            }

            // Any other pre-flight rejection (carpeta de demandas vacía o
            // ausente, planilla sin filas, formato inválido, bridge ocupado).
            var entrada07 = root.lastLogCapture(
                /\[CLEAN07\]\[ENTRADA_INVALIDA\]\s+([^\r\n]+)/g, 1)
            if (entrada07.length > 0) {
                var entradaDetalle07 = root.lastLogCapture(
                    /\[CLEAN07\]\[ENTRADA_DETALLE\]\s+([^\r\n]+)/g, 1)
                var entradaDetails07 = [{
                    "text": entrada07,
                    "color": String(Common.Theme.danger),
                    "bold": true
                }]
                if (entradaDetalle07.length > 0) {
                    entradaDetails07.push({
                        "text": entradaDetalle07,
                        "color": String(Common.Theme.text2),
                        "bold": false
                    })
                }
                return ({
                    "show": true,
                    "key": "clean07_invalid_input_" + runId,
                    "tone": "error",
                    "title": "Clean07 no pudo iniciar",
                    "message": "El bridge no se abrió porque las entradas no están listas. Corrige lo indicado abajo y vuelve a iniciar el bot.",
                    "confirmText": "Entendido",
                    "confirmTone": "primary",
                    "detailLines": entradaDetails07
                })
            }

            var fatal07 = root.lastLogCapture(
                /\[CLEAN07\]\[PASO_ERROR\]\s+([^\r\n]+)/g, 1)
            return ({
                "show": true,
                "key": "clean07_failed_" + runId,
                "tone": "error",
                "title": "Clean07 terminó con un error",
                "message": fatal07.length > 0
                    ? fatal07
                    : "Revisa los detalles técnicos de la ejecución para conocer la causa.",
                "confirmText": "Entendido",
                "confirmTone": "primary",
                "detailLines": []
            })
        }

        // ---- finished: the extension handshake was confirmed ----
        var resumen07 = root.lastLogCapture(
            /\[CLEAN07\]\[RESUMEN\]\s+([^\r\n]+)/g, 1)
        function resumen07Number(name) {
            var match = new RegExp("(?:^|\\s)" + name + "=(-?\\d+)").exec(resumen07)
            return match ? Number(match[1]) : 0
        }
        var filas07 = resumen07Number("filas")
        var pdfs07 = resumen07Number("pdfs")
        var conectado07 = /conectado=si/i.test(resumen07)

        var okDetails07 = [{
            "text": conectado07
                ? "Conexión con la extensión de Chrome confirmada."
                : "El bot terminó sin recibir Start desde la extensión.",
            "color": String(conectado07 ? Common.Theme.success : Common.Theme.warning),
            "bold": true
        }]
        okDetails07.push({
            "text": "Planilla: " + (archivo07.length > 0 ? archivo07 : "-")
                + " · " + filas07 + " fila(s) · " + pdfs07 + " PDF(s) en input/demandas",
            "color": String(Common.Theme.text2),
            "bold": false
        })

        // Steps the extension actually performed on the portal. Absent (0) while
        // the operator only confirmed the connection without working a row.
        var pasos07 = resumen07Number("pasos")
        var fin07 = root.lastLogCapture(/\[CLEAN07\]\[FIN\]\s+([^\r\n]+)/g, 1)
        if (pasos07 > 0) {
            okDetails07.push({
                "text": fin07.length > 0
                    ? fin07
                    : (pasos07 + " paso(s) completados en el portal."),
                "color": String(Common.Theme.success),
                "bold": false
            })
        }

        // ---- per-RUT outcome ------------------------------------------------
        // A row that fails no longer ends the run (see RECOVER_STEPS in the
        // bot's functions.py), so "success" alone stopped meaning "everything
        // went in". [CLEAN07][TALLY] is what separates a clean run from one
        // that finished with RUTs still needing a human.
        var tally07 = root.lastLogCapture(/\[CLEAN07\]\[TALLY\]\s+([^\r\n]+)/g, 1)
        function tally07Number(name) {
            var match = new RegExp("(?:^|\\s)" + name + "=(-?\\d+)").exec(tally07)
            return match ? Number(match[1]) : 0
        }
        var ingresadas07 = tally07Number("ingresadas")
        var conErrores07 = tally07Number("con_errores")
        var noIngresadas07 = tally07Number("no_ingresadas")
        var sinProcesar07 = tally07Number("sin_procesar")
        var ruts07 = tally07Number("ruts")
        var pendientes07 = conErrores07 + noIngresadas07 + sinProcesar07

        if (ruts07 > 0) {
            okDetails07.push({
                "text": ingresadas07 + " de " + ruts07 + " causa(s) ingresada(s) en PJUD.",
                "color": String(ingresadas07 > 0 ? Common.Theme.success : Common.Theme.warning),
                "bold": true
            })
            // FIRST of the problem lines on purpose: this is the only bucket
            // another run cannot fix, because the causa is already filed.
            if (conErrores07 > 0) {
                okDetails07.push({
                    "text": conErrores07 + " causa(s) quedaron ingresadas CON DOCUMENTOS "
                        + "PENDIENTES — hay que completarlas a mano en el portal (no las "
                        + "vuelvas a correr o se ingresarán dos veces).",
                    "color": String(Common.Theme.danger),
                    "bold": true
                })
            }
            if (noIngresadas07 > 0) {
                okDetails07.push({
                    "text": noIngresadas07 + " RUT(s) no se ingresaron; se pueden reintentar "
                        + "en otra corrida.",
                    "color": String(Common.Theme.warning),
                    "bold": false
                })
            }
            if (sinProcesar07 > 0) {
                okDetails07.push({
                    "text": sinProcesar07 + " RUT(s) quedaron sin procesar.",
                    "color": String(Common.Theme.warning),
                    "bold": false
                })
            }
            okDetails07.push({
                "text": "El detalle por RUT está en la tabla de esta ejecución y en "
                    + "Clean07_Resultado.xlsx.",
                "color": String(Common.Theme.text2),
                "bold": false
            })
        }

        var limpio07 = ruts07 > 0 && pendientes07 === 0
        var titulo07 = conectado07
            ? (ruts07 <= 0
                ? "Clean07 conectado correctamente"
                : (limpio07 ? "Clean07 terminó correctamente" : "Clean07 terminó con pendientes"))
            : "Clean07 finalizó sin conexión"
        var mensaje07
        if (!conectado07) {
            mensaje07 = "Las entradas pasaron la validación, pero nunca se presionó Start "
                + "en el panel Clean07 del portal."
        } else if (ruts07 > 0) {
            mensaje07 = limpio07
                ? ("Se ingresaron las " + ingresadas07 + " causa(s) de la planilla.")
                : ("Se ingresaron " + ingresadas07 + " de " + ruts07 + " causa(s). "
                   + "Revisa abajo lo que quedó pendiente.")
        } else if (pasos07 > 0) {
            mensaje07 = "La extensión trabajó el portal, pero la corrida no llegó a "
                + "ingresar ninguna causa."
        } else {
            mensaje07 = "Las entradas pasaron la validación y la extensión de Chrome quedó "
                + "enlazada con BotManager, pero no se ejecutó ningún paso en el portal."
        }

        return ({
            "show": true,
            "key": "clean07_completed_" + runId,
            "tone": (conectado07 && (ruts07 <= 0 || limpio07)) ? "success" : "warning",
            "title": titulo07,
            "message": mensaje07,
            "confirmText": "Entendido",
            "confirmTone": "primary",
            "detailLines": okDetails07
        })
    }

    function maybeShowCompletionNotification() {
        if (!completionNotificationArmed || completionNotificationTargetRunId <= 0) {
            return
        }
        if (!controller.runDetail) {
            return
        }

        var runId = Number(controller.runDetail.id || 0)
        if (runId !== completionNotificationTargetRunId) {
            return
        }

        // Use the TECHNICAL status, not runDetail.status — the latter holds the
        // plugin's display label, which some bots (clean02/clean03) set to a live
        // "N/M" progress chip while running. That non-"running" string would slip
        // past this guard and disarm the notification before the run finishes.
        var runStatus = String(controller.runDetail.statusTechnical
                               || controller.runDetail.status || "").toLowerCase()
        if (runStatus === "queued" || runStatus === "running" || runStatus.length === 0 || runStatus === "-") {
            return
        }

        var notification = controller.runDetail.completionNotification || ({})
        if (notification.show !== true) {
            notification = root.clean05FallbackCompletionNotification()
        }
        if (!notification || notification.show !== true) {
            notification = root.clean06FallbackCompletionNotification()
        }
        if (!notification || notification.show !== true) {
            notification = root.clean07FallbackCompletionNotification()
        }
        if (!notification || notification.show !== true) {
            completionNotificationArmed = false
            completionNotificationTargetRunId = 0
            return
        }

        var notificationKey = String(notification.key || "")
        if (notificationKey.length === 0) {
            notificationKey = String(controller.runDetail.id || 0) + "|" + String(notification.message || "")
        }
        if (notificationKey === lastCompletionNotificationKey) {
            completionNotificationArmed = false
            completionNotificationTargetRunId = 0
            return
        }

        completionNotificationWindow.titleText = String(notification.title || "")
        completionNotificationWindow.messageText = String(notification.message || "")
        completionNotificationWindow.tone = String(notification.tone || "info")
        completionNotificationWindow.confirmText = String(notification.confirmText || "Ok")
        completionNotificationWindow.confirmTone = String(notification.confirmTone || "primary")
        completionNotificationWindow.confirmAction = String(notification.confirmAction || "")
        completionNotificationWindow.secondaryText = String(notification.secondaryText || "")
        completionNotificationWindow.secondaryTone = String(notification.secondaryTone || "warning")
        completionNotificationWindow.secondaryAction = String(notification.secondaryAction || "")
        completionNotificationWindow.detailLines = notification.detailLines || []
        activeCompletionNotification = notification
        completionNotificationWindow.open()
        lastCompletionNotificationKey = notificationKey
        completionNotificationArmed = false
        completionNotificationTargetRunId = 0
    }

    function handleCompletionNotificationAction(actionKey) {
        var action = String(actionKey || "").trim()
        if (action.length === 0) {
            return
        }
        var runId = Number(controller.runDetail.id || 0)
        if (runId <= 0) {
            runId = Number(completionNotificationTargetRunId || 0)
        }
        if (action === "bot06_get_caratulas_retry_pending") {
            if (runId > 0) {
                controller.retryGetCaratulasPendientes(runId)
            }
            return
        }
        if (action === "bot06_get_caratulas_finalize_pending") {
            if (runId > 0) {
                controller.finalizeGetCaratulasPendientes(runId)
            }
            var followup = activeCompletionNotification
                && activeCompletionNotification.followupNotification
                ? activeCompletionNotification.followupNotification
                : null
            if (followup && followup.show === true) {
                completionNotificationWindow.titleText = String(followup.title || "")
                completionNotificationWindow.messageText = String(followup.message || "")
                completionNotificationWindow.tone = String(followup.tone || "info")
                completionNotificationWindow.confirmText = String(followup.confirmText || "Ok")
                completionNotificationWindow.confirmTone = String(followup.confirmTone || "primary")
                completionNotificationWindow.confirmAction = String(followup.confirmAction || "")
                completionNotificationWindow.secondaryText = String(followup.secondaryText || "")
                completionNotificationWindow.secondaryTone = String(followup.secondaryTone || "warning")
                completionNotificationWindow.secondaryAction = String(followup.secondaryAction || "")
                completionNotificationWindow.detailLines = followup.detailLines || []
                activeCompletionNotification = followup
                Qt.callLater(function() {
                    completionNotificationWindow.open()
                })
            }
            return
        }
        if (action === "bot06_get_caratulas_open_output") {
            var actionPayload = activeCompletionNotification
                && activeCompletionNotification.actionPayload
                ? activeCompletionNotification.actionPayload
                : null
            var outputDir = ""
            if (actionPayload && actionPayload.get_caratulas_output_dir !== undefined) {
                outputDir = String(actionPayload.get_caratulas_output_dir || "")
            }
            if (!outputDir || outputDir.trim().length === 0) {
                var summaryPath = String((controller.runDetail.runSummaryData || {}).getCaratulasSummaryJsonPath || "")
                if (summaryPath && summaryPath.trim().length > 0) {
                    outputDir = root.pathDirectory(summaryPath)
                }
            }
            controller.openPathInExplorer(String(outputDir || "").trim())
            return
        }
        if (action === "bot06_descargar_informe_open_output") {
            var descargarInformePayload = activeCompletionNotification
                && activeCompletionNotification.actionPayload
                ? activeCompletionNotification.actionPayload
                : null
            var descargarInformeOutputDir = ""
            if (descargarInformePayload && descargarInformePayload.descargar_informe_output_dir !== undefined) {
                descargarInformeOutputDir = String(descargarInformePayload.descargar_informe_output_dir || "")
            }
            if (!descargarInformeOutputDir || descargarInformeOutputDir.trim().length === 0) {
                descargarInformeOutputDir = String((controller.runDetail.runSummaryData || {}).descargarInformeOutputDir || "")
            }
            if (!descargarInformeOutputDir || descargarInformeOutputDir.trim().length === 0) {
                var descargarInformeFilePath = String((controller.runDetail.runSummaryData || {}).descargarInformeFilePath || "")
                if (descargarInformeFilePath && descargarInformeFilePath.trim().length > 0) {
                    descargarInformeOutputDir = root.pathDirectory(descargarInformeFilePath)
                }
            }
            controller.openPathInExplorer(String(descargarInformeOutputDir || "").trim())
            return
        }
        if (action === "n01_open_output_excel") {
            var n01Payload = activeCompletionNotification
                && activeCompletionNotification.actionPayload
                ? activeCompletionNotification.actionPayload
                : null
            var n01ExcelPath = ""
            if (n01Payload && n01Payload.output_excel_path !== undefined) {
                n01ExcelPath = String(n01Payload.output_excel_path || "")
            }
            if (!n01ExcelPath || n01ExcelPath.trim().length === 0) {
                n01ExcelPath = String((controller.runDetail.runSummaryData || {}).outputExcelPath || "")
            }
            controller.openFile(String(n01ExcelPath || "").trim())
            return
        }
        if (action === "clean03_open_output") {
            var clean03Payload = activeCompletionNotification
                && activeCompletionNotification.actionPayload
                ? activeCompletionNotification.actionPayload
                : null
            var clean03OutputDir = ""
            if (clean03Payload && clean03Payload.clean03_output_dir !== undefined) {
                clean03OutputDir = String(clean03Payload.clean03_output_dir || "")
            }
            if (!clean03OutputDir || clean03OutputDir.trim().length === 0) {
                clean03OutputDir = String((controller.runDetail.runSummaryData || {}).outputDir || "")
            }
            controller.openPathInExplorer(String(clean03OutputDir || "").trim())
            return
        }
        if (action === "clean04_open_output") {
            var clean04Payload = activeCompletionNotification
                && activeCompletionNotification.actionPayload
                ? activeCompletionNotification.actionPayload
                : null
            var clean04OutputDir = ""
            if (clean04Payload && clean04Payload.clean04_output_dir !== undefined) {
                clean04OutputDir = String(clean04Payload.clean04_output_dir || "")
            }
            if (!clean04OutputDir || clean04OutputDir.trim().length === 0) {
                clean04OutputDir = String((controller.runDetail.runSummaryData || {}).outputDir || "")
            }
            controller.openPathInExplorer(String(clean04OutputDir || "").trim())
            return
        }
        if (action === "clean02_open_output") {
            var clean02Payload = activeCompletionNotification
                && activeCompletionNotification.actionPayload
                ? activeCompletionNotification.actionPayload
                : null
            var clean02OutputDir = ""
            if (clean02Payload && clean02Payload.clean02_output_dir !== undefined) {
                clean02OutputDir = String(clean02Payload.clean02_output_dir || "")
            }
            if (!clean02OutputDir || clean02OutputDir.trim().length === 0) {
                clean02OutputDir = String((controller.runDetail.runSummaryData || {}).outputDir || "")
            }
            controller.openPathInExplorer(String(clean02OutputDir || "").trim())
            return
        }
    }

    onClosing: function(closeEvent) {
        if (!completionNotificationWindow.visible) {
            return
        }
        if (String(completionNotificationWindow.confirmAction || "") !== "bot06_get_caratulas_finalize_pending") {
            return
        }
        var runId = Number(controller.runDetail.id || 0)
        if (runId > 0) {
            controller.finalizeGetCaratulasPendientes(runId)
        }
    }

    Component.onCompleted: {
        root.showMaximized()
        controller.initialize()
        bootAnimationReady = true
    }

    Connections {
        target: controller
        function onInputFieldsChanged() {
            resetFormFields()
        }
        function onWorkspaceConfigChanged() {
            syncWorkspaceDefaults()
        }
        function onSelectedRunIdChanged() {
            runDetailTabIndex = 0
        }
        function onLastTriggeredRunIdChanged() {
            completionNotificationTargetRunId = Number(controller.lastTriggeredRunId || 0)
            completionNotificationArmed = completionNotificationTargetRunId > 0
            maybeShowCompletionNotification()
        }
        function onRunDetailChanged() {
            maybeShowCompletionNotification()
        }
    }

    Timer {
        interval: 2000
        repeat: true
        running: true
        onTriggered: controller.refresh()
    }

    Common.NotificationToast {
        id: completionNotificationWindow
        onActionTriggered: root.handleCompletionNotificationAction(actionKey)
    }

    Item {
        id: contentCanvas
        x: 0
        y: 0
        width: root.width / root.uiScale
        height: root.height / root.uiScale
        scale: root.uiScale
        transformOrigin: Item.TopLeft
        clip: true

        Rectangle {
            anchors.fill: parent
            color: Common.Theme.bg
        }

        RowLayout {
            id: shell
            anchors.fill: parent
            spacing: 0
            // One subtle boot fade — no ambient/infinite animation anywhere.
            opacity: root.bootAnimationReady ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }

            // ==================== SIDEBAR ====================
            Rectangle {
                id: sidebar
                Layout.preferredWidth: 264
                Layout.minimumWidth: 264
                Layout.fillHeight: true
                color: Common.Theme.sidebar

                Rectangle {
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    width: 1
                    color: Common.Theme.lineSoft
                }

                ColumnLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 14
                    anchors.rightMargin: 14
                    anchors.topMargin: 20
                    anchors.bottomMargin: 8
                    spacing: 0

                    // ---- brand ----
                    RowLayout {
                        Layout.fillWidth: true
                        Layout.leftMargin: 8
                        Layout.bottomMargin: 18
                        spacing: 11

                        // Default "CA" mark — hidden when branding ships a logo.
                        Rectangle {
                            width: 38
                            height: 38
                            radius: 9
                            visible: root.brandLogoUrl === ""
                            gradient: Gradient {
                                GradientStop { position: 0.0; color: "#1e50b3" }
                                GradientStop { position: 1.0; color: Common.Theme.accent }
                            }
                            Label {
                                anchors.centerIn: parent
                                text: "CA"
                                color: "#ffffff"
                                font.pixelSize: Common.Theme.fontSize(15)
                                font.weight: Font.Bold
                                font.letterSpacing: 0.5
                            }
                        }

                        // Client logo from branding.json (Phase 3).
                        Image {
                            visible: root.brandLogoUrl !== ""
                            source: root.brandLogoUrl
                            Layout.preferredWidth: 38
                            Layout.preferredHeight: 38
                            fillMode: Image.PreserveAspectFit
                            sourceSize.width: 76
                            sourceSize.height: 76
                            smooth: true
                            mipmap: true
                        }

                        ColumnLayout {
                            spacing: 1
                            Label {
                                text: root.brandDisplayName
                                color: Common.Theme.text
                                font.pixelSize: Common.Theme.fontSize(14)
                                font.weight: Font.DemiBold
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                            Label {
                                text: root.clientName.length > 0 ? ("Cliente: " + root.clientName) : "Automatización RPA"
                                color: Common.Theme.text3
                                font.pixelSize: Common.Theme.fontSize(12)
                                elide: Text.ElideRight
                                Layout.fillWidth: true
                            }
                        }
                    }

                    // ---- section label ----
                    Label {
                        text: "Procesos"
                        color: Common.Theme.text3
                        font.pixelSize: Common.Theme.fontSize(12)
                        font.weight: Font.DemiBold
                        font.capitalization: Font.AllUppercase
                        font.letterSpacing: 0.8
                        Layout.leftMargin: 10
                        Layout.topMargin: 4
                        Layout.bottomMargin: 6
                    }

                    // ---- process tree ----
                    ListView {
                        id: processTree
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        model: controller.processes
                        spacing: 2
                        clip: true

                        ScrollBar.vertical: Common.StyledScrollBar {
                            policy: ScrollBar.AsNeeded
                        }

                        delegate: Item {
                            id: procGroup
                            width: ListView.view.width
                            height: rowsColumn.height
                            implicitHeight: rowsColumn.height
                            property bool expanded: controller.selectedProcessCode === modelData.code
                            readonly property int rowH: 38

                            // A process "owns" the current selection when it is the
                            // expanded group AND a bot is selected — bots only render
                            // while expanded, so the selected bot is always in here.
                            readonly property bool ownsSelectedBot: expanded && controller.selectedBotId > 0
                            readonly property int selectedBotIndex: {
                                if (!expanded || controller.selectedBotId <= 0) {
                                    return -1
                                }
                                var bots = controller.bots || []
                                for (var i = 0; i < bots.length; i++) {
                                    if (Number(bots[i].id) === Number(controller.selectedBotId)) {
                                        return i
                                    }
                                }
                                return -1
                            }
                            // Vertical centre of the selected bot row. `drawY` lags
                            // `targetY` through a Behavior so the connector flows when
                            // the selection moves between bots of the same process.
                            readonly property real targetY: selectedBotIndex >= 0
                                ? (rowH + selectedBotIndex * rowH + rowH / 2)
                                : (rowH * 0.5)
                            property real drawY: rowH * 0.5
                            onTargetYChanged: drawY = targetY
                            Behavior on drawY { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                            Component.onCompleted: drawY = targetY

                            Column {
                                id: rowsColumn
                                width: parent.width

                                // process row
                                Rectangle {
                                    width: parent.width
                                    height: 38
                                    radius: Common.Theme.radiusInner
                                    color: procHover.containsMouse ? Common.Theme.panel2 : "transparent"
                                    Behavior on color { ColorAnimation { duration: 120 } }

                                    // Gentle light spilling from the left edge when this
                                    // process owns the selected bot — same edge the
                                    // connector flows from, so they read as one gesture.
                                    Rectangle {
                                        anchors.fill: parent
                                        radius: Common.Theme.radiusInner
                                        opacity: procGroup.ownsSelectedBot ? 1 : 0
                                        Behavior on opacity { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
                                        gradient: Gradient {
                                            orientation: Gradient.Horizontal
                                            GradientStop { position: 0.0; color: Qt.alpha(Common.Theme.accent, Common.Theme.isDark ? 0.16 : 0.12) }
                                            GradientStop { position: 0.65; color: "transparent" }
                                        }
                                    }

                                    RowLayout {
                                        anchors.fill: parent
                                        anchors.leftMargin: 10
                                        anchors.rightMargin: 10
                                        spacing: 8

                                        Label {
                                            text: procGroup.expanded ? "▾" : "▸"
                                            color: procGroup.ownsSelectedBot ? Common.Theme.accent : Common.Theme.text3
                                            Behavior on color { ColorAnimation { duration: 160 } }
                                            font.pixelSize: Common.Theme.fontSize(12)
                                            Layout.preferredWidth: 12
                                        }

                                        Label {
                                            text: modelData.name
                                            color: procGroup.ownsSelectedBot
                                                ? Common.Theme.accent
                                                : (procHover.containsMouse ? Common.Theme.text : Common.Theme.text2)
                                            Behavior on color { ColorAnimation { duration: 160 } }
                                            font.pixelSize: Common.Theme.fontSize(14)
                                            font.weight: Font.DemiBold
                                            elide: Text.ElideRight
                                            Layout.fillWidth: true
                                        }

                                        Rectangle {
                                            visible: procGroup.expanded
                                            radius: Common.Theme.radiusPill
                                            color: Common.Theme.panel2
                                            implicitHeight: 18
                                            implicitWidth: countLabel.implicitWidth + 16
                                            Label {
                                                id: countLabel
                                                anchors.centerIn: parent
                                                text: String((controller.bots || []).length)
                                                color: Common.Theme.text3
                                                font.pixelSize: Common.Theme.fontSize(12)
                                                font.weight: Font.DemiBold
                                            }
                                        }
                                    }

                                    MouseArea {
                                        id: procHover
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: controller.selectProcess(modelData.code)
                                    }
                                }

                                // bots of the expanded process
                                Repeater {
                                    model: procGroup.expanded ? (controller.bots || []) : []

                                    delegate: Rectangle {
                                        id: botRow
                                        width: procGroup.width
                                        height: 38
                                        radius: Common.Theme.radiusInner
                                        readonly property int botId: Number(modelData.id)
                                        readonly property bool active: Number(controller.selectedBotId) === botId
                                        readonly property bool hovered: root.hoveredSidebarBotId === botId
                                        color: "transparent"

                                        Rectangle {
                                            anchors.fill: parent
                                            radius: parent.radius
                                            color: botRow.active
                                                ? Qt.alpha(Common.Theme.accent, Common.Theme.isDark ? 0.20 : 0.11)
                                                : (botRow.hovered ? Qt.alpha(Common.Theme.accent, Common.Theme.isDark ? 0.11 : 0.07) : "transparent")
                                            border.width: botRow.hovered && !botRow.active ? 1 : 0
                                            border.color: Qt.alpha(Common.Theme.accent, Common.Theme.isDark ? 0.34 : 0.22)
                                            Behavior on color { ColorAnimation { duration: 120 } }
                                            Behavior on border.color { ColorAnimation { duration: 120 } }
                                        }

                                        Rectangle {
                                            anchors.fill: parent
                                            radius: parent.radius
                                            opacity: botRow.active ? 1.0 : (botRow.hovered ? 0.72 : 0.0)
                                            gradient: Gradient {
                                                orientation: Gradient.Horizontal
                                                GradientStop { position: 0.0; color: Qt.alpha(Common.Theme.accent, Common.Theme.isDark ? 0.26 : 0.14) }
                                                GradientStop { position: 0.58; color: "transparent" }
                                            }
                                            Behavior on opacity { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                                        }

                                        Rectangle {
                                            anchors.left: parent.left
                                            anchors.verticalCenter: parent.verticalCenter
                                            width: botRow.active ? 3 : 2
                                            height: botRow.active ? parent.height - 12 : parent.height - 20
                                            radius: 1
                                            color: botRow.active ? Common.Theme.accent : Qt.alpha(Common.Theme.accent, 0.70)
                                            opacity: (botRow.active || botRow.hovered) ? 1 : 0
                                            Behavior on opacity { NumberAnimation { duration: 120 } }
                                            Behavior on height { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                                        }

                                        RowLayout {
                                            anchors.fill: parent
                                            anchors.leftMargin: 30
                                            anchors.rightMargin: 10
                                            spacing: 10

                                            Rectangle {
                                                Layout.preferredWidth: 7
                                                Layout.preferredHeight: 7
                                                radius: 3.5
                                                color: botRow.active
                                                    ? Common.Theme.accent
                                                    : (botRow.hovered ? Qt.alpha(Common.Theme.accent, 0.85) : Common.Theme.text3)
                                                opacity: botRow.active ? 1.0 : (botRow.hovered ? 0.88 : 0.45)
                                                Behavior on color { ColorAnimation { duration: 120 } }
                                                Behavior on opacity { NumberAnimation { duration: 120 } }
                                            }

                                            Label {
                                                text: modelData.name
                                                color: botRow.active
                                                    ? Common.Theme.accent
                                                    : (botRow.hovered ? Common.Theme.text : Common.Theme.text2)
                                                font.pixelSize: Common.Theme.fontSize(14)
                                                font.weight: botRow.active || botRow.hovered ? Font.DemiBold : Font.Normal
                                                elide: Text.ElideRight
                                                Layout.fillWidth: true
                                                Behavior on color { ColorAnimation { duration: 120 } }
                                            }
                                        }

                                        MouseArea {
                                            id: botHover
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            cursorShape: Qt.PointingHandCursor
                                            onEntered: root.hoveredSidebarBotId = botRow.botId
                                            onExited: {
                                                if (root.hoveredSidebarBotId === botRow.botId) {
                                                    root.hoveredSidebarBotId = -1
                                                }
                                            }
                                            onClicked: controller.selectBot(modelData.id)
                                        }
                                    }
                                }
                            }

                            // ---- connector: a precise tree rail from the lower edge
                            // of the process row to the selected bot. The straight
                            // vertical trunk and short horizontal branch make the
                            // hierarchy explicit without crossing the bot label. The
                            // Canvas stays transparent to the mouse, and `drawY` keeps
                            // the existing animated movement between bot selections.
                            Canvas {
                                id: connector
                                anchors.fill: parent
                                opacity: procGroup.selectedBotIndex >= 0 ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }

                                readonly property color accent: Common.Theme.accent
                                readonly property bool isDark: Common.Theme.isDark
                                readonly property real startX: 17
                                readonly property real startY: procGroup.rowH - 1
                                readonly property real endX: 33
                                readonly property real endY: procGroup.drawY

                                onEndYChanged: requestPaint()
                                onAccentChanged: requestPaint()
                                onIsDarkChanged: requestPaint()
                                onWidthChanged: requestPaint()
                                onHeightChanged: requestPaint()
                                Component.onCompleted: requestPaint()

                                function cssRgba(a) {
                                    return "rgba(" + Math.round(accent.r * 255) + ","
                                        + Math.round(accent.g * 255) + ","
                                        + Math.round(accent.b * 255) + "," + a + ")"
                                }

                                onPaint: {
                                    var ctx = getContext("2d")
                                    ctx.reset()
                                    ctx.clearRect(0, 0, width, height)
                                    if (procGroup.selectedBotIndex < 0) {
                                        return
                                    }
                                    var sx = startX
                                    var sy = startY
                                    var ex = endX
                                    var ey = endY
                                    ctx.lineCap = "round"
                                    ctx.lineJoin = "round"

                                    // soft halo pass — wide, low alpha, blurred
                                    ctx.beginPath()
                                    ctx.moveTo(sx, sy)
                                    ctx.lineTo(sx, ey)
                                    ctx.lineTo(ex, ey)
                                    ctx.lineWidth = 6
                                    ctx.strokeStyle = cssRgba(isDark ? 0.18 : 0.14)
                                    ctx.shadowColor = cssRgba(0.55)
                                    ctx.shadowBlur = 8
                                    ctx.stroke()

                                    // crisp gradient core — faint at the process end,
                                    // bright where it meets the selected bot
                                    var grad = ctx.createLinearGradient(sx, sy, ex, ey)
                                    grad.addColorStop(0.0, cssRgba(0.05))
                                    grad.addColorStop(0.55, cssRgba(0.5))
                                    grad.addColorStop(1.0, cssRgba(0.95))
                                    ctx.beginPath()
                                    ctx.moveTo(sx, sy)
                                    ctx.lineTo(sx, ey)
                                    ctx.lineTo(ex, ey)
                                    ctx.lineWidth = 2
                                    ctx.strokeStyle = grad
                                    ctx.shadowBlur = 0
                                    ctx.stroke()

                                    // light landing on the selected bot's marker
                                    ctx.beginPath()
                                    ctx.arc(ex, ey, 3.2, 0, Math.PI * 2)
                                    ctx.fillStyle = cssRgba(0.9)
                                    ctx.shadowColor = cssRgba(0.6)
                                    ctx.shadowBlur = 6
                                    ctx.fill()
                                }
                            }
                        }
                    }

                    // ---- footer sysrow ----
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.topMargin: 6
                        implicitHeight: 1
                        color: Common.Theme.lineSoft
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        Layout.topMargin: 4
                        Layout.leftMargin: 10
                        Layout.rightMargin: 4
                        spacing: 9

                        Rectangle {
                            width: 8
                            height: 8
                            radius: 4
                            color: Common.Theme.success
                        }

                        Label {
                            text: controller.statusMessage
                            color: Common.Theme.text2
                            font.pixelSize: Common.Theme.fontSize(12)
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }

                        Label {
                            text: root.appVersion
                            color: Common.Theme.text3
                            font.pixelSize: Common.Theme.fontSize(12)
                        }

                        Common.FooterUtilityButton {
                            id: updatesButton
                            visible: root.updatesEnabled
                            enabled: root.updatesState !== "checking" && root.updatesState !== "downloading"
                            iconText: "⟳"
                            labelText: "Actualizar"
                            hoverIconRotation: 32
                            toolTipText: root.updatesMessage.length > 0
                                ? "Buscar actualizaciones — " + root.updatesMessage
                                : "Buscar actualizaciones"
                            onClicked: controller.checkForUpdates()
                        }

                        Common.FooterUtilityButton {
                            id: configButton
                            iconText: "⚙"
                            labelText: "Configurar"
                            hoverIconRotation: 18
                            toolTipText: "Abrir configuración"
                            onClicked: {
                                if (settingsDialog.visible) {
                                    settingsDialog.close()
                                } else {
                                    settingsDialog.open()
                                }
                            }
                        }
                    }
                }
            }

            // ==================== MAIN ====================
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 0

                // ---- license banner (Phase 4) ----
                // Only visible in licensed mode when the license is missing,
                // invalid or expired (the importer already disabled the bots).
                Rectangle {
                    visible: root.licenseBlocked
                    Layout.fillWidth: true
                    Layout.leftMargin: 28
                    Layout.rightMargin: 28
                    Layout.topMargin: 16
                    implicitHeight: licenseBannerRow.implicitHeight + 24
                    radius: Common.Theme.radiusCard
                    color: root.license.status === "expired" ? Common.Theme.warningSoft : Common.Theme.dangerSoft
                    border.width: 1
                    border.color: root.license.status === "expired" ? Common.Theme.warning : Common.Theme.danger

                    RowLayout {
                        id: licenseBannerRow
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.leftMargin: 16
                        anchors.rightMargin: 16
                        spacing: 12

                        Label {
                            text: "⚠"
                            color: root.license.status === "expired" ? Common.Theme.warning : Common.Theme.danger
                            font.pixelSize: Common.Theme.fontSize(18)
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                text: root.license.status === "expired" ? "Licencia expirada" : "Licencia no válida"
                                color: root.license.status === "expired" ? Common.Theme.warning : Common.Theme.danger
                                font.pixelSize: Common.Theme.fontSize(14)
                                font.weight: Font.DemiBold
                            }

                            Label {
                                text: root.licenseMessage.length > 0
                                    ? root.licenseMessage + " Contacta a tu proveedor para renovar la licencia."
                                    : "La licencia de esta instalación no es válida. Contacta a tu proveedor."
                                color: Common.Theme.text
                                font.pixelSize: Common.Theme.fontSize(13)
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                    }
                }

                // ---- updates banner (Phase 7) ----
                // Only on packaged installs with an update channel, and only
                // for announced states (available / downloading / ready /
                // applied / error / manual check results).
                Rectangle {
                    visible: root.updatesBannerVisible
                    Layout.fillWidth: true
                    Layout.leftMargin: 28
                    Layout.rightMargin: 28
                    Layout.topMargin: 16
                    implicitHeight: updatesBannerRow.implicitHeight + 24
                    radius: Common.Theme.radiusCard
                    color: root.updatesState === "error" ? Common.Theme.dangerSoft
                         : (root.updatesState === "uptodate" || root.updatesState === "applied")
                           ? Common.Theme.successSoft : Common.Theme.accentSoft
                    border.width: 1
                    border.color: root.updatesState === "error" ? Common.Theme.danger
                                : (root.updatesState === "uptodate" || root.updatesState === "applied")
                                  ? Common.Theme.success : Common.Theme.accent

                    RowLayout {
                        id: updatesBannerRow
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.leftMargin: 16
                        anchors.rightMargin: 16
                        spacing: 12

                        Label {
                            text: root.updatesState === "error" ? "⚠" : "⟳"
                            color: root.updatesState === "error" ? Common.Theme.danger
                                 : (root.updatesState === "uptodate" || root.updatesState === "applied")
                                   ? Common.Theme.success : Common.Theme.accent
                            font.pixelSize: Common.Theme.fontSize(18)
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2

                            Label {
                                text: root.updatesState === "checking" ? "Buscando actualizaciones"
                                    : root.updatesState === "available" ? "Actualización disponible"
                                    : root.updatesState === "downloading" ? "Descargando actualización"
                                    : root.updatesState === "ready" ? "Actualización lista"
                                    : root.updatesState === "uptodate" ? "Al día"
                                    : root.updatesState === "applied" ? "Actualización instalada"
                                    : "Error de actualización"
                                color: root.updatesState === "error" ? Common.Theme.danger
                                     : (root.updatesState === "uptodate" || root.updatesState === "applied")
                                       ? Common.Theme.success : Common.Theme.accent
                                font.pixelSize: Common.Theme.fontSize(14)
                                font.weight: Font.DemiBold
                            }

                            Label {
                                text: root.updatesMessage
                                color: Common.Theme.text
                                font.pixelSize: Common.Theme.fontSize(13)
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }

                        Common.GhostButton {
                            visible: root.updatesState === "available"
                            text: "Descargar"
                            onClicked: controller.downloadUpdates()
                        }

                        Common.GhostButton {
                            visible: root.updatesState === "ready"
                            text: "Reiniciar ahora"
                            onClicked: controller.restartToApplyUpdates()
                        }

                        Common.GhostButton {
                            visible: root.updatesState === "error"
                            text: "Reintentar"
                            onClicked: controller.checkForUpdates()
                        }

                        Button {
                            id: dismissUpdatesBannerButton
                            implicitWidth: 36
                            implicitHeight: 36
                            hoverEnabled: true
                            focusPolicy: Qt.StrongFocus
                            text: "✕"
                            onClicked: interfaceSettings.dismissedUpdatesBannerKey = root.updatesBannerKey

                            ToolTip.visible: hovered
                            ToolTip.text: "Cerrar aviso"
                            ToolTip.delay: 500

                            contentItem: Label {
                                text: dismissUpdatesBannerButton.text
                                color: dismissUpdatesBannerButton.hovered
                                    ? Common.Theme.text
                                    : Common.Theme.text2
                                font.pixelSize: Common.Theme.fontSize(13)
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }

                            background: Rectangle {
                                radius: Common.Theme.radiusInner
                                color: dismissUpdatesBannerButton.hovered
                                    ? Common.Theme.panel
                                    : "transparent"
                                border.width: 1
                                border.color: dismissUpdatesBannerButton.hovered
                                    ? Common.Theme.line
                                    : Common.Theme.lineSoft

                                Behavior on color { ColorAnimation { duration: 140 } }
                                Behavior on border.color { ColorAnimation { duration: 140 } }
                            }
                        }
                    }
                }

                // ---- page header ----
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.leftMargin: 28
                    Layout.rightMargin: 28
                    Layout.topMargin: 22
                    spacing: 0

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 12

                        Label {
                            text: controller.selectedBot.name
                                ? controller.selectedBot.name
                                : (controller.workspaceConfig.title ? controller.workspaceConfig.title : "Selecciona un bot")
                            color: Common.Theme.text
                            font.pixelSize: Common.Theme.fontSize(22)
                            font.weight: Font.DemiBold
                            elide: Text.ElideRight
                        }

                        Rectangle {
                            visible: (controller.selectedProcessName || "").length > 0
                            radius: Common.Theme.radiusPill
                            color: Common.Theme.accentSoft
                            implicitHeight: 22
                            implicitWidth: badgeLabel.implicitWidth + 20
                            Label {
                                id: badgeLabel
                                anchors.centerIn: parent
                                text: (controller.selectedProcessName || "").toUpperCase()
                                color: Common.Theme.accent
                                font.pixelSize: Common.Theme.fontSize(12)
                                font.weight: Font.DemiBold
                                font.letterSpacing: 0.4
                            }
                        }

                        Item { Layout.fillWidth: true }
                    }

                    Label {
                        text: controller.workspaceConfig.description
                            ? controller.workspaceConfig.description
                            : "Selecciona un bot para ver su espacio de trabajo."
                        color: Common.Theme.text2
                        font.pixelSize: Common.Theme.fontSize(14)
                        wrapMode: Text.WordWrap
                        maximumLineCount: 2
                        elide: Text.ElideRight
                        Layout.fillWidth: true
                        Layout.maximumWidth: 780
                        Layout.topMargin: 6
                    }

                    // ---- tabs ----
                    RowLayout {
                        Layout.fillWidth: true
                        Layout.topMargin: 18
                        spacing: 2

                        Repeater {
                            model: [
                                { key: 0, label: "Ejecutar" },
                                { key: 1, label: "Información del bot" }
                            ]
                            delegate: Item {
                                required property var modelData
                                implicitWidth: tabLabel.implicitWidth + 32
                                implicitHeight: 36
                                readonly property bool active: root.mainTabIndex === modelData.key

                                Label {
                                    id: tabLabel
                                    anchors.centerIn: parent
                                    text: parent.modelData.label
                                    color: parent.active ? Common.Theme.text : Common.Theme.text3
                                    font.pixelSize: Common.Theme.fontSize(14)
                                    font.weight: Font.DemiBold
                                }
                                Rectangle {
                                    anchors.left: parent.left
                                    anchors.right: parent.right
                                    anchors.bottom: parent.bottom
                                    height: 2
                                    color: parent.active ? Common.Theme.accent : "transparent"
                                }
                                MouseArea {
                                    anchors.fill: parent
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: root.mainTabIndex = parent.modelData.key
                                }
                            }
                        }
                        Item { Layout.fillWidth: true }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        implicitHeight: 1
                        color: Common.Theme.lineSoft
                    }
                }

                // ==================== CONTENT ====================
                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    // -------- Tab: Ejecutar --------
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 28
                        anchors.rightMargin: 28
                        anchors.topMargin: 20
                        anchors.bottomMargin: 24
                        spacing: 16
                        visible: root.mainTabIndex === 0

                        // left workspace: config + run detail share one vertical scroll
                        Flickable {
                            id: executionWorkspaceScroll
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            clip: true
                            contentWidth: width
                            contentHeight: executionWorkspaceContent.implicitHeight
                            flickableDirection: Flickable.VerticalFlick
                            boundsBehavior: Flickable.StopAtBounds

                            ScrollBar.vertical: Common.StyledScrollBar {
                                policy: ScrollBar.AsNeeded
                            }

                            ColumnLayout {
                                id: executionWorkspaceContent
                                width: Math.max(0, executionWorkspaceScroll.width - 12)
                                spacing: 16

                            // ---- Configurar ejecución ----
                            Common.AppCard {
                                Layout.fillWidth: true
                                title: "Configurar ejecución"

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 12

                                    Loader {
                                        id: workspaceTasksPanelLoader
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: (visible && item) ? Math.max(item.implicitHeight, item.childrenRect.height) : 0
                                        visible: root.workspaceTasksModuleSource().length > 0
                                        active: visible
                                        source: root.workspaceTasksModuleSource()
                                        onLoaded: {
                                            if (item) {
                                                item.width = width
                                            }
                                        }
                                        onWidthChanged: {
                                            if (item) {
                                                item.width = width
                                            }
                                        }
                                    }

                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "workspaceConfig"
                                        value: controller.workspaceConfig
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "helpers"
                                        value: ({
                                            fileUrlToLocalPath: root.fileUrlToLocalPath,
                                            localPathToFileUrl: root.localPathToFileUrl,
                                            pathDirectory: root.pathDirectory,
                                            isValidDateDmy: root.isValidDateDmy,
                                            compareDateDmy: root.compareDateDmy
                                        })
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "textMuted"
                                        value: root.cTextMuted
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "workspaceTaskName"
                                        value: workspaceTaskName
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "matrixPath"
                                        value: root.workspaceMatrixValueForTask(workspaceTaskName)
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "fechaDesde"
                                        value: workspaceFechaDesdeCaratulas
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "fechaHasta"
                                        value: workspaceFechaHastaCaratulas
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "informePath"
                                        value: workspaceInformeCausasPath
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "caratulasFolderPath"
                                        value: workspaceCaratulasPath
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "demandasPath"
                                        value: workspaceDemandasPath
                                        when: workspaceTasksPanelLoader.item !== null
                                    }
                                    Binding {
                                        target: workspaceTasksPanelLoader.item
                                        property: "planillaPath"
                                        value: workspacePlanillaPath
                                        when: workspaceTasksPanelLoader.item !== null
                                    }

                                    Connections {
                                        target: workspaceTasksPanelLoader.item
                                        ignoreUnknownSignals: true

                                        function onWorkspaceTaskNameEdited(value) {
                                            workspaceTaskName = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onMatrixPathEdited(value) {
                                            root.setWorkspaceMatrixValueForTask(workspaceTaskName, value)
                                            workspaceValidationMessage = ""
                                        }
                                        function onFechaDesdeEdited(value) {
                                            workspaceFechaDesdeCaratulas = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onFechaHastaEdited(value) {
                                            workspaceFechaHastaCaratulas = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onInformePathEdited(value) {
                                            workspaceInformeCausasPath = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onRuntimePythonEdited(value) {
                                            workspacePythonOverride = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onDemandasPathEdited(value) {
                                            workspaceDemandasPath = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onCaratulasFolderPathEdited(value) {
                                            workspaceCaratulasPath = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onPlanillaPathEdited(value) {
                                            workspacePlanillaPath = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onEstadoDiarioPathEdited(value) {
                                            workspaceEstadoDiarioPath = value
                                            workspaceValidationMessage = ""
                                        }
                                        function onMovimientosPathEdited(value) {
                                            workspaceMovimientosPath = value
                                            workspaceValidationMessage = ""
                                        }
                                    }

                                    Label {
                                        text: "Este bot no tiene tasks_component configurado."
                                        color: Common.Theme.text2
                                        visible: root.workspaceTasksModuleSource().length === 0
                                        Layout.fillWidth: true
                                        wrapMode: Text.Wrap
                                        font.pixelSize: Common.Theme.fontSize(14)
                                    }

                                    Label {
                                        text: workspaceValidationMessage
                                        color: Common.Theme.danger
                                        visible: workspaceValidationMessage.length > 0
                                        Layout.fillWidth: true
                                        wrapMode: Text.Wrap
                                        font.pixelSize: Common.Theme.fontSize(13)
                                    }

                                    RowLayout {
                                        Layout.fillWidth: true
                                        Layout.topMargin: 2
                                        spacing: 12

                                        Common.PrimaryRunButton {
                                            running: root.workspaceRunBusy
                                            enabled: controller.selectedBotId > 0
                                                && root.workspaceTasksModuleSource().length > 0
                                                && !root.workspaceRunBusy
                                            onClicked: root.runWorkspaceConfiguredBot()
                                        }

                                        Common.GhostButton {
                                            text: "Detener"
                                            alloyTone: "danger"
                                            enabled: root.workspaceRunBusy
                                            onClicked: controller.stopBot(Number(controller.lastTriggeredRunId || 0))
                                        }

                                        Item { Layout.fillWidth: true }

                                        Label {
                                            visible: controller.selectedBotId > 0
                                                && String(controller.selectedBot.lastRunStatus || "-") !== "-"
                                            text: "Última ejecución: "
                                                + String(controller.selectedBot.lastRunFinishedAt || "-")
                                                + " · " + String(controller.selectedBot.lastRunStatus || "-")
                                            color: Common.Theme.text3
                                            font.pixelSize: Common.Theme.fontSize(13)
                                            elide: Text.ElideRight
                                        }
                                    }

                                    // Clean05/Clean07 are attended: once the run starts the operator
                                    // has to leave the app, log into the portal in their own browser
                                    // and press Start there. Pulse an explicit next-step hint so
                                    // that handoff is obvious.
                                    Rectangle {
                                        id: attendedNextStepBanner
                                        readonly property string attendedBotKey:
                                            String(controller.selectedBot ? (controller.selectedBot.key || "") : "").toLowerCase()
                                        readonly property bool isClean07Attended:
                                            attendedBotKey.indexOf("clean07_ingreso_demandas_bbrr") >= 0
                                        Layout.fillWidth: true
                                        Layout.topMargin: 2
                                        visible: root.workspaceRunBusy
                                            && (attendedBotKey.indexOf("clean05_emerix_extension") >= 0
                                                || isClean07Attended)
                                        implicitHeight: attendedNextStepRow.implicitHeight + 20
                                        radius: 10
                                        color: Common.Theme.successSoft
                                        border.width: 1
                                        border.color: Qt.alpha(Common.Theme.success, 0.45)

                                        RowLayout {
                                            id: attendedNextStepRow
                                            anchors.fill: parent
                                            anchors.margins: 10
                                            spacing: 10

                                            Rectangle {
                                                Layout.alignment: Qt.AlignVCenter
                                                Layout.preferredWidth: 10
                                                Layout.preferredHeight: 10
                                                radius: 5
                                                color: Common.Theme.success
                                            }

                                            Label {
                                                Layout.fillWidth: true
                                                text: attendedNextStepBanner.isClean07Attended
                                                    ? "Bot iniciado. Ve a Chrome, ingresa a la Oficina Judicial Virtual y presiona Start en el panel Clean07."
                                                    : "Bot iniciado. Ve al navegador, ingresa a Emerix e inicia el proceso."
                                                color: Common.Theme.success
                                                wrapMode: Text.Wrap
                                                font.bold: true
                                                font.pixelSize: Common.Theme.fontSize(14)
                                            }
                                        }

                                        SequentialAnimation on opacity {
                                            running: attendedNextStepBanner.visible
                                            loops: Animation.Infinite
                                            NumberAnimation {
                                                from: 1.0
                                                to: 0.45
                                                duration: 900
                                                easing.type: Easing.InOutSine
                                            }
                                            NumberAnimation {
                                                from: 0.45
                                                to: 1.0
                                                duration: 900
                                                easing.type: Easing.InOutSine
                                            }
                                        }
                                    }
                                }
                            }

                            // ---- Detalle del run ----
                            Common.AppCard {
                                Layout.fillWidth: true
                                Layout.preferredHeight: Math.max(520, executionWorkspaceScroll.height)
                                Layout.minimumHeight: 520
                                fillContent: true
                                title: "Detalle del run #" + root.detailValue("id", 0)
                                subtitle: root.detailValue("botName", "") + (root.detailValue("createdAt", "").length > 0 ? " · " + root.detailValue("createdAt", "") : "")

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true
                                    spacing: 14

                                    // detail tabs
                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 2

                                        Repeater {
                                            model: [
                                                { key: 0, label: "Resumen del proceso" },
                                                { key: 1, label: "Log técnico" }
                                            ]
                                            delegate: Item {
                                                required property var modelData
                                                implicitWidth: dtabLabel.implicitWidth + 28
                                                implicitHeight: 32
                                                readonly property bool active: root.runDetailTabIndex === modelData.key

                                                Label {
                                                    id: dtabLabel
                                                    anchors.centerIn: parent
                                                    text: parent.modelData.label
                                                    color: parent.active ? Common.Theme.text : Common.Theme.text3
                                                    font.pixelSize: Common.Theme.fontSize(13)
                                                    font.weight: Font.DemiBold
                                                }
                                                Rectangle {
                                                    anchors.left: parent.left
                                                    anchors.right: parent.right
                                                    anchors.bottom: parent.bottom
                                                    height: 2
                                                    color: parent.active ? Common.Theme.accent : "transparent"
                                                }
                                                MouseArea {
                                                    anchors.fill: parent
                                                    cursorShape: Qt.PointingHandCursor
                                                    onClicked: root.runDetailTabIndex = parent.modelData.key
                                                }
                                            }
                                        }
                                        Item { Layout.fillWidth: true }
                                    }

                                    Rectangle {
                                        Layout.fillWidth: true
                                        implicitHeight: 1
                                        color: Common.Theme.lineSoft
                                    }

                                    // detail body
                                    Item {
                                        Layout.fillWidth: true
                                        Layout.fillHeight: true

                                        // Resumen del proceso (plugin summary)
                                        Item {
                                            id: runSummaryHost
                                            anchors.fill: parent
                                            visible: root.runDetailTabIndex === 0
                                            property string runSummarySource: root.detailValue("runSummaryComponent", "")
                                            property var runSummaryPayload: root.detailValue("runSummaryData", ({}))
                                            // Pure-QML log-parser fallbacks for bots WITHOUT a frozen
                                            // desktop plugin. This keeps their run detail on the
                                            // bot-pack/QML lane (no core rebuild): the component reads
                                            // the raw log and parses it itself. Match by bot name.
                                            readonly property string botNameLower: String(root.detailValue("botName", "")).toLowerCase()
                                            // Match clean05 on its STABLE bot key, not the display name,
                                            // so renaming the bot never breaks the summary panel.
                                            readonly property string selectedBotKeyLower: String(controller.selectedBot ? (controller.selectedBot.key || "") : "").toLowerCase()
                                            readonly property string fallbackSource: botNameLower.indexOf("n03") >= 0
                                                ? "run_summary/BotN03Summary.qml"
                                                : (selectedBotKeyLower.indexOf("clean05_emerix_extension") >= 0
                                                    ? "run_summary/Clean05Summary.qml"
                                                    : (selectedBotKeyLower.indexOf("clean06_crear_planilla_ingreso_demandas") >= 0
                                                        ? "run_summary/Clean06Summary.qml"
                                                        : (selectedBotKeyLower.indexOf("clean07_ingreso_demandas_bbrr") >= 0
                                                            ? "run_summary/Clean07Summary.qml"
                                                            : "")))
                                            readonly property bool useLogFallback: runSummarySource.length === 0
                                                && fallbackSource.length > 0
                                            readonly property string effectiveSource: useLogFallback
                                                ? fallbackSource
                                                : runSummarySource
                                            readonly property var effectivePayload: useLogFallback ? ({
                                                "logText": root.detailValue("logText", ""),
                                                "status": root.detailValue("status", ""),
                                                "statusTechnical": root.detailValue("statusTechnical", ""),
                                                "startedAt": root.detailValue("startedAt", ""),
                                                "finishedAt": root.detailValue("finishedAt", "")
                                            }) : runSummaryPayload

                                            Loader {
                                                id: runSummaryLoader
                                                anchors.fill: parent
                                                active: runSummaryHost.effectiveSource.length > 0
                                                source: runSummaryHost.effectiveSource.length > 0 ? runSummaryHost.effectiveSource : ""
                                            }

                                            Binding {
                                                target: runSummaryLoader.item
                                                property: "summaryData"
                                                value: runSummaryHost.effectivePayload
                                                when: runSummaryLoader.item !== null
                                            }

                                            Label {
                                                anchors.centerIn: parent
                                                visible: runSummaryHost.effectiveSource.length === 0
                                                text: root.detailValue("id", 0) > 0
                                                    ? "Sin resumen para este run."
                                                    : "Selecciona un run del historial para ver su detalle."
                                                color: Common.Theme.text3
                                                font.pixelSize: Common.Theme.fontSize(14)
                                            }
                                        }

                                        // Log técnico
                                        ScrollView {
                                            id: runTechnicalScroll
                                            anchors.fill: parent
                                            visible: root.runDetailTabIndex === 1
                                            clip: true
                                            contentWidth: availableWidth
                                            ScrollBar.vertical: Common.StyledScrollBar {
                                                policy: ScrollBar.AsNeeded
                                            }
                                            ScrollBar.horizontal: Common.StyledScrollBar {
                                                policy: ScrollBar.AlwaysOff
                                                visible: false
                                                interactive: false
                                            }

                                            ColumnLayout {
                                                width: runTechnicalScroll.availableWidth
                                                spacing: 8

                                                Label {
                                                    text: "Estado: " + root.detailValue("status", "-")
                                                    color: root.statusColor(root.detailValue("statusKey", root.detailValue("status", "-")))
                                                    font.pixelSize: Common.Theme.fontSize(14)
                                                }
                                                Label { text: "Proceso/Bot: " + root.detailValue("processCode", "-") + " / " + root.detailValue("botName", "-"); color: Common.Theme.text; font.pixelSize: Common.Theme.fontSize(14) }
                                                Label { text: "Creada: " + root.detailValue("createdAt", "-"); color: Common.Theme.text2; font.pixelSize: Common.Theme.fontSize(13) }
                                                Label { text: "Inicio/Fin: " + root.detailValue("startedAt", "-") + " -> " + root.detailValue("finishedAt", "-"); color: Common.Theme.text2; font.pixelSize: Common.Theme.fontSize(13) }
                                                Label { text: "Comando: " + root.detailValue("command", "-"); color: Common.Theme.text2; wrapMode: Text.Wrap; font.pixelSize: Common.Theme.fontSize(13); Layout.fillWidth: true }

                                                Label {
                                                    text: root.detailValue("errorMessage", "")
                                                    color: Common.Theme.danger
                                                    visible: text.length > 0
                                                    wrapMode: Text.Wrap
                                                    font.pixelSize: Common.Theme.fontSize(13)
                                                    Layout.fillWidth: true
                                                }

                                                Rectangle {
                                                    Layout.fillWidth: true
                                                    radius: Common.Theme.radiusInner
                                                    color: Common.Theme.panel2
                                                    border.width: 1
                                                    border.color: Common.Theme.lineSoft
                                                    implicitHeight: agent1Layout.implicitHeight + 16

                                                    ColumnLayout {
                                                        id: agent1Layout
                                                        anchors.fill: parent
                                                        anchors.margins: 8
                                                        spacing: 6

                                                        Label {
                                                            text: "Diagnóstico Agente IA"
                                                            color: Common.Theme.text
                                                            font.pixelSize: Common.Theme.fontSize(14)
                                                            font.weight: Font.DemiBold
                                                        }
                                                        Label {
                                                            text: "No hay diagnóstico Agente IA para este run. Ejecuta una corrida nueva con el manager actualizado."
                                                            color: Common.Theme.text2
                                                            visible: !root.detailValue("agent1Available", false)
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                        Label {
                                                            text: "Resumen: " + root.detailValue("agent1Summary", "-")
                                                            color: Common.Theme.text
                                                            visible: root.detailValue("agent1Available", false)
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                        Label {
                                                            text: "Causa raiz: " + root.detailValue("agent1RootCause", "-")
                                                            color: Common.Theme.text
                                                            visible: root.detailValue("agent1Available", false)
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                        Label {
                                                            text: "Sugerencia: " + root.detailValue("agent1SuggestedFix", "-")
                                                            color: Common.Theme.text
                                                            visible: root.detailValue("agent1Available", false)
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                        Label {
                                                            text: "Confianza: " + root.detailValue("agent1Confidence", "-")
                                                                + " | Reintento seguro: " + root.detailValue("agent1RetrySafe", "-")
                                                            color: Common.Theme.text2
                                                            visible: root.detailValue("agent1Available", false)
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                        Label {
                                                            text: "Origen: " + root.detailValue("agent1Source", "-")
                                                                + (root.detailValue("agent1Model", "").length > 0
                                                                    ? " (" + root.detailValue("agent1Model", "") + ")"
                                                                    : "")
                                                            color: Common.Theme.text2
                                                            visible: root.detailValue("agent1Available", false)
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                        Label {
                                                            text: "Proximos pasos:\n" + root.detailValue("agent1NextStepsText", "")
                                                            color: Common.Theme.text
                                                            visible: root.detailValue("agent1Available", false)
                                                                && root.detailValue("agent1NextStepsText", "").length > 0
                                                            wrapMode: Text.Wrap
                                                            font.pixelSize: Common.Theme.fontSize(13)
                                                            Layout.fillWidth: true
                                                        }
                                                    }
                                                }

                                                Label { text: "Entrada JSON"; color: Common.Theme.text; font.pixelSize: Common.Theme.fontSize(14); font.weight: Font.DemiBold }

                                                TextArea {
                                                    Layout.fillWidth: true
                                                    Layout.preferredHeight: 110
                                                    readOnly: true
                                                    text: root.detailValue("inputJson", "{}")
                                                    color: Common.Theme.text
                                                    font.pixelSize: Common.Theme.fontSize(13)
                                                    selectByMouse: true
                                                    wrapMode: TextArea.WrapAnywhere
                                                    background: Rectangle {
                                                        radius: Common.Theme.radiusInner
                                                        color: Common.Theme.panel2
                                                        border.width: 1
                                                        border.color: Common.Theme.lineSoft
                                                    }
                                                }

                                                Label { text: "Salida JSON"; color: Common.Theme.text; font.pixelSize: Common.Theme.fontSize(14); font.weight: Font.DemiBold }

                                                TextArea {
                                                    Layout.fillWidth: true
                                                    Layout.preferredHeight: 110
                                                    readOnly: true
                                                    text: root.detailValue("outputJson", "{}")
                                                    color: Common.Theme.text
                                                    font.pixelSize: Common.Theme.fontSize(13)
                                                    selectByMouse: true
                                                    wrapMode: TextArea.WrapAnywhere
                                                    background: Rectangle {
                                                        radius: Common.Theme.radiusInner
                                                        color: Common.Theme.panel2
                                                        border.width: 1
                                                        border.color: Common.Theme.lineSoft
                                                    }
                                                }

                                                RowLayout {
                                                    Layout.fillWidth: true
                                                    spacing: 10

                                                    Label {
                                                        text: "Logs (preview)"
                                                        color: Common.Theme.text
                                                        font.pixelSize: Common.Theme.fontSize(14)
                                                        font.weight: Font.DemiBold
                                                        Layout.fillWidth: true
                                                    }

                                                    Common.GhostButton {
                                                        id: copyLogPreviewButton
                                                        property bool copied: false
                                                        implicitHeight: 32
                                                        text: copied ? "✓ Copiado" : "Copiar"
                                                        enabled: logPreviewTextArea.text.length > 0
                                                        onClicked: {
                                                            logPreviewTextArea.selectAll()
                                                            logPreviewTextArea.copy()
                                                            logPreviewTextArea.deselect()
                                                            copied = true
                                                            copyLogFeedbackTimer.restart()
                                                        }

                                                        Timer {
                                                            id: copyLogFeedbackTimer
                                                            interval: 1600
                                                            onTriggered: copyLogPreviewButton.copied = false
                                                        }
                                                    }
                                                }

                                                ScrollView {
                                                    id: logPreviewScroll
                                                    Layout.fillWidth: true
                                                    Layout.preferredHeight: 170
                                                    clip: true
                                                    contentWidth: availableWidth
                                                    ScrollBar.vertical: Common.StyledScrollBar {
                                                        policy: ScrollBar.AsNeeded
                                                    }
                                                    ScrollBar.horizontal: Common.StyledScrollBar {
                                                        policy: ScrollBar.AlwaysOff
                                                        visible: false
                                                        interactive: false
                                                    }
                                                    background: Rectangle {
                                                        radius: Common.Theme.radiusInner
                                                        color: Common.Theme.panel2
                                                        border.width: 1
                                                        border.color: Common.Theme.lineSoft
                                                    }

                                                    TextArea {
                                                        id: logPreviewTextArea
                                                        width: logPreviewScroll.availableWidth
                                                        readOnly: true
                                                        text: root.detailValue("logText", "Sin log.")
                                                        color: Common.Theme.text
                                                        font.family: "Menlo, Consolas, monospace"
                                                        font.pixelSize: Common.Theme.fontSize(13)
                                                        selectByMouse: true
                                                        wrapMode: TextEdit.WrapAnywhere
                                                        textFormat: TextEdit.PlainText
                                                        background: null
                                                    }
                                                }

                                                Label {
                                                    text: "Artifacts: " + root.detailValue("artifactFilesText", "-")
                                                    color: Common.Theme.text2
                                                    wrapMode: Text.Wrap
                                                    font.pixelSize: Common.Theme.fontSize(13)
                                                    Layout.fillWidth: true
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        }

                        // right column: run history
                        Common.AppCard {
                            Layout.preferredWidth: 400
                            Layout.minimumWidth: 400
                            Layout.fillHeight: true
                            fillContent: true
                            title: "Historial de runs"

                            ColumnLayout {
                                Layout.fillWidth: true
                                Layout.fillHeight: true
                                spacing: 12

                                // filter chips
                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 6

                                    Repeater {
                                        model: [
                                            { key: "todos", label: "Todos" },
                                            { key: "exito", label: "Éxito" },
                                            { key: "fallidos", label: "Fallidos" },
                                            { key: "curso", label: "En curso" }
                                        ]
                                        delegate: Rectangle {
                                            required property var modelData
                                            readonly property bool active: root.runFilter === modelData.key
                                            radius: Common.Theme.radiusPill
                                            color: active ? Common.Theme.panel2 : "transparent"
                                            border.width: 1
                                            border.color: active ? Common.Theme.line : Common.Theme.lineSoft
                                            implicitHeight: 26
                                            implicitWidth: chipLabel.implicitWidth + 24

                                            Label {
                                                id: chipLabel
                                                anchors.centerIn: parent
                                                text: parent.modelData.label
                                                color: parent.active ? Common.Theme.text : Common.Theme.text3
                                                font.pixelSize: Common.Theme.fontSize(12)
                                                font.weight: Font.DemiBold
                                            }
                                            MouseArea {
                                                anchors.fill: parent
                                                cursorShape: Qt.PointingHandCursor
                                                onClicked: root.runFilter = parent.modelData.key
                                            }
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                }

                                // run list
                                ListView {
                                    id: runList
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true
                                    clip: true
                                    spacing: 7
                                    model: root.filterRuns(controller.runs, root.runFilter)

                                    ScrollBar.vertical: Common.StyledScrollBar {
                                        policy: ScrollBar.AsNeeded
                                    }

                                    delegate: Common.RunListItem {
                                        width: ListView.view.width
                                        runId: "#" + modelData.id
                                        name: modelData.runTag ? modelData.runTag : (modelData.botName ? modelData.botName : modelData.processCode)
                                        time: modelData.createdAt ? String(modelData.createdAt) : ""
                                        statusVariant: root.statusVariant(modelData.statusKey ? modelData.statusKey : modelData.status)
                                        statusText: modelData.status
                                        selected: controller.selectedRunId === modelData.id
                                        onClicked: controller.selectRun(modelData.id)
                                    }

                                    Label {
                                        anchors.centerIn: parent
                                        visible: runList.count === 0
                                        text: "Sin runs para este filtro."
                                        color: Common.Theme.text3
                                        font.pixelSize: Common.Theme.fontSize(14)
                                    }
                                }
                            }
                        }
                    }

                    // -------- Tab: Información del bot --------
                    Common.AppCard {
                        anchors.fill: parent
                        anchors.leftMargin: 28
                        anchors.rightMargin: 28
                        anchors.topMargin: 20
                        anchors.bottomMargin: 24
                        fillContent: true
                        visible: root.mainTabIndex === 1
                        title: controller.selectedBot.name ? controller.selectedBot.name : "Información del bot"

                        Flickable {
                            id: botInfoFlick
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            clip: true
                            contentWidth: width
                            contentHeight: botInfoLoader.item ? botInfoLoader.item.height : 0
                            flickableDirection: Flickable.VerticalFlick
                            boundsBehavior: Flickable.StopAtBounds

                            ScrollBar.vertical: Common.StyledScrollBar {
                                policy: ScrollBar.AsNeeded
                            }

                            Loader {
                                id: botInfoLoader
                                x: 0
                                width: botInfoFlick.width - 2
                                source: controller.workspaceConfig.infoComponent ? String(controller.workspaceConfig.infoComponent) : ""
                                onLoaded: {
                                    if (item) {
                                        item.width = width
                                    }
                                    if (root.mainTabIndex === 1 && controller) {
                                        controller.refreshBotInfoDependencies()
                                    }
                                }
                                onWidthChanged: {
                                    if (item) {
                                        item.width = width
                                    }
                                }
                            }

                            Binding {
                                target: botInfoLoader.item
                                property: "botInfo"
                                value: controller.botInfo
                                when: botInfoLoader.item !== null
                            }
                            Binding {
                                target: botInfoLoader.item
                                property: "selectedBotName"
                                value: controller.selectedBot.name ? controller.selectedBot.name : ""
                                when: botInfoLoader.item !== null
                            }
                            Binding {
                                target: botInfoLoader.item
                                property: "textMain"
                                value: root.cTextMain
                                when: botInfoLoader.item !== null
                            }
                            Binding {
                                target: botInfoLoader.item
                                property: "textMuted"
                                value: root.cTextMuted
                                when: botInfoLoader.item !== null
                            }
                            Binding {
                                target: botInfoLoader.item
                                property: "accent"
                                value: root.cAccent
                                when: botInfoLoader.item !== null
                            }
                            Binding {
                                target: botInfoLoader.item
                                property: "accentStrong"
                                value: root.cAccentStrong
                                when: botInfoLoader.item !== null
                            }
                            Binding {
                                target: botInfoLoader.item
                                property: "success"
                                value: root.cSuccess
                                when: botInfoLoader.item !== null
                            }
                        }
                    }
                }
            }
        }
    }

    Common.SettingsDialog {
        id: settingsDialog
        uiScaleValue: root.uiScale
        fontScaleValue: root.fontScale
        currentThemeMode: controller.themeMode
        cGlass: root.cGlass
        cPanel: root.cPanel
        cPanelSoft: root.cPanelSoft
        cLine: root.cLine
        cTextMain: root.cTextMain
        cTextMuted: root.cTextMuted
        cAccent: root.cAccent
        cAccentStrong: root.cAccentStrong
        cSuccess: root.cSuccess
        cDanger: root.cDanger
        controllerObject: controller
        currentPjudLoginUsername: controller.pjudLoginUsername
        currentPjudPassword: controller.pjudPassword
        currentPjudProfileLabel: controller.pjudProfileLabel
        onUiScaleEdited: controller.setUiScale(value)
        onResetUiScale: controller.setUiScale(1.0)
        onFontScaleEdited: function(value) {
            interfaceSettings.fontScale = Math.max(0.85, Math.min(1.25, value))
        }
        onResetFontScale: interfaceSettings.fontScale = 1.0
        onThemeModeEdited: controller.setThemeMode(value)
    }
}
