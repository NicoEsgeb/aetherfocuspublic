"""Logica de negocio de Clean08."""
from __future__ import annotations

import re
from copy import copy
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from bridge import BridgeState, EXTENSION_BUILD, run_bridge_session


SHEET_NAME = "Hoja1"
HEADER_ROW = 1
REQUIRED_COLUMNS = ("Tribunal", "ROL", "Año", "Archivo")
SUPPORTED_EXCEL_EXTENSIONS = {".xlsx", ".xlsm"}
OUTPUT_STATUS_HEADER = "ESTADO ESCRITO"
OUTPUT_STATUS_INGRESADO = "Ingresado"
OUTPUT_STATUS_NO_INGRESADO = "No ingresado"
OUTPUT_STATUS_REVISAR = "Revisar manualmente"
OUTPUT_GREEN = "C6EFCE"
OUTPUT_YELLOW = "FFEB9C"
OUTPUT_ORANGE = "F4B183"


class InputError(ValueError):
    """Raised when the selected workbook cannot be validated."""

    def __init__(self, message: str, *, reason: str, detail: str = ""):
        self.reason = reason
        self.detail = detail
        super().__init__(message)


class MissingColumnsError(ValueError):
    """Raised with every required column absent from Hoja1."""

    def __init__(self, missing: list[str], sheet_name: str, found: list[str]):
        self.missing = list(missing)
        self.sheet_name = sheet_name
        self.found = list(found)
        super().__init__(
            "La planilla no tiene todas las columnas necesarias. "
            f"Faltan: {', '.join(self.missing)}."
        )


class EmptyPlanillaError(ValueError):
    """Raised when Hoja1 has headers but no populated data rows."""

    def __init__(self, sheet_name: str):
        self.sheet_name = sheet_name
        super().__init__(f"La hoja {sheet_name} no contiene filas para procesar.")


class IncompleteRowsError(ValueError):
    """Raised with every populated row missing a required value."""

    def __init__(self, sheet_name: str, issues: list[dict[str, Any]]):
        self.sheet_name = sheet_name
        self.issues = list(issues)
        row_numbers = ", ".join(str(issue["row"]) for issue in self.issues)
        super().__init__(
            "Hay filas con datos obligatorios vacios. "
            f"Revisa las filas de Excel: {row_numbers}."
        )


@dataclass(frozen=True)
class ValidatedPlanilla:
    """Validated workbook metadata and the rows ready for future processing."""

    path: str
    filename: str
    sheet_name: str
    rows: tuple[dict[str, Any], ...]

    @property
    def row_count(self) -> int:
        return len(self.rows)


def _normalize_text(value: Any) -> str:
    """Trim, collapse whitespace and compare text without case sensitivity."""
    return " ".join(str(value if value is not None else "").split()).casefold()


def _is_blank(value: Any) -> bool:
    """Treat None and whitespace-only strings as empty; numeric zero is valid."""
    return value is None or (isinstance(value, str) and not value.strip())


def tribunal_portal_name(value: Any, *, excel_row: int) -> str:
    """Convert the Excel tribunal number to PJUD's exact visible option text."""
    if isinstance(value, bool):
        number = None
    else:
        try:
            parsed = Decimal(str(value).strip().replace(",", "."))
            number = int(parsed) if parsed == parsed.to_integral_value() else None
        except (InvalidOperation, ValueError, OverflowError):
            number = None

    if number is None or number <= 0:
        raise InputError(
            f'El Tribunal de la fila {excel_row} debe ser un número entero positivo.',
            reason="tribunal_invalido",
            detail=f"Fila {excel_row}: {value!r}",
        )
    return f"{number}º Juzgado Civil de Santiago"


def rol_portal_value(value: Any, *, excel_row: int) -> str:
    """Normalize the Excel ROL to the numeric text accepted by PJUD."""
    raw = str(value).strip()
    if not isinstance(value, bool) and raw.isdigit() and int(raw) > 0:
        return raw

    if not isinstance(value, bool):
        try:
            parsed = Decimal(raw.replace(",", "."))
            if parsed == parsed.to_integral_value() and int(parsed) > 0:
                return str(int(parsed))
        except (InvalidOperation, ValueError, OverflowError):
            pass

    raise InputError(
        f'El ROL de la fila {excel_row} debe ser un número entero positivo.',
        reason="rol_invalido",
        detail=f"Fila {excel_row}: {value!r}",
    )


def anio_portal_value(value: Any, *, excel_row: int) -> str:
    """Normalize the Excel Año to a four-digit PJUD dropdown label."""
    if not isinstance(value, bool):
        try:
            parsed = Decimal(str(value).strip().replace(",", "."))
            if parsed == parsed.to_integral_value():
                year = int(parsed)
                if 1000 <= year <= 9999:
                    return str(year)
        except (InvalidOperation, ValueError, OverflowError):
            pass

    raise InputError(
        f'El Año de la fila {excel_row} debe ser un año de cuatro dígitos.',
        reason="anio_invalido",
        detail=f"Fila {excel_row}: {value!r}",
    )


def resolve_archivo_pdf(folder: Path, value: Any, *, excel_row: int) -> Path:
    """Resolve an Archivo cell to one PDF directly inside escritos-pdfs."""
    filename = str(value or "").strip()
    if not filename or "/" in filename or "\\" in filename:
        raise InputError(
            f'El Archivo de la fila {excel_row} debe contener solo el nombre del PDF.',
            reason="archivo_pdf_invalido",
            detail=f"Fila {excel_row}: {filename or '(vacío)'}",
        )
    if Path(filename).suffix.lower() != ".pdf":
        raise InputError(
            f'El Archivo de la fila {excel_row} debe terminar en .pdf.',
            reason="archivo_pdf_invalido",
            detail=f"Fila {excel_row}: {filename}",
        )

    candidate = folder / filename
    if not candidate.is_file():
        raise InputError(
            f'No se encontró el PDF de la fila {excel_row}: {filename}',
            reason="archivo_pdf_no_encontrado",
            detail=str(candidate),
        )
    return candidate.resolve()


def _read_headers(worksheet: Any) -> dict[str, tuple[str, int]]:
    """Map normalized header text to original text and 1-based column index."""
    headers: dict[str, tuple[str, int]] = {}
    for row in worksheet.iter_rows(
        min_row=HEADER_ROW,
        max_row=HEADER_ROW,
        values_only=True,
    ):
        for index, value in enumerate(row, start=1):
            normalized = _normalize_text(value)
            if not normalized:
                continue
            headers.setdefault(normalized, (" ".join(str(value).split()), index))
        break
    return headers


def validate_planilla(path: str) -> ValidatedPlanilla:
    """Validate Hoja1, its four headers, row presence, and required cells."""
    import openpyxl

    target = Path(path).expanduser().resolve()
    if not target.is_file():
        raise InputError(
            f"No se encontro la planilla seleccionada: {target.name}",
            reason="planilla_inexistente",
            detail=str(target),
        )
    if target.suffix.lower() not in SUPPORTED_EXCEL_EXTENSIONS:
        raise InputError(
            "La planilla debe ser un archivo Excel .xlsx o .xlsm.",
            reason="planilla_formato",
            detail=target.name,
        )

    try:
        workbook = openpyxl.load_workbook(
            str(target),
            read_only=True,
            data_only=True,
        )
    except Exception as exc:
        raise InputError(
            "No se pudo abrir la planilla seleccionada.",
            reason="planilla_ilegible",
            detail=f"{target.name}: {exc}",
        ) from exc

    try:
        sheet_by_normalized_name = {
            _normalize_text(name): name for name in workbook.sheetnames
        }
        actual_sheet_name = sheet_by_normalized_name.get(_normalize_text(SHEET_NAME))
        if actual_sheet_name is None:
            found_sheets = ", ".join(workbook.sheetnames) or "(ninguna)"
            raise InputError(
                f"La planilla debe contener una hoja llamada {SHEET_NAME}.",
                reason="hoja_faltante",
                detail=f"Hojas encontradas: {found_sheets}",
            )

        worksheet = workbook[actual_sheet_name]
        headers = _read_headers(worksheet)
        resolved_columns: dict[str, int] = {}
        missing_columns: list[str] = []
        for required in REQUIRED_COLUMNS:
            match = headers.get(_normalize_text(required))
            if match is None:
                missing_columns.append(required)
            else:
                resolved_columns[required] = match[1]

        found_headers = [original for original, _ in headers.values()]
        if missing_columns:
            raise MissingColumnsError(
                missing_columns,
                actual_sheet_name,
                found_headers,
            )

        rows: list[dict[str, Any]] = []
        incomplete_rows: list[dict[str, Any]] = []
        for excel_row, raw_row in enumerate(
            worksheet.iter_rows(min_row=HEADER_ROW + 1, values_only=True),
            start=HEADER_ROW + 1,
        ):
            # Ignore completely blank spacer/trailing rows, including cells
            # that only contain whitespace.
            if not any(not _is_blank(value) for value in raw_row):
                continue

            record: dict[str, Any] = {"excel_row": excel_row}
            missing_values: list[str] = []
            for column_name, column_index in resolved_columns.items():
                value = (
                    raw_row[column_index - 1]
                    if column_index - 1 < len(raw_row)
                    else None
                )
                record[column_name] = value
                if _is_blank(value):
                    missing_values.append(column_name)

            rows.append(record)
            if missing_values:
                incomplete_rows.append(
                    {"row": excel_row, "missing": missing_values}
                )

        if not rows:
            raise EmptyPlanillaError(actual_sheet_name)
        if incomplete_rows:
            raise IncompleteRowsError(actual_sheet_name, incomplete_rows)

        return ValidatedPlanilla(
            path=str(target),
            filename=target.name,
            sheet_name=actual_sheet_name,
            rows=tuple(rows),
        )
    finally:
        workbook.close()


def _clean_failure_detail(value: Any) -> str:
    """Remove developer-only step numbering and page URLs from portal detail."""
    detail = " ".join(str(value or "").split())
    detail = re.sub(r"\s*\[página:\s*[^\]]+\]\s*$", "", detail, flags=re.I)
    detail = re.sub(
        r"\bStep\s*\d+(?:\s*/\s*\d+)?\b\s*[:.-]?\s*",
        "",
        detail,
        flags=re.I,
    )
    if "la extension no pudo completar" in detail.casefold():
        return ""
    return detail.strip()


def _failed_value(result: dict[str, Any], prefix: str) -> str:
    label = str(result.get("failed_step_label") or "").strip()
    marker = f"{prefix} ="
    if label.casefold().startswith(marker.casefold()):
        return label[len(marker):].strip()
    return ""


def _failure_location_message(result: dict[str, Any]) -> str:
    """Describe the failed portal location without exposing internal step IDs."""
    action = str(result.get("failed_step_action") or "").strip()
    tribunal = _failed_value(result, "Tribunal")
    rol = str(result.get("rol") or "").strip()
    anio = _failed_value(result, "Año")
    archivo = str(result.get("archivo") or "").strip()
    messages = {
        "click_ingresar_escrito": (
            'No se pudo abrir la opción "Ingresar Escrito" ni cargar un formulario nuevo.'
        ),
        "select_competencia": (
            'No se pudo seleccionar "Civil" en el menú Competencia.'
        ),
        "select_tribunal": (
            f'No se encontró o no se pudo seleccionar el tribunal "{tribunal}" '
            "en el menú Tribunal."
            if tribunal
            else "No se pudo seleccionar el tribunal indicado en la planilla."
        ),
        "select_tipo": 'No se pudo seleccionar "C" en el menú Tipo.',
        "fill_rol": (
            f'No se pudo ingresar el ROL "{rol}" en el formulario.'
            if rol
            else "No se pudo ingresar el ROL de la planilla."
        ),
        "select_anio": (
            f'No se pudo seleccionar el año "{anio}" en el menú Año.'
            if anio
            else "No se pudo seleccionar el año indicado en la planilla."
        ),
        "click_consulta_rol": (
            "No se pudo consultar la causa o el portal no cargó sus datos."
        ),
        "select_cuaderno": (
            'No se pudo seleccionar "1 Principal" en el menú Cuaderno.'
        ),
        "select_parte_presenta": (
            "No se pudo seleccionar al abogado en el menú Parte que Presenta."
        ),
        "select_grupo_escrito": (
            'No se pudo seleccionar "Escritos Generales" en el menú Grupo Escrito.'
        ),
        "select_tipo_escrito": (
            'No se pudo seleccionar "Señala domicilio" en el menú Tipo Escrito.'
        ),
        "click_grabar_escrito": (
            'No se pudo confirmar correctamente la acción "Grabar Escrito".'
        ),
        "upload_escrito_file": (
            f'No se pudo adjuntar el PDF "{archivo}".'
            if archivo
            else "No se pudo adjuntar el PDF indicado en la planilla."
        ),
        "await_escrito_uploaded": (
            f'PJUD no confirmó la carga del PDF "{archivo}".'
            if archivo
            else "PJUD no confirmó la carga del PDF."
        ),
        "click_cerrar_continuar": (
            'No se pudo cerrar la ventana con "Cerrar y Continuar".'
        ),
    }
    message = messages.get(action, "El portal no pudo completar esta fila.")
    detail = _clean_failure_detail(result.get("detail"))
    if detail and _normalize_text(detail) not in _normalize_text(message):
        return f"{message}\n\nDetalle del portal: {detail}"
    return message


def classify_output_row(result: dict[str, Any]) -> tuple[str, str, str]:
    """Return status, row colour, and optional Excel note for one result row."""
    archivo = str(result.get("archivo") or "").strip()
    location = _failure_location_message(result)

    # A visible Documento Principal card is the only success evidence.
    # Grabar Escrito alone can leave an escrito record without its PDF.
    if bool(result.get("upload_confirmed")):
        note = ""
        if result.get("status") != "completed":
            note = (
                f'PJUD confirmó la carga del PDF "{archivo}".\n\n{location}\n\n'
                "El documento quedó confirmado; no vuelva a ingresar este escrito."
            )
        return OUTPUT_STATUS_INGRESADO, OUTPUT_GREEN, note

    if bool(result.get("submission_started")):
        note = (
            'Se presionó "Grabar Escrito", por lo que el escrito podría existir '
            "en PJUD, pero no se confirmó la carga de su PDF.\n\n"
            f"{location}\n\n"
            "Revise el escrito manualmente antes de volver a procesar esta fila."
        )
        return OUTPUT_STATUS_REVISAR, OUTPUT_ORANGE, note

    note = (
        f"El escrito no fue ingresado.\n\n{location}\n\n"
        "Corrija el problema antes de volver a procesar esta fila."
    )
    return OUTPUT_STATUS_NO_INGRESADO, OUTPUT_YELLOW, note


def write_result_workbook(
    *,
    input_path: str,
    sheet_name: str,
    result_rows: list[dict[str, Any]],
    output_folder: str,
) -> str:
    """Write a styled copy of the input workbook with one safe row status."""
    import openpyxl
    from openpyxl.comments import Comment
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import (
        column_index_from_string,
        get_column_letter,
        range_boundaries,
    )
    from openpyxl.worksheet.table import TableColumn

    source = Path(input_path).expanduser().resolve()
    output_dir = Path(output_folder).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    keep_vba = source.suffix.lower() == ".xlsm"
    workbook = openpyxl.load_workbook(str(source), keep_vba=keep_vba)
    try:
        worksheet = workbook[sheet_name]
        existing_tables = list(worksheet.tables.values())
        existing_auto_filter = worksheet.auto_filter.ref
        original_column_dimensions = [
            (column_index_from_string(letter), copy(dimension))
            for letter, dimension in worksheet.column_dimensions.items()
        ]
        worksheet.insert_cols(1)

        # openpyxl moves cell content/styles but not column dimensions. Shift
        # explicit widths and visibility settings so the copy keeps its layout.
        for letter in list(worksheet.column_dimensions.keys()):
            del worksheet.column_dimensions[letter]
        for column_index, dimension in original_column_dimensions:
            target = worksheet.column_dimensions[
                get_column_letter(column_index + 1)
            ]
            target.width = dimension.width
            target.hidden = dimension.hidden
            target.bestFit = dimension.bestFit
            target.outlineLevel = dimension.outlineLevel
            target.collapsed = dimension.collapsed

        header = worksheet.cell(row=HEADER_ROW, column=1)
        neighbour = worksheet.cell(row=HEADER_ROW, column=2)
        header.value = OUTPUT_STATUS_HEADER
        try:
            header._style = copy(neighbour._style)
        except Exception:
            header.font = Font(bold=True)
        header.alignment = copy(neighbour.alignment)
        worksheet.column_dimensions["A"].width = 23

        # Keep an existing Excel table aligned. A table beginning at original
        # column A expands to include ESTADO ESCRITO; other tables shift right.
        for table in existing_tables:
            min_col, min_row, max_col, max_row = range_boundaries(table.ref)
            if min_col == 1:
                for table_column in table.tableColumns:
                    table_column.id += 1
                table.tableColumns.insert(
                    0,
                    TableColumn(id=1, name=OUTPUT_STATUS_HEADER),
                )
                max_col += 1
            else:
                min_col += 1
                max_col += 1
            table.ref = (
                f"{get_column_letter(min_col)}{min_row}:"
                f"{get_column_letter(max_col)}{max_row}"
            )

        if existing_auto_filter:
            min_col, min_row, max_col, max_row = range_boundaries(
                existing_auto_filter
            )
            if min_col == 1:
                max_col += 1
            else:
                min_col += 1
                max_col += 1
            worksheet.auto_filter.ref = (
                f"{get_column_letter(min_col)}{min_row}:"
                f"{get_column_letter(max_col)}{max_row}"
            )

        last_column = max(
            (
                cell.column
                for cell in worksheet[HEADER_ROW]
                if cell.value not in (None, "")
            ),
            default=worksheet.max_column,
        )
        fills = {
            OUTPUT_GREEN: PatternFill(fill_type="solid", fgColor=OUTPUT_GREEN),
            OUTPUT_YELLOW: PatternFill(fill_type="solid", fgColor=OUTPUT_YELLOW),
            OUTPUT_ORANGE: PatternFill(fill_type="solid", fgColor=OUTPUT_ORANGE),
        }

        for result in result_rows:
            excel_row = int(result.get("excel_row") or 0)
            if excel_row <= HEADER_ROW or excel_row > worksheet.max_row:
                continue
            status, colour, note = classify_output_row(result)
            for column in range(1, last_column + 1):
                worksheet.cell(row=excel_row, column=column).fill = fills[colour]

            status_cell = worksheet.cell(row=excel_row, column=1)
            status_cell.value = status
            status_font = copy(worksheet.cell(row=excel_row, column=2).font)
            status_font.bold = True
            status_cell.font = status_font
            status_cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
                wrap_text=True,
            )
            if note:
                status_cell.comment = Comment(note[:1200], "Clean08")
                status_cell.comment.width = 420
                status_cell.comment.height = 220

        suffix = source.suffix if keep_vba else ".xlsx"
        output_path = output_dir / f"Resultado_{source.stem}{suffix}"
        workbook.save(str(output_path))
        return str(output_path)
    finally:
        workbook.close()


def run_ingreso_escrito_ampliacion_domicilios(
    *,
    escritos_pdfs_folder: str,
    planilla_path: str,
    output_folder: str,
    bridge_host: str = "127.0.0.1",
    bridge_port: int = 8769,
    bridge_timeout_seconds: int = 7200,
) -> dict[str, Any]:
    """Validate all inputs, then run the attended extension workflow."""
    escritos_dir = Path(escritos_pdfs_folder).expanduser().resolve()
    output_dir = Path(output_folder).expanduser().resolve()

    # The workbook preflight is deliberately the first operation. No output
    # folder or external action is started until all rows are structurally safe.
    planilla = validate_planilla(planilla_path)

    if not escritos_dir.is_dir():
        raise FileNotFoundError(
            f"No existe la carpeta de escritos PDF: {escritos_dir}"
        )

    resolved_files = {
        int(row["excel_row"]): resolve_archivo_pdf(
            escritos_dir,
            row["Archivo"],
            excel_row=int(row["excel_row"]),
        )
        for row in planilla.rows
    }

    portal_rows: list[dict[str, Any]] = []
    for row in planilla.rows:
        excel_row = int(row["excel_row"])
        portal_rows.append(
            {
                "excel_row": excel_row,
                "tribunal": tribunal_portal_name(
                    row["Tribunal"],
                    excel_row=excel_row,
                ),
                "rol": rol_portal_value(
                    row["ROL"],
                    excel_row=excel_row,
                ),
                "anio": anio_portal_value(
                    row["Año"],
                    excel_row=excel_row,
                ),
                "archivo": str(row["Archivo"]).strip(),
            }
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    pdf_count = sum(
        1
        for path in escritos_dir.iterdir()
        if path.is_file() and path.suffix.lower() == ".pdf"
    )

    print("=" * 72)
    print("CLEAN08_INGRESO_ESCRITO_AMPLIACION_DOMICILIOS")
    print(f"  Carpeta de escritos PDF: {escritos_dir}")
    print(f"  PDFs encontrados: {pdf_count}")
    print(f"  Planilla seleccionada: {planilla.path}")
    print(f"  Hoja validada: {planilla.sheet_name}")
    print(f"  Columnas requeridas: OK ({', '.join(REQUIRED_COLUMNS)})")
    print(f"  Filas listas para procesar: {planilla.row_count}")
    print(f"  Carpeta de salida: {output_dir}")
    print("=" * 72)
    print(f"[CLEAN08][VALIDACION_OK] filas={planilla.row_count}")
    print(f"[CLEAN08][VERSION] {EXTENSION_BUILD}")
    print(f"[CLEAN08][PLANILLA] {planilla.filename}")

    state = BridgeState(
        summary_data={
            "workbook": {"filename": planilla.filename},
            "escritos": {
                "pdf_count": pdf_count,
            },
        },
        rows=tuple(portal_rows),
        file_paths={
            excel_row: str(path)
            for excel_row, path in resolved_files.items()
        },
    )
    result = run_bridge_session(
        state=state,
        host=bridge_host,
        port=bridge_port,
        timeout_seconds=bridge_timeout_seconds,
    )
    output_path = write_result_workbook(
        input_path=planilla.path,
        sheet_name=planilla.sheet_name,
        result_rows=list(result.get("result_rows", [])),
        output_folder=str(output_dir),
    )
    result["output_path"] = output_path
    for row_result in result.get("result_rows", []):
        position = int(row_result.get("row_number", 0))
        excel_row = int(row_result.get("excel_row", 0))
        if row_result.get("status") == "completed":
            print(
                f"[CLEAN08][FILA_OK] {position}/{planilla.row_count} "
                f"Excel={excel_row} ROL={row_result.get('rol', '')} "
                f"Archivo={row_result.get('archivo', '')}"
            )
            continue

        print(
            f"[CLEAN08][FILA_FALLA] {position}/{planilla.row_count} "
            f"Excel={excel_row} Step={row_result.get('failed_step_number', 0)} "
            f"Accion={row_result.get('failed_step_action', '')} "
            f"Detalle={row_result.get('detail', '')} "
            f"PostGrabar={'si' if row_result.get('submission_started') else 'no'} "
            f"Recuperacion={'ok' if row_result.get('recovery_ok') else 'fallo'}"
        )
    print(
        f"[CLEAN08][FIN] {result.get('rows_completed', 0)}/{planilla.row_count} "
        f"fila(s) procesada(s); completas={result.get('rows_ok', 0)}; "
        f"con_falla={result.get('rows_failed', 0)}."
    )
    print(f"[CLEAN08][OUTPUT] {output_path}")
    return result
