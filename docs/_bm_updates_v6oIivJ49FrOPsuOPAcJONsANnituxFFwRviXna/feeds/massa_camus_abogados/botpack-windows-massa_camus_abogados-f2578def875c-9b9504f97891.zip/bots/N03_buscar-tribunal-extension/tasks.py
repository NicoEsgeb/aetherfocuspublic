"""
N03 - Buscar Tribunal (Edge extension bridge)
=============================================
Runs a localhost bridge for the N03 Edge extension.

The user opens normal Edge, logs into PJUD manually, then presses Start in the
extension panel. The extension performs the post-login DOM work and sends row
results back to this task, which writes the Excel output.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from robocorp.tasks import task

from functions import (
    build_bridge_state,
    run_bridge_until_done,
    validate_planilla,
)

PATH_BOT = str(Path(__file__).parent)
PLANILLA_PATH = os.getenv("PLANILLA_PATH", str(Path(PATH_BOT) / "input" / "estado_diario.xlsx"))
N03_BRIDGE_HOST = os.getenv("N03_BRIDGE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    N03_BRIDGE_PORT = max(1, min(65535, int(os.getenv("N03_BRIDGE_PORT", "8765"))))
except ValueError:
    N03_BRIDGE_PORT = 8765
try:
    N03_TIMEOUT_MINUTES = max(5, int(os.getenv("N03_TIMEOUT_MINUTES", "120")))
except ValueError:
    N03_TIMEOUT_MINUTES = 120


def _new_run_dir(label: str) -> str:
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M")
    run_dir = output_root / f"{label}_{timestamp}"
    suffix = 2
    while run_dir.exists():
        run_dir = output_root / f"{label}_{timestamp}_{suffix}"
        suffix += 1
    run_dir.mkdir(parents=True, exist_ok=True)
    return str(run_dir)


@task
def N03_BUSCAR_TRIBUNAL_EXTENSION():
    """
    Start the localhost bridge used by the Edge extension.

    Keep this task running while the user starts the extension from the accepted
    PJUD tab. The task exits only after all E-* rows have been processed or the
    timeout is reached.
    """
    validate_planilla(PLANILLA_PATH)
    run_dir = _new_run_dir("N03_Buscar-Tribunal-Extension")
    extension_dir = Path(PATH_BOT) / "extension"

    state = build_bridge_state(PLANILLA_PATH, run_dir)
    summary = state.summary()

    print("=" * 72)
    print("N03_BUSCAR_TRIBUNAL_EXTENSION")
    print(f"  Planilla: {PLANILLA_PATH}")
    print(f"  Extension Edge: {extension_dir}")
    print(f"  Bridge: http://{N03_BRIDGE_HOST}:{N03_BRIDGE_PORT}")
    print(f"  Output: {state.output_path}")
    print(f"  Filas totales: {summary['total_rows']}")
    print(f"  Filas E-* a procesar: {summary['target_rows']}")
    print(f"  Omitidas/no E: {summary['skipped_rows']} | invalidas: {summary['invalid_rows']}")
    print("")
    print("Pasos:")
    print("  1. Abre Edge normal y entra a PJUD manualmente.")
    print("  2. Instala/carga la extension desempaquetada si aun no esta instalada.")
    print("  3. En la pestana PJUD, usa el panel 'N03 Buscar Tribunal' y presiona Start.")
    print("  4. Deja esta task corriendo hasta que la extension diga Completado.")
    print("=" * 72)

    if summary["target_rows"] <= 0:
        print("N03: no hay filas E-* para procesar.")
        print("Done")
        return

    final_summary = run_bridge_until_done(
        state=state,
        host=N03_BRIDGE_HOST,
        port=N03_BRIDGE_PORT,
        timeout_seconds=N03_TIMEOUT_MINUTES * 60,
    )
    counts = final_summary["counts"]
    print(
        "N03: proceso completado | "
        f"ok={counts.get('success', 0)} failed={counts.get('failed', 0)} "
        f"output={state.output_path}"
    )
    print("Done")
