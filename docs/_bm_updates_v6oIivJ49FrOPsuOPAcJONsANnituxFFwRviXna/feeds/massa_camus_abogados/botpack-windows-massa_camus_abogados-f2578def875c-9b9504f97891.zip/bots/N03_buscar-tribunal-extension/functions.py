"""
functions.py - Business logic for N03 - Buscar Tribunal (Edge extension bridge).

N03 is an attended, post-login assistant:
  - The user opens normal Edge and logs into PJUD manually.
  - This bot hosts a localhost HTTP bridge and owns Excel input/output.
  - The unpacked Edge extension runs inside the accepted PJUD tab, asks this
    bridge for the next row, manipulates the page DOM, and posts results back.

The bridge never receives PJUD credentials and never automates login/CAPTCHA.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import json
import re
import threading
import time

REQUIRED_SHEET = "Civil"
REQUIRED_HEADERS = {"Rol", "Fecha Ingreso", "Caratulado", "Tribunal"}


# ===========================================================================
# Offline logic (Excel + Rol parsing)
# ===========================================================================

def parse_rol(rol_str: str) -> tuple[str, str, str]:
    """Parse a Rol like 'E-12345-2023' into (letter, number1, number2)."""
    match = re.fullmatch(r"([A-Za-z])-(\d+)-(\d+)", str(rol_str).strip())
    if not match:
        raise ValueError(f"Formato de Rol inesperado: '{rol_str}' (esperado: X-número-número)")
    return match.group(1).upper(), match.group(2), match.group(3)


def read_all_civil_rows(path: str) -> list[dict[str, Any]]:
    """Return dicts with 'rol', 'tribunal', 'row_index' for every row in 'Civil'."""
    import openpyxl

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    ws = wb[REQUIRED_SHEET]
    rows = ws.iter_rows(min_row=1, values_only=True)
    header = [str(c).strip() if c is not None else "" for c in next(rows)]
    rol_col = header.index("Rol")
    tribunal_col = header.index("Tribunal")
    result: list[dict[str, Any]] = []
    for i, row in enumerate(rows):
        if row[rol_col] is not None:
            result.append({
                "row_index": i,
                "rol": str(row[rol_col]).strip(),
                "tribunal": str(row[tribunal_col]).strip() if row[tribunal_col] else "",
            })
    wb.close()
    return result


def create_output_excel(input_path: str, output_dir: str) -> str:
    """Copy input Excel to output_dir with '_output' + 'Causa/Tribunal Origen' cols."""
    import shutil
    import openpyxl
    from openpyxl.styles import PatternFill, Font
    from openpyxl.utils import get_column_letter

    HEADER_FILL = PatternFill(start_color="2E7D32", end_color="2E7D32", fill_type="solid")
    HEADER_FONT = Font(color="FFFFFF", bold=True)

    src = Path(input_path)
    dest = Path(output_dir) / (src.stem + "_output" + src.suffix)
    shutil.copy2(str(src), str(dest))

    wb = openpyxl.load_workbook(str(dest))
    ws = wb[REQUIRED_SHEET]
    headers = [cell.value for cell in ws[1]]
    next_col = len(headers) + 1
    col_widths = {"Causa Origen": 20, "Tribunal Origen": 42}
    for col_name in ("Causa Origen", "Tribunal Origen"):
        if col_name not in headers:
            cell = ws.cell(row=1, column=next_col, value=col_name)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            ws.column_dimensions[get_column_letter(next_col)].width = col_widths[col_name]
            next_col += 1
    wb.save(str(dest))
    wb.close()
    return str(dest)


def fill_output_row(output_path: str, row_index: int, causa_origen: str, tribunal_origen: str) -> None:
    """Fill 'Causa Origen'/'Tribunal Origen' for a data row (0-based)."""
    import openpyxl
    from openpyxl.styles import PatternFill

    DATA_FILL = PatternFill(start_color="C8E6C9", end_color="C8E6C9", fill_type="solid")
    wb = openpyxl.load_workbook(output_path)
    ws = wb[REQUIRED_SHEET]
    headers = [cell.value for cell in ws[1]]
    causa_col = headers.index("Causa Origen") + 1
    tribunal_col = headers.index("Tribunal Origen") + 1
    excel_row = row_index + 2
    c = ws.cell(row=excel_row, column=causa_col, value=causa_origen)
    c.fill = DATA_FILL
    t = ws.cell(row=excel_row, column=tribunal_col, value=tribunal_origen)
    t.fill = DATA_FILL
    wb.save(output_path)
    wb.close()


def fill_pending_row(output_path: str, row_index: int) -> None:
    """Mark a data row 'Pendiente' (orange)."""
    import openpyxl
    from openpyxl.styles import PatternFill

    PENDING_FILL = PatternFill(start_color="FF6600", end_color="FF6600", fill_type="solid")
    wb = openpyxl.load_workbook(output_path)
    ws = wb[REQUIRED_SHEET]
    headers = [cell.value for cell in ws[1]]
    causa_col = headers.index("Causa Origen") + 1
    tribunal_col = headers.index("Tribunal Origen") + 1
    excel_row = row_index + 2
    c = ws.cell(row=excel_row, column=causa_col, value="Pendiente")
    c.fill = PENDING_FILL
    t = ws.cell(row=excel_row, column=tribunal_col, value="Pendiente")
    t.fill = PENDING_FILL
    wb.save(output_path)
    wb.close()


def validate_planilla(path: str) -> None:
    """Validate the Estado Diario Excel; raise ValueError with a clear message."""
    import openpyxl

    target = Path(path)
    if not target.exists():
        raise ValueError(f"El archivo no existe: {target.name}")
    try:
        wb = openpyxl.load_workbook(str(target), read_only=True, data_only=True)
        sheet_names = wb.sheetnames
        wb.close()
    except Exception as exc:
        raise ValueError(f"No se pudo abrir el archivo Excel: {exc}") from exc
    if REQUIRED_SHEET not in sheet_names:
        hojas = ", ".join(sheet_names) if sheet_names else "(ninguna)"
        raise ValueError(
            f"La planilla no contiene la hoja '{REQUIRED_SHEET}'.\nHojas encontradas: {hojas}"
        )
    try:
        wb = openpyxl.load_workbook(str(target), read_only=True, data_only=True)
        ws = wb[REQUIRED_SHEET]
        first_row = [
            str(cell.value).strip() if cell.value is not None else ""
            for cell in next(ws.iter_rows(min_row=1, max_row=1))
        ]
        wb.close()
    except Exception as exc:
        raise ValueError(f"No se pudo leer la hoja '{REQUIRED_SHEET}': {exc}") from exc
    missing = REQUIRED_HEADERS - set(first_row)
    if missing:
        missing_str = ", ".join(f"'{h}'" for h in sorted(missing))
        raise ValueError(
            f"El formato no coincide con un archivo de 'Estado Diario'.\n"
            f"Se esperan las columnas: Rol, Fecha Ingreso, Caratulado, Tribunal.\n"
            f"Falta: {missing_str}.\nRevise nuevamente el archivo seleccionado."
        )


# ===========================================================================
# Local bridge state
# ===========================================================================

@dataclass
class WorkItem:
    row_index: int
    rol: str
    tribunal: str
    letra: str
    numero1: str
    numero2: str
    status: str = "pending"
    attempts: int = 0
    error: str = ""
    updated_at: float = field(default_factory=time.time)

    def to_payload(self) -> dict[str, Any]:
        return {
            "row_index": self.row_index,
            "rol": self.rol,
            "tribunal": self.tribunal,
            "letra": self.letra,
            "numero1": self.numero1,
            "numero2": self.numero2,
            "attempts": self.attempts,
        }


@dataclass
class BridgeState:
    output_path: str
    total_rows: int
    target_items: list[WorkItem]
    skipped_rows: int = 0
    invalid_rows: int = 0
    created_at: float = field(default_factory=time.time)
    last_extension_seen_at: float = 0.0
    logs: list[str] = field(default_factory=list)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def touch_extension(self) -> None:
        with self.lock:
            self.last_extension_seen_at = time.time()

    def next_item(self) -> dict[str, Any]:
        with self.lock:
            now = time.time()
            self.last_extension_seen_at = now
            # If Edge/extension was reloaded mid-row, release stale in-progress work.
            for item in self.target_items:
                if item.status == "in_progress" and now - item.updated_at > 300:
                    item.status = "pending"
                    item.updated_at = now
            for item in self.target_items:
                if item.status == "pending":
                    item.status = "in_progress"
                    item.attempts += 1
                    item.updated_at = now
                    return {"item": item.to_payload(), "summary": self.summary_unlocked()}
            return {"item": None, "summary": self.summary_unlocked()}

    def record_result(self, payload: dict[str, Any]) -> dict[str, Any]:
        row_index = _coerce_int(payload.get("row_index"), default=-1)
        status = str(payload.get("status") or "").strip().lower()
        causa_origen = str(payload.get("causa_origen") or "").strip()
        tribunal_origen = str(payload.get("tribunal_origen") or "").strip()
        error = str(payload.get("error") or "").strip()

        with self.lock:
            self.last_extension_seen_at = time.time()
            item = next((candidate for candidate in self.target_items if candidate.row_index == row_index), None)
            if item is None:
                return {"ok": False, "error": f"row_index desconocido: {row_index}"}

            if status == "success" and (causa_origen or tribunal_origen):
                fill_output_row(self.output_path, row_index, causa_origen, tribunal_origen)
                item.status = "success"
                item.error = ""
            else:
                fill_pending_row(self.output_path, row_index)
                item.status = "failed"
                item.error = error or "La extension no pudo extraer Causa/Tribunal Origen."
            item.updated_at = time.time()
            return {"ok": True, "summary": self.summary_unlocked()}

    def add_extension_log(self, message: str) -> None:
        clean = " ".join(str(message or "").split())
        if not clean:
            return
        with self.lock:
            self.last_extension_seen_at = time.time()
            self.logs.append(clean[:500])
            self.logs = self.logs[-200:]

    def summary(self) -> dict[str, Any]:
        with self.lock:
            return self.summary_unlocked()

    def summary_unlocked(self) -> dict[str, Any]:
        counts: dict[str, int] = {
            "pending": 0,
            "in_progress": 0,
            "success": 0,
            "failed": 0,
        }
        for item in self.target_items:
            counts[item.status] = counts.get(item.status, 0) + 1
        done = counts.get("pending", 0) == 0 and counts.get("in_progress", 0) == 0
        return {
            "done": done,
            "total_rows": self.total_rows,
            "target_rows": len(self.target_items),
            "skipped_rows": self.skipped_rows,
            "invalid_rows": self.invalid_rows,
            "counts": counts,
            "output_path": self.output_path,
            "extension_seen": self.last_extension_seen_at > 0,
        }


def _coerce_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def build_bridge_state(planilla_path: str, output_dir: str) -> BridgeState:
    """Create output Excel and prepare processable E-* rows for the extension."""
    rows = read_all_civil_rows(planilla_path)
    output_path = create_output_excel(planilla_path, output_dir)
    target_items: list[WorkItem] = []
    skipped_rows = 0
    invalid_rows = 0

    for row in rows:
        try:
            letra, numero1, numero2 = parse_rol(str(row["rol"]))
        except ValueError:
            invalid_rows += 1
            continue
        if letra != "E":
            skipped_rows += 1
            continue
        target_items.append(WorkItem(
            row_index=int(row["row_index"]),
            rol=str(row["rol"]),
            tribunal=str(row.get("tribunal") or ""),
            letra=letra,
            numero1=numero1,
            numero2=numero2,
        ))

    return BridgeState(
        output_path=output_path,
        total_rows=len(rows),
        target_items=target_items,
        skipped_rows=skipped_rows,
        invalid_rows=invalid_rows,
    )


# ===========================================================================
# HTTP bridge
# ===========================================================================

class N03BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], state: BridgeState):
        super().__init__(server_address, N03BridgeHandler)
        self.state = state


class N03BridgeHandler(BaseHTTPRequestHandler):
    server: N03BridgeServer

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        # Keep BotManager logs focused; extension logs are emitted explicitly.
        return

    def do_OPTIONS(self) -> None:
        self._send_empty(204)

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "name": "N03 PJUD bridge",
                "summary": self.server.state.summary(),
            })
            return
        if self.path.startswith("/session"):
            self.server.state.touch_extension()
            self._send_json({
                "ok": True,
                "summary": self.server.state.summary(),
            })
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self) -> None:
        if self.path.startswith("/next"):
            self._send_json({"ok": True, **self.server.state.next_item()})
            return
        if self.path.startswith("/result"):
            payload = self._read_json()
            self._send_json(self.server.state.record_result(payload))
            return
        if self.path.startswith("/log"):
            payload = self._read_json()
            message = str(payload.get("message") or "")
            self.server.state.add_extension_log(message)
            print(f"N03[EXT]: {message}")
            self._send_json({"ok": True})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def _read_json(self) -> dict[str, Any]:
        length = _coerce_int(self.headers.get("Content-Length"), default=0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _send_empty(self, status: int) -> None:
        self.send_response(status)
        self._send_cors_headers()
        self.end_headers()

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_cors_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Access-Control-Request-Private-Network")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")


def run_bridge_until_done(
    *,
    state: BridgeState,
    host: str,
    port: int,
    timeout_seconds: int,
    log_every_seconds: int = 15,
) -> dict[str, Any]:
    """
    Start the local bridge and block until every target row has a terminal result.
    Returns the final summary; raises TimeoutError if the extension does not finish.
    """
    server = N03BridgeServer((host, port), state)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"N03: bridge escuchando en http://{host}:{port}")

    deadline = time.time() + timeout_seconds
    last_log = 0.0
    try:
        while time.time() < deadline:
            summary = state.summary()
            now = time.time()
            if now - last_log >= log_every_seconds:
                counts = summary["counts"]
                seen = "si" if summary["extension_seen"] else "no"
                print(
                    "N03: estado "
                    f"extension={seen} pending={counts.get('pending', 0)} "
                    f"in_progress={counts.get('in_progress', 0)} "
                    f"ok={counts.get('success', 0)} failed={counts.get('failed', 0)}"
                )
                last_log = now
            if summary["done"]:
                return summary
            time.sleep(1.0)

        summary = state.summary()
        raise TimeoutError(
            "N03: timeout esperando que la extension termine. "
            f"Resumen actual: {json.dumps(summary, ensure_ascii=False)}"
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3.0)
