# N03 - Buscar Tribunal (Edge extension bridge)

N03 is an attended post-login version of N01:

1. You open normal Microsoft Edge.
2. You log into PJUD manually and solve any CAPTCHA manually.
3. BotManager runs a localhost bridge at `http://127.0.0.1:8765`.
4. The Edge extension runs inside the accepted PJUD tab, processes the Excel rows, and posts results back to BotManager.

The extension does not receive PJUD credentials and does not automate login.

## Install the extension in Edge

1. Open `edge://extensions`.
2. Enable `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder:

```text
bots/N03_buscar-tribunal-extension/extension
```

## Run

1. In BotManager, select `N03 - Buscar Tribunal (Extension)`.
2. Select the Estado Diario Excel.
3. Start the task. Keep it running.
4. In normal Edge, open `https://oficinajudicialvirtual.pjud.cl` and log in manually.
5. On the PJUD tab, use the `N03 Buscar Tribunal` panel in the lower-right corner and press `Start`.

The output Excel is written under:

```text
bots/N03_buscar-tribunal-extension/output
```
