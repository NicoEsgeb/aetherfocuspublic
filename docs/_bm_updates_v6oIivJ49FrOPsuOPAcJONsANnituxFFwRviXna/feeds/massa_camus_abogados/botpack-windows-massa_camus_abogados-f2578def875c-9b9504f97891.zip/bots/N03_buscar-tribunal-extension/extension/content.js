(() => {
  const BRIDGE_URL = "http://127.0.0.1:8765";
  const PANEL_ID = "n03-pjud-panel";
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  let running = false;
  let stopRequested = false;
  let connected = false;
  let lastSummary = null;

  function normalizeText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[º°]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function normalizeDigits(value) {
    return String(value || "").replace(/\D+/g, "");
  }

  function isVisible(element) {
    if (!element) {
      return false;
    }
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  async function waitFor(testFn, timeoutMs, label) {
    const started = Date.now();
    let lastError = "";
    while (Date.now() - started < timeoutMs) {
      try {
        const result = testFn();
        if (result) {
          return result;
        }
      } catch (error) {
        lastError = String(error && error.message ? error.message : error);
      }
      await sleep(250);
    }
    throw new Error(`Timeout esperando ${label || "condicion"}${lastError ? ` (${lastError})` : ""}`);
  }

  function withTimeout(promise, timeoutMs, label) {
    let timeoutId = null;
    const timeout = new Promise((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error(`Timeout en ${label}`)), timeoutMs);
    });
    return Promise.race([promise, timeout]).finally(() => {
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
      }
    });
  }

  function visibleByText(text, selectors = "a, button, span, div, li") {
    const wanted = normalizeText(text);
    const candidates = Array.from(document.querySelectorAll(selectors));
    return candidates.find((element) => isVisible(element) && normalizeText(element.innerText || element.textContent).includes(wanted));
  }

  function clickableByText(text) {
    const direct = visibleByText(text, "a, button, [role='button']");
    if (direct) {
      return direct;
    }
    const label = visibleByText(text, "span, li, div");
    if (!label) {
      return null;
    }
    return label.closest("a, button, [role='button']") || label;
  }

  async function bridgeRequest(path, options = {}) {
    const payload = await withTimeout(
      chrome.runtime.sendMessage({
        type: "N03_BRIDGE_REQUEST",
        path,
        options
      }),
      10000,
      `bridge ${path}`
    );
    if (!payload || payload.ok === false) {
      throw new Error(payload && payload.error ? payload.error : "Bridge no conectado");
    }
    return payload;
  }

  async function logToBridge(message) {
    const clean = String(message || "").trim();
    if (!clean) {
      return;
    }
    try {
      await bridgeRequest("/log", { method: "POST", body: { message: clean } });
    } catch (_) {
      // The panel already shows bridge connectivity; avoid recursive noise.
    }
  }

  async function runMainWorld(action, args) {
    const result = await withTimeout(
      chrome.runtime.sendMessage({
        type: "N03_MAIN_WORLD",
        action,
        args: args || {}
      }),
      12000,
      `accion navegador ${action}`
    );
    if (!result || result.ok === false) {
      throw new Error(result && result.error ? result.error : `main-world action failed: ${action}`);
    }
    return result;
  }

  async function stepLog(item, message) {
    const prefix = item ? `row=${item.row_index} rol=${item.rol}` : "setup";
    const text = `${prefix}: ${message}`;
    setStatus(text);
    await logToBridge(text);
  }

  function createPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      return existing;
    }

    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.innerHTML = `
      <div class="n03-title">N03 Buscar Tribunal</div>
      <div class="n03-status" data-role="status">Esperando bridge...</div>
      <div class="n03-counts" data-role="counts">-</div>
      <div class="n03-actions">
        <button type="button" data-role="start">Start</button>
        <button type="button" data-role="stop">Stop</button>
      </div>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('[data-role="start"]').addEventListener("click", () => {
      runLoop().catch((error) => {
        running = false;
        setStatus(`Error: ${error.message || error}`, true);
        logToBridge(`runLoop error: ${error.stack || error.message || error}`);
      });
    });
    panel.querySelector('[data-role="stop"]').addEventListener("click", () => {
      stopRequested = true;
      setStatus("Stop solicitado. Termino al cerrar la fila actual.", false);
    });
    return panel;
  }

  function setStatus(text, isError = false) {
    const panel = createPanel();
    const status = panel.querySelector('[data-role="status"]');
    status.textContent = text;
    status.classList.toggle("n03-error", Boolean(isError));
    status.classList.toggle("n03-ok", connected && !isError);
  }

  function renderSummary(summary) {
    lastSummary = summary || lastSummary;
    const panel = createPanel();
    const counts = panel.querySelector('[data-role="counts"]');
    if (!lastSummary) {
      counts.textContent = "-";
      return;
    }
    const c = lastSummary.counts || {};
    counts.textContent = `Pend: ${c.pending || 0} | En curso: ${c.in_progress || 0} | OK: ${c.success || 0} | Pendiente: ${c.failed || 0}`;
  }

  async function pollBridge() {
    try {
      const payload = await bridgeRequest("/health");
      connected = true;
      renderSummary(payload.summary);
      if (!running) {
        setStatus(payload.summary && payload.summary.done ? "Completado." : "Bridge conectado. Inicia sesión y presiona Start.");
      }
    } catch (_) {
      connected = false;
      if (!running) {
        setStatus("Bridge no conectado. Ejecuta N03 en BotManager.", true);
      }
    }
  }

  async function ensureCivilSearchReady() {
    if (!document.querySelector("#civilTab")) {
      const misCausas = clickableByText("Mis Causas");
      if (!misCausas) {
        throw new Error("No veo 'Mis Causas'. Inicia sesion manualmente en PJUD primero.");
      }
      misCausas.click();
    }

    const civilTab = await waitFor(() => document.querySelector("#civilTab"), 15000, "pestana Civil");
    if (isVisible(civilTab)) {
      civilTab.click();
      await sleep(500);
    }

    let rolField = document.querySelector("#rolMisCauCiv");
    const filtro = document.querySelector("#filtroMisCauCiv");
    if (filtro && (!rolField || !isVisible(rolField))) {
      filtro.click();
      await sleep(500);
    }

    rolField = await waitFor(() => {
      const field = document.querySelector("#rolMisCauCiv");
      return field && isVisible(field) ? field : false;
    }, 15000, "campo Rol Civil visible");
    await waitFor(() => {
      const field = document.querySelector("#anhoMisCauCiv");
      return field && isVisible(field) ? field : false;
    }, 15000, "campo Año Civil visible");
  }

  async function configureSearch(item) {
    await stepLog(item, "seleccionando tipo causa");
    await runMainWorld("selectPickerValue", { selectId: "tipoMisCauCiv", value: item.letra || "E" });
    await stepLog(item, "llenando numero de rol");
    await runMainWorld("setInputValue", { selector: "#rolMisCauCiv", value: item.numero1 });
    await stepLog(item, "llenando ano");
    await runMainWorld("setInputValue", { selector: "#anhoMisCauCiv", value: item.numero2 });
    await stepLog(item, "seleccionando todos los tipos");
    await runMainWorld("selectPickerAll", { selectId: "tipCausaMisCauCiv" });
    await stepLog(item, "seleccionando todos los estados");
    await runMainWorld("selectPickerAll", { selectId: "estadoCausaMisCauCiv" });
    await sleep(350);
    await verifySearchFields(item);
  }

  async function verifySearchFields(item) {
    await stepLog(item, "verificando filtros");
    await waitFor(() => {
      const rolField = document.querySelector("#rolMisCauCiv");
      const anhoField = document.querySelector("#anhoMisCauCiv");
      const tipoField = document.querySelector("#tipoMisCauCiv");
      if (!rolField || !anhoField) {
        return false;
      }
      const rolOk = normalizeDigits(rolField.value) === normalizeDigits(item.numero1);
      const anhoOk = normalizeDigits(anhoField.value) === normalizeDigits(item.numero2);
      const tipoValue = tipoField ? String(tipoField.value || "").trim().toUpperCase() : "E";
      const tipoOk = !tipoField || tipoValue === String(item.letra || "E").trim().toUpperCase();
      return rolOk && anhoOk && tipoOk;
    }, 6000, "campos de busqueda configurados");
  }

  function matchingRow(tribunalName) {
    const wanted = normalizeText(tribunalName);
    const rows = Array.from(document.querySelectorAll("#verDetalleMisCauCiv tr"));
    const found = [];
    for (const row of rows) {
      const cells = Array.from(row.querySelectorAll("td"));
      if (cells.length < 3) {
        continue;
      }
      const tribunalText = (cells[2].innerText || "").trim();
      if (!tribunalText) {
        continue;
      }
      found.push(tribunalText);
      const normalized = normalizeText(tribunalText);
      const link = row.querySelector("td a, a");
      const exact = wanted && normalized === wanted;
      if (link && (exact || !wanted)) {
        return { row, link, found };
      }
    }
    return { row: null, link: null, found };
  }

  function resultsContainSearchTerms(area, item) {
    const text = normalizeText(area ? area.innerText : "");
    const number = normalizeDigits(item.numero1);
    const year = normalizeDigits(item.numero2);
    if (!number || !year) {
      return true;
    }
    return text.includes(number) && text.includes(year);
  }

  async function clickSearchAndWaitResults(item, attemptNumber) {
    await stepLog(item, "buscando boton Buscar");
    const beforeText = (document.querySelector("#verDetalleMisCauCiv") || {}).innerText || "";
    const buscar = await waitFor(() => document.querySelector("#btnConsultaMisCauCiv"), 10000, "boton Buscar");
    const clickedAt = Date.now();
    await stepLog(item, `click Buscar intento ${attemptNumber}`);
    buscar.click();

    await stepLog(item, "esperando resultados");
    return waitFor(() => {
      const area = document.querySelector("#verDetalleMisCauCiv");
      if (!area) {
        return false;
      }
      const rows = Array.from(area.querySelectorAll("tr"));
      const hasData = rows.some((row) => row.querySelectorAll("td").length >= 3);
      const changed = area.innerText !== beforeText;
      const hasSearchTerms = resultsContainSearchTerms(area, item);
      const enoughTimePassed = Date.now() - clickedAt > 1200;
      if (!hasData) {
        return false;
      }
      if (hasSearchTerms) {
        return area;
      }
      return changed && enoughTimePassed ? area : false;
    }, 25000, "resultados de busqueda");
  }

  async function runSearchAndOpenModal(item) {
    let lastFound = [];
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      if (attempt > 1) {
        await stepLog(item, "reintentando busqueda");
      }
      await configureSearch(item);
      await clickSearchAndWaitResults(item, attempt);

      await stepLog(item, "buscando fila del tribunal");
      const match = matchingRow(item.tribunal);
      lastFound = match.found || [];
      if (!match.link) {
        await stepLog(item, `intento ${attempt} sin tribunal exacto`);
        await sleep(800);
        continue;
      }
      await stepLog(item, "abriendo modal de detalle");
      match.link.click();

      const modal = await waitFor(() => {
        const modal = document.querySelector("#modalDetalleMisCauCivil.in, #modalDetalleMisCauCivil.show, #modalDetalleMisCauCivil");
        return modal && isVisible(modal) ? modal : false;
      }, 15000, "modal detalle causa");
      await stepLog(item, "modal visible");
      return modal;
    }

    throw new Error(
      `Tribunal no encontrado tras 2 intentos: ${item.tribunal || "(sin tribunal)"} | vistos: ${lastFound.join(" | ")}`
    );
  }

  function readModalValue(modal, label) {
    const labelPattern = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const stopLabels = [
      "Historia Causa",
      "Cuaderno",
      "Informacion notificaciones",
      "Información notificaciones",
      "Agenda Receptor",
      "Historia Litigantes",
      "Notificaciones",
      "Escritos por Resolver",
      "Exhortos",
      "Piezas Exhorto",
      "Texto Demanda",
      "Anexos de la causa",
      "Certificado de Envio",
      "Certificado de Envío",
      "Ebook",
      "Cerrar",
    ];
    if (normalizeText(label).includes("causa origen")) {
      stopLabels.unshift("Tribunal Origen");
    }
    const stopPattern = stopLabels
      .map((value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .join("|");
    const allText = (modal.innerText || modal.textContent || "").replace(/\s+/g, " ").trim();
    const re = new RegExp(`${labelPattern}\\s*:\\s*(.*?)(?=\\s+(?:${stopPattern})\\b|$)`, "i");
    const match = allText.match(re);
    if (match && match[1]) {
      return match[1].trim();
    }

    const wanted = normalizeText(label);
    const nodes = Array.from(modal.querySelectorAll("td, th, div, span, p, li"));
    for (const node of nodes) {
      const text = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
      if (!text || !normalizeText(text).includes(wanted)) {
        continue;
      }
      const nodeMatch = text.match(re);
      if (nodeMatch && nodeMatch[1]) {
        return nodeMatch[1].trim();
      }
      const direct = text.match(new RegExp(`${labelPattern}\\s*:\\s*(.+)$`, "i"));
      if (direct && direct[1]) {
        return direct[1].trim();
      }
    }
    return "";
  }

  async function closeModal(modal) {
    const closeButton = modal.querySelector("button.close, [data-dismiss='modal'], [data-bs-dismiss='modal']");
    if (closeButton) {
      closeButton.click();
      await sleep(500);
    }
  }

  async function processItem(item) {
    setStatus(`Procesando ${item.rol}...`);
    await logToBridge(`procesando row=${item.row_index} rol=${item.rol} tribunal=${item.tribunal}`);
    const modal = await runSearchAndOpenModal(item);
    await stepLog(item, "leyendo modal");
    const causaOrigen = readModalValue(modal, "Causa Origen");
    const tribunalOrigen = readModalValue(modal, "Tribunal Origen");
    await stepLog(item, `valores leidos causa=${causaOrigen || "(vacio)"} tribunal=${tribunalOrigen || "(vacio)"}`);
    await closeModal(modal);

    if (!causaOrigen && !tribunalOrigen) {
      throw new Error("Modal abierto, pero no encontre Causa Origen / Tribunal Origen.");
    }
    return {
      row_index: item.row_index,
      status: "success",
      causa_origen: causaOrigen,
      tribunal_origen: tribunalOrigen
    };
  }

  async function runLoop() {
    if (running) {
      return;
    }
    running = true;
    stopRequested = false;

    try {
      await pollBridge();
      if (!connected) {
        throw new Error("Bridge no conectado. Inicia la task N03 en BotManager.");
      }
      await ensureCivilSearchReady();

      while (!stopRequested) {
        const nextPayload = await bridgeRequest("/next", { method: "POST", body: {} });
        renderSummary(nextPayload.summary);
        const item = nextPayload.item;
        if (!item) {
          setStatus("Completado.");
          break;
        }

        try {
          const result = await processItem(item);
          const saved = await bridgeRequest("/result", { method: "POST", body: result });
          renderSummary(saved.summary);
          setStatus(`OK ${item.rol}`);
        } catch (error) {
          const message = String(error && error.message ? error.message : error);
          await logToBridge(`error row=${item.row_index} rol=${item.rol}: ${message}`);
          const saved = await bridgeRequest("/result", {
            method: "POST",
            body: {
              row_index: item.row_index,
              status: "failed",
              error: message
            }
          });
          renderSummary(saved.summary);
          setStatus(`Pendiente ${item.rol}: ${message}`, true);
        }

        await sleep(800);
      }
    } finally {
      running = false;
    }
  }

  createPanel();
  pollBridge();
  setInterval(pollBridge, 2500);
})();
