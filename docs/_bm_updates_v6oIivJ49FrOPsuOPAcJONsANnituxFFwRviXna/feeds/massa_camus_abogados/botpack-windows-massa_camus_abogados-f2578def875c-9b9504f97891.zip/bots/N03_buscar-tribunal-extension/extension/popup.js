const statusEl = document.getElementById("status");

chrome.runtime.sendMessage({
  type: "N03_BRIDGE_REQUEST",
  path: "/health",
  options: {}
})
  .then((payload) => {
    if (!payload || payload.ok === false) {
      statusEl.textContent = "Bridge no conectado.";
      return;
    }
    const counts = payload.summary && payload.summary.counts ? payload.summary.counts : {};
    statusEl.textContent = `Bridge conectado. Pendientes: ${counts.pending || 0}, OK: ${counts.success || 0}.`;
  })
  .catch(() => {
    statusEl.textContent = "Bridge no conectado. Inicia la task N03.";
  });
