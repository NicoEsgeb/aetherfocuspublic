"""
CLEAN02 - SEPARAR ARCHIVOS (Clean BBRR)
=======================================
Splits scanned, RUT-named multi-document PDFs into their named sub-documents
(CHECKLIST, LIQUIDACION, INFORME, PAGARE(s), HOJA_DE_FIRMA, CEDULA, ANEXO).

100% local processing — no portal, no browser, no cloud. Uses PyMuPDF +
Tesseract OCR (Spanish) + NumPy/Pillow visual matching.

tasks.py stays THIN: it reads env vars, resolves the per-run output folder, and
delegates all logic to functions.py.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Enable imports from bots/shared/ (kept for parity with the bot template even
# though this local bot does not currently use shared portal/artifact helpers).
sys.path.insert(0, str(Path(__file__).parent.parent))

from robocorp.tasks import task
import os
from datetime import datetime

# Bot-specific business logic
from functions import separar_archivos

# ---------------------------------------------------------------------------
# Path and environment configuration
# ---------------------------------------------------------------------------
PATH_BOT = str(Path(__file__).parent)

# Folder (or single PDF) with the scanned RUT-named PDFs to separate.
SEPARAR_INPUT_PATH = os.getenv(
    "SEPARAR_INPUT_PATH",
    str(Path(PATH_BOT) / "input"),
)

# When "1", ignore the OCR cache and re-read every PDF from scratch (slower).
# Set by the desktop UI when the user ticks "Re-procesar desde cero".
SEPARAR_FORCE_FRESH = os.getenv("SEPARAR_FORCE_FRESH", "").strip() == "1"

# When "1", process the PDFs in parallel (one process per PDF, up to CPU-1).
# Set by the desktop UI when the user ticks "Procesar en paralelo".
SEPARAR_PARALLEL = os.getenv("SEPARAR_PARALLEL", "").strip() == "1"

# Optional power-user override for the worker count (default: CPU count - 1).
_max_workers_raw = os.getenv("SEPARAR_MAX_WORKERS", "").strip()
SEPARAR_MAX_WORKERS = int(_max_workers_raw) if _max_workers_raw.isdigit() else None


@task
def CLEAN02_SEPARAR_ARCHIVOS():
    """Separar archivos: divide cada PDF escaneado (RUT) en sus documentos."""
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    # Robocorp drops its own run logs (log.html + numbered output_*.robolog) into
    # output/; they pile up over time. Clear the previous run's leftovers so the
    # folder stays tidy — they are regenerated for this run and are NOT the bot's
    # results (those go in the Separar_<ts> subfolders). The active
    # output.robolog is left untouched.
    for _old in (*output_root.glob("output_*.robolog"), *output_root.glob("log.html")):
        try:
            _old.unlink()
        except OSError:
            pass
    # The desktop UI no longer picks the input; it is fixed at input/ and the
    # "Abrir carpeta de pdfs" button just opens it — make sure it exists. Only
    # create it when missing (an env override may point to a single PDF file).
    _input = Path(SEPARAR_INPUT_PATH)
    if not _input.exists():
        _input.mkdir(parents=True, exist_ok=True)
    run_stamp = datetime.now().strftime("%d.%m.%Y_%H_%M_%S")
    run_dir = output_root / f"Separar_{run_stamp}"

    print(f"[SEPARAR] Entrada : {SEPARAR_INPUT_PATH}")
    print(f"[SEPARAR] Salida  : {run_dir}")

    summary = separar_archivos(
        SEPARAR_INPUT_PATH, run_dir,
        force_fresh=SEPARAR_FORCE_FRESH,
        parallel=SEPARAR_PARALLEL,
        max_workers=SEPARAR_MAX_WORKERS,
    )

    totals = summary["totals"]
    print(
        f"\n[SEPARAR] Listo: {summary['pdf_count']} PDF procesado(s), "
        f"{totals['docs']} documento(s) generados "
        f"(auto {totals['auto']}, para revisar {totals['review']})."
    )
    if totals.get("dropped"):
        print(
            f"[SEPARAR] {totals['dropped']} pagina(s) descartada(s) en total "
            f"({totals.get('dropped_content', 0)} con contenido). Revisa los "
            "archivos _DESCARTADAS.pdf en _REVISAR por si hay algo util."
        )
    if summary["errors"]:
        print(f"[SEPARAR] {len(summary['errors'])} PDF con error:")
        for err in summary["errors"]:
            print(f"   - {err['pdf']}: {err['error']}")

    # Fail the task loudly when nothing could be produced. Otherwise robocorp
    # reports PASS on an empty run and the failure is easy to miss (e.g. when
    # Tesseract is missing, every PDF errors and 0 documents are generated).
    if totals["docs"] == 0:
        if summary["errors"]:
            raise RuntimeError(
                f"No se generó ningún documento: los {len(summary['errors'])} "
                "PDF fallaron (ver los errores arriba)."
            )
        raise RuntimeError(
            "No se generó ningún documento. Revisa la entrada: los PDF no "
            "produjeron documentos para separar."
        )

    print(
        "[SEPARAR] Revisa los documentos inciertos en la carpeta "
        "_REVISAR de cada RUT antes de usarlos."
    )
    print("Done")
