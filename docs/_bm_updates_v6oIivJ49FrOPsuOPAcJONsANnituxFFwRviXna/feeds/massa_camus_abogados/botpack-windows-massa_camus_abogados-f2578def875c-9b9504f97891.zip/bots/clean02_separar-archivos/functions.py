"""
clean02 "Separar archivos" — business logic
===========================================
Splits scanned, RUT-named multi-document PDFs into named sub-documents the way a
human operator does:

    CHECKLIST -> LIQUIDACION_DEUDA -> INFORME_DEUDA -> PAGARE(s) (MP/LP/TC)
              -> [HOJA_DE_FIRMA] -> [CEDULA_IDENTIDAD] -> [ANEXO_CONTRATO]

Everything else (blank backs, separators, "Condiciones Generales" boilerplate,
court certificates) is dropped. Each produced document is written as
`<RUT>_<LABEL>.pdf`; confident documents go straight to the run folder, uncertain
ones are routed to a `_REVISAR/` subfolder for a quick human check.

100% local: PyMuPDF render + Tesseract OCR (Spanish) + NumPy/Pillow visual
fingerprinting. No cloud, no portal, no browser.

tasks.py stays thin and only orchestrates calls into this module.
"""
from __future__ import annotations

import functools
import os
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

# ---------------------------------------------------------------------------
# Make the bundled engine importable as *flat* top-level modules
# (clean02, classifier, splitter). This must happen before importing them so
# the pre-built templates.pkl — pickled as `classifier.Templates` — resolves.
# ---------------------------------------------------------------------------
_ENGINE_DIR = Path(__file__).parent / "engine"
if str(_ENGINE_DIR) not in sys.path:
    sys.path.insert(0, str(_ENGINE_DIR))

import classifier as clf  # noqa: E402  (registers `classifier` for the pickle + API)
import clean02 as c  # noqa: E402  (engine helpers: Tesseract resolution/preflight)
from splitter import load_templates, split_pdf_with_review  # noqa: E402


def collect_input_pdfs(input_path: str) -> list[Path]:
    """Resolve the user's input to a sorted list of source PDFs.

    Accepts either a single `.pdf` file or a folder containing the scanned
    `<RUT>.pdf` files. Raises ValueError (Spanish) with a clear message when the
    input is missing, the wrong type, or contains no PDFs."""
    if not input_path or not str(input_path).strip():
        raise ValueError(
            "No se indicó una entrada.\n"
            "Selecciona el PDF o la carpeta con los PDF a separar."
        )
    p = Path(str(input_path).strip()).expanduser()
    if not p.exists():
        raise ValueError(
            "La ruta de entrada no existe.\n"
            f"Ruta: {p}"
        )
    if p.is_file():
        if p.suffix.lower() != ".pdf":
            raise ValueError(
                "El archivo seleccionado no es un PDF.\n"
                f"Archivo: {p.name}"
            )
        return [p]
    # Folder: top-level PDFs only (non-recursive), sorted for stable order.
    pdfs = sorted(p.glob("*.pdf"))
    if not pdfs:
        raise ValueError(
            "La carpeta seleccionada no contiene archivos PDF.\n"
            f"Carpeta: {p}"
        )
    return pdfs


# ---------------------------------------------------------------------------
# Per-PDF split — shared by the serial and parallel batch paths
# ---------------------------------------------------------------------------
# Each PDF is fully independent (own output folder, own OCR), so the parallel
# path fans them out over processes. Processes (not threads) on purpose: PyMuPDF
# is NOT thread-safe, but each process gets its own fitz context, and OCR is a
# deterministic Tesseract subprocess — so the produced documents are byte-for-byte
# identical to a serial run, only faster.


@functools.lru_cache(maxsize=1)
def _worker_templates():
    """Load the visual templates once per worker process (cached)."""
    return load_templates()


def _split_result(pdf: Path, output_dir: Path, tpl) -> dict:
    """Split ONE pdf into `output_dir/<RUT>/` and return a small, picklable
    result dict. A failure is captured (not raised) so one bad scan never aborts
    the batch — mirroring the serial loop's per-PDF try/except."""
    rut = pdf.stem
    case_dir = Path(output_dir) / rut
    try:
        manifest, recon = split_pdf_with_review(pdf, case_dir, tpl)
        return {"rut": rut, "pdf": pdf.name, "manifest": manifest,
                "recon": recon, "case_dir": str(case_dir)}
    except Exception as exc:  # one bad scan shouldn't abort the whole batch
        return {"rut": rut, "pdf": pdf.name, "error": str(exc)}


def _split_one_pdf(pdf_str: str, output_dir_str: str) -> dict:
    """ProcessPool worker: same as `_split_result` but loads its own templates.
    Runs in a fresh process, so it re-establishes the flat engine import path."""
    if str(_ENGINE_DIR) not in sys.path:      # belt-and-suspenders for 'spawn'
        sys.path.insert(0, str(_ENGINE_DIR))
    return _split_result(Path(pdf_str), Path(output_dir_str), _worker_templates())


def _account_case(summary: dict, result: dict) -> None:
    """Fold one PDF's result into the running totals/cases (NO printing). Called
    in input order by both paths, so the summary is identical regardless of the
    order results actually complete in."""
    if "error" in result:
        summary["errors"].append({"pdf": result["pdf"], "error": result["error"]})
        return
    manifest, recon = result["manifest"], result["recon"]
    n_auto = sum(1 for m in manifest if m["route"] == "AUTO")
    n_review = len(manifest) - n_auto
    totals = summary["totals"]
    totals["auto"] += n_auto
    totals["review"] += n_review
    totals["docs"] += len(manifest)
    totals["dropped"] += recon["dropped_pages"]
    totals["dropped_content"] += recon["dropped_content"]
    summary["cases"].append({
        "rut": result["rut"],
        "auto": n_auto,
        "review": n_review,
        "docs": len(manifest),
        "dropped": recon["dropped_pages"],
        "dropped_content": recon["dropped_content"],
        "dir": result["case_dir"],
    })


def _log_case(result: dict) -> None:
    """Print the per-PDF run-log line(s) for one result. Shared text so the serial
    and parallel paths read identically in the run log."""
    rut = result["rut"]
    if "error" in result:
        print(f"!! {rut}: ERROR — {result['error']}", flush=True)
        return
    manifest, recon = result["manifest"], result["recon"]
    n_auto = sum(1 for m in manifest if m["route"] == "AUTO")
    n_review = len(manifest) - n_auto
    # Page-conservation guard: every source page must land in a document or in
    # the descartadas PDF. If the totals don't add up, warn loudly.
    if not recon["balanced"]:
        print(
            f"!! {rut}: ADVERTENCIA — el conteo de paginas no cuadra "
            f"(total {recon['total_pages']}, en documentos "
            f"{recon['kept_pages']}, descartadas {recon['dropped_pages']}). "
            "Revisa el PDF original manualmente.",
            flush=True,
        )
    extra = ""
    if recon["dropped_pages"]:
        extra = (
            f"; {recon['dropped_pages']} pagina(s) descartada(s) "
            f"({recon['dropped_content']} con contenido) -> "
            f"_REVISAR/{recon['descartadas_pdf']}"
        )
    print(
        f"OK {rut}: {len(manifest)} documento(s) "
        f"(auto {n_auto}, revisar {n_review}){extra} -> {result['case_dir']}",
        flush=True,
    )


def _resolve_workers(parallel: bool, total: int, max_workers: int | None) -> int:
    """How many PDFs to process at once. 1 = serial. Parallelism only helps with
    2+ PDFs; the default leaves one core free so the machine stays responsive."""
    if not parallel or total <= 1:
        return 1
    if max_workers and max_workers > 0:
        return min(max_workers, total)
    return min(total, max(1, (os.cpu_count() or 2) - 1))


def _run_parallel(pdfs: list[Path], output_dir: Path, summary: dict,
                  total: int, n_workers: int) -> None:
    """Fan the per-PDF splits out over a process pool. Prints live progress as
    each finishes (completion order), but folds results into `summary` in INPUT
    order, so the summary matches a serial run byte-for-byte."""
    results: dict[int, dict] = {}
    done = 0
    with ProcessPoolExecutor(max_workers=n_workers) as ex:
        fut_to_idx = {ex.submit(_split_one_pdf, str(pdf), str(output_dir)): i
                      for i, pdf in enumerate(pdfs)}
        for fut in as_completed(fut_to_idx):
            i = fut_to_idx[fut]
            done += 1
            print(f"[CLEAN02][PROGRESS] {done}/{total}", flush=True)
            try:
                res = fut.result()
            except Exception as exc:  # a worker process crashed outright
                pdf = pdfs[i]
                res = {"rut": pdf.stem, "pdf": pdf.name, "error": str(exc)}
            results[i] = res
            _log_case(res)            # live feedback, completion order
    for i in range(len(pdfs)):        # summary + errors in stable input order
        _account_case(summary, results[i])


def separar_archivos(
    input_path: str, output_dir: str | Path, *, force_fresh: bool = False,
    parallel: bool = False, max_workers: int | None = None,
) -> dict:
    """Split every source PDF found at `input_path` into named documents under
    `output_dir/<RUT>/`. Returns a summary dict for logging.

    A failure on one PDF is recorded and skipped so the rest of the batch still
    runs; validation failures (missing/empty input) raise ValueError up front.

    When `force_fresh` is True the OCR feature cache is cleared first, so every
    PDF is re-read (OCR'd) from scratch instead of reusing a previous run's
    cached pages. Slower, but a guaranteed clean re-run.

    When `parallel` is True (and there are 2+ PDFs) the per-PDF splits run over a
    process pool of `max_workers` (default: CPU count minus one). OCR is
    deterministic and each PDF is independent, so the produced documents and the
    returned summary are identical to a serial run — only faster."""
    pdfs = collect_input_pdfs(input_path)
    total = len(pdfs)
    # Live progress markers consumed by the desktop UI (Clean02Plugin) to show a
    # "Procesando N de M" counter. flush=True so each line reaches the run log as
    # the PDF starts, not only when the whole batch finishes. "0/total" is emitted
    # up front so the UI shows the denominator from the very start.
    print(f"[CLEAN02][PROGRESS] 0/{total}", flush=True)
    if force_fresh:
        # User ticked "Re-procesar desde cero": drop cached OCR so every PDF is
        # read again from scratch (also heals a half-finished/corrupt cache).
        cleared = c.clear_feature_cache()
        print(
            f"[SEPARAR] Re-proceso desde cero: cache OCR limpiada "
            f"({cleared} archivo(s)); se volvera a leer cada PDF.",
            flush=True,
        )
    c.assert_tesseract_ready()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    tpl = load_templates()

    summary: dict = {
        "input": str(input_path),
        "output_dir": str(output_dir),
        "pdf_count": len(pdfs),
        "cases": [],
        "totals": {
            "auto": 0, "review": 0, "docs": 0,
            "dropped": 0, "dropped_content": 0,
        },
        "errors": [],
    }

    n_workers = _resolve_workers(parallel, total, max_workers)
    if n_workers > 1:
        print(
            f"[SEPARAR] Modo paralelo: hasta {n_workers} PDF a la vez "
            f"(de {os.cpu_count()} nucleos).",
            flush=True,
        )
        _run_parallel(pdfs, output_dir, summary, total, n_workers)
    else:
        for idx, pdf in enumerate(pdfs, start=1):
            # Marker for the live counter: idx is the PDF currently processed.
            print(f"[CLEAN02][PROGRESS] {idx}/{total}", flush=True)
            result = _split_result(pdf, output_dir, tpl)
            _log_case(result)
            _account_case(summary, result)

    return summary
