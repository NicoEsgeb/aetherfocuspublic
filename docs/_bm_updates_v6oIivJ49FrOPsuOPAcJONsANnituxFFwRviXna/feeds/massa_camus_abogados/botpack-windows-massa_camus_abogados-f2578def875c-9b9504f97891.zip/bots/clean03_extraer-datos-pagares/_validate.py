"""Throwaway: run the pipeline on the training data and score vs the human output."""
import sys, re, datetime as dt
from pathlib import Path

BOT = Path(__file__).parent
sys.path.insert(0, str(BOT))
from engine.pipeline import extraer_datos_pagares  # noqa: E402
import openpyxl  # noqa: E402

TRAIN = BOT / "input_for_training"
RUTS = TRAIN / "RUTS-used-by-human-input"
MATRIZ_IN = TRAIN / "Matriz_used-by-human-input" / "Matriz_Asignacion_input.xlsx"
HUMAN = TRAIN / "excel-created-by-human" / "Matriz_Asignacion_HUMAN-OUTPUT.xlsx"
OUT = BOT / "output" / "_VALIDATION_bot_output.xlsx"

FORCE = "--fresh" in sys.argv

print(">>> Running pipeline ...")
summary = extraer_datos_pagares(RUTS, MATRIZ_IN, OUT, force_fresh=FORCE)
print(">>> Summary:", {k: summary[k] for k in
      ("matriz_rows", "ruts", "processed_rows", "missing_rows", "extra_rows",
       "no_folder_rows", "flagged_cells", "output_rows")})

# ---- load both sheets by header --------------------------------------------
def load(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active
    headers = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]
    rows = []
    blanks = 0
    for r in ws.iter_rows(min_row=2, max_row=400, values_only=True):
        if all(v in (None, "") for v in r):
            blanks += 1
            if blanks >= 15:
                break  # human sheet's formatting spans ~1M rows; stop at the data
            continue
        blanks = 0
        rows.append({headers[i]: r[i] for i in range(len(headers)) if i < len(r)})
    wb.close()
    return rows

bot_rows = load(OUT)
human_rows = load(HUMAN)

def norm_op(v):
    return re.sub(r"\D", "", str(v or ""))

def key(row):
    return (norm_op(row.get("RUT")),
            str(row.get("CARTERA_ORIGINAL") or row.get("CARTERA") or "").strip().upper(),
            norm_op(row.get("OPERACIÓN") or row.get("OPERACION")))

bot_by = {key(r): r for r in bot_rows}
human_by = {key(r): r for r in human_rows}

# Only score RUTs that actually have a training folder (rows 2..38). The matriz
# has more rows (39..61) with no folders — the bot leaves those seed-only, so
# scoring them against the human's filled values would be meaningless.
def folder_rut(name):
    import re as _re
    mm = _re.match(r"^([\d.]+)\s*-\s*[0-9kK]$", name.strip())
    digits = _re.sub(r"\D", "", mm.group(1) if mm else name)
    return digits[:-1] if (not mm and len(digits) >= 2) else digits
FOLDER_RUTS = {folder_rut(p.name) for p in RUTS.iterdir() if p.is_dir() and not p.name.startswith(".")}
common = [k for k in human_by if k in bot_by and k[0] in FOLDER_RUTS]
print(f"\n>>> Human rows: {len(human_rows)}  Bot rows: {len(bot_rows)}  "
      f"Comparable (both): {len(common)}")

MONTHS = {1:1}
def to_date_str(v):
    if v in (None, ""):
        return ""
    if isinstance(v, (dt.datetime, dt.date)):
        return f"{v.day:02d}-{v.month:02d}-{v.year:04d}"
    s = str(v).strip()
    m = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$", s)
    if m:
        return f"{int(m.group(1)):02d}-{int(m.group(2)):02d}-{int(m.group(3)):04d}"
    return s

def to_int(v):
    if v in (None, ""):
        return None
    try:
        return int(round(float(str(v).replace(".", "").replace(",", "."))))
    except (ValueError, TypeError):
        return None

def to_float(v):
    if v in (None, ""):
        return None
    try:
        return round(float(str(v).replace(",", ".")), 2)
    except (ValueError, TypeError):
        return None

def norm_txt(v):
    folded = str(v or "").upper().translate(str.maketrans("ÁÉÍÓÚÜÑ", "AEIOUUN"))
    s = re.sub(r"[^A-Z0-9 ]", " ", folded)
    return re.sub(r"\s+", " ", s).strip()

AMOUNT = {"MONTO_PAGARE","MONTO_ADEUDADO","MONTO_CUOTA","MONTO_ULTIMA_CUOTA"}
INTF = {"NUM_CUOTAS","DIA_DEL_MES_VCTO_CUOTA","NRO_1RA_CUOTA_IMP","COD_CONTRATO"}
DATEF = {"FECHA_VCTO_1RA_CUOTA","FECHA_VCTO_ULTIMA_CUOTA","FECHA_SUSCRIPCION_PAGARE",
         "FECHA_VCTO_PAGARE","FECHA_1RA_CUOTA_IMP"}
FLOATF = {"TASA_INTERES"}
TEXTF = {"DOMICILIO_DEUDOR","COMUNA_DEUDOR","HOJA_DE_FIRMA"}

SCORE_FIELDS = list(AMOUNT) + list(INTF) + list(FLOATF) + list(DATEF) + list(TEXTF)

def compare(field, bot_v, hum_v):
    if field in AMOUNT or field in INTF:
        return to_int(bot_v) == to_int(hum_v)
    if field in FLOATF:
        return to_float(bot_v) == to_float(hum_v)
    if field in DATEF:
        b = to_date_str(bot_v)
        if b == to_date_str(hum_v):
            return True
        # Human cells stored as Excel datetimes are D/M-ambiguous (their string
        # dates are DD-MM, but typed dates got locale-parsed). Accept the swap.
        if isinstance(hum_v, (dt.datetime, dt.date)):
            swapped = f"{hum_v.month:02d}-{hum_v.day:02d}-{hum_v.year:04d}"
            return b == swapped
        return False
    if field == "DOMICILIO_DEUDOR":
        a, b = norm_txt(bot_v), norm_txt(hum_v)
        if not b:
            return None
        sa, sb = set(a.split()), set(b.split())
        jac = len(sa & sb) / len(sa | sb) if (sa | sb) else 0
        return jac >= 0.6
    return norm_txt(bot_v) == norm_txt(hum_v)

print("\n%-26s %6s %6s %6s   %s" % ("FIELD","human","match","rate","notes"))
print("-"*90)
overall_m = overall_n = 0
mismatches = []
for field in SCORE_FIELDS:
    n = m = 0
    miss_examples = []
    for k in common:
        hv = human_by[k].get(field)
        bv = bot_by[k].get(field)
        if field not in TEXTF and hv in (None, ""):
            continue  # human left it blank -> not expected
        if field in ("DOMICILIO_DEUDOR",) and hv in (None, ""):
            continue
        res = compare(field, bv, hv)
        if res is None:
            continue
        n += 1
        if res:
            m += 1
        else:
            if len(miss_examples) < 4:
                miss_examples.append((k[0], k[1], repr(bv), repr(hv)))
    rate = (m / n * 100) if n else 0
    overall_m += m; overall_n += n
    print("%-26s %6d %6d %5.0f%%" % (field, n, m, rate))
    for ex in miss_examples:
        mismatches.append((field, *ex))

print("-"*90)
print("OVERALL extracted-field accuracy: %d/%d = %.1f%%" %
      (overall_m, overall_n, (overall_m/overall_n*100 if overall_n else 0)))

print("\n>>> Sample mismatches (field, rut, cartera, bot, human):")
for mm in mismatches[:40]:
    print("   ", mm)

# ---- row-level + root-cause buckets -----------------------------------------
# RUTs whose misses are structurally impossible to fix (bad/missing source).
UNAVOIDABLE = {
    "6370728": "LP pagaré manuscrito (BankBoston 2004) — OCR no lee manuscrito",
    "10633883": "sin archivo INFORME_DEUDA en la carpeta",
    "11880887": "INFORME escaneado ilegible (~70 palabras OCR)",
    "14068125": "INFORME escaneado ilegible (~70 palabras OCR)",
    "13055502": "carpeta atípica (varios INFORME, .msg, español)",
    "9577308": "sin archivo HOJA_DE_FIRMA (el humano sí tenía)",
    "12407418": "sin archivo HOJA_DE_FIRMA",
    "12856191": "sin archivo HOJA_DE_FIRMA",
    "15509798": "sin archivo HOJA_DE_FIRMA",
    "10435841": "valor humano 18.983.172 != documento 22.396.297 (prob. error humano)",
}
rows_total = len(common)
rows_perfect = 0
for k in common:
    ok = True
    for field in SCORE_FIELDS:
        hv = human_by[k].get(field)
        if field not in TEXTF and hv in (None, ""):
            continue
        res = compare(field, bot_by[k].get(field), hv)
        if res is False:
            ok = False
            break
    if ok:
        rows_perfect += 1

# accuracy restricted to RUTs with good, complete source docs
gm = gn = 0
for field in SCORE_FIELDS:
    for k in common:
        if k[0] in UNAVOIDABLE:
            continue
        hv = human_by[k].get(field)
        if field not in TEXTF and hv in (None, ""):
            continue
        res = compare(field, bot_by[k].get(field), hv)
        if res is None:
            continue
        gn += 1
        gm += 1 if res else 0

print(f"\n>>> Filas (pagarés) comparadas: {rows_total}")
print(f">>> Filas 100% correctas: {rows_perfect}/{rows_total} = {rows_perfect/rows_total*100:.0f}%")
print(f">>> Precisión sobre RUTs con documentos completos y legibles "
      f"({rows_total - sum(1 for k in common if k[0] in UNAVOIDABLE)} pagarés): "
      f"{gm}/{gn} = {gm/gn*100:.1f}%")
print(f">>> RUTs excluidos por causa estructural ({len(UNAVOIDABLE)}):")
for r, why in UNAVOIDABLE.items():
    print(f"      {r}: {why}")
