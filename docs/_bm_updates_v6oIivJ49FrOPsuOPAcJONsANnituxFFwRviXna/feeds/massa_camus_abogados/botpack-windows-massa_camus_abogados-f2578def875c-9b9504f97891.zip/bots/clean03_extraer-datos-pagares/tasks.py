"""
CLEAN03 - EXTRAER DATOS PAGARÉS (Clean BBRR)
============================================
Reads a folder of RUT subfolders (each with the documents clean02 produced:
PAGARE_*, INFORME_DEUDA, HOJA_DE_FIRMA, etc.) plus the human-prepared input
matriz, and produces a single output matriz with every pagaré row filled in by
OCR — the same matriz a human builds by hand.

100% local: PyMuPDF + Tesseract OCR (Spanish) + openpyxl. No portal, browser
or cloud.

tasks.py stays THIN: it reads env vars, resolves the output path, and delegates
all logic to functions.py / the engine package.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Parity with the bot template (lets `from shared.xxx import ...` work even
# though this local bot does not currently use the shared helpers).
sys.path.insert(0, str(Path(__file__).parent.parent))

import os
from datetime import datetime

from robocorp.tasks import task

from functions import run_extraction

PATH_BOT = str(Path(__file__).parent)

# Folder with the RUT subfolders to process — FIXED at input/ruts/. The desktop
# UI no longer asks the user to pick it; its "Abrir carpeta" button just opens
# this folder so the user can drop the RUT folders in (or verify them).
PAGARES_INPUT_PATH = os.getenv("PAGARES_INPUT_PATH", str(Path(PATH_BOT) / "input" / "ruts"))


def _default_matriz_path() -> str:
    """First .xlsx/.xlsm in input/matriz/. The desktop UI normally sends the
    file the user picked; this is the fallback (e.g. CLI runs)."""
    matriz_dir = Path(PATH_BOT) / "input" / "matriz"
    found = sorted(matriz_dir.glob("*.xlsx")) + sorted(matriz_dir.glob("*.xlsm"))
    return str(found[0]) if found else str(matriz_dir / "Matriz_Asignacion_input.xlsx")


# The human-prepared input matriz (.xlsx). Worked on top of, never modified.
MATRIZ_INPUT_PATH = os.getenv("MATRIZ_INPUT_PATH", _default_matriz_path())
# When "1", ignore the OCR cache and re-read every PDF from scratch (slower).
CLEAN03_FORCE_FRESH = os.getenv("CLEAN03_FORCE_FRESH", "").strip() == "1"

# When "1", OCR the RUT folders in parallel (one process per RUT, up to CPU-1).
# Set by the desktop UI when the user ticks "Procesar en paralelo".
CLEAN03_PARALLEL = os.getenv("CLEAN03_PARALLEL", "").strip() == "1"

# Optional power-user override for the worker count (default: CPU count - 1).
_max_workers_raw = os.getenv("CLEAN03_MAX_WORKERS", "").strip()
CLEAN03_MAX_WORKERS = int(_max_workers_raw) if _max_workers_raw.isdigit() else None


@task
def CLEAN03_EXTRAER_DATOS_PAGARES():
    """Extraer datos de pagarés: rellena la matriz leyendo los PDF con OCR."""
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    # Robocorp drops its own run logs (log.html + numbered output_*.robolog) into
    # output/; a big OCR run splits them into many parts that pile up over time.
    # Clear the previous run's leftovers so the folder stays tidy — they are
    # regenerated for this run and are NOT the bot's results (the matriz lives in
    # the Extraer_<ts> subfolder). The active output.robolog is left untouched.
    for _old in (*output_root.glob("output_*.robolog"), *output_root.glob("log.html")):
        try:
            _old.unlink()
        except OSError:
            pass
    # Make sure the fixed input folder exists (so an empty install doesn't error).
    # Only create it when missing (an env override may point to a file).
    _ruts = Path(PAGARES_INPUT_PATH)
    if not _ruts.exists():
        _ruts.mkdir(parents=True, exist_ok=True)
    # One timestamped folder per run (like the other processes), holding the
    # generated matriz. The desktop "Abrir Resultados" button opens this folder.
    run_stamp = datetime.now().strftime("%d.%m.%Y_%H_%M_%S")
    run_dir = output_root / f"Extraer_{run_stamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    output_path = run_dir / f"Matriz_Asignacion_{run_stamp}.xlsx"

    print(f"[CLEAN03] Carpeta RUTs : {PAGARES_INPUT_PATH}")
    print(f"[CLEAN03] Matriz       : {MATRIZ_INPUT_PATH}")
    print(f"[CLEAN03] Salida       : {output_path}")

    summary = run_extraction(
        PAGARES_INPUT_PATH, MATRIZ_INPUT_PATH, str(output_path),
        force_fresh=CLEAN03_FORCE_FRESH,
        parallel=CLEAN03_PARALLEL,
        max_workers=CLEAN03_MAX_WORKERS,
    )

    print(
        f"\n[CLEAN03] Listo: {summary['output_rows']} fila(s) en la matriz "
        f"({summary['processed_rows']} procesada(s), "
        f"{summary['missing_rows']} sin pagaré, {summary['extra_rows']} extra, "
        f"{summary['no_folder_rows']} sin carpeta)."
    )
    # Structured one-liner that the desktop Clean03Plugin parses to build the
    # completion pop-up ("De X RUTs ... se procesaron Y", etc.).
    print(
        f"[CLEAN03][RESUMEN] ruts_total={summary['ruts']} "
        f"ruts_procesados={summary['ruts_processed']} "
        f"filas={summary['output_rows']} procesadas={summary['processed_rows']} "
        f"sin_pagare={summary['missing_rows']} extra={summary['extra_rows']} "
        f"sin_carpeta={summary['no_folder_rows']} marcadas={summary['flagged_cells']}"
    )
    if summary["flagged_cells"]:
        print(
            f"[CLEAN03] {summary['flagged_cells']} celda(s) marcada(s) en amarillo "
            "(NO_ENCONTRADO / REVISAR). Revísalas antes de usar la matriz."
        )
    if summary["missing_rows"]:
        print(
            f"[CLEAN03] {summary['missing_rows']} fila(s) en rojo: el pagaré "
            "esperado no se encontró en la carpeta del RUT."
        )

    # Fail loudly if nothing was produced (e.g. wrong input folder).
    if summary["output_rows"] == 0:
        raise RuntimeError(
            "No se generó ninguna fila. Revisa la carpeta de RUTs y la matriz de entrada."
        )

    print(f"[CLEAN03] Matriz generada: {output_path}")
    print("Done")
