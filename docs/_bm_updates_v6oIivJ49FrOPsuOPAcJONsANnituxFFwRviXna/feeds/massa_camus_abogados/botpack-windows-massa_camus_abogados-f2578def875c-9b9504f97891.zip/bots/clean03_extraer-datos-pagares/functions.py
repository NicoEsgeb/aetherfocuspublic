"""
clean03 "Extraer datos pagarés" — business logic bridge
=======================================================
Thin bridge between the Robocorp task and the engine package. All real work
lives in engine/ (ocr.py, extract.py, matriz.py, pipeline.py). 100% local:
PyMuPDF render + Tesseract OCR (Spanish) + openpyxl.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Make the bundled `engine` package importable (engine/pipeline.py uses relative
# imports, so the bot directory — not engine/ — must be on sys.path).
_BOT_DIR = Path(__file__).parent
if str(_BOT_DIR) not in sys.path:
    sys.path.insert(0, str(_BOT_DIR))

from engine.pipeline import extraer_datos_pagares  # noqa: E402


def run_extraction(pagares_input_path: str, matriz_input_path: str,
                   output_path: str, *, force_fresh: bool = False,
                   parallel: bool = False, max_workers: int | None = None) -> dict:
    """Run the full extraction and return the summary dict. Validation errors
    (missing input / wrong type) raise ValueError with a Spanish message.

    `parallel` fans the per-RUT OCR out over processes (identical output, faster);
    `max_workers` overrides the default worker count (CPU count minus one)."""
    return extraer_datos_pagares(
        pagares_input_path, matriz_input_path, output_path,
        force_fresh=force_fresh, parallel=parallel, max_workers=max_workers,
    )
