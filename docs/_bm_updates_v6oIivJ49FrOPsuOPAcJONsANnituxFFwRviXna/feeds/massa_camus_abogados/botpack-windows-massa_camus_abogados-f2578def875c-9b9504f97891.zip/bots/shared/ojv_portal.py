"""
shared/ojv_portal.py
--------------------
OJV (Oficina Judicial Virtual) portal helpers shared across all bots.

Provides:
  - goto_ojv_login_with_browser   -> Playwright-based login navigation
  - goto_ojv_login_with_driver    -> Selenium-based login navigation
  - ojv_url                       -> Build an absolute OJV URL from a relative path
  - handle_ojv_login_blockers     -> Dismiss risk warnings and modal avisors
"""
from __future__ import annotations

import os
import re
import time
from urllib.parse import urlparse


# ---------------------------------------------------------------------------
# Constants (all configurable via environment variables)
# ---------------------------------------------------------------------------

DEFAULT_OJV_LOGIN_URLS = (
    "https://ojv.pjud.cl/kpitec-ojv-web/views/login.html",
    "https://ojv.poderjudicial.cl/kpitec-ojv-web/loginTF",
)
OJV_RETRY_ATTEMPTS = 3
OJV_RETRY_WAIT_SECONDS = 4

DEFAULT_OJV_RISK_WARNING_CONTINUE_TEXT = "Entiendo los riesgos y deseo continuar"
OJV_RISK_WARNING_CONTINUE_TEXT = (
    os.getenv("OJV_RISK_WARNING_CONTINUE_TEXT", DEFAULT_OJV_RISK_WARNING_CONTINUE_TEXT).strip()
    or DEFAULT_OJV_RISK_WARNING_CONTINUE_TEXT
)
OJV_AUTO_ACCEPT_RISK_WARNING = os.getenv(
    "OJV_AUTO_ACCEPT_RISK_WARNING",
    "1",
).strip().lower() not in {"0", "false", "no", "off"}

try:
    OJV_RISK_WARNING_TIMEOUT_MS = max(0, int(os.getenv("OJV_RISK_WARNING_TIMEOUT_MS", "6000")))
except ValueError:
    OJV_RISK_WARNING_TIMEOUT_MS = 6000

try:
    OJV_LOGIN_AVISO_TIMEOUT_MS = max(0, int(os.getenv("OJV_LOGIN_AVISO_TIMEOUT_MS", "3000")))
except ValueError:
    OJV_LOGIN_AVISO_TIMEOUT_MS = 3000


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compile_warning_text_pattern(text: str) -> re.Pattern[str]:
    normalized = r"\s+".join(re.escape(part) for part in text.split())
    return re.compile(rf"{normalized}\.?", re.IGNORECASE)


OJV_RISK_WARNING_TEXT_PATTERN = _compile_warning_text_pattern(OJV_RISK_WARNING_CONTINUE_TEXT)


def _ordered_unique(values: list[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return tuple(ordered)


def _error_summary(error: Exception) -> str:
    text = str(error).strip()
    if not text:
        return error.__class__.__name__
    return text.splitlines()[0]


def _iter_browser_contexts(page) -> list:
    contexts = [page]
    try:
        for frame in page.frames:
            contexts.append(frame)
    except Exception:
        pass
    return contexts


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ojv_login_url_candidates() -> tuple[str, ...]:
    """Return OJV login URL candidates from env override + defaults."""
    env_urls = [
        value.strip()
        for value in os.getenv("OJV_LOGIN_URLS", "").split(",")
        if value.strip()
    ]
    return _ordered_unique(env_urls + list(DEFAULT_OJV_LOGIN_URLS))


def remember_ojv_base_url(url: str) -> None:
    """Store the active OJV base URL in the environment for subsequent calls."""
    parsed = urlparse(url)
    if parsed.scheme and parsed.netloc:
        os.environ["OJV_ACTIVE_BASE_URL"] = f"{parsed.scheme}://{parsed.netloc}"


def ojv_url(path: str) -> str:
    """Build an absolute OJV URL from a portal-relative path."""
    normalized_path = path if path.startswith("/") else f"/{path}"
    base_url = os.getenv("OJV_ACTIVE_BASE_URL", "").strip().rstrip("/")
    if not base_url:
        for login_url in ojv_login_url_candidates():
            parsed = urlparse(login_url)
            if parsed.scheme and parsed.netloc:
                base_url = f"{parsed.scheme}://{parsed.netloc}"
                break
    if not base_url:
        raise RuntimeError("No se pudo resolver base URL de OJV.")
    return f"{base_url}{normalized_path}"


def dismiss_vm_risk_warning_if_present(page, timeout_ms: int | None = None) -> bool:
    """Click the VM risk-warning button if visible. Returns True if dismissed."""
    if not OJV_AUTO_ACCEPT_RISK_WARNING:
        return False

    timeout = OJV_RISK_WARNING_TIMEOUT_MS if timeout_ms is None else max(0, timeout_ms)
    deadline = time.time() + (timeout / 1000)
    while True:
        saw_candidate = False
        for context in _iter_browser_contexts(page):
            candidates = (
                context.get_by_role("button", name=OJV_RISK_WARNING_TEXT_PATTERN).first,
                context.get_by_role("link", name=OJV_RISK_WARNING_TEXT_PATTERN).first,
                context.get_by_text(OJV_RISK_WARNING_TEXT_PATTERN).first,
            )
            for candidate in candidates:
                try:
                    if candidate.count() == 0:
                        continue
                    saw_candidate = True
                    if not candidate.is_visible():
                        continue
                    candidate.click(timeout=1000)
                    print(
                        "[OJV][WARN] Advertencia de seguridad detectada y confirmada "
                        f"('{OJV_RISK_WARNING_CONTINUE_TEXT}')."
                    )
                    return True
                except Exception:
                    continue

        if not saw_candidate:
            return False
        if time.time() >= deadline:
            return False
        time.sleep(0.25)


def dismiss_login_modal_aviso_if_present(page, timeout_ms: int | None = None) -> bool:
    """Close the login modal aviso if present. Returns True if closed."""
    timeout = OJV_LOGIN_AVISO_TIMEOUT_MS if timeout_ms is None else max(0, timeout_ms)
    aviso_close = page.locator("xpath=//*[@id='modalAviso']/div/div/div[1]/div/img").first
    try:
        if aviso_close.count() == 0:
            return False
        if not aviso_close.is_visible():
            return False
        aviso_close.click(timeout=max(timeout, 500))
        print("[OJV][WARN] Modal de aviso inicial cerrado automaticamente.")
        return True
    except Exception:
        return False


def handle_ojv_login_blockers(page) -> None:
    """Dismiss risk warnings and login modal avisors (two passes for sequenced blockers)."""
    for _ in range(2):
        handled_any = False
        if dismiss_vm_risk_warning_if_present(page):
            handled_any = True
            time.sleep(0.5)
        if dismiss_login_modal_aviso_if_present(page):
            handled_any = True
            time.sleep(0.2)
        if not handled_any:
            return


def _apply_stealth(page) -> None:
    """Apply playwright-stealth to a page to bypass WAF bot detection (F5 BIG-IP)."""
    try:
        from playwright_stealth import stealth_sync
        stealth_sync(page)
    except ImportError:
        try:
            from playwright_stealth import Stealth
            Stealth().use_sync(page)
        except Exception:
            pass
    except Exception:
        pass


def goto_ojv_login_with_browser():
    """
    Navigate to the OJV login page using robocorp.browser (Playwright).
    Tries all URL candidates with retries. Returns the Playwright page.
    """
    from robocorp import browser  # imported here to keep module importable without robocorp

    # Anti-detection: apply playwright-stealth before first navigation so the WAF
    # (F5 BIG-IP) does not detect Playwright's browser fingerprint.
    ctx = browser.context()
    page = ctx.new_page()
    _apply_stealth(page)

    urls = ojv_login_url_candidates()
    last_error: Exception | None = None
    for attempt in range(1, OJV_RETRY_ATTEMPTS + 1):
        for url in urls:
            try:
                page.goto(url)
                remember_ojv_base_url(url)
                handle_ojv_login_blockers(page)
                if attempt > 1 or url != urls[0]:
                    print(f"[OJV][LOGIN] URL abierta: {url} (intento {attempt})")
                return page
            except Exception as error:
                last_error = error
                print(
                    f"[OJV][LOGIN][WARN] intento={attempt} url={url} "
                    f"error={_error_summary(error)}"
                )
        if attempt < OJV_RETRY_ATTEMPTS:
            time.sleep(OJV_RETRY_WAIT_SECONDS)
    raise RuntimeError(
        "No se pudo abrir el login de OJV tras multiples intentos y hosts."
    ) from last_error


def goto_ojv_login_with_driver(driver) -> str:
    """
    Navigate to the OJV login page using a Selenium WebDriver.
    Tries all URL candidates with retries. Returns the URL that worked.
    """
    urls = ojv_login_url_candidates()
    last_error: Exception | None = None
    for attempt in range(1, OJV_RETRY_ATTEMPTS + 1):
        for url in urls:
            try:
                driver.get(url)
                remember_ojv_base_url(url)
                if attempt > 1 or url != urls[0]:
                    print(f"[OJV][LOGIN] URL abierta: {url} (intento {attempt})")
                return url
            except Exception as error:
                last_error = error
                print(
                    f"[OJV][LOGIN][WARN] intento={attempt} url={url} "
                    f"error={_error_summary(error)}"
                )
        if attempt < OJV_RETRY_ATTEMPTS:
            time.sleep(OJV_RETRY_WAIT_SECONDS)
    raise RuntimeError(
        "No se pudo abrir el login de OJV tras multiples intentos y hosts."
    ) from last_error
