from __future__ import annotations

import os

DEFAULT_PJUD_USERNAME = ""
DEFAULT_PJUD_PASSWORD = ""
DEFAULT_PJUD_PROFILE_LABEL = ""


def get_pjud_username() -> str:
    return os.getenv("PJUD_USERNAME", DEFAULT_PJUD_USERNAME).strip() or DEFAULT_PJUD_USERNAME


def get_pjud_password() -> str:
    return os.getenv("PJUD_PASSWORD", DEFAULT_PJUD_PASSWORD).strip() or DEFAULT_PJUD_PASSWORD


def get_pjud_profile_label() -> str:
    return os.getenv("PJUD_PROFILE_LABEL", DEFAULT_PJUD_PROFILE_LABEL).strip() or DEFAULT_PJUD_PROFILE_LABEL


def get_pjud_credentials() -> tuple[str, str, str]:
    return (
        get_pjud_username(),
        get_pjud_password(),
        get_pjud_profile_label(),
    )
