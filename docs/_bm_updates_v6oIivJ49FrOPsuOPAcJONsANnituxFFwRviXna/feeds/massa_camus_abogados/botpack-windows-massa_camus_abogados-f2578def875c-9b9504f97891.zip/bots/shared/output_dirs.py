"""
shared/output_dirs.py
---------------------
Timestamped output directory helpers shared across all bots.

Provides:
  - create_ingreso_output_dir           -> output/output_ingreso/Ingreso_<timestamp>/
  - create_descargar_caratulas_output_dir -> output/output_caratulas/Descargar_Caratulas_<ts>/
  - create_descargar_informe_output_dir -> output/output_descarga_informe/Descarga_de_Informe_<ts>/
  - resolve_descargar_caratulas_output_dir -> env override or auto-created directory
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_ingreso_output_dir(path_bot: str, run_started_at: datetime | None = None) -> str:
    """Create and return a unique timestamped ingreso output directory."""
    output_root = Path(path_bot) / "output" / "output_ingreso"
    output_root.mkdir(parents=True, exist_ok=True)

    timestamp_source = run_started_at or datetime.now()
    timestamp = timestamp_source.strftime("%d-%m-%Y_%H-%M")
    run_output = output_root / f"Ingreso_{timestamp}"

    suffix = 2
    while run_output.exists():
        run_output = output_root / f"Ingreso_{timestamp}_{suffix}"
        suffix += 1

    run_output.mkdir(parents=True, exist_ok=False)
    return str(run_output)


def create_descargar_caratulas_output_dir(
    path_bot: str,
    run_started_at: datetime | None = None,
) -> str:
    """Create and return a unique timestamped caratulas download output directory."""
    output_root = Path(path_bot) / "output" / "output_caratulas"
    output_root.mkdir(parents=True, exist_ok=True)

    timestamp_source = run_started_at or datetime.now()
    timestamp = timestamp_source.strftime("%d-%m-%Y_%H-%M")
    run_output = output_root / f"Descargar_Caratulas_{timestamp}"

    suffix = 2
    while run_output.exists():
        run_output = output_root / f"Descargar_Caratulas_{timestamp}_{suffix}"
        suffix += 1

    run_output.mkdir(parents=True, exist_ok=False)
    return str(run_output)


def resolve_descargar_caratulas_output_dir(path_bot: str) -> str:
    """
    Return the caratulas output directory.
    Uses GET_CARATULAS_OUTPUT_DIR / DESCARGAR_CARATULAS_OUTPUT_DIR env override if set,
    otherwise creates a new timestamped directory.
    """
    explicit_path = (
        os.getenv("GET_CARATULAS_OUTPUT_DIR", "").strip()
        or os.getenv("DESCARGAR_CARATULAS_OUTPUT_DIR", "").strip()
    )
    if explicit_path:
        resolved = Path(explicit_path).expanduser()
        if not resolved.is_absolute():
            resolved = (Path(path_bot) / resolved).resolve()
        resolved.mkdir(parents=True, exist_ok=True)
        return str(resolved)

    return create_descargar_caratulas_output_dir(path_bot)


def create_descargar_informe_output_dir(
    path_bot: str,
    run_started_at: datetime | None = None,
) -> str:
    """Create and return a unique timestamped informe download output directory."""
    output_root = Path(path_bot) / "output" / "output_descarga_informe"
    output_root.mkdir(parents=True, exist_ok=True)

    timestamp_source = run_started_at or datetime.now()
    timestamp = timestamp_source.strftime("%d-%m-%Y_%H-%M")
    run_output = output_root / f"Descarga_de_Informe_{timestamp}"

    suffix = 2
    while run_output.exists():
        run_output = output_root / f"Descarga_de_Informe_{timestamp}_{suffix}"
        suffix += 1

    run_output.mkdir(parents=True, exist_ok=False)
    return str(run_output)
