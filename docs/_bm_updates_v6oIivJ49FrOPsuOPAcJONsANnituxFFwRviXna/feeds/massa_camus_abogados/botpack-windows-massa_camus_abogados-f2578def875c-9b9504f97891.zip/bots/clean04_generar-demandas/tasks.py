"""
CLEAN04 - GENERAR DEMANDAS (Clean BBRR)
=======================================
Reads ONE matriz (the clean03 output, one row per pagaré) and:
  * generates 1 demanda per RUT — in BOTH PDF (output/.../demandas_pdf/) and
    editable Word (output/.../demandas_word/) — for RUTs that fully validate
    (a RUT with N pagarés = N rows = 1 demanda with N pagaré paragraphs);
  * writes an annotated COPY of that matriz ({name}_ESTADO.xlsx) into the run's
    output folder with a resumable `ESTADO` column (OK / REVISAR / ERROR) +
    yellow highlights on the specific missing cells. The ORIGINAL is never
    modified.

The bot is re-runnable on its own output: a RUT is skipped only when every one
of its rows already says ESTADO == "OK". The user fixes the yellow cells and
re-runs the same file; only the REVISAR/ERROR RUTs are reprocessed.

100% local: PyMuPDF (fitz) to lay out the PDFs + openpyxl to annotate the
matriz. No browser, portal or OCR.

tasks.py stays THIN: it reads env vars, resolves the run output folder, and
delegates all logic to functions.py / the engine package.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Parity with the bot template (lets `from shared.xxx import ...` work even
# though this local bot does not currently use the shared helpers).
sys.path.insert(0, str(Path(__file__).parent.parent))

import os
from datetime import datetime

from robocorp.tasks import task

from functions import run_generation

PATH_BOT = str(Path(__file__).parent)


def _default_matriz_path() -> str:
    """First .xlsx/.xlsm in input/matriz/. The desktop UI normally sends the
    file the user picked; this is the fallback (e.g. CLI runs)."""
    matriz_dir = Path(PATH_BOT) / "input" / "matriz"
    found = sorted(matriz_dir.glob("*.xlsx")) + sorted(matriz_dir.glob("*.xlsm"))
    return str(found[0]) if found else str(matriz_dir / "Matriz_Asignacion_input.xlsx")


# The matriz to read + annotate in place (the clean03 output). Selectable in the
# desktop UI; this is the fallback for CLI runs.
MATRIZ_INPUT_PATH = os.getenv("MATRIZ_INPUT_PATH", _default_matriz_path())
# When "1", regenerate every RUT's PDF even if its rows already say OK (ignore
# the resume/skip behaviour). Useful after fixing the template or a bad batch.
CLEAN04_FORCE_ALL = os.getenv("CLEAN04_FORCE_ALL", "").strip() == "1"


@task
def CLEAN04_GENERAR_DEMANDAS():
    """Generar demandas: 1 PDF por RUT + columna ESTADO (reanudable) en la matriz."""
    output_root = Path(PATH_BOT) / "output"
    output_root.mkdir(parents=True, exist_ok=True)
    # Robocorp drops its own run logs (log.html + numbered output_*.robolog) into
    # output/; clear the previous run's leftovers so the folder stays tidy — they
    # are regenerated for this run and are NOT the bot's results (the demandas
    # live in the Demandas_<ts> subfolder). The active output.robolog is left be.
    for _old in (*output_root.glob("output_*.robolog"), *output_root.glob("log.html")):
        try:
            _old.unlink()
        except OSError:
            pass

    run_stamp = datetime.now().strftime("%d.%m.%Y_%H_%M_%S")
    run_dir = output_root / f"Demandas_{run_stamp}"
    run_dir.mkdir(parents=True, exist_ok=True)

    print(f"[CLEAN04] Matriz  : {MATRIZ_INPUT_PATH}")
    print(f"[CLEAN04] Salida  : {run_dir}")
    if CLEAN04_FORCE_ALL:
        print("[CLEAN04] Forzar regeneración: se ignoran los ESTADO == OK previos.")

    summary = run_generation(
        MATRIZ_INPUT_PATH, str(run_dir), force_all=CLEAN04_FORCE_ALL,
    )

    print(
        f"\n[CLEAN04] Listo: {summary['ruts_total']} RUT en la matriz — "
        f"{summary['ruts_ok']} OK (PDF generado), "
        f"{summary['ruts_skipped']} ya estaban OK (omitidos), "
        f"{summary['ruts_revisar']} REVISAR, {summary['ruts_error']} ERROR."
    )
    # Structured one-liner the Clean04Plugin parses for the completion pop-up.
    print(
        f"[CLEAN04][RESUMEN] ruts_total={summary['ruts_total']} "
        f"ok={summary['ruts_ok']} omitidos={summary['ruts_skipped']} "
        f"revisar={summary['ruts_revisar']} error={summary['ruts_error']} "
        f"pdfs={summary['pdfs_generated']} "
        f"filas_total={summary['filas_total']} filas_ok={summary['filas_ok']} "
        f"filas_omitidos={summary['filas_skipped']} "
        f"filas_revisar={summary['filas_revisar']} filas_error={summary['filas_error']}"
    )
    if summary["ruts_revisar"]:
        print(
            f"[CLEAN04] {summary['ruts_revisar']} RUT en amarillo (REVISAR): faltan "
            "datos requeridos. Revisa las celdas amarillas de la matriz, corrígelas "
            "y vuelve a correr el MISMO archivo (solo se reprocesan esos RUT)."
        )
    if summary["ruts_error"]:
        print(
            f"[CLEAN04] {summary['ruts_error']} RUT en rojo (ERROR): CARTERA_A_PROCESAR "
            "sigue en RE (el humano debe ponerla MP/VI) o falló la escritura del PDF."
        )

    # Fail loudly if the matriz could not be read at all.
    if summary["ruts_total"] == 0:
        raise RuntimeError(
            "No se encontró ningún RUT en la matriz. Revisa el archivo de entrada."
        )

    print(f"[CLEAN04] Original SIN modificar: {summary['matriz_original']}")
    print(f"[CLEAN04] Copia anotada (ESTADO): {summary['matriz_path']}")
    print(f"[CLEAN04] Demandas en           : {run_dir}")
    print("Done")
