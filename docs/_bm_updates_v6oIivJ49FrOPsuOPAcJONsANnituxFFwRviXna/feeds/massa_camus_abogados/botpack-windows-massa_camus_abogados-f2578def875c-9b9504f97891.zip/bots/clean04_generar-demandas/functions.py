"""
clean04 "Generar demandas" — business logic bridge
==================================================
Thin bridge between the Robocorp task and the engine package. All real work
lives in engine/ (matriz_io.py, demanda_builder.py, render.py, pipeline.py).
100% local: PyMuPDF layout + openpyxl. No browser, portal or OCR.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Make the bundled `engine` package importable (engine/pipeline.py uses relative
# imports, so the bot directory — not engine/ — must be on sys.path).
_BOT_DIR = Path(__file__).parent
if str(_BOT_DIR) not in sys.path:
    sys.path.insert(0, str(_BOT_DIR))

from engine.pipeline import generar_demandas  # noqa: E402


def run_generation(matriz_input_path: str, run_dir: str, *,
                   force_all: bool = False) -> dict:
    """Generate 1 demanda PDF per fully-valid RUT and write an annotated COPY of
    the matriz (with the resumable ESTADO column) into run_dir — the original
    input matriz is never modified. Returns the summary dict. Validation errors
    (missing input / wrong type) raise ValueError with a Spanish message."""
    return generar_demandas(matriz_input_path, run_dir, force_all=force_all)
