# clean04 — Preguntas para el cliente (revisión de ejemplos)

Bot que genera las demandas (PDF) a partir de la matriz `Matriz_asignacion.xlsx` + la guía `Formato_macro_2026-06-24_v02.docx`.

> 🌳 **Diagrama único — [`arbol_decision.svg`](arbol_decision.svg)** (abre en cualquier navegador). Es **UN solo archivo** con todo: arriba el router (cómo se elige la plantilla de cada pagaré), al centro el armado paso a paso del párrafo de **A, B y C** en 3 columnas (base, campos requeridos, decisiones), y abajo lo que va una sola vez por demanda (cierre · RUEGO · 2° Otrosí). Los ⚠ del diagrama = números de esta tabla. *(Se consolidó todo aquí para editar un solo archivo; ya no hay `plantilla_*_flujo.svg` sueltos.)*
>
> 📌 **Detalle que emergió al mapear B y C** (visible en el diagrama): el total del párrafo usa **campos distintos** — B → `MONTO_ADEUDADO`, C → `MONTO_PAGARE` (en carteras "a la Vista" suelen ser iguales, pero el mergefield difiere).

> 🔴 **HALLAZGO URGENTE (lote `REVISION_URGENTE`, 64 demandas firmadas revisadas):** los **pagarés LP se están omitiendo de forma SISTEMÁTICA** cuando el RUT tiene un MP "en cuotas". Falta el párrafo del LP **y su monto no entra al total**. Pasó en **5 RUT** (ver punto #5). También: **14.026.491-1 quedó sin demanda** y **22.778.939-5 tiene demanda pero no está en la matriz** (ver punto #13). Esto NO es una ambigüedad de redacción: es un error que deja plata sin demandar. Avisar al cliente ya.

**Archivos:**
- Matriz de entrada (training): `training/matriz_usada/Matriz_asignacion.xlsx` (13 filas)
- Guía humana (reglas): `training/Formato_macro_2026-06-24_v02.docx`
- Demandas de training: `training/demandas_generadas/` (un PDF por RUT)
- **Lote grande revisado:** `REVISION_URGENTE/Matriz_Asignacion_Lote_2026_06_04_Asig_81_64.xlsm` (hoja `Asignacion_Final`, 81 pagarés / 64 RUT) + `REVISION_URGENTE/05_Demandas_firmadas/` (64 PDF firmados)

**Cómo se arma la demanda (entendido):** 1 PDF por RUT. La matriz tiene una fila por pagaré, así que un RUT con 4 pagarés = 4 filas = 1 PDF con 4 párrafos de pagaré. Cada párrafo usa una de 3 plantillas según el tipo de pagaré.

**Las 3 plantillas de párrafo** (regla validada **75/75** contra el lote `REVISION_URGENTE`, ver §"Regla de selección validada"):
- **A — "En cuotas"**: el pagaré trae **datos de cuota** (`TASA_INTERES` · `NUM_CUOTAS` · `MONTO_CUOTA`). Aplica a **MP y RE** (renegociación) — 45 MP + 11 RE en el lote.
- **B — "A la Vista"**: **sin** datos de cuota y **NO** `PAGARE_FIRMADO_CLIENTE`=SI (banco firmó por mandato: `CONTRATO_MANDATO_FIRMADO_CLIENTE`=SI, o por defecto). LP / LN / TC / VI, y MP/RE sin cuotas (clean03 los marca `VI`).
- **C — "Plazo fijo / firmado por el cliente"**: sin datos de cuota **y** `PAGARE_FIRMADO_CLIENTE`=SI (cliente firmó el pagaré). Requiere `FECHA_VCTO_PAGARE` para redactarse — si falta → REVISAR (ver #4).

> ⚙️ **Cruce automático:** el chequeo matriz↔demandas de este documento ahora es un script reutilizable — [`tools/cruce_matriz_demandas.py`](tools/cruce_matriz_demandas.py). Corrido sobre el lote `REVISION_URGENTE` (64 demandas firmadas) es la fuente de los números de #4, #5, #12, #13 y #14.

**Cómo leer la columna "Regla en la guía":** cita el texto que puedes buscar (Ctrl+F) dentro del `Formato_macro`. Si dice **❌ No está en la guía**, significa que la guía no tiene ninguna regla para ese caso (por eso es ambigüedad).

---

## Tabla de preguntas para el cliente

Instrucción: revisa **"Dónde verificarlo"** abriendo el PDF/matriz, compáralo con **"Regla en la guía"**, y hazle al cliente la **"Pregunta"**. Anota la respuesta en la última columna.

| # | Tema | Qué observamos | Dónde verificarlo (ejemplo concreto) | Regla en la guía (Formato_macro) | Pregunta para el cliente | Respuesta del cliente |
|---|------|----------------|--------------------------------------|----------------------------------|--------------------------|-----------------------|
| 1 | **✅ RESUELTO — Columnas que clean04 necesita** | clean03 generaba **una** columna `CONTRATO_FIRMADO_CLIENTE`. La matriz de clean04 necesita **dos**: `PAGARE_FIRMADO_CLIENTE` y `CONTRATO_MANDATO_FIRMADO_CLIENTE`. | Matriz, columnas **X** e **Y**. | La guía usa estos nombres en 3 lugares (bloque "a la Vista", Plantilla C y SEGUNDO OTROSÍ). | (Resuelto con el cliente) | **Respuesta cliente + HECHO en clean03:** (1) `CONTRATO_FIRMADO_CLIENTE` se **renombró** a `CONTRATO_MANDATO_FIRMADO_CLIENTE`; (2) se **agregó** `PAGARE_FIRMADO_CLIENTE`; (3) ambas las llena el **humano** (pintadas cyan) y traen **lista desplegable SI/NO**. Implementado en `clean03/engine/matriz.py` (COLUMNS + FILL_LATER + dropdown data-validation). Esquema clean03 ahora 31 cols (A..AE): …REGION_DEUDOR, **PAGARE_FIRMADO_CLIENTE**, **CONTRATO_MANDATO_FIRMADO_CLIENTE**, HOJA_DE_FIRMA… |
| 2 | **✅ RESUELTO — regla "salvo la última" (3 casos)** | La cláusula "salvo la última" tiene **3 posibilidades**, según 2 columnas. `MONTO_ULTIMA_CUOTA` vacío es ambiguo → la columna `PAGARE_ULTIMA_CUOTA_INFERIOR` lo desambigua. | «por $X»: RUT **7.609.381-4**. «inferior»: **6.307.213-3**, **15.061.748-0**. | Guía: la cláusula es un **add-on condicional** (bloques de `MONTO_ULTIMA_CUOTA` y de `PAGARE_ULTIMA_CUOTA_INFERIOR`); si ninguno aplica, el párrafo base termina sin agregar nada. | (Resuelto) | **REGLA (matriz clean03, columna llena):** (1) `MONTO_ULTIMA_CUOTA` con número → «, salvo la última por $ X.-»; (2) vacío + `PAGARE_ULTIMA_CUOTA_INFERIOR`=SI → «, salvo la última que será inferior.»; (3) vacío + `PAGARE_ULTIMA_CUOTA_INFERIOR`=NO → **no se agrega nada** (cuotas iguales). **La columna NO es redundante**: distingue (2) de (3). *(En matrices viejas la columna venía en blanco y los 4 casos vacíos eran "inferior"; con clean03 se usa la columna.)* |
| 3 | **✅ RESUELTO — MP "en cuotas" vs "a la Vista" (vía `CARTERA_A_PROCESAR`)** | La CARTERA original no bastaba: había MP que en realidad van "a la Vista". | RUT 11.834.864-8, 8.331.613-6: MP sin datos de cuotas → se redactaban "a la Vista". | La guía asumía CARTERA=MP → siempre "en cuotas". | (Resuelto con el cliente + implementado en clean03) | **Respuesta cliente + HECHO en clean03:** nueva columna **`CARTERA_A_PROCESAR`** (a la derecha de `CARTERA_ORIGINAL`). Es copia de la cartera, salvo que un **MP sin datos de cuotas** (TASA, NUM_CUOTAS, MONTO_CUOTA, MONTO_ULTIMA_CUOTA vacíos) pasa a **`VI`**. **clean04 elige la plantilla según `CARTERA_A_PROCESAR`, NO `CARTERA_ORIGINAL`.** Implementado en `pipeline._cartera_a_procesar` (un MP con extracción fallida = NO_ENCONTRADO NO se degrada a VI: queda MP y marcado). Elimina la dependencia de la nota manual "MP TIPO TC". |
| 4 | **✅ RESUELTO — Cuándo usar la plantilla "plazo fijo / firmado por el cliente"** | El disparador **NO es la fecha**: es la columna **`PAGARE_FIRMADO_CLIENTE`** (nueva, la llena el humano). En los datos históricos estaba vacía (la columna no existía aún) → por eso solo la fecha marcaba el único caso C. La guía siempre dijo que el disparador es esa columna. | RUT **8.711.083-4** (único C del lote, `FECHA_VCTO_PAGARE`=21-01-2026). El cliente confirmará que es `PAGARE_FIRMADO_CLIENTE`=SI (trivial). | Bloque guía: *"CARTERA / PAGARE_FIRMADO_CLIENTE / LP o LN o TC o VI / SI → …suscrito por el demandado… el día «FECHA_VCTO_PAGARE»."* (dispara por la columna, no por la fecha). | **RESPUESTA CLIENTE:** (1) el humano **llenará `PAGARE_FIRMADO_CLIENTE` y `CONTRATO_MANDATO_FIRMADO_CLIENTE`** en las matrices nuevas → el bot **confía en esas columnas** (sin fallback por fecha). (2) **Son independientes de la fecha:** un pagaré `PAGARE_FIRMADO_CLIENTE`=SI **puede NO** tener `FECHA_VCTO_PAGARE`. **REGLA DEL BOT:** `PAGARE_FIRMADO_CLIENTE`=SI → **Plantilla C**; `CONTRATO_MANDATO_FIRMADO_CLIENTE`=SI (o por defecto) → **B**. `FECHA_VCTO_PAGARE` = **campo REQUERIDO de C** (imprime «el día X») → si SI **sin** fecha → **REVISAR**. Pendiente solo confirmar 8.711.083-4=SI. |
| 5 | **✅ CONFIRMADO — Se omitían pagarés LP (eran errores)** | Cuando un RUT tenía un **MP "en cuotas" + un LP** (o MP+TC+LP), el **LP no se incluía**: faltaba el párrafo **y su monto quedaba fuera del total**. Sistemático, siempre el LP. | **Training:** 12.144.230-2 (LP 2223 34264). **Lote `REVISION_URGENTE`:** 12.144.230-2 · **12.436.386-1** (LP 2003 38103, ~$8.000.000) · **15.792.099-5** (LP 2157 23902) · **16.572.373-2** (LP 2222 97187) · **17.838.429-5** (LP 2203 17905). | La guía dice *"…repetir por cada pagaré…"*; la hoja `2_MP-1_LP-1` ya traía el LP → error del macro. | (Enviado y confirmado con el cliente) | **CONFIRMADO: eran errores.** El cliente los está revisando/corrigiendo. **Regla del bot:** incluir SIEMPRE todas las filas del RUT (todos los pagarés) y sumar todos los montos al total (ver "Principios de diseño"). |
| 6 | **✅ RESUELTO — Documento "Repertorio N° 9342" en el SEGUNDO OTROSÍ** | La guía (`Formato_macro`) es la **fuente de verdad**; las discrepancias en los PDF (p.ej. aparece con HOJA=NO en 8.331.613-6) son de un **formato viejo**. | Guía línea 148. Los PDF viejos no marcan la regla. | Bloque SEGUNDO OTROSÍ (guía): *"Si HOJA_DE_FIRMA / CONTRATO_MANDATO_FIRMADO_CLIENTE / SI / SI → Copia de la escritura pública… Repertorio N° 9342…"*. | **RESUELTO (cliente):** seguir la **guía**: incluir el doc 9342 **solo si `HOJA_DE_FIRMA`=SI Y `CONTRATO_MANDATO_FIRMADO_CLIENTE`=SI**. Lo que muestran los PDF viejos (con HOJA=NO) es formato antiguo → se ignora. |
| 7 | **✅ RESUELTO — Línea del NOTARIO cuando NO hay hoja de firma** | Igual que #6: manda la **guía**; las viñetas vacías de los PDF viejos son del formato antiguo. | Guía líneas 150-154. PDF viejos: 8.331.613-6 dejó viñeta vacía (formato viejo). | Bloque SEGUNDO OTROSÍ (guía): *"HOJA_DE_FIRMA / SI → «NOTARIO» / Hoja de firma suscrita por del demandado."* (condicional puro: solo dice qué hacer con SI). | **RESUELTO (cliente):** agregar la línea `«NOTARIO»` **solo si `HOJA_DE_FIRMA`=SI**. Si NO → **omitir la línea por completo** (sin viñeta vacía). Las viñetas vacías de los PDF viejos son formato antiguo. |
| 8 | **✅ RESUELTO — El monto total del "RUEGO A US."** | El total es la **suma de `MONTO_ADEUDADO`** de TODOS los pagarés del RUT. | **Verificado con el script:** en 58/63 demandas el total del PDF = Σ `MONTO_ADEUDADO`. Los **4 que no cuadran** son justo los RUT con **LP omitido (#5)** (12.144.230-2, 15.792.099-5, 16.572.373-2, 17.838.429-5): el PDF quedó corto por el monto del LP. | RUEGO A US. (guía línea 132): *"…por la suma de $ «MONTO_ADEUDADO».-"* (suma de la columna). | **RESUELTO (cliente + datos):** total = **Σ `MONTO_ADEUDADO`** de todas las filas del RUT. El **bot lo calcula siempre** (nunca en blanco). *(Corrige la nota vieja "Vista/Plazo → PAGARE": es `MONTO_ADEUDADO` para todos; en carteras a la Vista ADEUDADO=PAGARE, por eso coincidía.)* |
| 9 | **✅ RESUELTO — Párrafo de "tasa mensual"** | Aparece en demandas MP viejas pero la guía no lo menciona. | RUT 6.307.213-3, 7.609.381-4, 12.144.230-2, 15.061.748-0 → aparece: "**A contar de la fecha de suscripción… tasa del X% mensual.**" | **❌ No está en la guía** (coherente con que ya no va). | (Resuelto con el cliente) | **RESUELTO:** el cliente confirma que este párrafo **YA NO VA**. Algunos ejemplos viejos lo tienen, pero el bot debe **OMITIRLO**. (Quitado del flujo de Plantilla A.) |
| 10 | **✅ RESUELTO — usar siempre "Contrato Mandato"** | La guía dice "Contrato Mandato"; los PDF viejos dicen "Contrato de Productos y Servicios Bancarios". | RUT 11.834.864-8, 8.331.613-6, 15.156.152-7 → PDF con el término viejo. | Bloque "a la Vista": *"…en el **Contrato Mandato**…"* (guía). | (Resuelto con el cliente) | **RESUELTO:** usar SIEMPRE **"Contrato Mandato"** (reemplaza al viejo "Contrato de Productos y Servicios Bancarios" de los PDF). ⚠️ **Ojo:** el bloque `HOJA_DE_FIRMA`=SI de **Plantilla A** en la guía TAMBIÉN dice "Contrato de Productos y Servicios Bancarios" → por el reemplazo global, ahí también va **"Contrato Mandato"**. (Confirmar con cliente que aplica también a ese párrafo.) |
| 11 | **✅ RESUELTO — texto único "el (los) siguiente (s) pagaré(s)"** | El texto variaba (errores humanos). | RUT 11.834.864-8 (4 pagarés) decía "el siguiente pagaré"; 6.307.213-3 (1 pagaré) "el (los) siguiente (s) pagaré(s)". | Intro guía: *"…constan en el (los) siguiente (s) pagaré(s)"*. | (Resuelto con el cliente) | **RESUELTO:** el bot **NO ajusta singular/plural**. Se usa SIEMPRE el texto oficial literal **"el (los) siguiente (s) pagaré(s)"** (con los paréntesis). Sin lógica de conteo. |
| 12 | **✅ RESUELTO — Código en el encabezado de cada página** | Cada página traía un código arriba (`4_VI-0`, `1-LP-3`…) = nombre de la hoja de staging del `.xlsm`. No es un conteo confiable. | RUT 11.834.864-8 → "4_VI-0"; 8.711.083-4 → "1-LP-3". Descuadre: 16.939.048-7 y 8.331.613-6 dicen "4_VI-0" con solo 2 pagarés. | **❌ No está en la guía** (plomería interna del macro). | **RESUELTO (cliente):** **quitar el código** — ya no se usa. El bot **NO** lo emite en el encabezado del PDF. |
| 13 | **✅ RESUELTO — RUT sin demanda / demanda sin fila en la matriz** | Descuadre de completitud: **14.026.491-1** en la matriz sin PDF; **22.778.939-5** con PDF pero no en `Asignacion_Final`. | Lote `REVISION_URGENTE`. | (control de completitud — no está en la guía) | **RESUELTO (cliente):** no fue un error de lógica — el cliente simplemente **no alcanzó a enviar/mandar** esos casos. Aun así el bot debe **cuadrar matriz↔demandas** y avisar (1 demanda por cada RUT, sin faltantes ni sobrantes) para pescar este tipo de descuadre a tiempo. |
| 14 | **✅ RESUELTO (implementado en clean03) — `RE` (renegociación)** | Un `RE` puede ir a Plantilla A (si tiene cuotas) o "a la Vista" (si no) — el bot **no lo decide solo**; lo decide el humano. | 11 `RE` con cuotas → salieron A; 1 `RE` sin cuotas → salió "a la Vista" (lote `REVISION_URGENTE`). | La guía no distingue MP de RE al elegir plantilla (❌ no cubre RE). | **RESUELTO (cliente + hecho en clean03):** el `RE` llega como `RE` en `CARTERA_ORIGINAL`. En `CARTERA_A_PROCESAR` clean03 lo **copia tal cual y lo pinta MORADO** (aviso visual) — **NO** lo auto-convierte. **El humano cambia esa celda a `MP` o `VI`** a mano; clean04 elige la plantilla con `CARTERA_A_PROCESAR`. Si al generar la celda **sigue en `RE`** → **REVISAR**. Implementado en `clean03/engine/matriz.py` (`PURPLE`/`_FILL_PURPLE` + comentario + hoja de leyenda). |

---

## Datos que YA confirmamos en el código (no hace falta preguntar)

- 🎯 **Regla de selección de plantilla** (dos pasos):
  ```
  Paso 1 (A vs resto) — el bot lee la columna CARTERA_A_PROCESAR (la fija clean03):
    CARTERA_A_PROCESAR = MP   → Plantilla A (en cuotas)
    (clean03: MP con cuotas→MP · MP sin cuotas→VI · RE→MORADO, el humano lo pasa a MP/VI · si queda RE→REVISAR)

  Paso 2 (B vs C) — por columnas firmado (confirmado con cliente, #4):
    si PAGARE_FIRMADO_CLIENTE = SI            → Plantilla C (plazo fijo)   · requiere FECHA_VCTO_PAGARE, si falta → REVISAR
    si no (CONTRATO_MANDATO_FIRMADO_CLIENTE=SI o por defecto) → Plantilla B (a la Vista)
  ```
  **Paso 1** equivale a "¿tiene datos de cuota?" (validado 75/75 en el lote: 56 A = 45 MP + 11 RE · 18 B · 1 C), porque clean03 pone `VI` al MP sin cuotas y **deja el `RE` en morado para que el humano lo resuelva** (#14). **Paso 2** usa las columnas nuevas que el humano llenará en las matrices nuevas (antes vacías, por eso no salían en los datos). El cliente confirmó que `PAGARE_FIRMADO_CLIENTE` y `FECHA_VCTO_PAGARE` son **independientes** (SI puede venir sin fecha → REVISAR). Ver #4.
- 🔑 **`CARTERA_A_PROCESAR` (col. de clean03) = el selector de plantilla de clean04.** clean03 la fija: copia de la cartera, salvo **MP sin cuotas → `VI`** (auto) y **`RE` → se copia como `RE` en MORADO** (aviso; el humano lo cambia a `MP`/`VI` — no se auto-degrada, #14). Resuelve #3.
- `PAGARE_ULTIMA_CUOTA_INFERIOR` **la llena clean03** con "SI"/"NO" (blanco solo si falta el pagaré). Es columna del bot. → El punto #2 es solo confirmar que la muestra quedó vieja.
- `PAGARE_FIRMADO_CLIENTE` y `CONTRATO_MANDATO_FIRMADO_CLIENTE` **ahora las crea clean03** (cambio hecho tras respuesta del cliente, punto #1): humanas, cyan, con lista SI/NO. La antigua `CONTRATO_FIRMADO_CLIENTE` ya no existe (renombrada).
- Regla de "salvo la última" (Plantilla A, MP en cuotas) — **3 casos:** (1) `MONTO_ULTIMA_CUOTA` con número → "salvo la última por $X"; (2) vacío + `PAGARE_ULTIMA_CUOTA_INFERIOR`=SI → "salvo la última que será inferior"; (3) vacío + `=NO` → no se agrega nada (cuotas iguales). La columna `PAGARE_ULTIMA_CUOTA_INFERIOR` **es necesaria** para distinguir (2) de (3) — por eso NO es redundante. (En matrices viejas venía en blanco y los casos vacíos eran todos "inferior", pero con clean03 hay que usar la columna.)
- Párrafos de Plantilla A (base, salvo la última, vencimiento, cuota impaga) con su obligatoriedad OBLIGATORIO/NO OBLIGATORIO → ver sección **"Reglas de párrafos — Plantilla A"** más abajo (confirmado con cliente + 46/46).

---

## Reglas de párrafos — Plantilla A (MP en cuotas)

Confirmado con el cliente (marcas **OBLIGATORIO / NO OBLIGATORIO** en el `Formato_macro`) + verificado en datos (46/46 MP en cuotas).
**OBLIGATORIO** = si el campo falta → **REVISAR** (no emitir). **NO OBLIGATORIO** = si falta, se omite en silencio (sin flag).

Orden de párrafos:

1. **Párrafo base** — *obligatorio* (campos `TASA_INTERES`, `NUM_CUOTAS`, `MONTO_CUOTA`): "Pagaré Nº «OPERACIÓN»… interés mensual «TASA_INTERES»%… mediante «NUM_CUOTAS» cuotas… cada una por $ «MONTO_CUOTA».-"
   - **+ "salvo la última"** (3 casos, ver regla #2 arriba).
2. **OBLIGATORIO 1 — Vencimiento** (campos `DIA_DEL_MES_VCTO_CUOTA` **+** `FECHA_VCTO_1RA_CUOTA`, ambos obligatorios · 46/46): "Las cuotas tienen vencimiento los días «DIA_DEL_MES_VCTO_CUOTA» de cada mes, venciendo la primera el «FECHA_VCTO_1RA_CUOTA»" — ⚠️ **esta frase NO lleva punto final por sí sola**; el punto lo cierra el paso 3.
3. **NO OBLIGATORIO — última cuota** (campo `FECHA_VCTO_ULTIMA_CUOTA` · 41/46) → **cierre del punto 2**:
   - si `FECHA_VCTO_ULTIMA_CUOTA` **presente** → agregar " y la última el «FECHA_VCTO_ULTIMA_CUOTA»**.**" (el punto viene aquí).
   - si **vacío** → cerrar el punto 2 directamente con "**.**".
   - **No marca REVISAR si falta** (es no obligatorio).
4. **OBLIGATORIO 2 — Cuota impaga** (campos `NRO_1RA_CUOTA_IMP` **+** `FECHA_1RA_CUOTA_IMP` **+** `MONTO_ADEUDADO`, todos obligatorios · 46/46): "Llegada la fecha de vencimiento de la cuota Nº «NRO_1RA_CUOTA_IMP» del día «FECHA_1RA_CUOTA_IMP», esta no fue pagada, ni tampoco las posteriores, adeudando el demandado un capital insoluto de $ «MONTO_ADEUDADO».- más todos los intereses…"
5. **El párrafo "tasa mensual" NO va** — el cliente confirmó que ya no se incluye, aunque aparezca en ejemplos viejos (ver #9). *(Luego sigue el bloque `HOJA_DE_FIRMA`=SI — pendiente de mapear.)*

**Lista de campos OBLIGATORIOS de Plantilla A** (alimenta la validación de los Principios de diseño → si falta alguno en un MP en cuotas = REVISAR): `TASA_INTERES`, `NUM_CUOTAS`, `MONTO_CUOTA`, `DIA_DEL_MES_VCTO_CUOTA`, `FECHA_VCTO_1RA_CUOTA`, `NRO_1RA_CUOTA_IMP`, `FECHA_1RA_CUOTA_IMP`, `MONTO_ADEUDADO`.
**No obligatorio** (nunca genera REVISAR): `FECHA_VCTO_ULTIMA_CUOTA`, `MONTO_ULTIMA_CUOTA`/`PAGARE_ULTIMA_CUOTA_INFERIOR` (rigen la cláusula "salvo la última").

---

## Principios de diseño del bot (validación — antídoto a #5, #8, #13)

**Regla de oro: el bot NUNCA emite una demanda incompleta ni omite datos en silencio.** El desastre del #5 (LP omitidos) pasó justamente porque el macro descartó datos sin avisar. El bot nuevo debe ser "ruidoso": si algo no cuadra, lo marca y **NO** lo da por listo.

**Validaciones por RUT (antes de dar la demanda por "lista"):**
1. **Completitud de pagarés:** incluir TODAS las filas del RUT (1 párrafo por pagaré). Si N° de párrafos ≠ N° de filas → REVISAR. *(evita #5)*
2. **Campos requeridos por plantilla:** cada fila trae los campos que su plantilla necesita (ej. MP en cuotas: `FECHA_VCTO_1RA_CUOTA`, `DIA_DEL_MES_VCTO_CUOTA`, `MONTO_CUOTA`, `NUM_CUOTAS`, `TASA_INTERES`). Si falta alguno → REVISAR + indicar cuál. *(evita párrafos rotos)*
3. **Total:** el monto del RUEGO se calcula y nunca queda en blanco. *(evita #8)*
4. **Cuadre matriz↔demandas:** todo RUT de la matriz tiene demanda y toda demanda corresponde a un RUT. *(evita #13)*

**Salida: el estado va DENTRO de la misma matriz (no un Excel aparte).** Decisión del cliente — clean04 agrega una **columna inicial `ESTADO`** (col A) a la matriz de entrada y la guarda **en el mismo archivo**:

- **OK** (verde) — la demanda de ese RUT se generó (el PDF existe). Se marcan **todas** las filas del RUT.
- **REVISAR** (amarillo) — faltó algún dato requerido → **no** se generó el PDF. Se marcan todas las filas del RUT y se **pintan de amarillo las celdas puntuales que faltaban** (con comentario) para ubicarlas rápido.
- **ERROR** (rojo) — no se pudo generar (p. ej. `CARTERA_A_PROCESAR` sigue en `RE`, o error al escribir el PDF).

`ESTADO` es por fila pero **uniforme dentro de cada RUT** (1 PDF = 1 RUT = varias filas). **Reanudable / idempotente:** al re-correr, un RUT se **omite solo si todas sus filas dicen OK** (su PDF ya existe); si alguna no está OK, se reprocesa todo el RUT. Corre igual con una matriz limpia (sin `ESTADO`) o con una ya anotada — lo primero que hace es crear la columna `ESTADO` si no existe. Así el flujo es: correr → se marcan OK/REVISAR → el humano arregla las celdas amarillas → **re-correr el mismo archivo** → solo se reprocesan los REVISAR. Reutiliza el patrón de colores de clean03 (`engine/matriz.py`).

**Flujo cuando un RUT queda incompleto:** el bot lo marca REVISAR y **sigue con el resto** (nunca se detiene por un RUT malo). Es el control de calidad antes de firmar: se firma solo lo OK; lo REVISAR se corrige a mano y se re-corre.

---

## Prioridad

1. **✅ Resueltos:** #1 (columnas), #2 ("salvo la última"), #3 (MP→VI), **#4 (disparador de C = `PAGARE_FIRMADO_CLIENTE`=SI, cliente confirmó)**, #5 (LP omitidos = errores, cliente avisado), **#6 (doc 9342 = guía: HOJA=SI Y MANDATO=SI)**, **#7 (línea NOTARIO solo si HOJA=SI, si no se omite)**, **#8 (total = Σ MONTO_ADEUDADO, verificado 58/63)**, #9 (tasa mensual no va), #10 (usar "Contrato Mandato"), #11 (texto único "el (los) siguiente (s) pagaré(s)"), **#12 (quitar el código del encabezado)**, **#13 (RUT descuadrados = el cliente no los mandó)**, **#14 (RE → clean03 lo pinta morado; el humano lo pasa a MP/VI)**. #1, #3 y #14 ya implementados en clean03.
2. **Selección de plantilla (cerrada):** Paso 1 **A vs resto** = `CARTERA_A_PROCESAR`=MP (la fija clean03; `RE`→morado→el humano lo pasa a MP/VI); Paso 2 **B vs C** = columnas firmado (`PAGARE_FIRMADO_CLIENTE`=SI → C, requiere `FECHA_VCTO_PAGARE` o REVISAR; si no → B). Por diseño el bot **incluye todas las filas de cada RUT** (evita #5) y **cuadra matriz↔demandas** (evita #13). Único pendiente trivial: confirmar 8.711.083-4=SI.
3. **✅ Todas las preguntas de la tabla (#1–#14) están resueltas.** Solo queda mapear detalles de redacción (ítem 5), que **no bloquean** el build.
4. **Mapeado esta iteración:** flujos de **Plantilla B y C** reconstruidos del `Formato_macro` + PDF firmados (B verificado en el caso de 4 pagarés; C con caveat de 1 ejemplo) — ahora dentro del diagrama único [`arbol_decision.svg`](arbol_decision.svg).
5. **Aún por mapear (sin bloquear):** bloque `HOJA_DE_FIRMA` de Plantilla A (párrafo mandato+mora); si en C los párrafos mora/constancia se repiten por pagaré. *(El SEGUNDO OTROSÍ ya quedó mapeado: 4 docs fijos + doc 9342 (#6) + línea NOTARIO (#7) + Contrato Mandato (#1); la guía es la fuente de verdad.)*

---

## Método de verificación (para repetir en cada lote nuevo)

Ya automatizado en [`tools/cruce_matriz_demandas.py`](tools/cruce_matriz_demandas.py) (correr con `.venv/bin/python`). Cruza la hoja `Asignacion_Final` ↔ PDF firmados y, por cada pagaré:
- Detecta la **plantilla** usada (A/B/C) por las frases firma del párrafo y la **valida** contra la regla "¿datos de cuota?" (hoy 75/75).
- Compara las OPERACIÓN de la matriz vs los N° de pagaré del PDF → **pagarés omitidos** (#5) y bloques de más.
- Compara el set de RUT matriz vs PDF → **RUT sin demanda / demanda sin matriz** (#13).
- Revisa **total en blanco** en el "RUEGO A US." (#8) y **códigos de encabezado** que no cuadran (#12).

Correrlo como control de calidad **antes de firmar cada lote nuevo** (ajustar las dos rutas al inicio del script).
