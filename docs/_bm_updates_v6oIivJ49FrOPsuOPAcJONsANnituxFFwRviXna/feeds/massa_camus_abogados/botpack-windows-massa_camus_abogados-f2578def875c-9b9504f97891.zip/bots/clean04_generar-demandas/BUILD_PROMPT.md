# clean04 (generar-demandas) — BUILD PROMPT

Paste-and-go prompt for a fresh context window. Build the **clean04** bot that turns a
clean03-style matriz into legal *demanda* PDFs.

---

## 0. Read these first (in order — do NOT skip)

1. **`/Users/nicoesgeb/Documents/PersonalPorjects/Vault_brain/proyectos/botmanager.md`** — the vault note (mandatory per CLAUDE.md; architecture, conventions, key decisions).
2. Run **`/new-bot`** — the full bot-creation guide (botmanager.json, thin `tasks.py`, `functions.py`, QML info+tasks panels, runner env-var wiring, discovery rules).
3. **`bots/clean04_generar-demandas/AMBIGUEDADES.md`** + **`arbol_decision.svg`** — the COMPLETE spec. All 14 ambiguities are resolved. `arbol_decision.svg` is the single source of truth for template selection, each paragraph's fields, the shared closing, RUEGO total, and the SEGUNDO OTROSÍ documents. Open the SVG in a browser.
4. **`bots/clean04_generar-demandas/training/`** — `Formato_macro_2026-06-24_v02.docx` (the EXACT paragraph text / mergefields), `matriz_usada/Matriz_asignacion.xlsx` (input shape), `demandas_generadas/` (8 golden PDFs, one per RUT — validate against these).
5. **`bots/clean03_extraer-datos-pagares/`** — the reference **offline-bot** structure, and especially `engine/matriz.py` for the openpyxl styling pattern (colors, headers, comments, dropdowns) that clean04 will reuse to annotate the matriz.

Do not re-derive the spec — it's done. Follow `arbol_decision.svg` + `AMBIGUEDADES.md`.

---

## 1. What clean04 is

An **offline** bot (no portal, no WAF — like clean02/clean03). It reads ONE matriz
(`.xlsx`, the clean03 output, one row per pagaré), and:

- **Generates 1 demanda PDF per RUT** (a RUT with 4 pagarés = 4 rows = 1 PDF with 4 pagaré paragraphs).
- **Annotates the input matriz in place** with a resumable `ESTADO` column (see §4).

`process_code: CLEAN_BBRR`. Wiring (payload → runner env vars, matriz picker) mirrors
clean03 — no `Main.qml`/importer changes.

---

## 2. Input

- The matriz `.xlsx`. **Selectable** in the tasks panel exactly like clean03 (dialog opens
  at `input/matriz/`; fall back to the first `.xlsx` there). Path via env var, clean03-style.
- The matriz carries the clean03 columns. **Map every field by HEADER NAME, never by fixed
  column letter** (clean03 does this too). Relevant columns: `RUT, DV, NOMBRE, OPERACIÓN,
  CARTERA_ORIGINAL, CARTERA_A_PROCESAR, MONTO_PAGARE, MONTO_ADEUDADO, TASA_INTERES,
  NUM_CUOTAS, MONTO_CUOTA, MONTO_ULTIMA_CUOTA, PAGARE_ULTIMA_CUOTA_INFERIOR,
  FECHA_VCTO_1RA_CUOTA, DIA_DEL_MES_VCTO_CUOTA, FECHA_VCTO_ULTIMA_CUOTA,
  FECHA_SUSCRIPCION_PAGARE, FECHA_VCTO_PAGARE, NRO_1RA_CUOTA_IMP, FECHA_1RA_CUOTA_IMP,
  DOMICILIO_DEUDOR, COMUNA_DEUDOR, REGION_DEUDOR, PAGARE_FIRMADO_CLIENTE,
  CONTRATO_MANDATO_FIRMADO_CLIENTE, HOJA_DE_FIRMA, NOTARIO, …`. Tolerate extra/missing
  trailing columns (the clean04 matriz may lack `NOTA/COD_FORM_DDA`).

---

## 3. Outputs

1. **PDF demandas** — 1 per RUT, ONLY for RUTs that fully validate. Filename matches the
   training convention: `{RUT}-{DV}_DEMANDA.pdf` (e.g. `6.307.213-3_DEMANDA.pdf`). Write to
   a timestamped run dir under `output/`.
2. **The SAME input matriz, modified in place** — new first `ESTADO` column + yellow
   highlights on missing cells (see §4). Preserve clean03's existing formatting.

---

## 4. The `ESTADO` column — resumable / idempotent (CORE REQUIREMENT)

`ESTADO` is the **first column (A)**. It makes the bot re-runnable on its own output.

**On every run:**

1. If the matriz has **no `ESTADO` column**, insert it at column A (shift all data right by
   one). If it already exists, reuse it.
2. Read all rows; **group by RUT** (RUT+DV = one demanda = one PDF).
3. For each RUT group:
   - **Skip if done:** if *every* row in the group already says `ESTADO == "OK"`, skip it —
     the PDF already exists, don't regenerate. *(This is the resume behavior.)*
   - **Otherwise (re)process the whole RUT:**
     - Pick each row's template from `CARTERA_A_PROCESAR` + the firmado columns (per
       `arbol_decision.svg`) and check its **required fields** (§5). A field is *missing* if
       empty or `== "NO_ENCONTRADO"`. If `CARTERA_A_PROCESAR` is still `"RE"`, the row is
       invalid (human must set MP/VI).
     - **All rows complete →** generate the RUT's PDF, then (only after it's written) set
       `ESTADO = "OK"` (green) on all its rows and **clear** any previous yellow highlights.
     - **Anything missing →** do NOT generate the PDF. Set `ESTADO = "REVISAR"` (yellow) on
       all rows of that RUT and paint the **specific missing cells yellow** (add a short
       cell comment naming what's missing). 
     - **Hard failure** (PDF write error, unresolved `RE`, etc.) → `ESTADO = "ERROR"` (red).
4. Save the matriz **in place**.

**Result:** process 18/20 RUTs → 18 RUTs' rows = OK (+ 18 PDFs), 2 RUTs = REVISAR with the
missing cells highlighted (no PDF). The user fixes the yellow cells and **re-runs the same
file**; only the 2 REVISAR RUTs are reprocessed; once complete → OK + PDF. A clean matriz
(no `ESTADO`) and an already-annotated one both work.

**Invariant:** `OK` ⇔ the PDF for that RUT was successfully written. Never mark OK otherwise.

---

## 5. Template selection + required fields (from `arbol_decision.svg` / `AMBIGUEDADES.md`)

**Selection (per row):**
- `CARTERA_A_PROCESAR == MP` → **Plantilla A** (en cuotas).
- else → **Plantilla C** if `PAGARE_FIRMADO_CLIENTE == SI` (needs `FECHA_VCTO_PAGARE`, else REVISAR); otherwise **Plantilla B** (a la Vista).
- `CARTERA_A_PROCESAR == RE` → REVISAR (not resolved by the human yet).

**Required fields (REVISAR if missing):**
- **Common:** `RUT, DV, NOMBRE, OPERACIÓN, DOMICILIO_DEUDOR, COMUNA_DEUDOR, REGION_DEUDOR, FECHA_SUSCRIPCION_PAGARE`.
- **A:** `TASA_INTERES, NUM_CUOTAS, MONTO_CUOTA, DIA_DEL_MES_VCTO_CUOTA, FECHA_VCTO_1RA_CUOTA, NRO_1RA_CUOTA_IMP, FECHA_1RA_CUOTA_IMP, MONTO_ADEUDADO`. *(Not required: `FECHA_VCTO_ULTIMA_CUOTA`, `MONTO_ULTIMA_CUOTA`/`PAGARE_ULTIMA_CUOTA_INFERIOR` — they only shape the "salvo la última" clause.)*
- **B:** `MONTO_PAGARE, MONTO_ADEUDADO`.
- **C:** `MONTO_PAGARE, FECHA_VCTO_PAGARE`.

**Paragraph assembly** is fully specified in `arbol_decision.svg` (the three columns) —
base, "salvo la última" (3 cases via `MONTO_ULTIMA_CUOTA`/`PAGARE_ULTIMA_CUOTA_INFERIOR`),
vencimiento, cuota impaga, the mandato / mora / constancia paragraphs, etc. Take the exact
wording from `Formato_macro_2026-06-24_v02.docx` (mergefields shown as «FIELD»). Use
"Contrato Mandato" (not the old term). Omit the "tasa mensual" paragraph. Use the literal
"el (los) siguiente (s) pagaré(s)". No page-header code.

**Per demanda (once, after all pagarés):** shared closing (aceleración clause only if the
RUT has any A/MP-cuotas pagaré), **RUEGO total = Σ `MONTO_ADEUDADO` of all the RUT's rows**
(never blank), and the **SEGUNDO OTROSÍ** documents: 4 fixed docs always; doc "Repertorio
9342" iff `HOJA_DE_FIRMA=SI AND CONTRATO_MANDATO_FIRMADO_CLIENTE=SI`; the `«NOTARIO»` line
iff `HOJA_DE_FIRMA=SI` (else omit the line); "Contrato Mandato suscrito…" iff
`CONTRATO_MANDATO_FIRMADO_CLIENTE=SI`.

---

## 6. PDF generation — decide this first

The golden PDFs are Word/mail-merge shaped (bold labels, justified paragraphs, a header
block, digital-signature footer). Two viable routes — prototype ONE Plantilla-A PDF and
diff it against its golden before committing:

- **python-docx template → PDF** (recommended for fidelity): build a `.docx` template that
  mirrors `Formato_macro`, fill the paragraphs, convert to PDF (LibreOffice headless
  `soffice --headless --convert-to pdf`, or `docx2pdf`/Word on Windows). Closest to the
  originals; needs an office engine present.
- **reportlab / fpdf2** (self-contained, no office dependency): full control, but you
  re-create all formatting by hand.

Pick based on what's reliably available on the client's Windows machine (the bot must run
there). Add the chosen lib to `requirements.txt` + `BotManager_Initializer.bat`'s import check.

---

## 7. Bot scaffolding (per `/new-bot`)

```
bots/clean04_generar-demandas/
  botmanager.json      # bot_id: clean04_generar_demandas · process_code: CLEAN_BBRR · display_name
  tasks.py             # THIN: one @task, sys.path.insert, calls functions.py
  functions.py         # orchestration (read matriz → group by RUT → validate → render → annotate)
  engine/              # demanda_builder.py (paragraph assembly per template), estado.py
                       # (ESTADO column read/annotate via openpyxl — reuse clean03 matriz.py patterns)
  robot.yaml           # copy from _skeleton / rpa06_new
  input/matriz/        # .gitkeep (client data gitignored)
  output/              # .gitkeep
```

Plus QML: `app/desktop/qml/workspace_info/clean04_generar-demandas_information_bot_UI.qml`
and `…workspace_tasks/clean04_generar-demandas_tasks_bot_UI.qml` (matriz picker + "Abrir
carpeta"; add the "Clean BBRR" badge). Reference `rpa06_new_*` / clean03's panels. No
plugin yet (Detalle-run panel stays empty until a Clean04Plugin is built later).

---

## 8. Build order (incremental — validate as you go)

1. Scaffold the bot so it's discovered; matriz picker works end-to-end (reads a matriz, prints row count).
2. `ESTADO` column logic (§4) — insert/reuse, group by RUT, skip-if-OK, write OK/REVISAR/ERROR + yellow highlights. Test the resume behavior on a copy of the training matriz.
3. **Plantilla A** paragraph assembly → render one PDF → **diff against the golden** `demandas_generadas/` (e.g. 6.307.213-3, 7.609.381-4). Iterate until it matches.
4. Add **Plantilla B** (11.834.864-8 is a 4-pagaré B) and **C** (8.711.083-4), then the shared closing + RUEGO + SEGUNDO OTROSÍ.
5. Full run over the training matriz → compare the set of PDFs against the 8 goldens; confirm ESTADO/highlights are correct for any incomplete RUT.

---

## 9. Non-blocking open details (flag as REVISAR if unsure — don't block on them)

- The exact wording of Plantilla A's `HOJA_DE_FIRMA=SI` paragraph block (mandato+mora) — read it straight from `Formato_macro`.
- Whether Plantilla C's mora/constancia paragraphs repeat per pagaré (only 1 C example exists).
- Trivial: confirm RUT 8.711.083-4 is `PAGARE_FIRMADO_CLIENTE=SI` (the one Template-C row).

**Design law (never break it):** never emit an incomplete or wrong demanda silently. If
anything required is missing or ambiguous → REVISAR + highlight, no PDF. Always reconcile
matriz↔demandas (a RUT with no PDF, or a PDF with no rows, must be visible in ESTADO).
